"""
Trade Components eBay Listing Tool

V4.23.4 updater compatibility:
- Core imports, photo tooling, AI helpers, and eBay API client live in trade_components_core.py.
- This file focuses on the ListingTool GUI/controller and program entry point.
"""

from trade_components_core import *

# Backward compatibility: older installed updaters verify releases by scanning
# ebay_listing_tool.py itself for a literal APP_VERSION assignment.
APP_VERSION = "4.23.23"


class ListingTool(tk.Tk):
    def __init__(self):
        self._set_windows_app_identity()
        super().__init__()
        self.title(APP_NAME)
        self._set_window_icon()
        self.geometry("1180x900")
        self.minsize(1040, 760)

        self.settings = load_settings()
        self.photos = []
        self.cancel_event = threading.Event()
        self.worker = None
        self.session_ai_cost = 0.0
        self.session_ai_analyses = 0
        self.last_category_name = ""
        self.existing_image_urls = []
        self.editing_offer_id = ""
        self.editing_offer_status = ""
        self.original_offer = None
        self.original_inventory_item = None
        self.policy_maps = {"fulfillment": {}, "payment": {}, "return": {}}
        self.inventory_db_path = ensure_inventory_db()
        self.inventory_trees = {}
        self.inventory_search_var = tk.StringVar(value="")
        self.inventory_status_var = tk.StringVar(value="")
        self.orders_search_var = tk.StringVar(value="")
        self.orders_status_var = tk.StringVar(value="Orders will populate from eBay and Pending Shipping.")
        self.orders_detail_cache = {}
        self._orders_loading_ids = set()
        self.active_listings_cache = []
        self.recent_orders_cache = []
        self.listings_search_var = tk.StringVar(value="")
        self.listings_status_var = tk.StringVar(value="No eBay listing data loaded yet.")
        self.listings_page = 1
        self.listings_page_size_var = tk.StringVar(value="25")
        self.listings_page_var = tk.StringVar(value="Page 1 of 1")
        self.listings_sort_var = tk.StringVar(value="Newest first")
        self.listings_filter_var = tk.StringVar(value="All listings")
        self.offer_eligible_ids = set()
        self._listing_thumb_refs = {}
        self._listing_thumb_generation = 0
        self._listing_thumb_semaphore = threading.Semaphore(4)
        self.revamp_search_var = tk.StringVar(value="")
        self.revamp_age_var = tk.StringVar(value="180")
        self.revamp_status_var = tk.StringVar(value="Refresh listings to build the revamp queue.")
        self.attention_filter_var = tk.StringVar(value="ALL")
        self.attention_status_var = tk.StringVar(value="Run Sync + Scan to build the issue list.")
        self.sales_range_var = tk.StringVar(value="12")
        self.sales_status_var = tk.StringVar(value="Sales history will populate from eBay orders.")
        self.messages_cache = []
        self.messages_days_var = tk.StringVar(value="30")
        self.messages_search_var = tk.StringVar(value="")
        self.messages_status_var = tk.StringVar(value="Messages have not been refreshed yet.")
        self.messages_unread_var = tk.StringVar(value="Unread: —")
        self.sales_summary_vars = {
            "current": tk.StringVar(value="$0.00"),
            "previous": tk.StringVar(value="$0.00"),
            "mom": tk.StringVar(value="—"),
            "yoy": tk.StringVar(value="—"),
            "orders": tk.StringVar(value="0"),
            "units": tk.StringVar(value="0"),
        }
        self.dashboard_vars = {
            "active": tk.StringVar(value="—"),
            "attention": tk.StringVar(value="—"),
            "revamp": tk.StringVar(value="—"),
            "pending_location": tk.StringVar(value="—"),
            "pending_shipping": tk.StringVar(value="—"),
            "sold_today": tk.StringVar(value="—"),
            "sales_month": tk.StringVar(value="—"),
        }

        self._configure_style()
        self._build_ui()
        self._install_text_context_menus()
        self._validate_ui_callbacks()
        self.bind('<Control-s>', lambda e: self._save_listing_file())
        self.bind('<Control-p>', lambda e: self._preview())
        self.bind('<Control-f>', self._shortcut_focus_search)
        self.bind('<Control-r>', self._shortcut_refresh_current)
        self.bind('<Control-b>', lambda e: self._manual_backup())
        self._new_listing()
        self.after(700, self._auto_backup_once_per_day)
        self._log(f"APP STARTED: V{APP_VERSION} from {Path(__file__).resolve()}")
        self.after(1800, self._startup_ebay_sync)
        self.after(5000, lambda: self._check_for_updates(silent=True))

    @staticmethod
    def _set_windows_app_identity():
        """Give Windows a stable app identity so the taskbar can show our custom icon."""
        if os.name != "nt":
            return
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "TradeComponents.eBayListingTool"
            )
        except Exception:
            pass

    def _audit(self, action, detail=""):
        """Append one compact human-readable activity line."""
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().astimezone().isoformat(timespec="seconds")
            with ACTIVITY_LOG_FILE.open("a", encoding="utf-8") as fh:
                fh.write(f"{stamp}\t{str(action).strip()}\t{str(detail).strip()}\n")
        except Exception:
            pass

    def _auto_backup_once_per_day(self):
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            today = datetime.now().strftime("%Y-%m-%d")
            marker = BACKUP_DIR / f"inventory-{today}.db"
            if marker.exists():
                return
            if self.inventory_db_path.exists():
                shutil.copy2(self.inventory_db_path, marker)
            for src, name in (
                (OFFER_HISTORY_FILE, f"offer-history-{today}.json"),
                (BUYER_OFFER_HISTORY_FILE, f"buyer-offers-{today}.json"),
            ):
                if src.exists():
                    shutil.copy2(src, BACKUP_DIR / name)
            self._audit("AUTO BACKUP", marker.name)
            # Keep roughly 45 days of automatic DB backups.
            dbs = sorted(BACKUP_DIR.glob("inventory-*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
            for old in dbs[45:]:
                try:
                    old.unlink()
                except Exception:
                    pass
        except Exception as exc:
            self._log(f"AUTO BACKUP WARNING: {exc}")

    def _manual_backup(self):
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            dest = BACKUP_DIR / f"inventory-manual-{stamp}.db"
            shutil.copy2(self.inventory_db_path, dest)
            self._audit("MANUAL BACKUP", dest.name)
            messagebox.showinfo(
                "Backup",
                f"Inventory backup created successfully.\n\n{dest}",
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror("Backup", str(exc), parent=self)

    def _restore_backup(self):
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        path = filedialog.askopenfilename(
            title="Restore Inventory Backup",
            initialdir=str(BACKUP_DIR),
            filetypes=[("SQLite database", "*.db"), ("All files", "*.*")],
            parent=self,
        )
        if not path:
            return
        if not messagebox.askyesno(
            "Restore Inventory Backup",
            "Replace the current local inventory database with this backup?\n\n"
            "A safety copy of the current database will be created first.",
            parent=self,
        ):
            return
        try:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            safety = BACKUP_DIR / f"before-restore-{stamp}.db"
            if self.inventory_db_path.exists():
                shutil.copy2(self.inventory_db_path, safety)
            shutil.copy2(path, self.inventory_db_path)
            self._audit("RESTORE BACKUP", Path(path).name)
            self._inventory_refresh_all()
            self._refresh_dashboard()
            messagebox.showinfo(
                "Restore Inventory Backup",
                "Backup restored successfully.",
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror("Restore Inventory Backup", str(exc), parent=self)

    def _open_activity_log(self):
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            if not ACTIVITY_LOG_FILE.exists():
                ACTIVITY_LOG_FILE.write_text("", encoding="utf-8")
            if os.name == "nt":
                os.startfile(str(ACTIVITY_LOG_FILE))
            else:
                webbrowser.open(ACTIVITY_LOG_FILE.as_uri())
        except Exception as exc:
            messagebox.showerror("Activity Log", str(exc), parent=self)

    def _shortcut_focus_search(self, _event=None):
        try:
            current = self.notebook.select()
            if current == str(self.listings_tab):
                for child in self.listings_tab.winfo_children():
                    pass
                # Search field is the only Entry directly in Listings header with this variable.
                for widget in self.listings_tab.winfo_children():
                    pass
                self.listings_search_var.set(self.listings_search_var.get())
                # Tk focus search by textvariable name.
                target = self._find_entry_for_variable(self.listings_tab, self.listings_search_var)
            elif current == str(self.inventory_tab):
                target = self._find_entry_for_variable(self.inventory_tab, self.inventory_search_var)
            elif current == str(self.orders_tab):
                target = self._find_entry_for_variable(self.orders_tab, self.orders_search_var)
            elif current == str(self.messages_tab):
                target = self._find_entry_for_variable(self.messages_tab, self.messages_search_var)
            else:
                target = None
            if target is not None:
                target.focus_set()
                try:
                    target.selection_range(0, "end")
                except Exception:
                    pass
        except Exception:
            pass
        return "break"

    def _find_entry_for_variable(self, root, variable):
        name = str(variable)
        stack = [root]
        while stack:
            widget = stack.pop()
            try:
                if isinstance(widget, (ttk.Entry, tk.Entry)):
                    if str(widget.cget("textvariable")) == name:
                        return widget
                stack.extend(widget.winfo_children())
            except Exception:
                pass
        return None

    def _shortcut_refresh_current(self, _event=None):
        try:
            current = self.notebook.select()
            if current == str(self.listings_tab):
                self._refresh_listings_from_ebay()
            elif current == str(self.orders_tab):
                self._orders_refresh_from_ebay()
            elif current == str(self.messages_tab):
                self._refresh_messages_from_ebay()
            elif current == str(self.inventory_tab):
                self._inventory_refresh_all()
            elif current == str(self.attention_tab):
                self._attention_sync_and_scan()
            elif current == str(self.sales_tab):
                self._refresh_sales_from_ebay()
        except Exception:
            pass
        return "break"

    def _tree_sort_key(self, tree, column, iid):
        raw = str(tree.set(iid, column) or "").strip()
        cleaned = raw.replace(",", "").replace("$", "").replace("%", "")
        try:
            return (0, float(cleaned))
        except Exception:
            pass
        parts = re.split(r"(\d+)", raw.casefold())
        cooked = []
        for part in parts:
            if part.isdigit():
                cooked.append((0, int(part)))
            else:
                cooked.append((1, part))
        return (1, cooked)

    def _apply_treeview_sort(self, tree, column, reverse):
        if tree is None:
            return
        children = list(tree.get_children(""))
        children.sort(
            key=lambda iid: self._tree_sort_key(tree, column, iid),
            reverse=bool(reverse),
        )
        for index, iid in enumerate(children):
            tree.move(iid, "", index)

    def _sort_treeview_column(self, tree, column):
        """Sort a Treeview by the clicked column; repeated clicks reverse direction."""
        if tree is None:
            return
        if not hasattr(self, "_tree_sort_states"):
            self._tree_sort_states = {}
        if not hasattr(self, "_tree_last_sort"):
            self._tree_last_sort = {}

        key = (str(tree), column)
        reverse = not self._tree_sort_states.get(key, False)
        self._tree_sort_states[key] = reverse
        self._tree_last_sort[str(tree)] = (column, reverse)
        self._apply_treeview_sort(tree, column, reverse)

    def _reapply_treeview_sort(self, tree):
        if tree is None:
            return
        state = getattr(self, "_tree_last_sort", {}).get(str(tree))
        if state:
            self._apply_treeview_sort(tree, state[0], state[1])


    @staticmethod
    def _version_tuple(value):
        nums = re.findall(r"\d+", str(value or ""))
        return tuple(int(x) for x in nums[:4]) or (0,)

    def _fetch_update_manifest(self):
        req = request.Request(
            UPDATE_MANIFEST_URL,
            headers={
                "User-Agent": f"TradeComponents-eBay-Listing-Tool/{APP_VERSION}",
                "Cache-Control": "no-cache",
            },
            method="GET",
        )
        with request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8", "replace")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise RuntimeError("The update manifest is not a JSON object.")

        version = str(data.get("version", "") or "").strip()
        filename = str(data.get("file", "") or "").strip()
        if not version or not filename:
            raise RuntimeError("version.json must contain both 'version' and 'file'.")
        if "/" in filename or "\\" in filename or filename.startswith("."):
            raise RuntimeError("The update filename in version.json is invalid.")
        if not filename.lower().endswith(".zip"):
            raise RuntimeError("The update file must be a .zip archive.")

        return {
            "version": version,
            "file": filename,
            "sha256": str(data.get("sha256", "") or "").strip().lower(),
        }

    def _check_for_updates(self, silent=False):
        def work():
            try:
                manifest = self._fetch_update_manifest()
                latest = manifest["version"]
                newer = self._version_tuple(latest) > self._version_tuple(APP_VERSION)

                if not newer:
                    if not silent:
                        self.after(
                            0,
                            lambda: messagebox.showinfo(
                                "Software Update",
                                f"You're up to date.\n\nInstalled version: V{APP_VERSION}",
                                parent=self,
                            ),
                        )
                    return

                def prompt():
                    install = messagebox.askyesno(
                        "Software Update",
                        f"A newer version is available.\n\n"
                        f"Installed: V{APP_VERSION}\n"
                        f"Available: V{latest}\n\n"
                        "Download and install it now?\n\n"
                        "Your local settings, API keys, inventory database, and image cache "
                        "are stored separately and will not be replaced.",
                        parent=self,
                    )
                    if install:
                        self._download_and_install_update(manifest)

                self.after(0, prompt)
            except Exception as exc:
                if not silent:
                    self.after(
                        0,
                        lambda e=str(exc): messagebox.showerror(
                            "Software Update",
                            "Could not check for updates.\n\n" + e,
                            parent=self,
                        ),
                    )
                else:
                    self._log("UPDATE CHECK: " + str(exc))

        threading.Thread(target=work, daemon=True).start()

    def _download_and_install_update(self, manifest):
        """
        Download and install a release directly into the currently running app folder.

        Python does not keep the .py source file locked, so release files can be
        replaced safely while this process is still alive. This is more reliable
        on managed Windows PCs than handing the update off to a detached PowerShell
        process. A temporary backup is kept until every release file is copied.
        """
        latest = manifest["version"]
        filename = manifest["file"]
        url = parse.urljoin(UPDATE_BASE_URL, filename)

        progress = tk.Toplevel(self)
        progress.title("Software Update")
        progress.transient(self)
        progress.resizable(False, False)
        progress.geometry("460x165")
        ttk.Label(
            progress,
            text=f"Installing V{latest}…",
            style="Section.TLabel",
        ).pack(anchor="w", padx=18, pady=(18, 6))
        status_var = tk.StringVar(value="Downloading from fuscaldo.org…")
        ttk.Label(progress, textvariable=status_var).pack(anchor="w", padx=18, pady=(0, 8))
        bar = ttk.Progressbar(progress, mode="indeterminate")
        bar.pack(fill="x", padx=18, pady=(0, 16))
        bar.start(12)

        def fail(message):
            try:
                bar.stop()
                progress.destroy()
            except Exception:
                pass
            messagebox.showerror("Software Update", message, parent=self)

        def work():
            temp_root = None
            try:
                temp_root = Path(tempfile.mkdtemp(prefix="trade_components_update_"))
                zip_file = temp_root / "update.zip"
                extract_dir = temp_root / "payload"
                backup_dir = temp_root / "backup"
                extract_dir.mkdir(parents=True, exist_ok=True)
                backup_dir.mkdir(parents=True, exist_ok=True)

                req = request.Request(
                    url,
                    headers={
                        "User-Agent": f"TradeComponents-eBay-Listing-Tool/{APP_VERSION}",
                        "Cache-Control": "no-cache",
                    },
                    method="GET",
                )
                with request.urlopen(req, timeout=90) as resp, open(zip_file, "wb") as out:
                    shutil.copyfileobj(resp, out)

                if zip_file.stat().st_size < 1000:
                    raise RuntimeError("The downloaded update file is unexpectedly small.")

                expected_hash = manifest.get("sha256", "")
                if expected_hash:
                    import hashlib
                    h = hashlib.sha256()
                    with open(zip_file, "rb") as fh:
                        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                            h.update(chunk)
                    if h.hexdigest().lower() != expected_hash:
                        raise RuntimeError(
                            "The update checksum does not match version.json. "
                            "The update was not installed."
                        )

                with zipfile.ZipFile(zip_file, "r") as zf:
                    members = zf.infolist()
                    if not members:
                        raise RuntimeError("The downloaded update ZIP is empty.")

                    extract_root = extract_dir.resolve()
                    for member in members:
                        candidate = (extract_dir / member.filename).resolve()
                        if candidate != extract_root and extract_root not in candidate.parents:
                            raise RuntimeError("The update ZIP contains an unsafe file path.")
                    zf.extractall(extract_dir)

                entries = [p for p in extract_dir.iterdir() if p.name != "__MACOSX"]
                payload_dir = entries[0] if len(entries) == 1 and entries[0].is_dir() else extract_dir

                main_py = payload_dir / "ebay_listing_tool.py"
                if not main_py.exists():
                    raise RuntimeError(
                        "The update ZIP does not contain ebay_listing_tool.py."
                    )

                # Confirm the downloaded package really contains the advertised version.
                try:
                    incoming_version = ""
                    for version_file in (
                        main_py,
                        payload_dir / "trade_components_core.py",
                    ):
                        if not version_file.exists():
                            continue
                        incoming_source = version_file.read_text(encoding="utf-8", errors="ignore")
                        version_match = re.search(
                            r'APP_VERSION\s*=\s*["\']([^"\']+)["\']',
                            incoming_source,
                        )
                        if version_match:
                            incoming_version = version_match.group(1)
                            break
                    if incoming_version and self._version_tuple(incoming_version) != self._version_tuple(latest):
                        raise RuntimeError(
                            f"version.json says V{latest}, but latest.zip contains V{incoming_version}."
                        )
                except RuntimeError:
                    raise
                except Exception:
                    pass

                target_dir = Path(__file__).resolve().parent
                release_files = [p for p in payload_dir.rglob("*") if p.is_file()]
                if not release_files:
                    raise RuntimeError("No release files were found in latest.zip.")

                self.after(0, lambda: status_var.set("Backing up the current program…"))

                # Back up only files that this release is about to replace.
                backed_up = []
                for src_file in release_files:
                    rel = src_file.relative_to(payload_dir)
                    target_file = target_dir / rel
                    if target_file.exists() and target_file.is_file():
                        backup_file = backup_dir / rel
                        backup_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(target_file, backup_file)
                        backed_up.append(rel)

                copied = []
                try:
                    self.after(0, lambda: status_var.set("Applying the update…"))
                    for src_file in release_files:
                        rel = src_file.relative_to(payload_dir)
                        target_file = target_dir / rel
                        target_file.parent.mkdir(parents=True, exist_ok=True)

                        # Copy through a temporary sibling then replace. This avoids
                        # leaving a partially-written Python file if a copy is interrupted.
                        tmp_target = target_file.with_name(target_file.name + ".update_tmp")
                        shutil.copy2(src_file, tmp_target)
                        os.replace(tmp_target, target_file)
                        copied.append(rel)
                except Exception as copy_exc:
                    # Roll back every file for which a backup exists.
                    for rel in reversed(backed_up):
                        try:
                            backup_file = backup_dir / rel
                            target_file = target_dir / rel
                            if backup_file.exists():
                                shutil.copy2(backup_file, target_file)
                        except Exception:
                            pass
                    raise RuntimeError(
                        "Windows could not replace the program files, so the old version "
                        "was restored.\n\n" + str(copy_exc)
                    ) from copy_exc

                # Verify the installed source has the advertised version before restart.
                installed_version = ""
                for version_file in (
                    target_dir / "ebay_listing_tool.py",
                    target_dir / "trade_components_core.py",
                ):
                    if not version_file.exists():
                        continue
                    installed_source = version_file.read_text(
                        encoding="utf-8", errors="ignore"
                    )
                    installed_match = re.search(
                        r'APP_VERSION\s*=\s*["\']([^"\']+)["\']',
                        installed_source,
                    )
                    if installed_match:
                        installed_version = installed_match.group(1)
                        break
                if self._version_tuple(installed_version) != self._version_tuple(latest):
                    raise RuntimeError(
                        f"The files were copied, but verification found V{installed_version or 'unknown'} "
                        f"instead of V{latest}."
                    )

                self.after(0, lambda: status_var.set("Update installed. Restarting…"))

                # Restart the exact installation folder that was just updated.
                launcher = target_dir / "LAUNCH_TOOL.vbs"
                start_bat = target_dir / "START_TOOL.bat"

                if os.name == "nt" and launcher.exists():
                    restart_cmd = [
                        str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "wscript.exe"),
                        str(launcher),
                    ]
                elif start_bat.exists():
                    restart_cmd = [str(start_bat)]
                else:
                    restart_cmd = [sys.executable, str(target_dir / "ebay_listing_tool.py")]

                def finish():
                    try:
                        bar.stop()
                        progress.destroy()
                    except Exception:
                        pass

                    messagebox.showinfo(
                        "Software Update",
                        f"V{latest} was installed successfully.\n\n"
                        "The app will close and reopen now.",
                        parent=self,
                    )

                    try:
                        creationflags = 0
                        if os.name == "nt":
                            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                        subprocess.Popen(
                            restart_cmd,
                            cwd=str(target_dir),
                            creationflags=creationflags,
                            close_fds=True,
                        )
                    except Exception as restart_exc:
                        messagebox.showwarning(
                            "Software Update",
                            "The update was installed successfully, but Windows could not "
                            "restart the app automatically.\n\n"
                            f"Open the app normally. It should now be V{latest}.\n\n"
                            f"{restart_exc}",
                            parent=self,
                        )

                    self.quit()
                    self.destroy()

                self.after(0, finish)

            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): fail(
                        "The update could not be installed.\n\n" + e
                    ),
                )

        threading.Thread(target=work, daemon=True).start()


    def _set_window_icon(self):
        """Load the bundled PNG/ICO so both the window and desktop shortcut use the updated icon."""
        try:
            base_dir = Path(__file__).resolve().parent
            png_icon = base_dir / "TradeComponents_icon.png"
            ico_icon = base_dir / "TradeComponents_icon.ico"
            self._icon_photo_ref = None
            if png_icon.exists():
                try:
                    self._icon_photo_ref = tk.PhotoImage(file=str(png_icon))
                    self.iconphoto(True, self._icon_photo_ref)
                except Exception:
                    self._icon_photo_ref = None
            if ico_icon.exists():
                try:
                    self.iconbitmap(default=str(ico_icon))
                    self.iconbitmap(str(ico_icon))
                except Exception:
                    pass

            # Windows can initially inherit the Python executable icon while the
            # window is being created. Re-apply our icon once Tk has registered
            # the top-level window with the shell.
            if os.name == "nt":
                try:
                    self.after(
                        250,
                        lambda: self.iconbitmap(str(ico_icon)) if ico_icon.exists() else None,
                    )
                except Exception:
                    pass
        except Exception:
            pass

    def _configure_style(self):
        """A restrained, native-looking visual refresh without third-party UI packages."""
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        default_font = ("Segoe UI", 10)
        heading_font = ("Segoe UI Semibold", 11)
        title_font = ("Segoe UI Semibold", 18)
        small_font = ("Segoe UI", 9)

        shell_bg = "#f4f1ec"
        card_bg = "#fbfaf7"
        tab_bg = "#e7e1d8"
        accent = "#315f8f"
        accent_soft = "#e7eef6"
        text_dark = "#2f3a46"

        try:
            self.configure(bg=shell_bg)
        except Exception:
            pass

        style.configure(".", font=default_font, background=shell_bg, foreground=text_dark)
        style.configure("TFrame", background=shell_bg)
        style.configure("TLabel", background=shell_bg, foreground=text_dark)
        style.configure("Header.TLabel", font=title_font, background=shell_bg, foreground="#163761")
        style.configure("Subheader.TLabel", font=small_font, background=shell_bg, foreground="#4b5d73")
        style.configure("Section.TLabel", font=heading_font, background=shell_bg, foreground=accent)

        style.configure("TNotebook", padding=6, background=shell_bg, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9), background=tab_bg, foreground=text_dark, borderwidth=0)
        style.map(
            "TNotebook.Tab",
            background=[("selected", "#ffffff"), ("active", accent_soft)],
            foreground=[("selected", accent), ("active", accent)],
        )

        style.configure("TLabelframe", padding=10, background=card_bg, borderwidth=1, relief="groove")
        style.configure("TLabelframe.Label", font=heading_font, background=shell_bg, foreground=accent)
        style.configure("TButton", padding=(12, 8), background="#fdfcf9", foreground=text_dark, borderwidth=1)
        style.map("TButton", background=[("active", accent_soft)])
        style.configure("Accent.TButton", font=("Segoe UI Semibold", 10), padding=(12, 8), background=accent_soft, foreground=accent)
        style.map("Accent.TButton", background=[("active", "#d8e9ff")])
        style.configure("Danger.TButton", font=("Segoe UI Semibold", 10), padding=(12, 8))
        style.configure("TEntry", fieldbackground="#ffffff")
        style.configure("TCombobox", fieldbackground="#ffffff")
        style.configure("Treeview", rowheight=24, fieldbackground="#ffffff", background="#ffffff")
        style.configure("Treeview.Heading", font=heading_font)

    def _install_text_context_menus(self):
        """Add familiar right-click editing commands to Entry/Text/Spinbox widgets."""

        def popup(event):
            widget = event.widget
            menu = tk.Menu(self, tearoff=False)

            can_edit = True
            try:
                state = str(widget.cget("state"))
                if state in ("disabled", "readonly"):
                    can_edit = False
            except Exception:
                pass

            def do_cut():
                try:
                    widget.event_generate("<<Cut>>")
                except Exception:
                    pass

            def do_copy():
                try:
                    widget.event_generate("<<Copy>>")
                except Exception:
                    pass

            def do_paste():
                try:
                    widget.event_generate("<<Paste>>")
                except Exception:
                    pass

            def do_select_all():
                try:
                    if isinstance(widget, tk.Text):
                        widget.tag_add("sel", "1.0", "end-1c")
                        widget.mark_set("insert", "1.0")
                        widget.see("insert")
                    else:
                        widget.selection_range(0, "end")
                        widget.icursor("end")
                except Exception:
                    pass

            menu.add_command(label="Cut", command=do_cut, state="normal" if can_edit else "disabled")
            menu.add_command(label="Copy", command=do_copy)
            menu.add_command(label="Paste", command=do_paste, state="normal" if can_edit else "disabled")
            menu.add_separator()
            menu.add_command(label="Select All", command=do_select_all)

            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                try:
                    menu.grab_release()
                except Exception:
                    pass
            return "break"

        # Windows/macOS/Linux-friendly class bindings.
        for cls in ("Entry", "TEntry", "Text", "Spinbox", "TSpinbox"):
            try:
                self.bind_class(cls, "<Button-3>", popup, add="+")
            except Exception:
                pass
            try:
                self.bind_class(cls, "<Button-2>", popup, add="+")
            except Exception:
                pass

    def _validate_ui_callbacks(self):
        """Catch missing integrated UI callbacks immediately during development."""
        pm = getattr(self, "photo_manager", None)
        if pm is not None:
            required = ("_ai_group_current_batch",)
            missing = [name for name in required if not callable(getattr(pm, name, None))]
            if missing:
                raise RuntimeError(
                    "Integrated photo manager is missing required callback(s): "
                    + ", ".join(missing)
                )
        if getattr(self, "photo_manager", None) is not None:
            if getattr(self.photo_manager, "analyze_btn", None) is None:
                raise RuntimeError("Photo Manager Analyze button was not initialized.")
            self.analyze_btn = self.photo_manager.analyze_btn

        try:
            probe = self._selected_photo_paths()
            if not isinstance(probe, list):
                raise RuntimeError("selected-photo bridge did not return a list")
        except Exception as exc:
            raise RuntimeError("Main photo bridge startup test failed: " + str(exc))



    def _show_progress_popup(self, title, message):
        try:
            if getattr(self, "_progress_popup", None) is not None:
                self._progress_popup.destroy()
        except Exception:
            pass

        win = tk.Toplevel(self)
        win.title(title)
        win.resizable(False, False)
        win.transient(self)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        win.protocol("WM_DELETE_WINDOW", lambda: None)

        frame = ttk.Frame(win, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)

        self._progress_message_var = tk.StringVar(value=message)
        ttk.Label(frame, text=title, style="Section.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            frame,
            textvariable=self._progress_message_var,
            wraplength=420,
            justify="left"
        ).grid(row=1, column=0, sticky="w", pady=(6, 10))

        self._progress_bar = ttk.Progressbar(frame, mode="indeterminate", length=420)
        self._progress_bar.grid(row=2, column=0, sticky="ew")
        self._progress_bar.start(12)

        ttk.Button(frame, text="STOP / CANCEL", command=self._stop).grid(
            row=3, column=0, sticky="e", pady=(10, 0)
        )

        self._progress_popup = win
        self.update_idletasks()

    def _update_progress_popup(self, message):
        if hasattr(self, "_progress_message_var"):
            self._progress_message_var.set(message)
        try:
            if getattr(self, "_progress_popup", None) is not None:
                self._progress_popup.update_idletasks()
        except Exception:
            pass

    def _close_progress_popup(self):
        """Close any active progress popup. Safe to call repeatedly."""
        bar = getattr(self, "_progress_bar", None)
        win = getattr(self, "_progress_popup", None)

        self._progress_bar = None
        self._progress_popup = None

        try:
            if bar is not None:
                bar.stop()
        except Exception:
            pass

        try:
            if win is not None and win.winfo_exists():
                win.destroy()
        except Exception:
            pass


    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self, padding=(14, 8, 14, 6))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(
            header, text="Trade Components eBay Listing Tool", style="Header.TLabel"
        ).grid(row=0, column=0, sticky="w")
        ttk.Button(
            header,
            text="CHECK FOR UPDATES",
            command=self._check_for_updates,
        ).grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))
        ttk.Label(
            header,
            text="V4.23.23  •  Offers workspace + workflow tools",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        notebook = ttk.Notebook(self)
        notebook.grid(row=1, column=0, sticky="nsew", padx=12, pady=(4, 12))

        self.dashboard_tab = ttk.Frame(notebook, padding=10)
        self.listing_tab = ttk.Frame(notebook, padding=10)
        self.listings_tab = ttk.Frame(notebook, padding=10)
        self.revamp_tab = ttk.Frame(notebook, padding=10)
        self.inventory_tab = ttk.Frame(notebook, padding=10)
        self.orders_tab = ttk.Frame(notebook, padding=10)
        self.attention_tab = ttk.Frame(notebook, padding=10)
        self.sales_tab = ttk.Frame(notebook, padding=10)
        self.messages_tab = ttk.Frame(notebook, padding=10)
        self.settings_tab = ttk.Frame(notebook, padding=10)

        notebook.add(self.dashboard_tab, text="Dashboard")
        notebook.add(self.listing_tab, text="Listing Editor")
        notebook.add(self.inventory_tab, text="Inventory")
        notebook.add(self.orders_tab, text="Orders")
        notebook.add(self.listings_tab, text="Listings")
        notebook.add(self.messages_tab, text="Messages")
        notebook.add(self.attention_tab, text="Needs Attention")
        notebook.add(self.sales_tab, text="Sales")
        notebook.add(self.settings_tab, text="Settings")
        self.notebook = notebook

        # Wheel movement over the notebook tab strip must never change tabs.
        notebook.bind("<MouseWheel>", lambda event: "break")

        self._build_dashboard_tab()
        self._build_listing_tab()
        self._build_listings_tab()
        self._build_revamp_tab()
        self._build_inventory_tab()
        self._build_orders_tab()
        self._build_attention_tab()
        self._build_sales_tab()
        self._build_messages_tab()
        self._build_settings_tab()
        self._refresh_dashboard()


    # =======================================================================
    # BUSY / LOADING FEEDBACK
    # =======================================================================

    def _show_busy(self, title="Working…", message="Please wait…", cancellable=False):
        """
        Show a modal progress box for a long-running operation.

        Starting a new long operation clears any stale cancellation flag left by
        a previously cancelled operation.
        """
        try:
            self.cancel_event.clear()
        except Exception:
            pass

        # Never allow an orphaned old busy window to survive into a new operation.
        try:
            old = getattr(self, "_busy_window", None)
            if old is not None and old.winfo_exists():
                try:
                    old.grab_release()
                except Exception:
                    pass
                old.destroy()
        except Exception:
            pass

        win = tk.Toplevel(self)
        self._busy_window = win
        win.title(str(title))
        win.transient(self)
        win.resizable(False, False)
        win.protocol("WM_DELETE_WINDOW", self._request_cancel_from_busy if cancellable else lambda: None)

        self._busy_title_var = tk.StringVar(value=str(title))
        self._busy_message_var = tk.StringVar(value=str(message))
        self._busy_status_var = tk.StringVar(value="Starting…")

        frame = ttk.Frame(win, padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, textvariable=self._busy_title_var, style="Section.TLabel").pack(
            anchor="w", pady=(0, 6)
        )
        ttk.Label(
            frame,
            textvariable=self._busy_message_var,
            wraplength=410,
            justify="left",
        ).pack(anchor="w", fill="x", pady=(0, 10))

        bar = ttk.Progressbar(frame, mode="indeterminate", length=410)
        self._busy_bar = bar
        bar.pack(fill="x", pady=(0, 7))
        bar.start(12)

        ttk.Label(
            frame,
            textvariable=self._busy_status_var,
            wraplength=410,
            justify="left",
            font=("Segoe UI", 8),
            foreground="#5f6870",
        ).pack(anchor="w", fill="x", pady=(0, 10))

        if cancellable:
            ttk.Button(
                frame,
                text="STOP / CANCEL",
                command=self._request_cancel_from_busy,
            ).pack(anchor="e")

        try:
            win.grab_set()
        except Exception:
            pass

        win.update_idletasks()
        try:
            x = self.winfo_rootx() + max(0, (self.winfo_width() - win.winfo_reqwidth()) // 2)
            y = self.winfo_rooty() + max(0, (self.winfo_height() - win.winfo_reqheight()) // 2)
            win.geometry(f"+{x}+{y}")
        except Exception:
            pass
        return win

    def _update_busy(self, message=None, title=None, status=None):
        """Update the active loading box from the UI thread."""
        try:
            win = getattr(self, "_busy_window", None)
            if win is None or not win.winfo_exists():
                return
            if title is not None:
                self._busy_title_var.set(str(title))
                win.title(str(title))
            if message is not None:
                self._busy_message_var.set(str(message))
            if status is not None:
                clean = self._busy_status_text(status)
                if clean:
                    self._busy_status_var.set(clean)
        except Exception:
            pass

    def _busy_status_text(self, value):
        """
        Turn a log/progress message into a compact line for the loading box.
        Keep the detailed log untouched; this is just an at-a-glance status.
        """
        text = str(value or "").strip()
        if not text:
            return ""
        lines = [x.strip() for x in text.splitlines() if x.strip()]
        if not lines:
            return ""
        text = lines[-1]

        # Hide long raw API/XML/HTML payloads from the compact status line.
        if len(text) > 220:
            text = text[:217].rstrip() + "…"
        return text


    def _hide_busy(self):
        """Destroy the current progress box. Safe to call repeatedly."""
        win = getattr(self, "_busy_window", None)
        self._busy_window = None
        self._busy_title_var = None
        self._busy_message_var = None
        self._busy_status_var = None

        try:
            bar = getattr(self, "_busy_bar", None)
            self._busy_bar = None
            if bar is not None:
                bar.stop()
        except Exception:
            pass

        try:
            if win is not None and win.winfo_exists():
                try:
                    win.grab_release()
                except Exception:
                    pass
                win.destroy()
        except Exception:
            pass

    def _request_cancel_from_busy(self):
        """
        Request cancellation and immediately release the modal UI.

        The worker may need a moment to return from a network request, but the
        user should never be trapped behind a stale loading box.
        """
        try:
            self.cancel_event.set()
        except Exception:
            pass
        self._hide_busy()
        self._log("USER CANCELLED CURRENT OPERATION")

    def _finish_busy_from_worker(self):
        """Thread-safe convenience used from worker finally blocks."""
        try:
            self.after(0, self._hide_busy)
        except Exception:
            pass

    # =======================================================================
    # DAILY OPERATIONS / LISTINGS / REVAMP / NEEDS ATTENTION
    # =======================================================================

    def _select_top_tab(self, tab):
        try:
            self.notebook.select(tab)
        except Exception:
            pass

    def _build_dashboard_tab(self):
        outer = self.dashboard_tab
        outer.columnconfigure(0, weight=1)

        ttk.Label(outer, text="Daily Operations", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 4)
        )
        ttk.Label(
            outer,
            text="A quick view of what needs action today. Counts refresh as eBay/inventory data is synchronized.",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(0, 12))

        cards = ttk.Frame(outer)
        cards.grid(row=2, column=0, sticky="ew")
        for c in range(4):
            cards.columnconfigure(c, weight=1)

        specs = [
            ("active", "ACTIVE LISTINGS", self.listings_tab, None),
            ("attention", "OPEN ISSUES", self.attention_tab, None),
            ("revamp", "REVAMP QUEUE", self.revamp_tab, None),
            ("pending_location", "PENDING LOCATION", self.inventory_tab, "PENDING_LOCATION"),
            ("pending_shipping", "ORDERS TO SHIP", self.orders_tab, None),
            ("sold_today", "SOLD TODAY", self.inventory_tab, "SOLD"),
            ("sales_month", "SALES THIS MONTH", self.sales_tab, None),
        ]
        for i, (key, label, target, inventory_key) in enumerate(specs):
            card = ttk.LabelFrame(cards, text=label, padding=14)
            card.grid(row=i // 4, column=i % 4, sticky="nsew", padx=5, pady=5)
            ttk.Label(
                card, textvariable=self.dashboard_vars[key], style="Header.TLabel"
            ).pack(anchor="center", pady=(4, 8))
            ttk.Button(
                card,
                text="OPEN",
                command=(
                    (lambda k=inventory_key: self._open_inventory_subtab(k))
                    if inventory_key
                    else (lambda t=target: self._select_top_tab(t))
                ),
            ).pack(fill="x")

        actions = ttk.LabelFrame(outer, text="Start Here", padding=12)
        actions.grid(row=3, column=0, sticky="ew", pady=(14, 0))
        for c in range(4):
            actions.columnconfigure(c, weight=1)
        ttk.Button(
            actions,
            text="SYNC + SCAN EVERYTHING",
            command=self._attention_sync_and_scan,
            style="Primary.TButton",
        ).grid(row=0, column=0, padx=4, sticky="ew")
        ttk.Button(
            actions,
            text="NEW LISTING",
            command=lambda: self._select_top_tab(self.listing_tab),
        ).grid(row=0, column=1, padx=4, sticky="ew")
        ttk.Button(
            actions,
            text="VIEW REVAMP QUEUE",
            command=lambda: self._select_top_tab(self.revamp_tab),
        ).grid(row=0, column=2, padx=4, sticky="ew")
        ttk.Button(
            actions,
            text="NEEDS ATTENTION",
            command=lambda: self._select_top_tab(self.attention_tab),
        ).grid(row=0, column=3, padx=4, sticky="ew")

    def _open_inventory_subtab(self, key):
        """Open Inventory directly on a specific workflow tab."""
        if str(key or "").upper() == "PENDING_SHIPPING":
            self._select_top_tab(self.orders_tab)
            self._orders_refresh_view()
            return
        self._select_top_tab(self.inventory_tab)
        mapping = {
            "MASTER": 0,
            "PENDING_LOCATION": 1,
            "SOLD": 2,
        }
        try:
            self.inventory_notebook.select(mapping.get(str(key).upper(), 0))
        except Exception:
            pass
        try:
            tree = self.inventory_trees.get(str(key).upper())
            if tree is not None:
                tree.focus_set()
        except Exception:
            pass

    def _refresh_dashboard(self):
        try:
            con = self._inventory_connect()
            try:
                pending_location = con.execute(
                    "SELECT COUNT(*) FROM inventory_items WHERE status='PENDING_LOCATION'"
                ).fetchone()[0]
                pending_shipping = con.execute(
                    """SELECT COUNT(DISTINCT CASE
                           WHEN trim(COALESCE(ebay_order_id,''))<>'' THEN ebay_order_id
                           ELSE 'LOCAL-' || id END)
                       FROM inventory_items
                       WHERE status='PENDING_SHIPPING'"""
                ).fetchone()[0]
                sold_today = con.execute(
                    "SELECT COUNT(*) FROM inventory_items "
                    "WHERE status='SOLD' AND date(date_sold)=date('now')"
                ).fetchone()[0]
                open_issues = con.execute(
                    "SELECT COUNT(*) FROM attention_issues WHERE state='OPEN'"
                ).fetchone()[0]
                month_sales = con.execute(
                    "SELECT SUM(sales_value) FROM sales_orders WHERE substr(creation_date,1,7)=strftime('%Y-%m','now')"
                ).fetchone()[0]
            finally:
                con.close()

            self.dashboard_vars["pending_location"].set(f"{pending_location:,}")
            self.dashboard_vars["pending_shipping"].set(f"{pending_shipping:,}")
            self.dashboard_vars["sold_today"].set(f"{sold_today:,}")
            self.dashboard_vars["attention"].set(f"{open_issues:,}")
            self.dashboard_vars["sales_month"].set(f"${float(month_sales or 0):,.0f}")
            self.dashboard_vars["active"].set(
                f"{len(self.active_listings_cache):,}" if self.active_listings_cache else "—"
            )
            revamp_count = len(self._compute_revamp_rows(self.active_listings_cache))
            self.dashboard_vars["revamp"].set(
                f"{revamp_count:,}" if self.active_listings_cache else "—"
            )
        except Exception:
            pass

    def _build_listings_tab(self):
        outer = self.listings_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(1, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        top.columnconfigure(2, weight=1)
        ttk.Label(top, text="Listings", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 14)
        )
        ttk.Button(
            top, text="REFRESH FROM EBAY", command=self._refresh_listings_from_ebay
        ).grid(row=0, column=1, padx=(0, 10))
        search_entry = ttk.Entry(
            top, textvariable=self.listings_search_var, width=34
        )
        search_entry.grid(row=0, column=2, sticky="e", padx=(0, 8))
        search_entry.bind(
            "<Return>",
            lambda _e: self._listing_search_changed(),
        )
        ttk.Button(
            top, text="SEARCH", command=self._listing_search_changed
        ).grid(row=0, column=3)

        inner = ttk.Notebook(outer)
        inner.grid(row=1, column=0, sticky="nsew")
        self.listings_notebook = inner

        active_frame = ttk.Frame(inner, padding=6)
        active_frame.columnconfigure(0, weight=1)
        active_frame.rowconfigure(1, weight=1)
        inner.add(active_frame, text="Active Listings")

        # Revamp is a listing-management workflow, so keep it inside Listings.
        self.revamp_tab = ttk.Frame(inner, padding=6)
        inner.add(self.revamp_tab, text="Revamp Queue")

        # Consolidate every offer-related workflow into one Offers tab.
        self.offers_tab = ttk.Frame(inner, padding=6)
        self.offers_tab.columnconfigure(0, weight=1)
        self.offers_tab.rowconfigure(0, weight=1)
        inner.add(self.offers_tab, text="Offers")

        self.offers_notebook = ttk.Notebook(self.offers_tab)
        self.offers_notebook.grid(row=0, column=0, sticky="nsew")

        self.offer_eligible_tab = ttk.Frame(self.offers_notebook, padding=6)
        self.buyer_offer_history_tab = ttk.Frame(self.offers_notebook, padding=6)
        self.existing_tab = ttk.Frame(self.offers_notebook, padding=6)

        self.offers_notebook.add(self.offer_eligible_tab, text="Offer Eligible")
        self.offers_notebook.add(
            self.buyer_offer_history_tab, text="Buyer Offer History"
        )
        self.offers_notebook.add(
            self.existing_tab, text="Edit Existing / Inventory Offers"
        )

        ttk.Label(
            active_frame,
            textvariable=self.listings_status_var,
            style="Subheader.TLabel",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 5))

        # A dedicated style keeps the taller thumbnail rows isolated to Listings.
        try:
            ttk.Style(self).configure("Listings.Treeview", rowheight=82)
        except Exception:
            pass

        cols = (
            "item_number", "title", "sku", "qty", "price",
            "age", "photos", "offer", "location"
        )
        tree = ttk.Treeview(
            active_frame,
            columns=cols,
            show=("tree", "headings"),
            selectmode="extended",
            style="Listings.Treeview",
        )
        self.active_listings_tree = tree
        tree.heading("#0", text="PHOTO")
        tree.column("#0", width=105, minwidth=105, anchor="center", stretch=False)

        heads = {
            "item_number": "ITEM #", "title": "TITLE", "sku": "SKU",
            "qty": "EBAY QTY", "price": "PRICE", "age": "AGE (DAYS)",
            "photos": "PHOTOS", "offer": "OFFER", "location": "LOCATION",
        }
        widths = {
            "item_number": 120, "title": 390, "sku": 125, "qty": 75,
            "price": 85, "age": 80, "photos": 65, "offer": 95, "location": 115,
        }
        for c in cols:
            tree.heading(
                c, text=heads[c],
                command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col),
            )
            tree.column(
                c, width=widths[c], anchor="w",
                stretch=(c == "title")
            )

        vs = ttk.Scrollbar(active_frame, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(active_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=1, column=0, sticky="nsew")
        vs.grid(row=1, column=1, sticky="ns")
        hs.grid(row=2, column=0, sticky="ew")
        tree.bind("<Double-1>", lambda _e: self._open_selected_active_listing())
        tree.bind("<Button-3>", lambda e, tr=tree: self._active_listing_context_menu(e, tr))

        active_actions = ttk.Frame(active_frame)
        active_actions.grid(row=3, column=0, sticky="ew", pady=(7, 0))
        ttk.Button(
            active_actions, text="OPEN ON EBAY",
            command=self._open_selected_active_listing
        ).pack(side="left", padx=(0, 5))
        ttk.Button(
            active_actions, text="MARK REVIEWED",
            command=self._mark_selected_listing_reviewed
        ).pack(side="left", padx=5)
        ttk.Button(
            active_actions, text="SEND OFFER",
            command=self._send_offer_selected_listing,
        ).pack(side="left", padx=5)
        ttk.Button(
            active_actions, text="OFFER HISTORY",
            command=self._show_selected_buyer_offer_history,
        ).pack(side="left", padx=5)
        ttk.Button(
            active_actions, text="END LISTING",
            command=self._end_selected_active_listing,
            style="Danger.TButton",
        ).pack(side="left", padx=5)
        ttk.Button(
            active_actions, text="END SELECTED",
            command=self._bulk_end_selected_listings,
        ).pack(side="left", padx=5)
        ttk.Button(
            active_actions, text="SHOW IN REVAMP QUEUE",
            command=lambda: self.listings_notebook.select(self.revamp_tab),
        ).pack(side="left", padx=5)

        # Pagination controls. Only the current page's thumbnails are alive.
        pager = ttk.Frame(active_frame)
        pager.grid(row=4, column=0, sticky="ew", pady=(8, 0))
        pager.columnconfigure(3, weight=1)

        ttk.Button(
            pager, text="◀ PREVIOUS", command=self._listings_previous_page
        ).grid(row=0, column=0, padx=(0, 7))
        ttk.Button(
            pager, text="NEXT ▶", command=self._listings_next_page
        ).grid(row=0, column=1, padx=(0, 12))
        ttk.Label(
            pager, textvariable=self.listings_page_var,
            style="Subheader.TLabel"
        ).grid(row=0, column=2, sticky="w")

        ttk.Label(pager, text="Filter:").grid(
            row=0, column=4, sticky="e", padx=(10, 5)
        )
        filter_box = ttk.Combobox(
            pager,
            textvariable=self.listings_filter_var,
            values=(
                "All listings",
                "Offer eligible",
                "Older than 180 days",
                "No SKU",
                "Zero local stock",
                "Low stock (1-2)",
                "Stock mismatch",
            ),
            state="readonly",
            width=20,
        )
        filter_box.grid(row=0, column=5, sticky="e", padx=(0, 12))
        filter_box.bind(
            "<<ComboboxSelected>>",
            lambda _e: self._listing_filter_changed(),
        )

        ttk.Label(pager, text="Sort:").grid(
            row=0, column=6, sticky="e", padx=(10, 5)
        )
        sort_box = ttk.Combobox(
            pager,
            textvariable=self.listings_sort_var,
            values=(
                "Newest first",
                "Oldest first",
                "Price: high to low",
                "Price: low to high",
                "Quantity: high to low",
                "Quantity: low to high",
                "Title: A to Z",
                "Title: Z to A",
                "Offer eligible first",
            ),
            state="readonly",
            width=22,
        )
        sort_box.grid(row=0, column=7, sticky="e", padx=(0, 12))
        sort_box.bind(
            "<<ComboboxSelected>>",
            lambda _e: self._listing_sort_changed(),
        )

        ttk.Label(pager, text="Listings per page:").grid(
            row=0, column=8, sticky="e", padx=(10, 5)
        )
        page_size = ttk.Combobox(
            pager,
            textvariable=self.listings_page_size_var,
            values=("25", "50", "100"),
            state="readonly",
            width=6,
        )
        page_size.grid(row=0, column=9, sticky="e")
        page_size.bind(
            "<<ComboboxSelected>>",
            lambda _e: self._listings_page_size_changed(),
        )

        self._build_offer_eligible_tab()
        self._build_buyer_offer_history_tab()
        self._build_existing_tab()

    def _listing_age_days(self, start_time):
        raw = str(start_time or "").strip()
        if not raw:
            return None
        for fmt in (
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.000Z",
        ):
            try:
                # time.strptime has no %f support; strip fractional seconds first.
                candidate = raw
                actual_fmt = fmt
                if "%f" in fmt:
                    candidate = re.sub(r"\.\d+Z$", "Z", raw)
                    actual_fmt = "%Y-%m-%dT%H:%M:%SZ"
                started = time.mktime(time.strptime(candidate, actual_fmt))
                return max(0, int((time.time() - started) / 86400))
            except Exception:
                continue
        return None

    def _listing_local_map(self):
        con = self._inventory_connect()
        try:
            rows = con.execute(
                """SELECT * FROM inventory_items
                   WHERE parent_item_id IS NULL AND item_number IS NOT NULL
                   AND trim(item_number)<>'' ORDER BY id"""
            ).fetchall()
            return {str(r["item_number"]).strip(): dict(r) for r in rows}
        finally:
            con.close()

    def _listing_review_map(self):
        con = self._inventory_connect()
        try:
            return {
                str(r["item_number"]): str(r["reviewed_at"] or "")
                for r in con.execute("SELECT item_number,reviewed_at FROM listing_reviews")
            }
        finally:
            con.close()

    def _days_since_text_timestamp(self, raw):
        raw = str(raw or "").strip()
        if not raw:
            return None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                t = time.mktime(time.strptime(raw[:19] if "%H" in fmt else raw[:10], fmt))
                return max(0, int((time.time() - t) / 86400))
            except Exception:
                pass
        return None

    def _selected_active_listing_data(self):
        tree = getattr(self, "active_listings_tree", None)
        if tree is None:
            return None
        sel = tree.selection()
        if not sel:
            return None
        item_number = str(sel[0])
        for listing in self.active_listings_cache:
            if str(listing.get("item_number", "") or "") == item_number:
                return listing
        return None

    def _build_offer_eligible_tab(self):
        f = self.offer_eligible_tab
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        top.columnconfigure(3, weight=1)
        ttk.Label(
            top,
            text="Listings Eligible for Seller-Initiated Offers",
            style="Section.TLabel",
        ).grid(row=0, column=0, sticky="w", padx=(0, 12))
        ttk.Button(
            top, text="REFRESH ELIGIBILITY",
            command=self._refresh_offer_eligibility_only,
        ).grid(row=0, column=1, padx=(0, 8))
        ttk.Button(
            top, text="SEND OFFER",
            command=self._send_offer_from_eligible_tab,
            style="Primary.TButton",
        ).grid(row=0, column=2, padx=(0, 8))
        self.offer_eligible_status_var = tk.StringVar(
            value="Refresh Listings or eligibility to check interested buyers."
        )
        ttk.Label(
            top, textvariable=self.offer_eligible_status_var,
            style="Subheader.TLabel",
        ).grid(row=0, column=3, sticky="e")

        cols = ("item_number", "title", "price", "qty", "age", "location")
        tree = ttk.Treeview(
            f, columns=cols, show="headings", selectmode="browse"
        )
        self.offer_eligible_tree = tree
        heads = {
            "item_number": "ITEM #", "title": "TITLE", "price": "PRICE",
            "qty": "QTY", "age": "AGE (DAYS)", "location": "LOCATION",
        }
        widths = {
            "item_number": 125, "title": 460, "price": 90,
            "qty": 70, "age": 90, "location": 130,
        }
        for c in cols:
            tree.heading(
                c, text=heads[c],
                command=lambda col=c, tr=tree:
                    self._sort_treeview_column(tr, col),
            )
            tree.column(c, width=widths[c], anchor="w", stretch=(c == "title"))
        vs = ttk.Scrollbar(f, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(f, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=1, column=0, sticky="nsew")
        vs.grid(row=1, column=1, sticky="ns")
        hs.grid(row=2, column=0, sticky="ew")
        tree.bind("<Double-1>", lambda _e: self._send_offer_from_eligible_tab())

    def _populate_offer_eligible_tree(self):
        tree = getattr(self, "offer_eligible_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        local = self._listing_local_map()
        eligible = [
            x for x in self.active_listings_cache
            if str(x.get("item_number", "") or "") in self.offer_eligible_ids
        ]
        eligible.sort(key=lambda x: str(x.get("start_time", "") or ""))
        for listing in eligible:
            item_number = str(listing.get("item_number", "") or "")
            price = float(listing.get("price", 0) or 0)
            age = self._listing_age_days(listing.get("start_time"))
            location = str((local.get(item_number) or {}).get("location", "") or "")
            tree.insert(
                "", "end", iid=item_number,
                values=(
                    item_number, listing.get("title", ""),
                    f"${price:,.2f}" if price else "",
                    listing.get("quantity_available", ""),
                    "" if age is None else age,
                    location,
                ),
            )
        if hasattr(self, "offer_eligible_status_var"):
            self.offer_eligible_status_var.set(
                f"{len(eligible):,} listing(s) currently eligible."
            )

    def _selected_offer_eligible_listing(self):
        tree = getattr(self, "offer_eligible_tree", None)
        if tree is None:
            return None
        sel = tree.selection()
        if not sel:
            return None
        number = str(sel[0])
        return next(
            (
                x for x in self.active_listings_cache
                if str(x.get("item_number", "") or "") == number
            ),
            None,
        )

    def _send_offer_from_eligible_tab(self):
        listing = self._selected_offer_eligible_listing()
        if not listing:
            messagebox.showinfo("Offers", "Select an eligible listing first.", parent=self)
            return
        item_number = str(listing.get("item_number", "") or "")
        tree = getattr(self, "active_listings_tree", None)
        if tree is not None:
            # The item may be on another page. Temporarily filter the active view.
            self.listings_search_var.set(item_number)
            self.listings_page = 1
            self._populate_active_listings_tree()
            if tree.exists(item_number):
                tree.selection_set(item_number)
                tree.focus(item_number)
        self._send_offer_selected_listing()

    def _refresh_offer_eligibility_only(self):
        self._show_busy(
            "Refreshing Offer Eligibility",
            "Checking eBay for listings with interested buyers…",
            cancellable=True,
        )
        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                eligible = client.find_eligible_offer_items()
                self.offer_eligible_ids = set(eligible)
                self.after(0, self._populate_offer_eligible_tree)
                self.after(0, self._populate_active_listings_tree)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Offers", "Could not refresh offer eligibility.\n\n" + e,
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()
        threading.Thread(target=work, daemon=True).start()

    def _build_buyer_offer_history_tab(self):
        f = self.buyer_offer_history_tab
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(
            top,
            text="Seller-Initiated Buyer Offers",
            style="Section.TLabel",
        ).pack(side="left")
        ttk.Button(
            top,
            text="REFRESH LOCAL HISTORY",
            command=self._refresh_buyer_offer_history_table,
        ).pack(side="right")

        cols = (
            "sent", "listing", "title", "offer",
            "recipient", "status", "offer_id"
        )
        tree = ttk.Treeview(
            f, columns=cols, show="headings", selectmode="browse"
        )
        self.buyer_offer_history_tree = tree
        heads = {
            "sent": "SENT",
            "listing": "LISTING #",
            "title": "TITLE",
            "offer": "OFFER",
            "recipient": "RECIPIENT",
            "status": "STATUS",
            "offer_id": "OFFER ID",
        }
        widths = {
            "sent": 145, "listing": 125, "title": 330,
            "offer": 105, "recipient": 145, "status": 100,
            "offer_id": 145,
        }
        for c in cols:
            tree.heading(
                c, text=heads[c],
                command=lambda col=c, tr=tree:
                    self._sort_treeview_column(tr, col),
            )
            tree.column(
                c, width=widths[c], anchor="w",
                stretch=(c == "title"),
            )
        vs = ttk.Scrollbar(f, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(f, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=1, column=0, sticky="nsew")
        vs.grid(row=1, column=1, sticky="ns")
        hs.grid(row=2, column=0, sticky="ew")
        tree.bind(
            "<Double-1>",
            lambda _e: self._open_selected_buyer_offer_listing(),
        )
        self.after_idle(self._refresh_buyer_offer_history_table)

    def _buyer_offer_display(self, row):
        pct = row.get("discount_percentage")
        price = row.get("offer_price")
        currency = str(row.get("currency", "USD") or "USD")
        if pct not in (None, ""):
            return f"{pct}% off"
        if price not in (None, ""):
            try:
                return f"${float(price):,.2f}" + (
                    "" if currency == "USD" else f" {currency}"
                )
            except Exception:
                return str(price)
        return ""

    def _refresh_buyer_offer_history_table(self):
        tree = getattr(self, "buyer_offer_history_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        for n, row in enumerate(load_buyer_offer_history()):
            tree.insert(
                "", "end", iid=f"buyer_offer_{n}",
                values=(
                    row.get("creation_date") or row.get("sent_at", ""),
                    row.get("listing_id", ""),
                    row.get("title", ""),
                    self._buyer_offer_display(row),
                    row.get("buyer_reference", ""),
                    row.get("status", ""),
                    row.get("offer_id", ""),
                ),
            )

    def _open_selected_buyer_offer_listing(self):
        tree = getattr(self, "buyer_offer_history_tree", None)
        if tree is None:
            return
        sel = tree.selection()
        if not sel:
            return
        vals = tree.item(sel[0], "values") or ()
        listing_id = str(vals[1] or "") if len(vals) > 1 else ""
        if listing_id:
            webbrowser.open("https://www.ebay.com/itm/" + listing_id)

    def _show_selected_buyer_offer_history(self):
        listing = self._selected_active_listing_data()
        if not listing:
            messagebox.showinfo(
                "Buyer Offer History",
                "Select a listing first.",
                parent=self,
            )
            return
        listing_id = str(listing.get("item_number", "") or "")
        rows = [
            r for r in load_buyer_offer_history()
            if str(r.get("listing_id", "") or "") == listing_id
        ]

        win = tk.Toplevel(self)
        win.title("Buyer Offer History")
        win.transient(self)
        win.geometry("760x430")
        frame = ttk.Frame(win, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(
            frame,
            text=listing.get("title", "") or listing_id,
            style="Section.TLabel",
            wraplength=710,
        ).pack(anchor="w")
        ttk.Label(
            frame, text=f"Listing #: {listing_id}"
        ).pack(anchor="w", pady=(2, 8))

        if not rows:
            ttk.Label(
                frame,
                text=(
                    "No seller-initiated offers from this program "
                    "have been recorded for this listing yet."
                ),
            ).pack(anchor="w", pady=12)
            return

        cols = ("sent", "offer", "recipient", "status", "offer_id")
        tree = ttk.Treeview(
            frame, columns=cols, show="headings", height=12
        )
        for col, heading, width in (
            ("sent", "SENT", 145),
            ("offer", "OFFER", 100),
            ("recipient", "RECIPIENT", 145),
            ("status", "STATUS", 95),
            ("offer_id", "OFFER ID", 145),
        ):
            tree.heading(col, text=heading)
            tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        for row in rows:
            tree.insert(
                "", "end",
                values=(
                    row.get("creation_date") or row.get("sent_at", ""),
                    self._buyer_offer_display(row),
                    row.get("buyer_reference", ""),
                    row.get("status", ""),
                    row.get("offer_id", ""),
                ),
            )

    def _send_offer_selected_listing(self):
        listing = self._selected_active_listing_data()
        if not listing:
            messagebox.showinfo(
                "Send Offer", "Select a listing first.", parent=self
            )
            return

        listing_id = str(listing.get("item_number", "") or "")
        if listing_id not in self.offer_eligible_ids:
            messagebox.showinfo(
                "Send Offer",
                "eBay does not currently report this listing as eligible "
                "for a seller-initiated offer.\n\n"
                "Refresh Listings if buyer interest may have changed.",
                parent=self,
            )
            return

        original_price = float(listing.get("price", 0) or 0)
        win = tk.Toplevel(self)
        win.title("Send Offer to Interested Buyers")
        win.transient(self)
        win.resizable(False, False)
        win.grab_set()

        frame = ttk.Frame(win, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(1, weight=1)

        ttk.Label(
            frame,
            text=listing.get("title", "") or listing_id,
            style="Section.TLabel",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(
            frame,
            text=(
                f"Listing #: {listing_id}   •   "
                f"Current price: ${original_price:,.2f}"
            ),
        ).grid(
            row=1, column=0, columnspan=2,
            sticky="w", pady=(2, 12)
        )

        mode_var = tk.StringVar(value="percent")
        value_var = tk.StringVar(value="10")
        qty_var = tk.StringVar(value="1")
        counter_var = tk.BooleanVar(value=False)
        preview_var = tk.StringVar(value="")

        ttk.Radiobutton(
            frame, text="Percent discount",
            variable=mode_var, value="percent",
        ).grid(row=2, column=0, sticky="w", pady=3)
        ttk.Radiobutton(
            frame, text="Exact offer price",
            variable=mode_var, value="price",
        ).grid(row=3, column=0, sticky="w", pady=3)

        value_entry = ttk.Entry(
            frame, textvariable=value_var, width=16
        )
        value_entry.grid(
            row=2, column=1, rowspan=2,
            sticky="w", padx=(8, 0)
        )

        ttk.Label(frame, text="Quantity:").grid(
            row=4, column=0, sticky="w", pady=(10, 3)
        )
        ttk.Spinbox(
            frame, from_=1,
            to=max(1, int(listing.get("quantity_available", 1) or 1)),
            textvariable=qty_var, width=8,
        ).grid(row=4, column=1, sticky="w", padx=(8, 0), pady=(10, 3))

        ttk.Checkbutton(
            frame, text="Allow buyer counteroffers",
            variable=counter_var,
        ).grid(
            row=5, column=0, columnspan=2,
            sticky="w", pady=(4, 8)
        )

        ttk.Label(frame, text="Optional message:").grid(
            row=6, column=0, columnspan=2, sticky="w"
        )
        message_box = tk.Text(frame, height=4, width=58, wrap="word")
        message_box.grid(
            row=7, column=0, columnspan=2,
            sticky="ew", pady=(3, 8)
        )

        ttk.Label(
            frame, textvariable=preview_var,
            style="Subheader.TLabel",
        ).grid(
            row=8, column=0, columnspan=2,
            sticky="w", pady=(0, 10)
        )

        previous = [
            r for r in load_buyer_offer_history()
            if str(r.get("listing_id", "") or "") == listing_id
        ]
        previous_text = (
            f"Previous offers recorded for this listing: {len(previous)}"
        )
        if previous:
            previous_text += (
                "   •   Most recent: "
                + self._buyer_offer_display(previous[0])
            )
        ttk.Label(
            frame, text=previous_text, wraplength=500
        ).grid(
            row=9, column=0, columnspan=2,
            sticky="w", pady=(0, 10)
        )

        def update_preview(*_args):
            try:
                val = float(value_var.get())
                if mode_var.get() == "percent":
                    offer_price = original_price * (1 - val / 100)
                    preview_var.set(
                        f"Offer preview: {val:g}% off → "
                        f"${offer_price:,.2f} for 4 days"
                    )
                else:
                    preview_var.set(
                        f"Offer preview: ${val:,.2f} for 4 days"
                    )
            except Exception:
                preview_var.set("Enter a valid discount or price.")

        mode_var.trace_add("write", update_preview)
        value_var.trace_add("write", update_preview)
        update_preview()

        buttons = ttk.Frame(frame)
        buttons.grid(
            row=10, column=0, columnspan=2,
            sticky="e", pady=(4, 0)
        )

        def submit():
            try:
                val = float(value_var.get())
                qty = max(1, int(qty_var.get() or 1))
            except Exception:
                messagebox.showerror(
                    "Send Offer",
                    "Enter a valid offer value and quantity.",
                    parent=win,
                )
                return
            if val <= 0:
                messagebox.showerror(
                    "Send Offer",
                    "The offer value must be greater than zero.",
                    parent=win,
                )
                return

            if mode_var.get() == "percent":
                if val >= 100:
                    messagebox.showerror(
                        "Send Offer",
                        "The discount must be less than 100%.",
                        parent=win,
                    )
                    return
                discount = val
                exact_price = None
                offer_price = original_price * (1 - val / 100)
                confirm_offer = f"{val:g}% off (${offer_price:,.2f})"
            else:
                if original_price and val >= original_price:
                    messagebox.showerror(
                        "Send Offer",
                        "The offer price must be below the listing price.",
                        parent=win,
                    )
                    return
                discount = None
                exact_price = val
                confirm_offer = f"${val:,.2f}"

            text = message_box.get("1.0", "end").strip()
            allow_counter = bool(counter_var.get())

            if not messagebox.askyesno(
                "Send Offer",
                f"Send {confirm_offer} to all buyers eBay currently "
                f"considers eligible for this listing?\n\n"
                "eBay determines the recipients.",
                parent=win,
            ):
                return

            try:
                win.grab_release()
            except Exception:
                pass
            win.destroy()

            self._show_busy(
                "Sending Buyer Offer",
                f"Sending {confirm_offer} through eBay…",
                cancellable=False,
            )

            def work():
                try:
                    client = EbayClient(
                        self.settings.copy(),
                        self.cancel_event,
                        self._log,
                    )
                    response = client.send_offer_to_interested_buyers(
                        listing_id,
                        discount_percentage=discount,
                        price=exact_price,
                        quantity=qty,
                        message=text,
                        allow_counter_offer=allow_counter,
                    )
                    offers = response.get("offers", []) or []
                    now = datetime.now().astimezone().isoformat(
                        timespec="seconds"
                    )
                    history_rows = []
                    for offer in offers:
                        buyer = offer.get("buyer", {}) or {}
                        buyer_ref = str(
                            buyer.get("maskedUsername")
                            or buyer.get("immutableUserId")
                            or buyer.get("userId")
                            or ""
                        )
                        history_rows.append({
                            "listing_id": listing_id,
                            "title": listing.get("title", ""),
                            "original_price": original_price,
                            "discount_percentage": discount,
                            "offer_price": exact_price,
                            "currency": self.settings.get("currency", "USD"),
                            "quantity": qty,
                            "message": text,
                            "allow_counter_offer": allow_counter,
                            "duration_days": 4,
                            "offer_id": offer.get("offerId", ""),
                            "status": offer.get("offerStatus", "PENDING"),
                            "buyer_reference": buyer_ref,
                            "creation_date": offer.get("creationDate", now),
                            "sent_at": now,
                        })
                    if not history_rows:
                        history_rows.append({
                            "listing_id": listing_id,
                            "title": listing.get("title", ""),
                            "original_price": original_price,
                            "discount_percentage": discount,
                            "offer_price": exact_price,
                            "currency": self.settings.get("currency", "USD"),
                            "quantity": qty,
                            "message": text,
                            "allow_counter_offer": allow_counter,
                            "duration_days": 4,
                            "offer_id": "",
                            "status": "SENT",
                            "buyer_reference": "",
                            "creation_date": now,
                            "sent_at": now,
                        })

                    append_buyer_offer_history(history_rows)
                    self._audit(
                        "SEND BUYER OFFER",
                        f"listing={listing_id}; offer={confirm_offer}; recipients={len(offers)}",
                    )
                    try:
                        eligible = client.find_eligible_offer_items()
                        self.offer_eligible_ids = set(eligible)
                    except Exception:
                        self.offer_eligible_ids.discard(listing_id)

                    self.after(0, self._refresh_buyer_offer_history_table)
                    self.after(0, self._populate_active_listings_tree)
                    self.after(
                        0,
                        lambda: messagebox.showinfo(
                            "Send Offer",
                            f"Offer sent successfully.\n\n"
                            f"eBay returned {len(offers)} recipient "
                            f"offer record(s).",
                            parent=self,
                        ),
                    )
                except Exception as exc:
                    self.after(
                        0,
                        lambda e=str(exc): messagebox.showerror(
                            "Send Offer",
                            "eBay could not send the offer.\n\n" + e,
                            parent=self,
                        ),
                    )
                finally:
                    self._finish_busy_from_worker()

            threading.Thread(target=work, daemon=True).start()

        ttk.Button(
            buttons, text="CANCEL", command=win.destroy
        ).pack(side="right", padx=(6, 0))
        ttk.Button(
            buttons, text="SEND OFFER",
            command=submit, style="Primary.TButton",
        ).pack(side="right")
        value_entry.focus_set()

    def _refresh_listings_from_ebay(self):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME, "Another operation is already running.", parent=self)
            return
        self._save_settings_ui_silent()
        self.listings_status_var.set("Loading current active listings from eBay…")
        self._show_busy(
            "Refreshing Listings",
            "Loading current active listings from eBay and rebuilding listing views…",
            cancellable=True,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                active = client.get_all_active_listings()
                self.active_listings_cache = active
                try:
                    self._log(
                        "Checking active listings for interested buyers…"
                    )
                    eligible = client.find_eligible_offer_items()
                    self.offer_eligible_ids = set(eligible)
                    self._log(
                        f"Interested-buyer offers: "
                        f"{len(eligible):,} listing(s) currently eligible."
                    )
                except Exception as offer_exc:
                    self.offer_eligible_ids = set()
                    self._log(
                        "Interested-buyer eligibility check skipped: "
                        + str(offer_exc)
                    )
                self.listings_page = 1
                self.after(0, self._populate_active_listings_tree)
                self.after(0, self._populate_offer_eligible_tree)
                self.after(0, self._refresh_buyer_offer_history_table)
                self.after(0, self._populate_revamp_tree)
                self.after(0, self._refresh_dashboard)
                self.after(0, self._orders_refresh_view)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Listings", "Could not refresh current eBay listings.\n\n" + e,
                        parent=self,
                    ),
                )
                self.after(0, lambda: self.listings_status_var.set("Listing refresh failed."))
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()

    def _listing_filter_changed(self):
        self.listings_page = 1
        self._populate_active_listings_tree()

    def _listing_sort_changed(self):
        self.listings_page = 1
        self._populate_active_listings_tree()

    def _listing_search_changed(self):
        self.listings_page = 1
        self._populate_active_listings_tree()

    def _listings_page_size(self):
        try:
            return max(1, min(100, int(self.listings_page_size_var.get() or 25)))
        except Exception:
            return 25

    def _listings_filtered_rows(self):
        search = str(
            self.listings_search_var.get() or ""
        ).strip().casefold()
        local = self._listing_local_map()
        rows = []
        for listing in self.active_listings_cache:
            item_number = str(listing.get("item_number", "") or "")
            title = str(listing.get("title", "") or "")
            sku = str(listing.get("sku", "") or "")
            location = str(
                (local.get(item_number) or {}).get("location", "") or ""
            )
            hay = " ".join((item_number, title, sku, location)).casefold()
            if search and search not in hay:
                continue

            filter_name = str(
                self.listings_filter_var.get() or "All listings"
            )
            local_row = local.get(item_number) or {}
            try:
                local_stock = int(float(local_row.get("stock") or 0))
            except Exception:
                local_stock = 0
            try:
                ebay_qty = int(float(listing.get("quantity_available") or 0))
            except Exception:
                ebay_qty = 0
            age = self._listing_age_days(listing.get("start_time"))

            if filter_name == "Offer eligible" and item_number not in self.offer_eligible_ids:
                continue
            if filter_name == "Older than 180 days" and not (age is not None and age >= 180):
                continue
            if filter_name == "No SKU" and str(listing.get("sku", "") or "").strip():
                continue
            if filter_name == "Zero local stock" and local_stock != 0:
                continue
            if filter_name == "Low stock (1-2)" and local_stock not in (1, 2):
                continue
            if filter_name == "Stock mismatch" and ebay_qty == local_stock:
                continue

            rows.append((listing, location))

        sort_name = str(
            self.listings_sort_var.get() or "Newest first"
        )

        def start_ts(row):
            raw = str(row[0].get("start_time", "") or "")
            try:
                return datetime.fromisoformat(
                    raw.replace("Z", "+00:00")
                ).timestamp()
            except Exception:
                return 0

        if sort_name == "Newest first":
            rows.sort(key=start_ts, reverse=True)
        elif sort_name == "Oldest first":
            rows.sort(key=start_ts)
        elif sort_name == "Price: high to low":
            rows.sort(
                key=lambda r: float(r[0].get("price", 0) or 0),
                reverse=True,
            )
        elif sort_name == "Price: low to high":
            rows.sort(key=lambda r: float(r[0].get("price", 0) or 0))
        elif sort_name == "Quantity: high to low":
            rows.sort(
                key=lambda r: int(r[0].get("quantity_available", 0) or 0),
                reverse=True,
            )
        elif sort_name == "Quantity: low to high":
            rows.sort(
                key=lambda r: int(r[0].get("quantity_available", 0) or 0)
            )
        elif sort_name == "Title: A to Z":
            rows.sort(
                key=lambda r: str(r[0].get("title", "") or "").casefold()
            )
        elif sort_name == "Title: Z to A":
            rows.sort(
                key=lambda r: str(r[0].get("title", "") or "").casefold(),
                reverse=True,
            )
        elif sort_name == "Offer eligible first":
            rows.sort(
                key=lambda r: (
                    str(r[0].get("item_number", "") or "")
                    not in self.offer_eligible_ids,
                    -start_ts(r),
                )
            )
        return rows

    def _listings_page_size_changed(self):
        self.listings_page = 1
        self._populate_active_listings_tree()

    def _listings_previous_page(self):
        if self.listings_page > 1:
            self.listings_page -= 1
            self._populate_active_listings_tree()

    def _listings_next_page(self):
        total = len(self._listings_filtered_rows())
        page_size = self._listings_page_size()
        pages = max(1, (total + page_size - 1) // page_size)
        if self.listings_page < pages:
            self.listings_page += 1
            self._populate_active_listings_tree()

    def _listing_thumb_cache_path(self, url):
        if not url:
            return None
        IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        name = uuid.uuid5(uuid.NAMESPACE_URL, str(url)).hex + ".jpg"
        return IMAGE_CACHE_DIR / ("listing_" + name)

    def _listing_load_thumbnail_worker(self, item_number, url, generation):
        if not url:
            return
        with self._listing_thumb_semaphore:
            try:
                cache_path = self._listing_thumb_cache_path(url)
                if cache_path is None:
                    return

                image = None
                if cache_path.exists():
                    try:
                        image = Image.open(cache_path).convert("RGB")
                    except Exception:
                        image = None

                if image is None:
                    req = request.Request(
                        url,
                        headers={"User-Agent": "Mozilla/5.0 TradeComponents/1.0"},
                    )
                    with request.urlopen(req, timeout=20) as resp:
                        raw = resp.read()
                    import io
                    image = Image.open(io.BytesIO(raw)).convert("RGB")
                    try:
                        image.save(cache_path, "JPEG", quality=82, optimize=True)
                    except Exception:
                        pass

                image.thumbnail((92, 72), Image.Resampling.LANCZOS)
                self.after(
                    0,
                    lambda im=image.copy(), iid=str(item_number), gen=generation:
                        self._listing_apply_thumbnail(iid, im, gen)
                )
            except Exception as exc:
                self._log(
                    f"LISTING THUMBNAIL WARNING {item_number}: {exc}"
                )

    def _listing_apply_thumbnail(self, item_number, pil_image, generation):
        if generation != self._listing_thumb_generation:
            return
        tree = getattr(self, "active_listings_tree", None)
        if tree is None or not tree.exists(str(item_number)):
            return
        try:
            photo = ImageTk.PhotoImage(pil_image)
            self._listing_thumb_refs[str(item_number)] = photo
            tree.item(str(item_number), image=photo)
        except Exception as exc:
            self._log(
                f"LISTING THUMBNAIL DISPLAY WARNING {item_number}: {exc}"
            )

    def _listing_queue_thumbnail(self, item_number, url, generation):
        if not url:
            return
        threading.Thread(
            target=self._listing_load_thumbnail_worker,
            args=(str(item_number), str(url), generation),
            daemon=True,
        ).start()

    def _populate_active_listings_tree(self):
        tree = getattr(self, "active_listings_tree", None)
        if tree is None:
            return

        # Invalidate thumbnail callbacks from the previous page.
        self._listing_thumb_generation += 1
        generation = self._listing_thumb_generation
        self._listing_thumb_refs.clear()
        tree.delete(*tree.get_children())

        rows = self._listings_filtered_rows()
        total_filtered = len(rows)
        page_size = self._listings_page_size()
        total_pages = max(1, (total_filtered + page_size - 1) // page_size)
        self.listings_page = max(1, min(self.listings_page, total_pages))

        start_index = (self.listings_page - 1) * page_size
        end_index = min(start_index + page_size, total_filtered)
        page_rows = rows[start_index:end_index]

        for listing, location in page_rows:
            item_number = str(listing.get("item_number", "") or "")
            title = str(listing.get("title", "") or "")
            sku = str(listing.get("sku", "") or "")
            age = self._listing_age_days(listing.get("start_time"))
            price = float(listing.get("price", 0) or 0)

            vals = (
                item_number,
                title,
                sku,
                listing.get("quantity_available", ""),
                f"${price:,.2f}" if price else "",
                "" if age is None else age,
                listing.get("picture_count", ""),
                "ELIGIBLE" if item_number in self.offer_eligible_ids else "",
                location,
            )
            tree.insert(
                "", "end",
                iid=item_number,
                text="",
                values=vals,
            )

        self._reapply_treeview_sort(tree)

        # Load only the images visible on the current page, after the text rows
        # are already rendered so the UI remains responsive.
        for listing, _location in page_rows:
            item_number = str(listing.get("item_number", "") or "")
            url = str(listing.get("primary_picture_url", "") or "")
            if item_number and url:
                self._listing_queue_thumbnail(item_number, url, generation)

        self.listings_page_var.set(
            f"Page {self.listings_page:,} of {total_pages:,}"
        )
        if total_filtered:
            self.listings_status_var.set(
                f"Showing listings {start_index + 1:,}–{end_index:,} of "
                f"{total_filtered:,} matching listings "
                f"({len(self.active_listings_cache):,} active total)."
            )
        else:
            self.listings_status_var.set(
                f"No listings match the current search "
                f"({len(self.active_listings_cache):,} active total)."
            )

    def _selected_active_listing_number(self, tree=None):
        tree = tree or getattr(self, "active_listings_tree", None)
        if tree is None:
            return ""
        sel = tree.selection()
        return str(sel[0]) if sel else ""

    def _open_selected_active_listing(self, tree=None):
        item_number = self._selected_active_listing_number(tree)
        if not item_number:
            return
        webbrowser.open(f"https://www.ebay.com/itm/{item_number}")


    def _end_ebay_listing(self, item_number, title=""):
        item_number = str(item_number or "").strip()
        if not item_number:
            messagebox.showinfo("End Listing", "Select a listing first.", parent=self)
            return

        title = str(title or "").strip()
        display = title or next(
            (
                str(x.get("title", "") or "")
                for x in self.active_listings_cache
                if str(x.get("item_number", "") or "") == item_number
            ),
            "",
        )

        if not messagebox.askyesno(
            "End eBay Listing",
            "End this eBay listing now?\n\n"
            f"{display}\n"
            f"Item #: {item_number}\n\n"
            "This removes the listing from eBay's active listings. It does NOT "
            "mark the inventory as sold and it does not delete the local inventory row.",
            parent=self,
        ):
            return

        self._save_settings_ui_silent()
        self._show_busy(
            "Ending Listing",
            f"Ending eBay listing {item_number} and updating local inventory status…",
            cancellable=False,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                client.end_active_listing(item_number, reason="NotAvailable")

                # If the exact listing has a local record, keep the inventory but
                # stop treating it as LISTED.
                con = self._inventory_connect()
                try:
                    rows = con.execute(
                        """SELECT id,status,location FROM inventory_items
                           WHERE parent_item_id IS NULL
                             AND trim(COALESCE(item_number,''))=?""",
                        (item_number,),
                    ).fetchall()
                    for r in rows:
                        if str(r["status"] or "").upper() == "LISTED":
                            new_status = "MASTER" if str(r["location"] or "").strip() else "PENDING_LOCATION"
                            con.execute(
                                "UPDATE inventory_items SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                                (new_status, r["id"]),
                            )
                    # Any Needs Attention issue tied to this now-ended listing
                    # is no longer actionable as an active-listing problem.
                    con.execute(
                        """UPDATE attention_issues
                           SET state='RESOLVED', last_seen=CURRENT_TIMESTAMP
                           WHERE trim(COALESCE(item_number,''))=? AND state<>'RESOLVED'""",
                        (item_number,),
                    )
                    con.commit()
                finally:
                    con.close()

                # Remove immediately from the local active cache, then refresh the
                # surrounding views. A normal sync will verify with eBay afterward.
                self._audit("END LISTING", item_number)
                self.active_listings_cache = [
                    x for x in self.active_listings_cache
                    if str(x.get("item_number", "") or "") != item_number
                ]
                self.after(0, self._populate_active_listings_tree)
                self.after(0, self._populate_revamp_tree)
                self.after(0, self._inventory_refresh_all)
                self.after(0, self._refresh_attention_trees)
                self.after(0, self._refresh_dashboard)
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        "End Listing",
                        f"eBay listing {item_number} was ended successfully.",
                        parent=self,
                    ),
                )
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "End Listing",
                        "The listing could not be ended.\n\n" + e,
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()

    def _bulk_end_selected_listings(self):
        tree = getattr(self, "active_listings_tree", None)
        if tree is None:
            return
        selected = [str(x) for x in tree.selection()]
        if len(selected) < 2:
            return self._end_selected_active_listing(tree)
        if not messagebox.askyesno(
            "End Selected Listings",
            f"End {len(selected)} selected eBay listings?\n\n"
            "Inventory rows will remain local and will not be marked sold.",
            parent=self,
        ):
            return
        self._show_busy(
            "Ending Selected Listings",
            f"Preparing to end {len(selected)} listings…",
            cancellable=True,
        )
        def work():
            ended = []
            failed = []
            client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
            try:
                for n, item_number in enumerate(selected, 1):
                    if self.cancel_event.is_set():
                        break
                    self._log(f"Bulk end {n}/{len(selected)}: {item_number}")
                    try:
                        client.end_active_listing(item_number, reason="NotAvailable")
                        ended.append(item_number)
                        self._audit("END LISTING", item_number)
                    except Exception as exc:
                        failed.append((item_number, str(exc)))
                if ended:
                    con = self._inventory_connect()
                    try:
                        for item_number in ended:
                            con.execute(
                                """UPDATE inventory_items
                                   SET status=CASE
                                       WHEN trim(COALESCE(location,''))<>'' THEN 'MASTER'
                                       ELSE 'PENDING_LOCATION' END,
                                       updated_at=CURRENT_TIMESTAMP
                                   WHERE parent_item_id IS NULL
                                     AND item_number=?
                                     AND status='LISTED'""",
                                (item_number,),
                            )
                        con.commit()
                    finally:
                        con.close()
                    self.active_listings_cache = [
                        x for x in self.active_listings_cache
                        if str(x.get("item_number", "") or "") not in set(ended)
                    ]
                self.after(0, self._populate_active_listings_tree)
                self.after(0, self._populate_revamp_tree)
                self.after(0, self._inventory_refresh_all)
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        "End Selected Listings",
                        f"Ended: {len(ended)}\nFailed: {len(failed)}",
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()
        threading.Thread(target=work, daemon=True).start()

    def _end_selected_active_listing(self, tree=None):
        tree = tree or getattr(self, "active_listings_tree", None)
        item_number = self._selected_active_listing_number(tree)
        if not item_number:
            messagebox.showinfo("End Listing", "Select a listing first.", parent=self)
            return
        title = ""
        try:
            vals = tree.item(item_number, "values")
            if vals and len(vals) > 1:
                title = str(vals[1])
        except Exception:
            pass
        self._end_ebay_listing(item_number, title)

    def _active_listing_context_menu(self, event, tree):
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
        item_number = self._selected_active_listing_number(tree)
        if not item_number:
            return "break"
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(
            label="Open on eBay",
            command=lambda: self._open_selected_active_listing(tree),
        )
        menu.add_command(
            label="Send Offer to Interested Buyers",
            command=self._send_offer_selected_listing,
        )
        menu.add_command(
            label="Buyer Offer History",
            command=self._show_selected_buyer_offer_history,
        )
        menu.add_command(
            label="Jump to Inventory Item",
            command=lambda n=item_number: self._inventory_jump_to_item(item_number=n),
        )
        menu.add_separator()
        menu.add_command(
            label="End eBay Listing…",
            command=lambda: self._end_selected_active_listing(tree),
        )
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _mark_selected_listing_reviewed(self, tree=None):
        tree = tree or getattr(self, "active_listings_tree", None)
        if tree is None:
            return
        selected = [str(x) for x in tree.selection()]
        if not selected:
            messagebox.showinfo("Listings", "Select at least one listing first.", parent=self)
            return
        con = self._inventory_connect()
        try:
            for item_number in selected:
                con.execute(
                    """INSERT INTO listing_reviews(item_number,reviewed_at,note)
                       VALUES(?,CURRENT_TIMESTAMP,'')
                       ON CONFLICT(item_number)
                       DO UPDATE SET reviewed_at=CURRENT_TIMESTAMP""",
                    (item_number,),
                )
            con.commit()
        finally:
            con.close()
        self._audit("MARK REVIEWED", f"{len(selected)} listing(s)")
        self._populate_revamp_tree()
        self._refresh_dashboard()

    def _build_revamp_tab(self):
        outer = self.revamp_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 7))
        top.columnconfigure(4, weight=1)
        ttk.Label(top, text="Revamp Queue", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 14)
        )
        ttk.Label(top, text="Flag age:").grid(row=0, column=1, sticky="e")
        age_box = ttk.Combobox(
            top, textvariable=self.revamp_age_var,
            values=("90", "180", "270", "365", "540", "730"),
            width=7, state="readonly",
        )
        age_box.grid(row=0, column=2, padx=(5, 10))
        age_box.bind("<<ComboboxSelected>>", lambda _e: self._populate_revamp_tree())
        ttk.Label(top, text="Search:").grid(row=0, column=3, sticky="e")
        ent = ttk.Entry(top, textvariable=self.revamp_search_var, width=30)
        ent.grid(row=0, column=4, sticky="e", padx=(5, 7))
        ent.bind("<KeyRelease>", lambda _e: self._populate_revamp_tree())
        ttk.Button(
            top, text="REFRESH FROM EBAY", command=self._refresh_listings_from_ebay
        ).grid(row=0, column=5)

        ttk.Label(
            outer,
            textvariable=self.revamp_status_var,
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="ew", pady=(0, 6))

        cols = ("priority", "item_number", "title", "age", "price", "qty", "location", "reasons")
        tree = ttk.Treeview(outer, columns=cols, show="headings", selectmode="browse")
        self.revamp_tree = tree
        heads = {
            "priority": "PRIORITY", "item_number": "ITEM #", "title": "TITLE",
            "age": "AGE", "price": "PRICE", "qty": "QTY", "location": "LOCATION",
            "reasons": "WHY IT NEEDS WORK",
        }
        widths = {
            "priority": 75, "item_number": 120, "title": 350, "age": 70,
            "price": 85, "qty": 60, "location": 115, "reasons": 450,
        }
        for c in cols:
            tree.heading(
                c, text=heads[c],
                command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col),
            )
            tree.column(c, width=widths[c], anchor="w", stretch=(c in ("title", "reasons")))
        vs = ttk.Scrollbar(outer, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(outer, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=2, column=0, sticky="nsew")
        vs.grid(row=2, column=1, sticky="ns")
        hs.grid(row=3, column=0, sticky="ew")
        tree.tag_configure("HIGH", background="#f3cccc")
        tree.tag_configure("MEDIUM", background="#f5e4bd")
        tree.tag_configure("LOW", background="#e7eef6")
        tree.bind("<Double-1>", lambda _e: self._open_selected_active_listing(self.revamp_tree))
        tree.bind("<Button-3>", lambda e, tr=tree: self._active_listing_context_menu(e, tr))

        actions = ttk.Frame(outer)
        actions.grid(row=4, column=0, sticky="ew", pady=(7, 0))
        ttk.Button(
            actions, text="OPEN ON EBAY",
            command=lambda: self._open_selected_active_listing(self.revamp_tree)
        ).pack(side="left", padx=(0, 5))
        ttk.Button(
            actions, text="MARK REVIEWED",
            command=lambda: self._mark_selected_listing_reviewed(self.revamp_tree)
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="EDIT / REVAMP",
            command=self._revamp_edit_selected
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="END LISTING",
            command=lambda: self._end_selected_active_listing(self.revamp_tree),
            style="Danger.TButton",
        ).pack(side="left", padx=5)

    def _compute_revamp_rows(self, active):
        if not active:
            return []
        local = self._listing_local_map()
        reviews = self._listing_review_map()
        try:
            age_threshold = max(1, int(self.revamp_age_var.get() or 180))
        except Exception:
            age_threshold = 180

        rows = []
        for listing in active:
            item_number = str(listing.get("item_number", "") or "")
            title = str(listing.get("title", "") or "")
            sku = str(listing.get("sku", "") or "")
            age = self._listing_age_days(listing.get("start_time"))
            reviewed_days = self._days_since_text_timestamp(reviews.get(item_number, ""))
            local_row = local.get(item_number)
            location = str((local_row or {}).get("location", "") or "")
            reasons = []
            high = False
            medium = False

            effective_age = reviewed_days if reviewed_days is not None else age
            if effective_age is not None and effective_age >= age_threshold:
                if reviewed_days is not None:
                    reasons.append(f"Last reviewed {effective_age} days ago")
                else:
                    reasons.append(f"Listing is {effective_age} days old / no app review recorded")
                medium = True
                if effective_age >= 365:
                    high = True

            if not local_row:
                reasons.append("Active listing is missing from local inventory")
                high = True
            else:
                try:
                    local_stock = int(float(local_row.get("stock") or 0))
                    ebay_qty = int(float(listing.get("quantity_available") or 0))
                    if local_stock != ebay_qty:
                        reasons.append(f"Stock mismatch: local {local_stock} vs eBay {ebay_qty}")
                        high = True
                except Exception:
                    pass
                if not location:
                    reasons.append("No physical inventory location")
                    high = True

            raw_pictures = listing.get("picture_count", None)
            if raw_pictures is not None:
                try:
                    pictures = int(raw_pictures)
                except Exception:
                    pictures = None
                if pictures is not None and pictures < 4:
                    reasons.append(f"Only {pictures} listing photo(s)")
            if len(title.strip()) < 45:
                reasons.append("Title is short and may have room for better keywords")
            if not sku:
                reasons.append("No SKU / Custom Label")
            if not float(listing.get("price", 0) or 0):
                reasons.append("No current price returned")
                high = True

            if not reasons:
                continue
            priority = "HIGH" if high else ("MEDIUM" if medium else "LOW")
            rows.append({
                "priority": priority,
                "item_number": item_number,
                "title": title,
                "age": age,
                "price": float(listing.get("price", 0) or 0),
                "qty": listing.get("quantity_available", ""),
                "location": location,
                "reasons": "; ".join(reasons),
            })
        rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        rows.sort(key=lambda r: (rank.get(r["priority"], 9), -(r["age"] or 0), r["title"].casefold()))
        return rows

    def _populate_revamp_tree(self):
        tree = getattr(self, "revamp_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        rows = self._compute_revamp_rows(self.active_listings_cache)
        search = str(self.revamp_search_var.get() or "").strip().casefold()
        shown = 0
        for row in rows:
            hay = " ".join(
                str(row.get(k, "") or "")
                for k in ("item_number", "title", "location", "reasons", "priority")
            ).casefold()
            if search and search not in hay:
                continue
            vals = (
                row["priority"], row["item_number"], row["title"],
                "" if row["age"] is None else row["age"],
                f"${row['price']:,.2f}" if row["price"] else "",
                row["qty"], row["location"], row["reasons"],
            )
            tree.insert(
                "", "end", iid=row["item_number"], values=vals,
                tags=(row["priority"],)
            )
            shown += 1
        self._reapply_treeview_sort(tree)
        self.revamp_status_var.set(
            f"{shown:,} listing(s) currently have at least one revamp reason. "
            "MARK REVIEWED resets the age-based reminder without changing the eBay listing."
        )
        self._refresh_dashboard()

    def _revamp_edit_selected(self):
        item_number = self._selected_active_listing_number(self.revamp_tree)
        if not item_number:
            return
        # The Inventory API editor cannot always edit legacy Seller Hub listings,
        # so open the listing and the Edit Existing page together.
        webbrowser.open(f"https://www.ebay.com/itm/{item_number}")
        try:
            self._select_top_tab(self.listings_tab)
            self.listings_notebook.select(self.existing_tab)
        except Exception:
            pass


    def _build_messages_tab(self):
        outer = self.messages_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 7))
        top.columnconfigure(7, weight=1)
        ttk.Label(top, text="Messages", style="Header.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 12))
        ttk.Button(top, text="REFRESH FROM EBAY", command=self._refresh_messages_from_ebay).grid(row=0, column=1, padx=(0, 8))
        ttk.Label(top, text="Days:").grid(row=0, column=2)
        combo = ttk.Combobox(top, textvariable=self.messages_days_var,
                             values=("7","14","30","60","90","180","365"),
                             width=6, state="readonly")
        combo.grid(row=0, column=3, padx=(4, 10))
        combo.bind("<<ComboboxSelected>>", lambda _e: self._refresh_messages_view())
        ttk.Label(top, textvariable=self.messages_unread_var).grid(row=0, column=4, padx=(0, 10))
        ttk.Label(top, text="Search:").grid(row=0, column=5)
        ent = ttk.Entry(top, textvariable=self.messages_search_var, width=28)
        ent.grid(row=0, column=6, padx=(4, 0), sticky="e")
        ent.bind("<KeyRelease>", lambda _e: self._refresh_messages_view())

        ttk.Label(outer, textvariable=self.messages_status_var, style="Subheader.TLabel").grid(
            row=1, column=0, sticky="ew", pady=(0, 6)
        )

        paned = ttk.Panedwindow(outer, orient="horizontal")
        paned.grid(row=2, column=0, sticky="nsew")
        left = ttk.Frame(paned, padding=4)
        right = ttk.Frame(paned, padding=8)
        paned.add(left, weight=2)
        paned.add(right, weight=3)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(3, weight=1)

        cols = ("updated", "status", "sender", "item_number", "item_title")
        tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        self.messages_tree = tree
        heads = {
            "updated":"UPDATED", "status":"STATUS", "sender":"BUYER",
            "item_number":"ITEM #", "item_title":"ITEM",
        }
        widths = {"updated":145, "status":90, "sender":145, "item_number":120, "item_title":360}
        for c in cols:
            tree.heading(c, text=heads[c], command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col))
            tree.column(c, width=widths[c], minwidth=60, anchor="w", stretch=False)
        vs = ttk.Scrollbar(left, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(left, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        tree.tag_configure("unread", background="#e7f0fb")
        tree.bind("<<TreeviewSelect>>", lambda _e: self._messages_show_selected())
        tree.bind("<Double-1>", self._messages_double_click)
        tree.bind("<Button-3>", lambda e, tr=tree: self._messages_context_menu(e, tr))
        tree.bind("<Shift-MouseWheel>",
                  lambda e, tr=tree: tr.xview_scroll(int(-1 * (e.delta / 120)), "units"))

        self.message_subject_var = tk.StringVar(value="Select a conversation")
        self.message_meta_var = tk.StringVar(value="")
        ttk.Label(right, textvariable=self.message_subject_var, style="Section.TLabel").grid(
            row=0, column=0, sticky="ew"
        )
        ttk.Label(right, textvariable=self.message_meta_var, wraplength=540, justify="left").grid(
            row=1, column=0, sticky="ew", pady=(4, 8)
        )

        actions = ttk.Frame(right)
        actions.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(actions, text="REPLY", command=self._messages_reply_selected).pack(side="left", padx=(0, 5))
        ttk.Button(actions, text="DELETE", command=self._messages_delete_selected).pack(side="left", padx=5)
        ttk.Button(actions, text="OPEN EBAY ITEM", command=self._messages_open_item).pack(side="left", padx=5)
        ttk.Button(actions, text="JUMP TO INVENTORY", command=self._messages_jump_inventory).pack(side="left", padx=5)

        chat_wrap = ttk.Frame(right)
        chat_wrap.grid(row=3, column=0, sticky="nsew")
        chat_wrap.columnconfigure(0, weight=1)
        chat_wrap.rowconfigure(0, weight=1)
        self.message_chat_canvas = tk.Canvas(chat_wrap, highlightthickness=0, borderwidth=0, background="#f7f7f7")
        chat_scroll = ttk.Scrollbar(chat_wrap, orient="vertical", command=self.message_chat_canvas.yview)
        self.message_chat_canvas.configure(yscrollcommand=chat_scroll.set)
        self.message_chat_canvas.grid(row=0, column=0, sticky="nsew")
        chat_scroll.grid(row=0, column=1, sticky="ns")

        self.message_chat_frame = tk.Frame(self.message_chat_canvas, background="#f7f7f7")
        self._message_chat_window = self.message_chat_canvas.create_window(
            (0, 0), window=self.message_chat_frame, anchor="nw"
        )
        self.message_chat_frame.bind(
            "<Configure>",
            lambda _e: self.message_chat_canvas.configure(
                scrollregion=self.message_chat_canvas.bbox("all")
            ),
        )
        self.message_chat_canvas.bind(
            "<Configure>",
            lambda e: self.message_chat_canvas.itemconfigure(self._message_chat_window, width=e.width),
        )
        self.message_chat_canvas.bind("<MouseWheel>", self._message_chat_scroll)

    def _message_plain_text(self, value):
        raw = str(value or "")
        if not raw:
            return ""
        for _ in range(3):
            decoded = html.unescape(raw)
            if decoded == raw:
                break
            raw = decoded

        from html.parser import HTMLParser

        class _VisibleTextParser(HTMLParser):
            def __init__(self):
                super().__init__(convert_charrefs=True)
                self.hidden = 0
                self.parts = []
            def handle_starttag(self, tag, attrs):
                tag = str(tag or "").casefold()
                if tag in {"style","script","head","template","svg"}:
                    self.hidden += 1
                elif not self.hidden and tag in {"br","p","div","li","tr","table","section","article"}:
                    self.parts.append("\n")
            def handle_endtag(self, tag):
                tag = str(tag or "").casefold()
                if tag in {"style","script","head","template","svg"}:
                    self.hidden = max(0, self.hidden - 1)
                elif not self.hidden and tag in {"p","div","li","tr","table","section","article"}:
                    self.parts.append("\n")
            def handle_data(self, data):
                if not self.hidden and data:
                    self.parts.append(data)

        parser = _VisibleTextParser()
        try:
            parser.feed(raw)
            parser.close()
            plain = "".join(parser.parts)
        except Exception:
            plain = raw

        lines = []
        for line in plain.replace("\r", "").split("\n"):
            line = re.sub(r"[ \t]+", " ", line).strip()
            if line:
                lines.append(line)
        return "\n".join(lines).strip()

    def _message_source_text(self, msg):
        """Choose the fullest eBay message payload available for display."""
        if not isinstance(msg, dict):
            return str(msg or "")
        primary = str(msg.get("text", "") or "")
        html_text = str(msg.get("html_text", "") or "")
        content = str(msg.get("content", "") or "")

        # Prefer the HTML/Text payload when it is materially longer; eBay's
        # Content field can be a shortened preview ending in an ellipsis.
        candidates = [primary, html_text, content]
        candidates = [c for c in candidates if c]
        if not candidates:
            return ""
        return max(candidates, key=len)

    def _message_payload_candidates(self, msg):
        """Return distinct eBay body variants, longest first."""
        if not isinstance(msg, dict):
            return [str(msg or "")]
        seen = set()
        candidates = []
        for key in ("html_text", "text", "content"):
            value = str(msg.get(key, "") or "")
            if not value:
                continue
            norm = value.strip()
            if norm and norm not in seen:
                seen.add(norm)
                candidates.append(norm)
        candidates.sort(key=len, reverse=True)
        return candidates

    def _best_primary_message_text(self, msg):
        """
        Return the complete buyer-written message when GetMemberMessages supplied
        it; otherwise fall back to parsing the My Messages template.
        """
        if isinstance(msg, dict):
            member_body = str(msg.get("member_body", "") or "").strip()
            if member_body:
                return member_body

        best = ""
        for payload in self._message_payload_candidates(msg):
            candidate = self._message_primary_text(payload)
            if not candidate:
                continue
            truncated = (
                candidate.rstrip().endswith("...")
                or candidate.rstrip().endswith("…")
                or "[...]" in candidate
            )
            best_truncated = (
                best.rstrip().endswith("...")
                or best.rstrip().endswith("…")
                or "[...]" in best
            ) if best else True
            if not best or (best_truncated and not truncated) or (
                truncated == best_truncated and len(candidate) > len(best)
            ):
                best = candidate
        return best

    def _collapse_repeated_message_block(self, value):
        """Collapse an exact repeated paragraph/block accidentally duplicated by eBay."""
        text = str(value or "").strip()
        if not text:
            return ""
        lines = [x.rstrip() for x in text.splitlines()]
        n = len(lines)

        # Exact repeated halves are common in eBay's quoted seller section.
        if n >= 2 and n % 2 == 0:
            half = n // 2
            left = [x.strip().casefold() for x in lines[:half]]
            right = [x.strip().casefold() for x in lines[half:]]
            if left == right:
                return "\n".join(lines[:half]).strip()

        # Also catch repeated multi-line prefixes before a signature/template edge.
        for size in range(n // 2, 1, -1):
            first = [x.strip().casefold() for x in lines[:size]]
            second = [x.strip().casefold() for x in lines[size:size * 2]]
            if len(second) == size and first == second:
                return "\n".join(lines[:size] + lines[size * 2:]).strip()

        return text

    def _best_previous_reply_text(self, msg):
        """
        Return the seller response attached to GetMemberMessages when available;
        otherwise parse the quoted "Your previous message" template section.
        """
        if isinstance(msg, dict):
            responses = [
                str(x or "").strip()
                for x in (msg.get("member_responses", []) or [])
                if str(x or "").strip()
            ]
            if responses:
                # A single exchange can technically contain multiple responses.
                # Render them as one seller bubble, without duplicate copies.
                clean = []
                seen = set()
                for response in responses:
                    normalized = re.sub(r"\s+", " ", response).strip().casefold()
                    if normalized and normalized not in seen:
                        seen.add(normalized)
                        clean.append(response)
                if clean:
                    return "\n\n".join(clean)

        best = ""
        for payload in self._message_payload_candidates(msg):
            candidate = self._collapse_repeated_message_block(
                self._message_previous_reply(payload)
            )
            if not candidate:
                continue
            if not best or len(candidate) > len(best):
                best = candidate
        return best

    def _message_section_lines(self, value):
        plain = self._message_plain_text(value)
        return [re.sub(r"\s+", " ", x).strip() for x in plain.splitlines() if x.strip()]

    def _message_is_template_marker(self, line):
        low = str(line or "").strip().casefold().rstrip(":")
        if low in {
            "new message", "new message from", "your previous message",
            "previous message", "reply", "make an offer", "view item",
            "respond now", "message from", "seller message", "buyer message",
        }:
            return True
        if low.startswith("item id") or low.startswith("ebay item number") or low.startswith("message id"):
            return True
        return False

    def _extract_message_section(self, value, heading):
        lines = self._message_section_lines(value)
        wanted = heading.casefold().rstrip(":")
        start_index = None
        for i, line in enumerate(lines):
            normalized = line.casefold().rstrip(":")
            if normalized == wanted:
                start_index = i + 1
                break
        if start_index is None:
            return ""

        collected = []
        for line in lines[start_index:]:
            low = line.casefold().rstrip(":")
            if self._message_is_template_marker(line):
                break
            if re.fullmatch(r"\(\d+\)", line):
                continue
            if wanted == "your previous message" and low.startswith("dear "):
                continue
            collected.append(line)
        return "\n".join(collected).strip()

    def _message_primary_text(self, value):
        section = self._extract_message_section(value, "New message")
        if section:
            return section
        lines = self._message_section_lines(value)
        collected = []
        for line in lines:
            if self._message_is_template_marker(line):
                if collected:
                    break
                continue
            if line.casefold().startswith("dear "):
                continue
            collected.append(line)
        return "\n".join(collected).strip()

    def _message_previous_reply(self, value):
        """
        Extract only the most recent seller-written reply quoted by eBay.
        Stop before usernames, buyer text, or older quoted transcript content.
        """
        lines = self._message_section_lines(value)
        start_index = None
        for i, line in enumerate(lines):
            if line.casefold().rstrip(":") == "your previous message":
                start_index = i + 1
                break
        if start_index is None:
            return ""

        seller = str(self.settings.get("ebay_user_id", "") or "").strip().casefold()
        collected = []
        for line in lines[start_index:]:
            stripped = line.strip()
            low = stripped.casefold().rstrip(":")

            if self._message_is_template_marker(stripped):
                break
            if low.startswith("dear "):
                continue
            if re.fullmatch(r"\(\d+\)", stripped):
                continue

            simple_user = bool(re.fullmatch(r"-?\s*[A-Za-z0-9_.-]{3,64}", stripped))
            if seller and low.lstrip("- ").strip() == seller:
                break
            if collected and simple_user and (stripped.startswith("-") or len(stripped.split()) == 1):
                break

            collected.append(stripped)

        deduped = []
        for line in collected:
            if not deduped or deduped[-1].casefold() != line.casefold():
                deduped.append(line)
        return "\n".join(deduped).strip()

    def _format_ebay_system_message(self, value):
        """
        Make automated eBay notices readable. Templates vary, so retain the
        useful business details and cut off standard footer/help/legal material.
        """
        lines = self._message_section_lines(value)
        if not lines:
            return ""

        stop_markers = (
            "the right way to package",
            "is this email helpful",
            "email reference id",
            "please see our payments terms",
            "ebay commerce inc",
            "learn more about our seller standards",
        )
        skip_exact = {
            "get a shipping label",
            "add the tracking number",
            "reply",
            "make an offer",
            "view item",
        }

        kept = []
        for line in lines:
            low = line.casefold().strip()
            if any(marker in low for marker in stop_markers):
                break
            if low in skip_exact:
                continue
            if low.startswith("http://") or low.startswith("https://"):
                continue
            if low.startswith("new message") or low.startswith("your previous message"):
                continue
            kept.append(line)

        compact = []
        for line in kept:
            if not compact or compact[-1].casefold() != line.casefold():
                compact.append(line)
        return "\n".join(compact[:28]).strip()


    def _conversation_key(self, msg):
        sender = str(msg.get("sender", "") or "").strip().casefold()
        item = str(msg.get("item_number", "") or "").strip()
        subject = str(msg.get("subject", "") or "").strip().casefold()
        return sender + "|" + (item or subject)

    def _message_conversations(self):
        groups = {}
        for msg in self.messages_cache:
            groups.setdefault(self._conversation_key(msg), []).append(msg)
        for msgs in groups.values():
            msgs.sort(key=lambda m: str(m.get("received", "") or ""))
        return groups

    def _message_by_id(self, conversation_key):
        return self._message_conversations().get(str(conversation_key), [])

    def _format_message_received(self, raw):
        try:
            return datetime.fromisoformat(str(raw).replace("Z","+00:00")).astimezone().strftime("%Y-%m-%d %I:%M %p")
        except Exception:
            return str(raw or "")

    def _refresh_messages_view(self):
        tree = getattr(self, "messages_tree", None)
        if tree is None:
            return
        old = tree.selection()
        old_id = old[0] if old else ""
        tree.delete(*tree.get_children())
        search = str(self.messages_search_var.get() or "").strip().casefold()
        unread_total = 0
        shown = 0

        conversations = self._message_conversations()
        ordered = sorted(
            conversations.items(),
            key=lambda kv: str(kv[1][-1].get("received", "") or ""),
            reverse=True,
        )
        for key, msgs in ordered:
            latest = msgs[-1]
            unread = sum(1 for m in msgs if not m.get("read"))
            unread_total += unread
            hay = " ".join(
                str(m.get(field, "") or "")
                for m in msgs
                for field in (
                    "sender", "subject", "text", "member_body",
                    "item_number", "item_title"
                )
            ).casefold()
            if search and search not in hay:
                continue
            status = f"{unread} UNREAD" if unread else ("REPLIED" if latest.get("replied") else "READ")
            tree.insert(
                "", "end", iid=key,
                values=(
                    self._format_message_received(latest.get("received")),
                    status,
                    latest.get("sender",""),
                    latest.get("item_number",""),
                    latest.get("item_title",""),
                ),
                tags=("unread",) if unread else (),
            )
            shown += 1

        self.messages_unread_var.set(f"Unread: {unread_total:,}")
        self.messages_status_var.set(
            f"Showing {shown:,} conversation(s) from the last {self.messages_days_var.get()} days."
        )
        self._reapply_treeview_sort(tree)
        if old_id and tree.exists(old_id):
            tree.selection_set(old_id)
            tree.focus(old_id)
            tree.see(old_id)

    def _refresh_messages_from_ebay(self, silent=False):
        try:
            days = int(self.messages_days_var.get() or 30)
        except Exception:
            days = 30
        if not silent:
            self._show_busy("Refreshing Messages", f"Loading the last {days} days of eBay messages…", cancellable=True)
        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                my_messages = client.get_my_messages(days=days, max_messages=150)

                member_messages = []
                try:
                    member_messages = client.get_member_messages(
                        days=days, max_messages=400
                    )
                    self._log(
                        f"MESSAGES: GetMemberMessages returned "
                        f"{len(member_messages)} buyer/seller exchange(s)."
                    )
                except Exception as member_exc:
                    # Keep My Messages fully usable for eBay alerts, read/delete,
                    # and any conversations GetMemberMessages cannot return.
                    self._log(
                        "MESSAGES: full conversation-body lookup unavailable; "
                        f"using My Messages fallback. {member_exc}"
                    )

                self.messages_cache = client.enrich_my_messages_with_member_messages(
                    my_messages, member_messages
                )
                enriched = sum(
                    1 for m in self.messages_cache
                    if str(m.get("member_body", "") or "").strip()
                )
                self._log(
                    f"MESSAGES: {enriched} inbox message(s) enriched with "
                    "full GetMemberMessages body text."
                )
                self.after(0, self._refresh_messages_view)
            except Exception as exc:
                if not silent:
                    self.after(0, lambda e=str(exc): messagebox.showerror(
                        "eBay Messages", "Could not refresh eBay messages.\n\n" + e, parent=self
                    ))
            finally:
                if not silent:
                    self._finish_busy_from_worker()
        threading.Thread(target=work, daemon=True).start()

    def _selected_message_thread(self):
        sel = self.messages_tree.selection()
        return self._message_by_id(sel[0]) if sel else []

    def _selected_message(self):
        thread = self._selected_message_thread()
        return thread[-1] if thread else None

    def _message_chat_scroll(self, event):
        try:
            delta = int(-1 * (event.delta / 120))
            if delta == 0:
                delta = -1 if event.delta > 0 else 1
            self.message_chat_canvas.yview_scroll(delta, "units")
        except Exception:
            pass
        return "break"

    def _bind_message_chat_wheel(self, widget):
        try:
            widget.bind("<MouseWheel>", self._message_chat_scroll, add="+")
        except Exception:
            pass
        for child in widget.winfo_children():
            self._bind_message_chat_wheel(child)

    def _refresh_message_chat_scrollregion(self):
        try:
            self.message_chat_frame.update_idletasks()
            bbox = self.message_chat_canvas.bbox("all")
            if bbox:
                self.message_chat_canvas.configure(scrollregion=bbox)
        except Exception:
            pass

    def _render_chat_bubble(self, text, who, timestamp="", outgoing=False):
        if not text:
            return
        row = tk.Frame(self.message_chat_frame, background="#f7f7f7")
        row.pack(fill="x", padx=8, pady=5)
        bg = "#dceeff" if outgoing else "#ffffff"
        bubble = tk.Frame(row, background=bg, bd=1, relief="solid")
        bubble.pack(anchor="e" if outgoing else "w",
                    padx=(90,8) if outgoing else (8,90))
        tk.Label(
            bubble, text=(who + (f"  •  {timestamp}" if timestamp else "")),
            background=bg, foreground="#5c6670", font=("Segoe UI",8),
            anchor="w", justify="left"
        ).pack(fill="x", padx=9, pady=(6,2))
        body_label = tk.Label(
            bubble, text=text, background=bg, foreground="#20262d",
            wraplength=500, justify="left", anchor="w"
        )
        body_label.pack(fill="x", padx=9, pady=(0,8))
        self._bind_message_chat_wheel(row)
        self._refresh_message_chat_scrollregion()

    def _messages_mark_open_thread_read(self, thread):
        """Mark unread messages read as soon as the conversation is opened."""
        unread = [
            m for m in (thread or [])
            if not bool(m.get("read")) and str(m.get("message_id", "") or "").strip()
        ]
        if not unread:
            return
        ids = [str(m.get("message_id")) for m in unread]
        for msg in unread:
            msg["read"] = True
        self.after(0, self._refresh_messages_view)

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                for mid in ids:
                    client.mark_my_message_read(mid, read=True)
            except Exception as exc:
                self._log(f"MESSAGE AUTO-READ WARNING: {exc}")

        threading.Thread(target=work, daemon=True).start()

    def _messages_show_selected(self):
        thread = self._selected_message_thread()
        if not thread:
            return
        latest = thread[-1]
        self._messages_mark_open_thread_read(thread)
        sender = str(latest.get("sender","") or "")
        item_number = str(latest.get("item_number","") or "")
        item_title = str(latest.get("item_title","") or "")
        self.message_subject_var.set(f"Conversation with {sender}" if sender else "eBay Conversation")
        meta = item_title + (f"   •   Item #: {item_number}" if item_number else "")
        self.message_meta_var.set(meta.strip())

        for child in self.message_chat_frame.winfo_children():
            child.destroy()

        # Buyer conversations use GetMemberMessages bodies when available. For
        # those exchanges the seller response belongs after the buyer question.
        # Older/fallback GetMyMessages templates still use the quoted previous
        # seller reply before the current buyer message.
        seen = set()
        bubbles = []
        for msg in thread:
            sender_name = str(msg.get("sender", "") or "").strip()
            source_text = self._message_source_text(msg)
            is_system = sender_name.casefold() == "ebay"
            has_member_exchange = bool(str(msg.get("member_body", "") or "").strip())

            seller_text = (
                "" if is_system
                else self._best_previous_reply_text(msg)
            )
            primary = (
                self._format_ebay_system_message(source_text)
                if is_system
                else self._best_primary_message_text(msg)
            )

            if seller_text and not has_member_exchange:
                key = ("out", re.sub(r"\s+", " ", seller_text).strip().casefold())
                if key not in seen:
                    seen.add(key)
                    bubbles.append(("You", seller_text, "", True))

            if primary:
                key = ("in", re.sub(r"\s+", " ", primary).strip().casefold())
                if key not in seen:
                    seen.add(key)
                    bubbles.append((
                        sender_name or "Buyer",
                        primary,
                        self._format_message_received(
                            msg.get("member_created") or msg.get("received")
                        ),
                        False,
                    ))

            if seller_text and has_member_exchange:
                key = ("out", re.sub(r"\s+", " ", seller_text).strip().casefold())
                if key not in seen:
                    seen.add(key)
                    bubbles.append(("You", seller_text, "", True))

        if not bubbles:
            bubbles.append(("eBay", "(No readable conversation text returned.)", "", False))

        for who, body, timestamp, outgoing in bubbles:
            self._render_chat_bubble(body, who, timestamp, outgoing)

        self._bind_message_chat_wheel(self.message_chat_frame)
        self._refresh_message_chat_scrollregion()
        self.message_chat_canvas.yview_moveto(1.0)

    def _messages_double_click(self, event):
        if self.messages_tree.identify_region(event.x,event.y) not in ("cell","tree"):
            return "break"
        row = self.messages_tree.identify_row(event.y)
        if not row:
            return "break"
        self.messages_tree.selection_set(row)
        self.messages_tree.focus(row)
        self._messages_show_selected()
        return "break"

    def _messages_open_item(self):
        msg = self._selected_message()
        if msg and msg.get("item_number"):
            webbrowser.open(f"https://www.ebay.com/itm/{msg['item_number']}")

    def _messages_jump_inventory(self):
        msg = self._selected_message()
        if msg and msg.get("item_number") and not self._inventory_jump_to_item(item_number=msg["item_number"]):
            messagebox.showinfo("Messages","No local inventory row was found for this item.",parent=self)

    def _messages_mark_selected(self, read=True):
        thread = self._selected_message_thread()
        if not thread:
            return
        ids = [str(m.get("message_id","") or "") for m in thread if m.get("message_id")]
        self._show_busy("Updating Conversation","Updating message status on eBay…",cancellable=False)
        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                for mid in ids:
                    client.mark_my_message_read(mid, read=read)
                for msg in thread:
                    msg["read"] = bool(read)
                self.after(0, self._refresh_messages_view)
            except Exception as exc:
                self.after(0, lambda e=str(exc): messagebox.showerror(
                    "Messages","Could not update the conversation.\n\n"+e,parent=self
                ))
            finally:
                self._finish_busy_from_worker()
        threading.Thread(target=work,daemon=True).start()

    def _messages_delete_selected(self):
        thread = self._selected_message_thread()
        if not thread:
            return

        ids = [
            str(m.get("message_id", "") or "").strip()
            for m in thread
            if str(m.get("message_id", "") or "").strip()
        ]
        if not ids:
            return

        sender = str(thread[-1].get("sender", "") or "this conversation")
        count = len(ids)
        if not messagebox.askyesno(
            "Delete eBay Messages",
            f"Delete {count} message(s) in the conversation with {sender}?\n\n"
            "This also deletes them from eBay My Messages.",
            parent=self,
        ):
            return

        self._show_busy(
            "Deleting Messages",
            f"Deleting {count} eBay message(s)…",
            cancellable=False,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                client.delete_my_messages(ids)
                id_set = set(ids)
                self.messages_cache = [
                    m for m in self.messages_cache
                    if str(m.get("message_id", "") or "") not in id_set
                ]
                def finish_ui():
                    self._refresh_messages_view()
                    self.message_subject_var.set("Select a conversation")
                    self.message_meta_var.set("")
                    for child in self.message_chat_frame.winfo_children():
                        child.destroy()
                self.after(0, finish_ui)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Delete eBay Messages",
                        "Could not delete the selected messages.\n\n" + e,
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()

    def _messages_reply_selected(self):
        msg = self._selected_message()
        if not msg:
            return
        item_number = str(msg.get("item_number","") or "").strip()
        sender = str(msg.get("sender","") or "").strip()
        if sender.casefold() == "ebay":
            messagebox.showinfo(
                "Messages",
                "This is an automated eBay notice and cannot be replied to.",
                parent=self,
            )
            return
        if not item_number or not sender:
            messagebox.showinfo(
                "Messages","This conversation does not contain enough buyer/item information for an in-app reply.",parent=self
            )
            return
        body = simpledialog.askstring(
            "Reply to eBay Conversation", f"Reply to {sender} (max 200 characters):", parent=self
        )
        if body is None:
            return
        body = body.strip()
        if not body:
            return
        if len(body) > 200:
            messagebox.showwarning(
                "Reply",f"eBay limits this reply to 200 characters. Current length: {len(body)}.",parent=self
            )
            return
        subject = str(msg.get("subject","") or "")
        if not subject.lower().startswith("re:"):
            subject = "Re: " + subject
        self._show_busy("Sending Reply","Sending reply through eBay Messages…",cancellable=False)
        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                client.reply_to_partner_message(
                    item_number, sender, subject[:100], body, msg.get("question_type") or "General"
                )
                self.after(0, lambda: self._refresh_messages_from_ebay(silent=True))
                self.after(0, lambda: messagebox.showinfo("Messages","Reply sent successfully.",parent=self))
            except Exception as exc:
                self.after(0, lambda e=str(exc): messagebox.showerror(
                    "Messages","Could not send the reply.\n\n"+e,parent=self
                ))
            finally:
                self._finish_busy_from_worker()
        threading.Thread(target=work,daemon=True).start()

    def _messages_context_menu(self, event, tree):
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
            self._messages_show_selected()
        thread = self._selected_message_thread()
        msg = thread[-1] if thread else None
        if not msg:
            return "break"
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Open Conversation", command=self._messages_show_selected)
        menu.add_command(label="Reply", command=self._messages_reply_selected)
        menu.add_command(label="Delete Conversation", command=self._messages_delete_selected)
        if msg.get("item_number"):
            menu.add_command(label="Open eBay Item", command=self._messages_open_item)
            menu.add_command(label="Jump to Inventory Item", command=self._messages_jump_inventory)
        menu.add_separator()
        all_read = all(bool(m.get("read")) for m in thread)
        menu.add_command(
            label="Mark Unread" if all_read else "Mark Read",
            command=lambda: self._messages_mark_selected(read=not all_read),
        )
        menu.add_command(
            label="Copy Conversation",
            command=lambda: (
                self.clipboard_clear(),
                self.clipboard_append("\n\n".join(
                    f"{m.get('sender','')} — {self._format_message_received(m.get('received'))}\n"
                    f"{self._best_primary_message_text(m)}" for m in thread
                )),
            ),
        )
        try:
            menu.tk_popup(event.x_root,event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"


    def _build_attention_tab(self):
        outer = self.attention_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 7))
        top.columnconfigure(4, weight=1)
        ttk.Label(top, text="Needs Attention", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 14)
        )
        ttk.Button(
            top, text="SYNC + SCAN", command=self._attention_sync_and_scan,
            style="Primary.TButton"
        ).grid(row=0, column=1, padx=(0, 6))
        ttk.Button(
            top, text="AUTO FIX SAFE", command=self._attention_auto_fix_safe
        ).grid(row=0, column=2, padx=(0, 6))
        ttk.Button(
            top, text="RULES", command=self._attention_manage_rules
        ).grid(row=0, column=3, padx=(0, 10))
        ttk.Label(top, text="Category:").grid(row=0, column=4)
        filter_box = ttk.Combobox(
            top, textvariable=self.attention_filter_var,
            values=("ALL", "LISTINGS", "INVENTORY", "SHIPPING", "DATA"),
            width=13, state="readonly",
        )
        filter_box.grid(row=0, column=5, padx=(5, 8))
        filter_box.bind("<<ComboboxSelected>>", lambda _e: self._refresh_attention_trees())

        ttk.Label(
            outer, textvariable=self.attention_status_var, style="Subheader.TLabel"
        ).grid(row=1, column=0, sticky="ew", pady=(0, 6))

        nb = ttk.Notebook(outer)
        nb.grid(row=2, column=0, sticky="nsew")
        self.attention_notebook = nb
        self.attention_trees = {}

        for state, label in (("OPEN", "OPEN ISSUES"), ("IGNORED", "IGNORED"), ("RESOLVED", "RESOLVED")):
            frame = ttk.Frame(nb, padding=5)
            frame.columnconfigure(0, weight=1)
            frame.rowconfigure(0, weight=1)
            nb.add(frame, text=label)

            cols = ("severity", "category", "issue", "item", "item_number", "location", "action")
            tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
            heads = {
                "severity": "SEVERITY", "category": "CATEGORY", "issue": "ISSUE",
                "item": "ITEM", "item_number": "ITEM #", "location": "LOCATION",
                "action": "SUGGESTED ACTION",
            }
            widths = {
                "severity": 80, "category": 95, "issue": 330, "item": 360,
                "item_number": 115, "location": 105, "action": 260,
            }
            for c in cols:
                tree.heading(
                    c, text=heads[c],
                    command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col),
                )
                tree.column(c, width=widths[c], minwidth=60, anchor="w", stretch=False)
            vs = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
            hs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
            tree.grid(row=0, column=0, sticky="nsew")
            vs.grid(row=0, column=1, sticky="ns")
            hs.grid(row=1, column=0, sticky="ew")
            tree.tag_configure("CRITICAL", background="#e6a1a1")
            tree.tag_configure("WARNING", background="#f1dfaf")
            tree.tag_configure("INFO", background="#dfeaf5")
            tree.bind("<Double-1>", lambda _e, tr=tree: self._attention_open_selected(tr))
            tree.bind("<Shift-MouseWheel>", lambda e, tr=tree: tr.xview_scroll(int(-1 * (e.delta / 120)), "units"))
            tree.bind("<Button-3>", lambda e, tr=tree: self._attention_context_menu(e, tr))
            self.attention_trees[state] = tree

        actions = ttk.Frame(outer)
        actions.grid(row=3, column=0, sticky="ew", pady=(7, 0))
        ttk.Button(
            actions, text="OPEN / FIX", command=self._attention_open_selected
        ).pack(side="left", padx=(0, 5))
        ttk.Button(
            actions, text="IGNORE", command=lambda: self._set_attention_selected_state("IGNORED")
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="RESTORE TO OPEN", command=lambda: self._set_attention_selected_state("OPEN")
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="MARK RESOLVED", command=lambda: self._set_attention_selected_state("RESOLVED")
        ).pack(side="left", padx=5)

        self._refresh_attention_trees()


    def _attention_issue_type(self, issue_key):
        return str(issue_key or "").split(":", 1)[0].strip()

    def _attention_context_menu(self, event, tree):
        """Context-sensitive right-click actions for issue rows."""
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
        row = self._attention_selected(tree)
        if not row:
            return "break"

        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Open / Fix", command=lambda: self._attention_open_selected(tree))
        item_number = str(row.get("item_number", "") or "")
        if item_number:
            menu.add_command(
                label="Open eBay Listing",
                command=lambda n=item_number: webbrowser.open(f"https://www.ebay.com/itm/{n}"),
            )
            menu.add_command(
                label="Jump to Inventory Item",
                command=lambda n=item_number: self._inventory_jump_to_item(item_number=n),
            )
            menu.add_command(
                label="Copy Item Number",
                command=lambda n=item_number: (self.clipboard_clear(), self.clipboard_append(n)),
            )
            if any(
                str(x.get("item_number", "") or "") == item_number
                for x in self.active_listings_cache
            ):
                menu.add_command(
                    label="End eBay Listing…",
                    command=lambda n=item_number: self._end_ebay_listing(n, str(row.get("item", "") or "")),
                )
        menu.add_separator()
        menu.add_command(label="Ignore This Issue", command=lambda: self._set_attention_selected_state("IGNORED"))
        menu.add_command(label="Always Ignore This Issue Type", command=lambda: self._attention_ignore_issue_type(row))
        menu.add_command(label="Mark Resolved", command=lambda: self._set_attention_selected_state("RESOLVED"))
        menu.add_command(label="Restore to Open", command=lambda: self._set_attention_selected_state("OPEN"))
        menu.add_separator()
        menu.add_command(label="Manage Ignore Rules…", command=self._attention_manage_rules)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try: menu.grab_release()
            except Exception: pass
        return "break"

    def _attention_ignore_issue_type(self, row):
        issue_type = self._attention_issue_type(row.get("issue_key"))
        if not issue_type:
            return
        if not messagebox.askyesno(
            "Needs Attention",
            f"Always ignore future issues of type:\n\n{issue_type}\n\n"
            "You can restore this issue type later from RULES.",
            parent=self,
        ):
            return
        con = self._inventory_connect()
        ignored_count = 0
        try:
            con.execute(
                """INSERT INTO attention_rules(issue_type,rule_action,enabled)
                   VALUES(?,'IGNORE',1)
                   ON CONFLICT(issue_type) DO UPDATE SET rule_action='IGNORE',enabled=1""",
                (issue_type,),
            )
            row = con.execute(
                """SELECT COUNT(*) FROM attention_issues
                   WHERE (issue_type=? OR issue_key LIKE ?) AND state='OPEN'""",
                (issue_type, issue_type + ':%'),
            ).fetchone()
            ignored_count = int(row[0] or 0) if row else 0
            con.execute(
                "UPDATE attention_issues SET state='IGNORED' WHERE issue_type=? OR issue_key LIKE ?",
                (issue_type, issue_type + ':%'),
            )
            con.commit()
        finally:
            con.close()
        self._refresh_attention_trees()
        self._refresh_dashboard()
        messagebox.showinfo(
            "Needs Attention",
            f"Ignored {ignored_count:,} currently open issue(s) of type:\n\n{issue_type}\n\n"
            "Future issues of this type will also be ignored until you remove the rule.",
            parent=self,
        )

    def _attention_manage_rules(self):
        win = tk.Toplevel(self)
        win.title("Needs Attention Rules")
        win.geometry("620x390")
        win.transient(self)
        win.columnconfigure(0, weight=1)
        win.rowconfigure(1, weight=1)
        ttk.Label(
            win,
            text="Ignored Issue Types",
            style="Header.TLabel",
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(12, 6))
        tree = ttk.Treeview(win, columns=("type", "action"), show="headings", selectmode="browse")
        tree.heading("type", text="ISSUE TYPE")
        tree.heading("action", text="RULE")
        tree.column("type", width=390)
        tree.column("action", width=130)
        tree.grid(row=1, column=0, sticky="nsew", padx=12)
        def reload_rules():
            tree.delete(*tree.get_children())
            con = self._inventory_connect()
            try:
                rows = con.execute(
                    "SELECT issue_type,rule_action FROM attention_rules WHERE enabled=1 ORDER BY issue_type"
                ).fetchall()
                for r in rows:
                    tree.insert("", "end", iid=r["issue_type"], values=(r["issue_type"], r["rule_action"]))
            finally:
                con.close()
        def remove_rule():
            sel = tree.selection()
            if not sel: return
            issue_type = str(sel[0])
            con = self._inventory_connect()
            try:
                con.execute("DELETE FROM attention_rules WHERE issue_type=?", (issue_type,))
                con.execute(
                    "UPDATE attention_issues SET state='OPEN' WHERE issue_type=? AND state='IGNORED'",
                    (issue_type,),
                )
                con.commit()
            finally:
                con.close()
            reload_rules(); self._refresh_attention_trees(); self._refresh_dashboard()
        buttons = ttk.Frame(win)
        buttons.grid(row=2, column=0, sticky="ew", padx=12, pady=12)
        ttk.Button(buttons, text="RESTORE SELECTED TYPE", command=remove_rule).pack(side="left")
        ttk.Button(buttons, text="CLOSE", command=win.destroy).pack(side="right")
        reload_rules()

    def _attention_auto_fix_safe(self):
        """
        Apply only deterministic, reversible housekeeping:
        - sync order fulfillment states
        - reconcile active eBay quantities to local STOCK
        - import active listings missing locally to Pending Location
        - resolve issues no longer detected
        Never changes prices, ends/re-lists listings, or assigns physical locations.
        """
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME, "Another operation is already running.", parent=self)
            return
        if not messagebox.askyesno(
            "Auto Fix Safe Issues",
            "Run safe automatic fixes now?\n\n"
            "This WILL:\n"
            "• sync Pending Shipping / Sold status\n"
            "• reconcile local STOCK to current eBay available quantity\n"
            "• import missing active listings into Pending Location\n"
            "• close issues that no longer exist\n\n"
            "It will NOT change prices, end/relist items, choose locations, or alter listing content.",
            parent=self,
        ):
            return
        self._attention_sync_and_scan()

    def _attention_selected(self, explicit_tree=None):
        tree = explicit_tree
        if tree is None:
            try:
                idx = self.attention_notebook.index(self.attention_notebook.select())
                state = ("OPEN", "IGNORED", "RESOLVED")[idx]
                tree = self.attention_trees[state]
            except Exception:
                return None
        sel = tree.selection()
        if not sel:
            return None
        issue_key = str(sel[0])
        con = self._inventory_connect()
        try:
            row = con.execute(
                "SELECT * FROM attention_issues WHERE issue_key=?", (issue_key,)
            ).fetchone()
            return dict(row) if row else None
        finally:
            con.close()

    def _attention_open_selected(self, explicit_tree=None):
        row = self._attention_selected(explicit_tree)
        if not row:
            return
        item_number = str(row.get("item_number", "") or "")
        category = str(row.get("category", "") or "").upper()
        action = str(row.get("action", "") or "").upper()

        issue_key = str(row.get("issue_key", "") or "")
        if issue_key.startswith("possible_inventory_match:"):
            self._confirm_probable_inventory_match(row)
            return

        # Many issue keys contain the exact local inventory row id.
        row_id = None
        m = re.match(
            r"(?:pending_location|zero_stock_active|stock_gt_qty|listed_not_active|pending_shipping_age):(\\d+)$",
            issue_key,
        )
        if m:
            row_id = int(m.group(1))

        # OPEN / FIX should first take the user to the actual item in our local
        # system, regardless of whether it lives in Master, Pending Location,
        # Pending Shipping, or Sold.
        if self._inventory_jump_to_item(item_number=item_number, row_id=row_id):
            return

        # If no local record exists, fall back to the relevant external/workflow view.
        if "REVAMP" in action:
            self._select_top_tab(self.revamp_tab)
        elif item_number:
            webbrowser.open(f"https://www.ebay.com/itm/{item_number}")

    def _set_attention_selected_state(self, state):
        row = self._attention_selected()
        if not row:
            return
        con = self._inventory_connect()
        try:
            con.execute(
                "UPDATE attention_issues SET state=?,last_seen=CURRENT_TIMESTAMP WHERE issue_key=?",
                (state, row["issue_key"]),
            )
            con.commit()
        finally:
            con.close()
        self._refresh_attention_trees()
        self._refresh_dashboard()

    def _refresh_attention_trees(self):
        trees = getattr(self, "attention_trees", None)
        if not trees:
            return
        category_filter = str(self.attention_filter_var.get() or "ALL").upper()
        con = self._inventory_connect()
        try:
            counts = {}
            for state, tree in trees.items():
                tree.delete(*tree.get_children())
                sql = "SELECT * FROM attention_issues WHERE state=?"
                args = [state]
                if category_filter != "ALL":
                    sql += " AND category=?"
                    args.append(category_filter)
                sql += """
                    ORDER BY CASE severity
                        WHEN 'CRITICAL' THEN 0 WHEN 'WARNING' THEN 1 ELSE 2 END,
                        last_seen DESC
                """
                rows = con.execute(sql, args).fetchall()
                counts[state] = len(rows)
                for r in rows:
                    vals = (
                        r["severity"], r["category"], r["issue"], r["item"] or "",
                        r["item_number"] or "", r["location"] or "", r["action"] or "",
                    )
                    tree.insert(
                        "", "end", iid=r["issue_key"], values=vals,
                        tags=(r["severity"],)
                    )
        finally:
            con.close()

        for tr in trees.values():
            self._reapply_treeview_sort(tr)

        self.attention_status_var.set(
            f"Open: {counts.get('OPEN',0):,}  •  Ignored: {counts.get('IGNORED',0):,}  •  "
            f"Resolved: {counts.get('RESOLVED',0):,}. "
            "Resolved issues are automatically reopened if a future scan detects the problem again."
        )

    def _attention_sync_and_scan(self):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME, "Another operation is already running.", parent=self)
            return
        self._save_settings_ui_silent()
        self.attention_status_var.set("Synchronizing eBay and scanning for issues…")
        self._show_busy(
            "Sync + Scan",
            "Synchronizing eBay listings/orders and checking inventory for issues…",
            cancellable=True,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                orders = client.get_recent_orders(90)
                self.recent_orders_cache = orders
                for order in orders or []:
                    if isinstance(order, dict) and order.get("orderId"):
                        self.orders_detail_cache[str(order.get("orderId"))] = order
                self._store_sales_orders(orders)
                pending, sold, _new_lines = self._inventory_sync_orders_apply(orders)

                active = client.get_all_active_listings()
                self.active_listings_cache = active
                self._inventory_sync_active_apply(active)

                issues = self._detect_attention_issues(active)
                self._store_attention_scan(issues)

                self.after(0, self._populate_active_listings_tree)
                self.after(0, self._populate_revamp_tree)
                self.after(0, self._refresh_attention_trees)
                self.after(0, self._refresh_sales_view)
                self.after(0, self._refresh_dashboard)
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        "Needs Attention",
                        f"Sync + Scan complete.\n\n"
                        f"Active eBay listings checked: {len(active):,}\n"
                        f"Recent orders checked: {len(orders):,}\n"
                        f"Issues detected this scan: {len(issues):,}\n\n"
                        "Safe eBay/inventory status updates were applied first; the remaining "
                        "items are now listed in Needs Attention.",
                        parent=self,
                    ),
                )
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Needs Attention", "Sync + Scan failed.\n\n" + e, parent=self
                    ),
                )
                self.after(0, lambda: self.attention_status_var.set("Sync + Scan failed."))
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()


    def _normalize_match_text(self, value):
        value = str(value or "").casefold()
        value = re.sub(r"[^a-z0-9]+", " ", value)
        stop = {"new","used","surplus","nos","lot","qty","quantity","the","a","an","for","with","and","of","in","to"}
        return " ".join(t for t in value.split() if t not in stop).strip()

    def _token_overlap_score(self, a, b):
        aa = set(self._normalize_match_text(a).split())
        bb = set(self._normalize_match_text(b).split())
        if not aa or not bb:
            return 0.0
        return len(aa & bb) / max(1, len(aa | bb))

    def _find_probable_inventory_match(self, listing, candidate_rows):
        title = str(listing.get("title", "") or "")
        sku = str(listing.get("sku", "") or "").strip().casefold()
        ebay_qty = listing.get("quantity_available", None)
        scored = []
        for row in candidate_rows:
            item_name = str(row.get("item", "") or "")
            location = str(row.get("location", "") or "").strip()
            if not item_name or not location:
                continue
            blob = " ".join(str(row.get(k, "") or "") for k in ("item","comment","condition","item_number")).casefold()
            sku_bonus = 0.45 if sku and len(sku) >= 3 and sku in blob else 0.0
            nt = self._normalize_match_text(title)
            ni = self._normalize_match_text(item_name)
            seq = difflib.SequenceMatcher(None, nt, ni).ratio() if nt and ni else 0.0
            overlap = self._token_overlap_score(title, item_name)
            qty_bonus = 0.0
            try:
                local_stock = int(float(row.get("stock") or 0))
                if ebay_qty is not None and int(float(ebay_qty)) == local_stock and local_stock > 0:
                    qty_bonus = 0.08
            except Exception:
                pass
            score = (0.58 * overlap) + (0.34 * seq) + sku_bonus + qty_bonus
            scored.append((score, row))
        if not scored:
            return None
        scored.sort(key=lambda x: x[0], reverse=True)
        best = scored[0]
        second = scored[1] if len(scored) > 1 else None
        if best[0] < 0.68:
            return None
        if second and (best[0] - second[0]) < 0.10:
            return None
        row = dict(best[1])
        row["_match_score"] = round(best[0], 3)
        return row

    def _confirm_probable_inventory_match(self, issue_row):
        issue_key = str(issue_row.get("issue_key", "") or "")
        m = re.match(r"possible_inventory_match:(\\d+):(.+)$", issue_key)
        if not m:
            return
        inventory_id = int(m.group(1))
        current_item_number = str(m.group(2)).strip()
        con = self._inventory_connect()
        try:
            row = con.execute("SELECT * FROM inventory_items WHERE id=?", (inventory_id,)).fetchone()
            if not row:
                return
            old_item_number = str(row["item_number"] or "").strip()
            item_name = str(row["item"] or "")
            location = str(row["location"] or "")
            msg = (
                "Use this remembered inventory row for the current active eBay listing?\n\n"
                f"Inventory item: {item_name}\n"
                f"Location: {location or '(none)'}\n"
                f"Old item number: {old_item_number or '(blank)'}\n"
                f"Current eBay item number: {current_item_number}\n\n"
                "This keeps the existing location and inventory data, and updates the eBay item number."
            )
            if not messagebox.askyesno("Confirm Inventory Match", msg, parent=self):
                return
            comment = str(row["comment"] or "")
            if old_item_number and old_item_number != current_item_number:
                stamp = f"Previous eBay item #: {old_item_number}"
                if stamp not in comment:
                    comment = (comment + (" | " if comment else "") + stamp).strip()
            con.execute(
                "UPDATE inventory_items SET item_number=?,status='LISTED',comment=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (current_item_number, comment, inventory_id),
            )
            con.execute(
                "UPDATE attention_issues SET state='RESOLVED',last_seen=CURRENT_TIMESTAMP WHERE issue_key=?",
                (issue_key,),
            )
            con.commit()
        finally:
            con.close()
        self._inventory_refresh_all()
        self._refresh_attention_trees()
        self._refresh_dashboard()

    def _detect_attention_issues(self, active):
        issues = []
        local = self._listing_local_map()
        active_map = {str(x.get("item_number", "") or ""): x for x in active}
        con_match = self._inventory_connect()
        try:
            match_rows = [
                dict(r) for r in con_match.execute(
                    """SELECT * FROM inventory_items
                       WHERE parent_item_id IS NULL
                         AND trim(COALESCE(location,''))<>''
                         AND status NOT IN ('SOLD','PENDING_SHIPPING')"""
                ).fetchall()
            ]
        finally:
            con_match.close()

        def add(key, severity, category, issue, item="", item_number="", location="", action="Review"):
            issues.append({
                "issue_key": key,
                "issue_type": self._attention_issue_type(key),
                "severity": severity,
                "category": category,
                "issue": issue,
                "item": item,
                "item_number": item_number,
                "location": location,
                "action": action,
            })

        # Active-listing problems.
        for item_number, listing in active_map.items():
            title = str(listing.get("title", "") or "")
            sku = str(listing.get("sku", "") or "")
            local_row = local.get(item_number)
            probable_match = None
            if not local_row:
                probable_match = self._find_probable_inventory_match(listing, match_rows)
                if probable_match:
                    old_num = str(probable_match.get("item_number", "") or "").strip()
                    loc = str(probable_match.get("location", "") or "").strip()
                    candidate_name = str(probable_match.get("item", "") or "")
                    score = int(round(float(probable_match.get("_match_score", 0)) * 100))
                    add(
                        f"possible_inventory_match:{probable_match['id']}:{item_number}",
                        "WARNING", "INVENTORY",
                        f"Possible remembered inventory match ({score}% confidence)",
                        title, item_number, loc,
                        f"Review suggested match: {candidate_name}"
                        + (f" / old item # {old_num}" if old_num else ""),
                    )
                else:
                    add(
                        f"active_missing_inventory:{item_number}", "CRITICAL", "LISTINGS",
                        "Active eBay listing is missing from local inventory",
                        title, item_number, "", "Add / reconcile inventory record",
                    )
            else:
                location = str(local_row.get("location", "") or "")
                if not location:
                    probable_match = self._find_probable_inventory_match(listing, match_rows)
                    if probable_match and int(probable_match.get("id")) != int(local_row.get("id")):
                        old_num = str(probable_match.get("item_number", "") or "").strip()
                        loc = str(probable_match.get("location", "") or "").strip()
                        candidate_name = str(probable_match.get("item", "") or "")
                        score = int(round(float(probable_match.get("_match_score", 0)) * 100))
                        add(
                            f"possible_inventory_match:{probable_match['id']}:{item_number}",
                            "WARNING", "INVENTORY",
                            f"Possible remembered inventory match ({score}% confidence)",
                            title, item_number, loc,
                            f"Review suggested match: {candidate_name}"
                            + (f" / old item # {old_num}" if old_num else ""),
                        )
                    else:
                        # Missing physical location is handled by the dedicated
                        # PENDING LOCATION workflow, not Needs Attention.
                        pass
                try:
                    ebay_qty = int(float(listing.get("quantity_available") or 0))
                    local_stock = int(float(local_row.get("stock") or 0))
                    if ebay_qty != local_stock:
                        add(
                            f"qty_mismatch:{item_number}", "CRITICAL", "INVENTORY",
                            f"Quantity mismatch: eBay {ebay_qty} vs local STOCK {local_stock}",
                            title, item_number, location, "Reconcile stock",
                        )
                except Exception:
                    pass

            if not sku:
                add(
                    f"missing_sku:{item_number}", "INFO", "LISTINGS",
                    "Active listing has no SKU / Custom Label",
                    title, item_number, str((local_row or {}).get("location", "") or ""),
                    "Add SKU when listing is revamped",
                )

            # Revamp-only observations belong in the dedicated Revamp Queue,
            # not in Needs Attention. Photo counts are also omitted from Attention
            # because GetMyeBaySelling does not reliably return PictureDetails for
            # every active listing.

        # Local inventory records that disagree with current eBay state.
        con = self._inventory_connect()
        try:
            parent_rows = con.execute(
                "SELECT * FROM inventory_items WHERE parent_item_id IS NULL"
            ).fetchall()

            for r in parent_rows:
                item_number = str(r["item_number"] or "").strip()
                status = str(r["status"] or "MASTER").upper()
                item = str(r["item"] or "")
                location = str(r["location"] or "")
                try:
                    stock = float(r["stock"] if r["stock"] is not None else 0)
                except Exception:
                    stock = 0
                try:
                    qty = float(r["qty"] if r["qty"] is not None else 0)
                except Exception:
                    qty = 0

                if status in ("LISTED", "MASTER") and stock <= 0:
                    add(
                        f"zero_stock_active:{r['id']}", "CRITICAL", "INVENTORY",
                        "Active/master inventory record has zero stock",
                        item, item_number, location, "Review stock / listing status",
                    )
                if qty > 0 and stock > qty:
                    add(
                        f"stock_gt_qty:{r['id']}", "WARNING", "DATA",
                        f"STOCK ({stock:g}) is greater than original QTY ({qty:g})",
                        item, item_number, location, "Verify quantities",
                    )
                if status == "LISTED" and item_number and item_number not in active_map:
                    add(
                        f"listed_not_active:{r['id']}", "WARNING", "LISTINGS",
                        "Local item is marked LISTED but is not in eBay Active Listings",
                        item, item_number, location, "Review ended/removed listing",
                    )

            duplicates = con.execute(
                """SELECT item_number,COUNT(*) AS c
                   FROM inventory_items
                   WHERE parent_item_id IS NULL AND trim(COALESCE(item_number,''))<>''
                   GROUP BY item_number HAVING COUNT(*)>1"""
            ).fetchall()
            for d in duplicates:
                add(
                    f"duplicate_item_number:{d['item_number']}", "CRITICAL", "DATA",
                    f"eBay Item Number appears on {d['c']} main inventory records",
                    "", str(d["item_number"]), "", "Review duplicate inventory records",
                )

            pending_rows = con.execute(
                """SELECT * FROM inventory_items
                   WHERE status='PENDING_SHIPPING'"""
            ).fetchall()
            for r in pending_rows:
                days = self._days_since_text_timestamp(r["created_at"])
                if days is not None and days >= 3:
                    add(
                        f"pending_shipping_age:{r['id']}", "WARNING", "SHIPPING",
                        f"Pending shipment has been open for {days} days",
                        str(r["item"] or ""), str(r["item_number"] or ""),
                        str(r["location"] or ""), "Check order / shipment",
                    )
        finally:
            con.close()

        return issues

    def _store_attention_scan(self, issues):
        scan_token = str(uuid.uuid4())
        con = self._inventory_connect()
        try:
            ignored_types = {
                str(r["issue_type"])
                for r in con.execute(
                    "SELECT issue_type FROM attention_rules WHERE enabled=1 AND rule_action='IGNORE'"
                ).fetchall()
            }
            for issue in issues:
                issue_type = str(issue.get("issue_type") or self._attention_issue_type(issue.get("issue_key")))
                existing = con.execute(
                    "SELECT state FROM attention_issues WHERE issue_key=?",
                    (issue["issue_key"],),
                ).fetchone()
                old_state = str(existing["state"]) if existing else "OPEN"
                if issue_type in ignored_types:
                    state = "IGNORED"
                else:
                    state = "IGNORED" if old_state == "IGNORED" else "OPEN"
                con.execute(
                    """INSERT INTO attention_issues(
                           issue_key,issue_type,severity,category,issue,item,item_number,location,
                           action,state,first_seen,last_seen,scan_token
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?)
                       ON CONFLICT(issue_key) DO UPDATE SET
                           issue_type=excluded.issue_type,
                           severity=excluded.severity,
                           category=excluded.category,
                           issue=excluded.issue,
                           item=excluded.item,
                           item_number=excluded.item_number,
                           location=excluded.location,
                           action=excluded.action,
                           state=?,
                           last_seen=CURRENT_TIMESTAMP,
                           scan_token=excluded.scan_token""",
                    (
                        issue["issue_key"], issue_type, issue["severity"], issue["category"],
                        issue["issue"], issue["item"], issue["item_number"],
                        issue["location"], issue["action"], state, scan_token, state,
                    ),
                )
            con.execute(
                """UPDATE attention_issues
                   SET state='RESOLVED'
                   WHERE COALESCE(scan_token,'')<>? AND state NOT IN ('RESOLVED','IGNORED')""",
                (scan_token,),
            )
            con.commit()
        finally:
            con.close()



    # =======================================================================
    # SALES ANALYTICS
    # =======================================================================

    def _build_sales_tab(self):
        outer = self.sales_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(3, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Sales Analytics", style="Header.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(top, text="History:").grid(row=0, column=2, padx=(10, 4))
        rng = ttk.Combobox(top, textvariable=self.sales_range_var, values=("6", "12", "24"), width=6, state="readonly")
        rng.grid(row=0, column=3, padx=(0, 6))
        rng.bind("<<ComboboxSelected>>", lambda _e: self._refresh_sales_view())
        ttk.Button(top, text="REFRESH FROM EBAY", command=self._refresh_sales_from_ebay).grid(row=0, column=4, padx=(0, 5))
        ttk.Button(top, text="EBAY-STYLE MONTHLY REPORT / PRINT", command=self._sales_monthly_report).grid(row=0, column=5)

        cards = ttk.Frame(outer)
        cards.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        for c in range(6): cards.columnconfigure(c, weight=1)
        card_specs = [
            ("current", "THIS MONTH"), ("previous", "LAST MONTH"),
            ("mom", "MONTH VS MONTH"), ("yoy", "YEAR VS YEAR"),
            ("orders", "ORDERS THIS MONTH"), ("units", "UNITS THIS MONTH"),
        ]
        for c, (key, label) in enumerate(card_specs):
            box = ttk.LabelFrame(cards, text=label, padding=9)
            box.grid(row=0, column=c, sticky="nsew", padx=3)
            ttk.Label(box, textvariable=self.sales_summary_vars[key], style="Section.TLabel").pack(anchor="center")

        ttk.Label(outer, textvariable=self.sales_status_var, style="Subheader.TLabel").grid(
            row=2, column=0, sticky="ew", pady=(0, 5)
        )

        body = ttk.Panedwindow(outer, orient="vertical")
        body.grid(row=3, column=0, sticky="nsew")
        chart_frame = ttk.LabelFrame(body, text="Monthly Sales", padding=7)
        table_frame = ttk.LabelFrame(body, text="Monthly Comparison", padding=7)
        body.add(chart_frame, weight=3); body.add(table_frame, weight=2)

        chart_frame.columnconfigure(0, weight=1); chart_frame.rowconfigure(0, weight=1)
        self.sales_canvas = tk.Canvas(chart_frame, bg="#fbfaf7", highlightthickness=0, height=300)
        self.sales_canvas.grid(row=0, column=0, sticky="nsew")
        self.sales_canvas.bind("<Configure>", lambda _e: self._draw_sales_chart())

        table_frame.columnconfigure(0, weight=1); table_frame.rowconfigure(0, weight=1)
        cols = ("month", "sales", "orders", "units", "change")
        tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        self.sales_tree = tree
        heads = {"month":"MONTH", "sales":"SALES", "orders":"ORDERS", "units":"UNITS", "change":"VS PRIOR MONTH"}
        widths = {"month":120, "sales":130, "orders":100, "units":100, "change":140}
        for c in cols:
            tree.heading(c, text=heads[c], command=lambda col=c,tr=tree:self._sort_treeview_column(tr,col))
            tree.column(c, width=widths[c], anchor="w")
        vs = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vs.set)
        tree.grid(row=0, column=0, sticky="nsew"); vs.grid(row=0, column=1, sticky="ns")
        tree.bind("<Button-3>", lambda e, tr=tree: self._sales_context_menu(e, tr))
        self._refresh_sales_view()

    def _sales_context_menu(self, event, tree):
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
        sel = tree.selection()
        menu = tk.Menu(self, tearoff=False)
        if sel:
            values = tree.item(sel[0], "values") or ()
            month = str(values[0] or "") if values else ""
            menu.add_command(
                label=f"Create / Print Report for {month}",
                command=lambda m=month: self._sales_monthly_report(m),
            )
            menu.add_command(
                label="Copy Row",
                command=lambda v=values: (
                    self.clipboard_clear(),
                    self.clipboard_append("\t".join(str(x) for x in v)),
                ),
            )
            menu.add_separator()
        menu.add_command(label="Refresh Sales from eBay", command=self._refresh_sales_from_ebay)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _month_bounds_utc(self, month_key):
        m = re.fullmatch(r"(\d{4})-(\d{2})", str(month_key or "").strip())
        if not m:
            raise ValueError("Month must be YYYY-MM.")
        year, month = int(m.group(1)), int(m.group(2))
        start = datetime(year, month, 1, tzinfo=timezone.utc)
        if month == 12:
            end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            end = datetime(year, month + 1, 1, tzinfo=timezone.utc)
        return start, end

    @staticmethod
    def _money_value(obj):
        try:
            if isinstance(obj, dict):
                return float(obj.get("value", 0) or 0)
            return float(obj or 0)
        except Exception:
            return 0.0

    def _find_money_recursive(self, obj, candidate_keys):
        """Find the first Amount-like value under one of several normalized keys."""
        wanted = {re.sub(r"[^a-z0-9]", "", str(k).casefold()) for k in candidate_keys}

        def walk(value):
            if isinstance(value, dict):
                # Prefer exact candidate keys at this level.
                for k, v in value.items():
                    nk = re.sub(r"[^a-z0-9]", "", str(k).casefold())
                    if nk in wanted:
                        if isinstance(v, dict) and "value" in v:
                            return self._money_value(v)
                        if isinstance(v, (int, float, str)):
                            try:
                                return float(v)
                            except Exception:
                                pass
                for v in value.values():
                    found = walk(v)
                    if found is not None:
                        return found
            elif isinstance(value, list):
                for v in value:
                    found = walk(v)
                    if found is not None:
                        return found
            return None

        return walk(obj)

    def _ebay_earnings_summary_values(self, response):
        """
        Normalize eBay's order_earnings_summary payload into Seller Hub-style
        gross/expense/refund/net components.
        """
        gross = self._find_money_recursive(
            response,
            ("grossAmount", "grossSalesAmount", "grossSales", "totalGrossAmount"),
        )
        expenses = self._find_money_recursive(
            response,
            ("expenseAmount", "expensesAmount", "totalExpenses", "totalExpenseAmount"),
        )
        refunds = self._find_money_recursive(
            response,
            ("totalBuyerRefunds", "buyerRefundAmount", "buyerRefundsAmount", "totalRefundAmount"),
        )
        net = self._find_money_recursive(
            response,
            ("netOrderEarnings", "netOrderEarningsAmount", "netEarnings", "orderEarningsAmount"),
        )

        gross = float(gross or 0.0)
        expenses = float(expenses or 0.0)
        refunds = float(refunds or 0.0)
        if net is None:
            net = gross - expenses - refunds
        net = float(net or 0.0)

        return {
            "gross_ex_tax": gross,
            "selling_costs": expenses,
            "buyer_refunds": refunds,
            "net_sales": net,
        }

    def _orders_ebay_collected_tax(self, orders):
        """
        Sum taxes/fees that eBay collected from buyers for the selected orders.
        Orders should be requested with fieldGroups=TAX_BREAKDOWN.
        """
        total = 0.0
        for order in orders or []:
            if not isinstance(order, dict):
                continue
            # TAX_BREAKDOWN returns line-level taxes. For US orders eBay generally
            # indicates collect-and-remit at the order level.
            collect_and_remit = bool(order.get("ebayCollectAndRemitTax"))
            for li in order.get("lineItems", []) or []:
                if not isinstance(li, dict):
                    continue

                explicit = li.get("ebayCollectAndRemitTaxes", []) or []
                if explicit:
                    for tax in explicit:
                        if isinstance(tax, dict):
                            total += self._money_value(tax.get("amount", {}))
                    continue

                if collect_and_remit:
                    for tax in li.get("taxes", []) or []:
                        if isinstance(tax, dict):
                            total += self._money_value(tax.get("amount", {}))
        return total

    def _finance_report_summary(self, transactions):
        summary = {
            "gross_sales": 0.0,
            "selling_fees": 0.0,
            "shipping_labels": 0.0,
            "refunds": 0.0,
            "credits": 0.0,
            "other_charges": 0.0,
            "net_proceeds": 0.0,
            "sales_transactions": 0,
        }
        fee_breakdown = {}

        for tx in transactions or []:
            ttype = str(tx.get("transactionType", "") or "").upper()
            booking = str(tx.get("bookingEntry", "") or "").upper()
            amount = self._money_value(tx.get("amount", {}))
            signed = -amount if booking == "DEBIT" else amount

            # Skip payout/transfer movement so money moving to a bank account is not
            # treated as a business expense.
            if ttype not in ("PAYOUT", "TRANSFER"):
                summary["net_proceeds"] += signed

            if ttype == "SALE":
                summary["sales_transactions"] += 1
                basis = self._money_value(tx.get("totalFeeBasisAmount", {}))
                summary["gross_sales"] += basis if basis > 0 else amount
                fees = self._money_value(tx.get("totalFeeAmount", {}))
                summary["selling_fees"] += fees

                for li in tx.get("orderLineItems", []) or []:
                    for fee in li.get("marketplaceFees", []) or []:
                        name = str(fee.get("feeType", "") or "Other selling fee")
                        value = self._money_value(fee.get("amount", {}))
                        fee_breakdown[name] = fee_breakdown.get(name, 0.0) + value

            elif ttype == "REFUND":
                summary["refunds"] += amount
            elif ttype == "SHIPPING_LABEL":
                summary["shipping_labels"] += amount if booking == "DEBIT" else -amount
            elif ttype == "CREDIT":
                summary["credits"] += amount
            elif ttype in ("NON_SALE_CHARGE", "ADJUSTMENT", "DISPUTE"):
                if booking == "DEBIT":
                    summary["other_charges"] += amount
                    name = str(tx.get("feeType", "") or tx.get("transactionMemo", "") or ttype)
                    fee_breakdown[name] = fee_breakdown.get(name, 0.0) + amount
                else:
                    summary["credits"] += amount

        return summary, fee_breakdown

    def _sales_cached_month_summary(self, month_key):
        con = self._inventory_connect()
        try:
            row = con.execute(
                """SELECT COALESCE(SUM(sales_value),0), COALESCE(SUM(order_total),0),
                          COUNT(*), COALESCE(SUM(units),0)
                   FROM sales_orders WHERE substr(creation_date,1,7)=?""",
                (month_key,),
            ).fetchone()
            return {
                "merchandise_sales": float(row[0] or 0),
                "order_total": float(row[1] or 0),
                "orders": int(row[2] or 0),
                "units": int(row[3] or 0),
            }
        finally:
            con.close()

    def _seller_hub_report_fallback(self, client, start_iso, end_iso):
        """
        Build Seller Hub-style headline totals without the newer order_earnings
        resource. Uses Trading GetOrders for sales/tax and regular Finances
        transactions for costs/refunds.
        """
        trading_orders = client.get_trading_orders_between(start_iso, end_iso)
        valid_orders = [
            o for o in trading_orders
            if str(o.get("status", "") or "").upper() not in ("CANCELLED", "CANCELED")
        ]
        total_sales = sum(float(o.get("total", 0) or 0) for o in valid_orders)
        ebay_tax = sum(float(o.get("tax", 0) or 0) for o in valid_orders)
        units = sum(int(o.get("units", 0) or 0) for o in valid_orders)
        order_count = len(valid_orders)

        # Regular Finances transactions are broadly available even when the new
        # order_earnings endpoint is not enabled for the keyset.
        txs = client.get_finance_transactions(start_iso, end_iso)
        finance, fees = self._finance_report_summary(txs)

        # Seller Hub selling costs are net costs for the period, so credits reduce
        # fees/labels/charges rather than being presented as a second deduction.
        selling_costs = max(
            0.0,
            float(finance.get("selling_fees", 0) or 0)
            + float(finance.get("shipping_labels", 0) or 0)
            + float(finance.get("other_charges", 0) or 0)
            - float(finance.get("credits", 0) or 0),
        )
        net_sales = total_sales - ebay_tax - selling_costs

        return {
            "total_sales": total_sales,
            "ebay_tax": ebay_tax,
            "selling_costs": selling_costs,
            "net_sales": net_sales,
            "units": units,
            "order_count": order_count,
            "buyer_refunds": float(finance.get("refunds", 0) or 0),
            "shipping_labels": float(finance.get("shipping_labels", 0) or 0),
            "credits": float(finance.get("credits", 0) or 0),
            "fees": fees,
            "source": "Trading GetOrders + Finances compatibility mode",
        }

    def _sales_monthly_report(self, month_key=None):
        if not month_key:
            month_key = simpledialog.askstring(
                "Monthly Sales Report",
                "Month to report (YYYY-MM):",
                initialvalue=datetime.now().strftime("%Y-%m"),
                parent=self,
            )
        if not month_key:
            return
        month_key = str(month_key).strip()
        try:
            start, end = self._month_bounds_utc(month_key)
        except Exception:
            messagebox.showerror(
                "Monthly Sales Report",
                "Enter the month as YYYY-MM, for example 2026-08.",
                parent=self,
            )
            return

        self._save_settings_ui_silent()
        self.sales_status_var.set(f"Building Seller Hub-style report for {month_key}…")
        self._show_busy(
            "Building Monthly Sales Report",
            f"Matching eBay Seller Hub Performance reporting for {month_key}…",
            cancellable=True,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                start_iso = start.strftime("%Y-%m-%dT%H:%M:%S.000Z")
                end_inclusive = end - timedelta(milliseconds=1)
                end_iso = end_inclusive.strftime("%Y-%m-%dT%H:%M:%S.999Z")

                report_source = "Finances Order Earnings API"
                try:
                    earnings_raw = client.get_order_earnings_summary(start_iso, end_iso)
                    orders = client.get_orders_between(
                        start_iso, end_iso, field_groups="TAX_BREAKDOWN"
                    )
                    earnings = self._ebay_earnings_summary_values(earnings_raw)
                    ebay_tax = self._orders_ebay_collected_tax(orders)
                    total_sales = earnings["gross_ex_tax"] + ebay_tax
                    selling_costs = earnings["selling_costs"]
                    net_sales = earnings["net_sales"]
                    buyer_refunds = earnings["buyer_refunds"]

                    if abs(net_sales) < 0.0001 and abs(earnings["gross_ex_tax"]) > 0.0001:
                        net_sales = earnings["gross_ex_tax"] - selling_costs - buyer_refunds

                    units = 0
                    order_count = 0
                    for order in orders or []:
                        if not isinstance(order, dict):
                            continue
                        cancel_state = str(
                            ((order.get("cancelStatus") or {}).get("cancelState") or "")
                        ).upper()
                        if cancel_state in ("CANCELED", "CANCELLED"):
                            continue
                        order_count += 1
                        for li in order.get("lineItems", []) or []:
                            try:
                                units += int(li.get("quantity", 1) or 1)
                            except Exception:
                                units += 1

                    try:
                        txs = client.get_finance_transactions(start_iso, end_iso)
                        finance_detail, fees = self._finance_report_summary(txs)
                        shipping_labels = finance_detail.get("shipping_labels", 0.0)
                        credits = finance_detail.get("credits", 0.0)
                    except Exception:
                        fees = {}
                        shipping_labels = 0.0
                        credits = 0.0

                except Exception as exc:
                    msg = str(exc)
                    if "403" in msg or "1100" in msg or "Access denied" in msg:
                        self._log(
                            "MONTHLY REPORT: newer Order Earnings API is not enabled "
                            "for this seller/keyset; using compatibility reporting path."
                        )
                        fallback = self._seller_hub_report_fallback(
                            client, start_iso, end_iso
                        )
                        total_sales = fallback["total_sales"]
                        ebay_tax = fallback["ebay_tax"]
                        selling_costs = fallback["selling_costs"]
                        net_sales = fallback["net_sales"]
                        units = fallback["units"]
                        order_count = fallback["order_count"]
                        buyer_refunds = fallback["buyer_refunds"]
                        shipping_labels = fallback["shipping_labels"]
                        credits = fallback["credits"]
                        fees = fallback["fees"]
                        report_source = fallback["source"]
                    else:
                        raise

                avg_price = (total_sales / units) if units else 0.0

                reports_dir = APP_DIR / "sales_reports"
                reports_dir.mkdir(parents=True, exist_ok=True)
                report_path = reports_dir / f"Trade_Components_Sales_Report_{month_key}.html"

                month_label = start.strftime("%B %Y")
                fee_rows = "".join(
                    f"<tr><td>{html.escape(str(name).replace('_',' ').title())}</td>"
                    f"<td class='num'>${value:,.2f}</td></tr>"
                    for name, value in sorted(fees.items(), key=lambda x: (-x[1], x[0]))
                ) or "<tr><td colspan='2'>No detailed fee categories were returned.</td></tr>"

                report_html = f"""<!doctype html>
<html><head><meta charset="utf-8">
<title>Trade Components Sales Report - {html.escape(month_label)}</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;color:#253444;margin:36px;}}
h1{{color:#173d68;margin-bottom:4px}} .sub{{color:#66717d;margin-bottom:24px}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}
.card{{border:1px solid #ccd3da;border-radius:8px;padding:14px;background:#fafafa}}
.card b{{display:block;font-size:12px;color:#64717e;margin-bottom:5px}}
.card span{{font-size:20px;font-weight:600}}
.net{{background:#e4f2f3}}
table{{border-collapse:collapse;width:100%;margin-top:12px}}
th,td{{border-bottom:1px solid #d8dde2;padding:9px;text-align:left}}
th{{background:#eef2f5}} .num{{text-align:right}}
.note{{font-size:12px;color:#66717d;margin-top:20px;line-height:1.45}}
@media print{{button{{display:none}} body{{margin:18px}}}}
</style></head><body>
<button onclick="window.print()">Print Report</button>
<h1>Trade Components Inc.</h1>
<div class="sub">eBay Sales Performance Report — {html.escape(month_label)}</div>

<div class="grid">
<div class="card"><b>TOTAL SALES (INCLUDES TAXES)</b><span>${total_sales:,.2f}</span></div>
<div class="card"><b>TAXES / FEES COLLECTED BY EBAY</b><span>${ebay_tax:,.2f}</span></div>
<div class="card"><b>SELLING COSTS (INCLUDES SHIPPING)</b><span>${selling_costs:,.2f}</span></div>
<div class="card net"><b>NET SALES</b><span>${net_sales:,.2f}</span></div>
<div class="card"><b>QUANTITY SOLD</b><span>{units:,}</span></div>
<div class="card"><b>AVG. SALES PRICE PER ITEM</b><span>${avg_price:,.2f}</span></div>
<div class="card"><b>ORDERS</b><span>{order_count:,}</span></div>
<div class="card"><b>BUYER REFUNDS</b><span>${buyer_refunds:,.2f}</span></div>
</div>

<h2>Seller Hub reconciliation</h2>
<table>
<tr><th>Seller Hub-style measure</th><th class="num">Amount</th></tr>
<tr><td>Total sales (gross seller amount + eBay-collected taxes/fees)</td><td class="num">${total_sales:,.2f}</td></tr>
<tr><td>Less: taxes / fees collected by eBay</td><td class="num">${ebay_tax:,.2f}</td></tr>
<tr><td>Less: selling costs including eBay-account shipping costs</td><td class="num">${selling_costs:,.2f}</td></tr>
<tr><td><b>Net sales</b></td><td class="num"><b>${net_sales:,.2f}</b></td></tr>
</table>

<h2>Selling-cost detail</h2>
<table><tr><th>Fee / charge</th><th class="num">Amount</th></tr>
{fee_rows}
<tr><td>Shipping labels appearing in Finances transactions</td><td class="num">${shipping_labels:,.2f}</td></tr>
<tr><td>Seller credits appearing in Finances transactions</td><td class="num">${credits:,.2f}</td></tr>
</table>

<p class="note">
This report is intentionally based on eBay's order-earnings reporting rather than raw
monthly payment-ledger movement. That keeps the headline figures aligned with Seller Hub
Performance: Total Sales, taxes/fees collected by eBay, Selling Costs, and Net Sales.
Detailed fee rows are supplemental and can differ in timing because individual Finances
transactions are recorded when the charge or credit posts.
</p>
<p class="note">Report data path: {html.escape(report_source)}.</p>
<p class="note">Generated {datetime.now().strftime("%Y-%m-%d %H:%M")}.</p>
</body></html>"""
                report_path.write_text(report_html, encoding="utf-8")

                self.after(
                    0,
                    lambda: self.sales_status_var.set(
                        f"Seller Hub-style report ready: {month_key} — "
                        f"Total ${total_sales:,.2f}, Net ${net_sales:,.2f}"
                    ),
                )
                self.after(0, lambda p=report_path: webbrowser.open(p.resolve().as_uri()))
                self.after(
                    0,
                    lambda p=report_path: messagebox.showinfo(
                        "Monthly Sales Report",
                        "The Seller Hub-style monthly report was created and opened.\n\n"
                        "Compare the four headline figures against Seller Hub > Performance > Sales.\n\n"
                        f"Data source: {report_source}\n\n"
                        f"Saved locally at:\n{p}",
                        parent=self,
                    ),
                )
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Monthly Sales Report",
                        "Could not build the Seller Hub-style monthly report.\n\n" + e,
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()


    def _order_sales_values(self, order):
        pricing = order.get("pricingSummary", {}) or {}
        def money(field):
            obj = pricing.get(field, {}) or {}
            try: return float(obj.get("value", 0) or 0)
            except Exception: return 0.0
        # priceSubtotal is merchandise sales; fall back to total if unavailable.
        sales_value = money("priceSubtotal")
        order_total = money("total")
        if sales_value <= 0:
            sales_value = order_total
        currency = str((pricing.get("priceSubtotal") or pricing.get("total") or {}).get("currency", "USD") or "USD")
        units = 0
        for li in order.get("lineItems", []) or []:
            try: units += int(li.get("quantity", 1) or 1)
            except Exception: units += 1
        return sales_value, order_total, currency, units

    def _store_sales_orders(self, orders):
        if not orders: return 0
        con = self._inventory_connect(); stored = 0
        try:
            for order in orders:
                if not isinstance(order, dict): continue
                oid = str(order.get("orderId", "") or "").strip()
                created = str(order.get("creationDate", "") or "").strip()
                if not oid or not created: continue
                sales_value, order_total, currency, units = self._order_sales_values(order)
                cancel_state = str(((order.get("cancelStatus") or {}).get("cancelState") or "")).upper()
                if cancel_state in ("CANCELED", "CANCELLED"):
                    sales_value = 0.0
                    order_total = 0.0
                    units = 0
                status = str(order.get("orderFulfillmentStatus", "") or "")
                con.execute(
                    """INSERT INTO sales_orders(order_id,creation_date,sales_value,order_total,currency,units,fulfillment_status,updated_at)
                       VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(order_id) DO UPDATE SET creation_date=excluded.creation_date,
                           sales_value=excluded.sales_value,order_total=excluded.order_total,currency=excluded.currency,
                           units=excluded.units,fulfillment_status=excluded.fulfillment_status,updated_at=CURRENT_TIMESTAMP""",
                    (oid, created, sales_value, order_total, currency, units, status),
                )
                stored += 1
            con.commit()
        finally: con.close()
        return stored

    def _month_key(self, dt):
        return f"{dt.year:04d}-{dt.month:02d}"

    def _sales_month_rows(self, months=None):
        try: months = int(months or self.sales_range_var.get() or 12)
        except Exception: months = 12
        months = max(1, min(months, 60))
        now = datetime.now()
        keys = []
        y, m = now.year, now.month
        for _ in range(months):
            keys.append(f"{y:04d}-{m:02d}")
            m -= 1
            if m == 0: y -= 1; m = 12
        keys.reverse()
        con = self._inventory_connect()
        try:
            raw = con.execute(
                """SELECT substr(creation_date,1,7) AS month,
                          SUM(sales_value) AS sales, COUNT(*) AS orders, SUM(units) AS units
                   FROM sales_orders GROUP BY substr(creation_date,1,7)"""
            ).fetchall()
            data = {str(r["month"]): {"sales":float(r["sales"] or 0), "orders":int(r["orders"] or 0), "units":int(r["units"] or 0)} for r in raw}
        finally: con.close()
        rows=[]
        for key in keys:
            d=data.get(key,{"sales":0.0,"orders":0,"units":0})
            rows.append({"month":key, **d})
        return rows

    def _pct_text(self, current, prior):
        if prior == 0:
            return "—" if current == 0 else "NEW"
        pct = (current-prior)/prior*100.0
        return f"{pct:+.1f}%"

    def _refresh_sales_view(self):
        if not hasattr(self, "sales_tree"): return
        rows = self._sales_month_rows()
        self.sales_tree.delete(*self.sales_tree.get_children())
        prior = None
        for row in rows:
            change = "—" if prior is None else self._pct_text(row["sales"], prior)
            self.sales_tree.insert("", "end", values=(row["month"], f"${row['sales']:,.2f}", row["orders"], row["units"], change))
            prior = row["sales"]
        if rows:
            cur=rows[-1]; prev=rows[-2] if len(rows)>1 else {"sales":0}
            self.sales_summary_vars["current"].set(f"${cur['sales']:,.2f}")
            self.sales_summary_vars["previous"].set(f"${prev['sales']:,.2f}")
            self.sales_summary_vars["mom"].set(self._pct_text(cur["sales"], prev["sales"]))
            yoy_key = f"{datetime.now().year-1:04d}-{datetime.now().month:02d}"
            yoy = next((r for r in rows if r["month"] == yoy_key), None)
            if yoy is None:
                con = self._inventory_connect()
                try:
                    value = con.execute(
                        "SELECT SUM(sales_value) FROM sales_orders WHERE substr(creation_date,1,7)=?",
                        (yoy_key,),
                    ).fetchone()[0]
                    yoy = {"sales": float(value or 0)} if value is not None else None
                finally:
                    con.close()
            self.sales_summary_vars["yoy"].set(self._pct_text(cur["sales"], yoy["sales"]) if yoy else "—")
            self.sales_summary_vars["orders"].set(str(cur["orders"]))
            self.sales_summary_vars["units"].set(str(cur["units"]))
            self.dashboard_vars["sales_month"].set(f"${cur['sales']:,.0f}")
        self._reapply_treeview_sort(self.sales_tree)
        self.sales_status_var.set(
            f"Showing {len(rows)} month(s). Sales uses eBay merchandise subtotal when available; otherwise order total."
        )
        self._draw_sales_chart()

    def _draw_sales_chart(self):
        canvas = getattr(self, "sales_canvas", None)
        if canvas is None: return
        rows = self._sales_month_rows()
        canvas.delete("all")
        w=max(400,canvas.winfo_width()); h=max(220,canvas.winfo_height())
        left, right, top, bottom = 70, 20, 20, 45
        plot_w=w-left-right; plot_h=h-top-bottom
        maxv=max([r["sales"] for r in rows] or [1]); maxv=max(maxv,1)
        canvas.create_line(left,top,left,h-bottom,fill="#8795a3")
        canvas.create_line(left,h-bottom,w-right,h-bottom,fill="#8795a3")
        n=max(1,len(rows)); gap=5; barw=max(5,(plot_w-gap*(n+1))/n)
        for i,row in enumerate(rows):
            x0=left+gap+i*(barw+gap); x1=x0+barw
            bh=(row["sales"]/maxv)*plot_h; y0=h-bottom-bh
            canvas.create_rectangle(x0,y0,x1,h-bottom,fill="#5d7fa3",outline="")
            label=row["month"][2:].replace("-","/")
            if n <= 12 or i % 2 == 0:
                canvas.create_text((x0+x1)/2,h-bottom+15,text=label,fill="#44515f",font=("Segoe UI",8))
        for frac in (0,.25,.5,.75,1):
            y=h-bottom-frac*plot_h; val=maxv*frac
            canvas.create_line(left-4,y,w-right,y,fill="#e5dfd6")
            canvas.create_text(left-8,y,text=f"${val:,.0f}",anchor="e",fill="#596675",font=("Segoe UI",8))

    def _refresh_sales_from_ebay(self):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME,"Another operation is already running.",parent=self); return
        self._save_settings_ui_silent()
        try: months=max(1,min(int(self.sales_range_var.get() or 12),24))
        except Exception: months=12
        self.sales_status_var.set(f"Loading approximately {months} months of eBay order history…")
        self._show_busy(
            "Refreshing Sales",
            f"Downloading and consolidating approximately {months} months of eBay order history…",
            cancellable=True,
        )
        def work():
            try:
                client=EbayClient(self.settings.copy(),self.cancel_event,self._log)
                end_dt=datetime.now(timezone.utc)
                desired_start=end_dt-timedelta(days=int(months*31+10))
                # Fulfillment API creationDate is strictly limited to the previous
                # two years. Stay just inside the boundary; locally cached older
                # data remains available for comparisons.
                earliest_allowed=end_dt-timedelta(days=729)
                start_dt=max(desired_start, earliest_allowed)
                cursor=start_dt; all_orders={}
                while cursor < end_dt:
                    chunk_end=min(cursor+timedelta(days=89),end_dt)
                    a=cursor.strftime("%Y-%m-%dT%H:%M:%S.000Z")
                    b=chunk_end.strftime("%Y-%m-%dT%H:%M:%S.000Z")
                    for order in client.get_orders_between(a,b):
                        oid=str(order.get("orderId","") or "")
                        if oid: all_orders[oid]=order
                    cursor=chunk_end+timedelta(seconds=1)
                stored=self._store_sales_orders(list(all_orders.values()))
                self.after(0,self._refresh_sales_view); self.after(0,self._refresh_dashboard)
                self.after(0,lambda: messagebox.showinfo("Sales Analytics",f"Sales history refreshed.\n\nOrders retrieved: {len(all_orders):,}\nOrders stored/updated: {stored:,}",parent=self))
            except Exception as exc:
                self.after(0,lambda e=str(exc): messagebox.showerror("Sales Analytics","Could not refresh sales history.\n\n"+e,parent=self))
            finally:
                self._finish_busy_from_worker()
        threading.Thread(target=work,daemon=True).start()

    # =======================================================================
    # ORDERS / PENDING SHIPPING WORKSPACE
    # =======================================================================

    def _build_orders_tab(self):
        outer = self.orders_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        top.columnconfigure(4, weight=1)

        ttk.Label(top, text="Orders to Ship", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 14)
        )
        ttk.Button(
            top, text="REFRESH FROM EBAY", command=self._orders_refresh_from_ebay
        ).grid(row=0, column=1, padx=(0, 8))
        ttk.Button(
            top, text="PURCHASE LABEL", command=self._orders_purchase_label,
            style="Primary.TButton"
        ).grid(row=0, column=2, padx=(0, 8))
        ttk.Label(top, text="Search:").grid(row=0, column=3, sticky="e")
        search = ttk.Entry(top, textvariable=self.orders_search_var, width=32)
        search.grid(row=0, column=4, sticky="ew", padx=(6, 0))
        search.bind("<KeyRelease>", lambda _e: self._orders_refresh_view())

        ttk.Label(
            outer,
            textvariable=self.orders_status_var,
            style="Subheader.TLabel",
            anchor="w",
        ).grid(row=1, column=0, sticky="ew", pady=(0, 6))

        paned = ttk.Panedwindow(outer, orient="horizontal")
        paned.grid(row=2, column=0, sticky="nsew")

        left = ttk.Frame(paned, padding=(0, 0, 6, 0))
        right = ttk.Frame(paned, padding=(6, 0, 0, 0))
        paned.add(left, weight=3)
        paned.add(right, weight=2)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(3, weight=1)

        cols = (
            "ship_by", "order_id", "item", "buyer", "qty",
            "total", "location", "payment", "fulfillment"
        )
        tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        self.orders_tree = tree

        heads = {
            "ship_by": "SHIP BY",
            "order_id": "ORDER #",
            "item": "ITEM(S)",
            "buyer": "BUYER",
            "qty": "QTY",
            "total": "ORDER TOTAL",
            "location": "LOCATION",
            "payment": "PAYMENT",
            "fulfillment": "FULFILLMENT",
        }
        widths = {
            "ship_by": 100,
            "order_id": 155,
            "item": 360,
            "buyer": 150,
            "qty": 55,
            "total": 95,
            "location": 125,
            "payment": 115,
            "fulfillment": 125,
        }
        for col in cols:
            tree.heading(
                col,
                text=heads[col],
                command=lambda c=col, tr=tree: self._sort_treeview_column(tr, c),
            )
            tree.column(col, width=widths[col], minwidth=50, anchor="w", stretch=False)

        vs = ttk.Scrollbar(left, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(left, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        tree.tag_configure("overdue", background="#f3c7c7", foreground="#442222")
        tree.tag_configure("due_soon", background="#fff0c2", foreground="#4a3b00")
        tree.tag_configure("normal", background="#dceeff", foreground="#213547")
        tree.bind("<<TreeviewSelect>>", lambda _e: self._orders_show_selected())
        tree.bind("<Double-1>", lambda _e: self._orders_show_selected())
        tree.bind("<Button-3>", self._orders_context_menu)
        tree.bind(
            "<Shift-MouseWheel>",
            lambda e: tree.xview_scroll(int(-1 * (e.delta / 120)), "units"),
        )

        self.order_detail_title_var = tk.StringVar(value="Select an order")
        self.order_detail_meta_var = tk.StringVar(value="")
        ttk.Label(
            right, textvariable=self.order_detail_title_var, style="Section.TLabel"
        ).grid(row=0, column=0, sticky="ew")
        ttk.Label(
            right,
            textvariable=self.order_detail_meta_var,
            justify="left",
            wraplength=520,
        ).grid(row=1, column=0, sticky="ew", pady=(3, 8))

        actions = ttk.Frame(right)
        actions.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(
            actions, text="PURCHASE LABEL",
            command=self._orders_purchase_label,
            style="Primary.TButton",
        ).pack(side="left", padx=(0, 5))
        ttk.Button(
            actions, text="OPEN ORDER ON EBAY",
            command=self._orders_open_order,
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="JUMP TO INVENTORY",
            command=self._orders_jump_selected_inventory,
        ).pack(side="left", padx=5)
        ttk.Button(
            actions, text="ADJUST STOCK",
            command=self._orders_adjust_stock,
        ).pack(side="left", padx=5)

        detail_wrap = ttk.Frame(right)
        detail_wrap.grid(row=3, column=0, sticky="nsew")
        detail_wrap.columnconfigure(0, weight=1)
        detail_wrap.rowconfigure(0, weight=1)

        self.order_detail_text = tk.Text(
            detail_wrap,
            wrap="word",
            state="disabled",
            borderwidth=1,
            relief="solid",
            padx=10,
            pady=8,
        )
        dscroll = ttk.Scrollbar(
            detail_wrap, orient="vertical", command=self.order_detail_text.yview
        )
        self.order_detail_text.configure(yscrollcommand=dscroll.set)
        self.order_detail_text.grid(row=0, column=0, sticky="nsew")
        dscroll.grid(row=0, column=1, sticky="ns")
        self.order_detail_text.tag_configure(
            "section", font=("Segoe UI", 10, "bold"), spacing1=8, spacing3=3
        )
        self.order_detail_text.tag_configure(
            "label", font=("Segoe UI", 9, "bold")
        )
        self.order_detail_text.tag_configure(
            "muted", foreground="#5f6870"
        )

        self._orders_refresh_view()

    def _orders_cache_map(self):
        out = {}
        for order in self.recent_orders_cache or []:
            if isinstance(order, dict):
                oid = str(order.get("orderId", "") or "").strip()
                if oid:
                    out[oid] = order
        out.update({
            str(k): v
            for k, v in (self.orders_detail_cache or {}).items()
            if isinstance(v, dict)
        })
        return out

    def _orders_local_rows(self):
        con = self._inventory_connect()
        try:
            rows = con.execute(
                """SELECT * FROM inventory_items
                   WHERE status='PENDING_SHIPPING'
                   ORDER BY CASE WHEN trim(COALESCE(ship_by_date,''))='' THEN 1 ELSE 0 END,
                            ship_by_date, ebay_order_id, item"""
            ).fetchall()

            # V4.23.19 migration-on-read: older builds marked a zero-stock
            # physical parent DEPLETED immediately when the order was placed.
            # Restore it to Master visibility until the sale actually ships.
            for row in rows:
                self._ensure_pending_parent_visible(con, row)
            con.commit()

            return [dict(r) for r in rows]
        finally:
            con.close()

    def _orders_group_local(self):
        groups = {}
        for row in self._orders_local_rows():
            order_id = str(row.get("ebay_order_id", "") or "").strip()
            key = order_id or f"LOCAL-{row.get('id')}"
            groups.setdefault(key, []).append(row)
        return groups

    def _orders_money(self, value):
        if isinstance(value, dict):
            amount = value.get("value", "")
            currency = str(value.get("currency", "") or "")
        else:
            amount = value
            currency = ""
        try:
            number = float(amount)
            return f"${number:,.2f}" + (f" {currency}" if currency and currency != "USD" else "")
        except Exception:
            return str(amount or "")

    def _orders_order_total(self, order):
        pricing = (order or {}).get("pricingSummary", {}) or {}
        return self._orders_money(pricing.get("total", ""))

    def _orders_buyer_name(self, order):
        buyer = (order or {}).get("buyer", {}) or {}
        return str(
            buyer.get("username")
            or buyer.get("taxAddress", {}).get("fullName")
            or ""
        )

    def _orders_item_summary(self, local_rows, order):
        titles = []
        for li in (order or {}).get("lineItems", []) or []:
            if isinstance(li, dict):
                title = str(li.get("title", "") or "").strip()
                if title and title not in titles:
                    titles.append(title)
        if not titles:
            for row in local_rows or []:
                title = str(row.get("item", "") or "").strip()
                if title and title not in titles:
                    titles.append(title)
        if not titles:
            return ""
        if len(titles) == 1:
            return titles[0]
        return f"{len(titles)} items — " + "; ".join(titles[:2]) + (
            "…" if len(titles) > 2 else ""
        )

    def _orders_total_qty(self, local_rows, order):
        qty = 0
        line_items = (order or {}).get("lineItems", []) or []
        if line_items:
            for li in line_items:
                try:
                    qty += int((li or {}).get("quantity", 1) or 1)
                except Exception:
                    qty += 1
            return qty
        for row in local_rows or []:
            try:
                qty += int(row.get("sale_quantity") or row.get("qty") or 0)
            except Exception:
                pass
        return qty

    def _orders_refresh_view(self):
        tree = getattr(self, "orders_tree", None)
        if tree is None:
            return

        selected = tree.selection()
        selected_id = selected[0] if selected else ""
        tree.delete(*tree.get_children())

        cache = self._orders_cache_map()
        groups = self._orders_group_local()
        search = str(self.orders_search_var.get() or "").strip().casefold()

        today = datetime.now().date()
        displayed = 0
        for order_id, local_rows in groups.items():
            order = cache.get(order_id, {})
            buyer = self._orders_buyer_name(order)
            item_summary = self._orders_item_summary(local_rows, order)
            qty = self._orders_total_qty(local_rows, order)
            total = self._orders_order_total(order)
            locations = []
            for row in local_rows:
                loc = str(row.get("location", "") or "").strip()
                if loc and loc not in locations:
                    locations.append(loc)
            location = ", ".join(locations)
            ship_by = min(
                [
                    str(r.get("ship_by_date", "") or "").strip()
                    for r in local_rows
                    if str(r.get("ship_by_date", "") or "").strip()
                ] or [""]
            )
            payment = str(order.get("orderPaymentStatus", "") or "").replace("_", " ")
            fulfillment = str(order.get("orderFulfillmentStatus", "") or "PENDING SHIPPING").replace("_", " ")

            hay = " ".join([
                order_id, buyer, item_summary, location, ship_by, payment, fulfillment,
                " ".join(str(r.get("item_number", "") or "") for r in local_rows),
            ]).casefold()
            if search and search not in hay:
                continue

            tag = "normal"
            if ship_by:
                try:
                    due = datetime.strptime(ship_by[:10], "%Y-%m-%d").date()
                    if due < today:
                        tag = "overdue"
                    elif (due - today).days <= 1:
                        tag = "due_soon"
                except Exception:
                    pass

            tree.insert(
                "", "end", iid=order_id,
                values=(
                    ship_by,
                    order_id.replace("LOCAL-", ""),
                    item_summary,
                    buyer,
                    qty,
                    total,
                    location,
                    payment,
                    fulfillment,
                ),
                tags=(tag,),
            )
            displayed += 1

        self.orders_status_var.set(
            f"{displayed:,} order(s) awaiting shipment. "
            "Red = overdue; yellow = due today/tomorrow."
        )
        self._reapply_treeview_sort(tree)

        if selected_id and tree.exists(selected_id):
            tree.selection_set(selected_id)
            tree.focus(selected_id)
            tree.see(selected_id)
        elif displayed:
            first = tree.get_children()[0]
            tree.selection_set(first)
            tree.focus(first)
            self.after(10, self._orders_show_selected)

    def _orders_selected_id(self):
        tree = getattr(self, "orders_tree", None)
        if tree is None:
            return ""
        sel = tree.selection()
        return str(sel[0]) if sel else ""

    def _orders_append_detail(self, text, value="", tag=None):
        widget = self.order_detail_text
        widget.insert("end", str(text), tag or ())
        if value != "":
            widget.insert("end", str(value))
        widget.insert("end", "\n")

    def _orders_render_detail(self, order_id, order, local_rows):
        widget = self.order_detail_text
        widget.config(state="normal")
        widget.delete("1.0", "end")

        item_summary = self._orders_item_summary(local_rows, order)
        buyer = self._orders_buyer_name(order)
        ship_by = min(
            [
                str(r.get("ship_by_date", "") or "").strip()
                for r in local_rows
                if str(r.get("ship_by_date", "") or "").strip()
            ] or [""]
        )

        self.order_detail_title_var.set(item_summary or f"Order {order_id}")
        meta = f"Order #: {order_id}"
        if buyer:
            meta += f"   •   Buyer: {buyer}"
        if ship_by:
            meta += f"   •   Ship by: {ship_by}"
        self.order_detail_meta_var.set(meta)

        self._orders_append_detail("ORDER SUMMARY", tag="section")
        summary_fields = [
            ("Order ID: ", order_id),
            ("Created: ", str(order.get("creationDate", "") or "")),
            ("Last modified: ", str(order.get("lastModifiedDate", "") or "")),
            ("Payment: ", str(order.get("orderPaymentStatus", "") or "").replace("_", " ")),
            ("Fulfillment: ", str(order.get("orderFulfillmentStatus", "") or "").replace("_", " ")),
            ("Ship by: ", ship_by),
        ]
        cancel_state = str(((order.get("cancelStatus") or {}).get("cancelState") or ""))
        if cancel_state:
            summary_fields.append(("Cancel state: ", cancel_state.replace("_", " ")))
        for label, value in summary_fields:
            if value:
                self._orders_append_detail(label, value, "label")

        pricing = order.get("pricingSummary", {}) or {}
        if pricing:
            self._orders_append_detail("\nPRICING", tag="section")
            for key, label in (
                ("priceSubtotal", "Items subtotal: "),
                ("deliveryCost", "Shipping charged: "),
                ("tax", "Tax: "),
                ("discount", "Discount: "),
                ("adjustment", "Adjustment: "),
                ("total", "Order total: "),
            ):
                if pricing.get(key) not in (None, "", {}):
                    self._orders_append_detail(label, self._orders_money(pricing.get(key)), "label")

        buyer_data = order.get("buyer", {}) or {}
        ship_to = {}
        instructions = order.get("fulfillmentStartInstructions", []) or []
        if instructions and isinstance(instructions[0], dict):
            ship_to = (
                ((instructions[0].get("shippingStep") or {}).get("shipTo")) or {}
            )

        if buyer_data or ship_to:
            self._orders_append_detail("\nBUYER / SHIP TO", tag="section")
            if buyer:
                self._orders_append_detail("eBay buyer: ", buyer, "label")
            if ship_to:
                full_name = str(ship_to.get("fullName", "") or "")
                company = str(ship_to.get("companyName", "") or "")
                address = ship_to.get("contactAddress", {}) or {}
                phone = str(ship_to.get("primaryPhone", "") or "")
                email = str(ship_to.get("email", "") or "")
                if full_name:
                    self._orders_append_detail("Name: ", full_name, "label")
                if company:
                    self._orders_append_detail("Company: ", company, "label")
                address_lines = [
                    str(address.get("addressLine1", "") or ""),
                    str(address.get("addressLine2", "") or ""),
                    " ".join(
                        x for x in [
                            str(address.get("city", "") or ""),
                            str(address.get("stateOrProvince", "") or ""),
                            str(address.get("postalCode", "") or ""),
                        ] if x
                    ),
                    str(address.get("countryCode", "") or ""),
                ]
                address_text = "\n".join(x for x in address_lines if x.strip())
                if address_text:
                    self._orders_append_detail("Address:\n", address_text, "label")
                if phone:
                    self._orders_append_detail("Phone: ", phone, "label")
                if email:
                    self._orders_append_detail("Email: ", email, "label")

        line_items = order.get("lineItems", []) or []
        self._orders_append_detail("\nITEMS", tag="section")
        if line_items:
            for i, li in enumerate(line_items, 1):
                if not isinstance(li, dict):
                    continue
                title = str(li.get("title", "") or "")
                self._orders_append_detail(f"{i}. ", title or "Item", "label")
                details = []
                for key, label in (
                    ("legacyItemId", "Item #"),
                    ("sku", "SKU"),
                    ("lineItemId", "Line item"),
                    ("quantity", "Qty"),
                    ("soldFormat", "Format"),
                ):
                    value = li.get(key)
                    if value not in (None, ""):
                        details.append(f"{label}: {value}")
                if li.get("lineItemCost"):
                    details.append(f"Item cost: {self._orders_money(li.get('lineItemCost'))}")
                if li.get("deliveryCost"):
                    details.append(f"Shipping: {self._orders_money(li.get('deliveryCost'))}")
                if details:
                    self._orders_append_detail("   " + "   •   ".join(details))

        if local_rows:
            self._orders_append_detail("\nLOCAL INVENTORY", tag="section")
            for row in local_rows:
                bits = [
                    f"Location: {row.get('location') or '—'}",
                    f"Condition: {row.get('condition') or '—'}",
                    f"Item #: {row.get('item_number') or '—'}",
                    f"Qty: {row.get('sale_quantity') or row.get('qty') or '—'}",
                ]
                self._orders_append_detail(" • ".join(bits))

        if instructions:
            self._orders_append_detail("\nSHIPPING / FULFILLMENT", tag="section")
            for inst in instructions:
                if not isinstance(inst, dict):
                    continue
                for key, label in (
                    ("minEstimatedDeliveryDate", "Estimated delivery from: "),
                    ("maxEstimatedDeliveryDate", "Estimated delivery by: "),
                ):
                    if inst.get(key):
                        self._orders_append_detail(label, inst.get(key), "label")
                shipping_step = inst.get("shippingStep", {}) or {}
                if shipping_step:
                    for key, label in (
                        ("shippingCarrierCode", "Carrier: "),
                        ("shippingServiceCode", "Service: "),
                    ):
                        if shipping_step.get(key):
                            self._orders_append_detail(label, shipping_step.get(key), "label")

        payment_summary = order.get("paymentSummary", {}) or {}
        payments = payment_summary.get("payments", []) or []
        if payments:
            self._orders_append_detail("\nPAYMENT DETAILS", tag="section")
            for pmt in payments:
                if not isinstance(pmt, dict):
                    continue
                bits = []
                if pmt.get("paymentStatus"):
                    bits.append(str(pmt.get("paymentStatus")).replace("_", " "))
                if pmt.get("paymentDate"):
                    bits.append(str(pmt.get("paymentDate")))
                if pmt.get("amount"):
                    bits.append(self._orders_money(pmt.get("amount")))
                if pmt.get("paymentMethod"):
                    bits.append(str(pmt.get("paymentMethod")))
                if bits:
                    self._orders_append_detail(" • ".join(bits))

        if not order:
            self._orders_append_detail(
                "\nLive eBay details are loading or unavailable. "
                "The local Pending Shipping information above is still usable.",
                tag="muted",
            )

        widget.config(state="disabled")

    def _orders_show_selected(self):
        order_id = self._orders_selected_id()
        if not order_id:
            return
        groups = self._orders_group_local()
        local_rows = groups.get(order_id, [])
        cache = self._orders_cache_map()
        order = cache.get(order_id, {})
        self._orders_render_detail(order_id, order, local_rows)

        if (
            order_id.startswith("LOCAL-")
            or order_id in self.orders_detail_cache
            or order_id in self._orders_loading_ids
        ):
            return

        # Fetch the exact order quietly so selecting a row reveals every field
        # available from the Fulfillment API, even when it fell outside the most
        # recent cache page/window.
        self._orders_loading_ids.add(order_id)
        self.orders_status_var.set(f"Loading full eBay details for order {order_id}…")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                detail = client.get_order_by_id(order_id)
                if isinstance(detail, dict) and detail:
                    self.orders_detail_cache[order_id] = detail
                    self.after(0, self._orders_refresh_view)
                    self.after(0, self._orders_show_selected)
            except Exception as exc:
                self._log(f"ORDER DETAIL WARNING {order_id}: {exc}")
            finally:
                self._orders_loading_ids.discard(order_id)
                self.after(0, self._orders_update_status_only)

        threading.Thread(target=work, daemon=True).start()

    def _orders_update_status_only(self):
        try:
            count = len(self._orders_group_local())
            self.orders_status_var.set(
                f"{count:,} order(s) awaiting shipment."
            )
        except Exception:
            pass

    def _orders_refresh_from_ebay(self):
        self._show_busy(
            "Refreshing Orders",
            "Loading awaiting-shipment orders and reconciling local status…",
            cancellable=True,
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                orders = client.get_recent_orders(90)
                self.recent_orders_cache = orders
                for order in orders or []:
                    if isinstance(order, dict) and order.get("orderId"):
                        self.orders_detail_cache[str(order.get("orderId"))] = order
                self._store_sales_orders(orders)
                self._inventory_sync_orders_apply(orders)
                self._reconcile_stale_pending_shipping(client, orders)

                for order in orders or []:
                    if isinstance(order, dict):
                        oid = str(order.get("orderId", "") or "").strip()
                        if oid:
                            self.orders_detail_cache[oid] = order

                self.after(0, self._orders_refresh_view)
                self.after(0, self._refresh_dashboard)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Orders",
                        "Could not refresh orders from eBay.\n\n" + e,
                        parent=self,
                    ),
                )
            finally:
                self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()

    def _orders_purchase_label(self):
        order_id = self._orders_selected_id()
        if not order_id or order_id.startswith("LOCAL-"):
            messagebox.showinfo(
                "Orders",
                "Select an eBay order with an Order ID first.",
                parent=self,
            )
            return
        # eBay's single-label flow opens directly to the package/label page for
        # this order rather than the Seller Hub order list.
        webbrowser.open(
            "https://www.ebay.com/ship/single/" + parse.quote(order_id, safe="")
        )

    def _orders_open_order(self):
        order_id = self._orders_selected_id()
        if not order_id or order_id.startswith("LOCAL-"):
            return
        webbrowser.open(
            "https://www.ebay.com/sh/ord/details?orderid="
            + parse.quote(order_id, safe="")
        )

    def _orders_adjust_stock(self):
        order_id = self._orders_selected_id()
        if not order_id:
            return
        rows = self._orders_group_local().get(order_id, [])
        if not rows:
            return
        parent_id = rows[0].get("parent_item_id")
        if not parent_id:
            messagebox.showinfo(
                "Adjust Stock",
                "This order is not linked to a physical inventory parent row.",
                parent=self,
            )
            return
        con = self._inventory_connect()
        try:
            parent = con.execute(
                "SELECT * FROM inventory_items WHERE id=?",
                (int(parent_id),),
            ).fetchone()
        finally:
            con.close()
        if not parent:
            return
        current = int(parent["stock"] or 0)
        value = simpledialog.askinteger(
            "Adjust Available Stock",
            f"{parent['item']}\n\n"
            f"Current available stock: {current}\n\n"
            "Enter the NEW AVAILABLE quantity. Do not include units already "
            "committed to this pending order.",
            initialvalue=current,
            minvalue=0,
            parent=self,
        )
        if value is None:
            return
        con = self._inventory_connect()
        try:
            status = str(parent["status"] or "MASTER").upper()
            if value <= 0:
                status = "AWAITING_SHIPMENT"
            elif status in ("AWAITING_SHIPMENT", "DEPLETED"):
                status = "LISTED" if str(parent["item_number"] or "").strip() else "MASTER"
            con.execute(
                """UPDATE inventory_items
                   SET stock=?, status=?, updated_at=CURRENT_TIMESTAMP
                   WHERE id=?""",
                (int(value), status, int(parent_id)),
            )
            con.commit()
        finally:
            con.close()
        self._audit(
            "STOCK ADJUSTMENT",
            f"Order {order_id}; item {parent['item_number'] or parent_id}; "
            f"{current} -> {value}",
        )
        self._inventory_refresh_all()
        self._orders_refresh_view()

    def _orders_jump_selected_inventory(self):
        order_id = self._orders_selected_id()
        if not order_id:
            return
        groups = self._orders_group_local()
        rows = groups.get(order_id, [])
        if not rows:
            return
        # A Pending Shipping child belongs to a parent physical inventory row.
        parent_id = rows[0].get("parent_item_id")
        item_number = rows[0].get("item_number", "")
        jumped = False
        if parent_id:
            jumped = self._inventory_jump_to_item(row_id=parent_id)
        if not jumped:
            jumped = self._inventory_jump_to_item(item_number=item_number)
        if not jumped:
            messagebox.showinfo(
                "Orders",
                "The matching physical inventory row could not be found.",
                parent=self,
            )

    def _orders_context_menu(self, event):
        tree = self.orders_tree
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
            self._orders_show_selected()
        if not tree.selection():
            return "break"
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Purchase Shipping Label", command=self._orders_purchase_label)
        menu.add_command(label="Open Order on eBay", command=self._orders_open_order)
        menu.add_command(label="Jump to Inventory", command=self._orders_jump_selected_inventory)
        menu.add_separator()
        menu.add_command(
            label="Copy Order Number",
            command=lambda: (
                self.clipboard_clear(),
                self.clipboard_append(self._orders_selected_id()),
            ),
        )
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _orders_jump_to_order(self, order_id="", item_number="", row_id=None):
        order_id = str(order_id or "").strip()
        self._select_top_tab(self.orders_tab)
        self.orders_search_var.set("")
        self._orders_refresh_view()

        if not order_id:
            # Try resolving the order from the local child row/item number.
            con = self._inventory_connect()
            try:
                row = None
                if row_id is not None:
                    row = con.execute(
                        "SELECT ebay_order_id FROM inventory_items WHERE id=?",
                        (int(row_id),),
                    ).fetchone()
                if row is None and item_number:
                    row = con.execute(
                        """SELECT ebay_order_id FROM inventory_items
                           WHERE status='PENDING_SHIPPING' AND item_number=?
                           ORDER BY id DESC LIMIT 1""",
                        (str(item_number).strip(),),
                    ).fetchone()
                if row:
                    order_id = str(row[0] or "").strip()
            finally:
                con.close()

        if order_id and self.orders_tree.exists(order_id):
            self.orders_tree.selection_set(order_id)
            self.orders_tree.focus(order_id)
            self.orders_tree.see(order_id)
            self._orders_show_selected()
            return True
        return False

    def _inventory_connect(self):
        con = sqlite3.connect(self.inventory_db_path)
        con.row_factory = sqlite3.Row
        return con

    def _build_inventory_tab(self):
        outer = self.inventory_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Inventory", style="Header.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 14))
        ttk.Label(top, text="Search:").grid(row=0, column=1, sticky="e")
        search = ttk.Entry(top, textvariable=self.inventory_search_var, width=38)
        search.grid(row=0, column=2, sticky="ew", padx=(6, 8))
        search.bind("<KeyRelease>", lambda _e: self._inventory_refresh_all())
        ttk.Button(top, text="SYNC EBAY STATUS", command=self._inventory_sync_ebay).grid(row=0, column=3, padx=3)
        ttk.Button(top, text="EXPORT CSV", command=self._inventory_export_csv).grid(row=0, column=4, padx=3)

        status = ttk.Label(
            outer,
            textvariable=self.inventory_status_var,
            style="Subheader.TLabel",
            anchor="w",
        )
        status.grid(row=1, column=0, sticky="ew", pady=(0, 6))

        nb = ttk.Notebook(outer)
        nb.grid(row=2, column=0, sticky="nsew")
        self.inventory_notebook = nb

        for key, label in (
            ("MASTER", "MASTER LIST"),
            ("PENDING_LOCATION", "PENDING LOCATION"),
            ("SOLD", "SOLD"),
        ):
            frame = ttk.Frame(nb, padding=5)
            frame.columnconfigure(0, weight=1)
            frame.rowconfigure(0, weight=1)
            nb.add(frame, text=label)
            self._inventory_build_tree(frame, key)

        controls = ttk.Frame(outer)
        controls.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        for col in range(9):
            controls.columnconfigure(col, weight=1)
        ttk.Button(controls, text="ADD ITEM", command=self._inventory_add_manual).grid(row=0, column=0, padx=3, sticky="ew")
        ttk.Button(controls, text="EDIT ITEM", command=self._inventory_edit_selected).grid(row=0, column=1, padx=3, sticky="ew")
        ttk.Button(controls, text="ASSIGN LOCATION", command=self._inventory_assign_location).grid(row=0, column=2, padx=3, sticky="ew")
        ttk.Button(controls, text="MOVE TO PENDING", command=self._inventory_move_pending).grid(row=0, column=3, padx=3, sticky="ew")
        ttk.Button(controls, text="MARK SOLD", command=self._inventory_mark_sold).grid(row=0, column=4, padx=3, sticky="ew")
        ttk.Button(controls, text="UNMARK SOLD", command=self._inventory_unmark_sold).grid(row=0, column=5, padx=3, sticky="ew")
        ttk.Button(controls, text="OPEN EBAY", command=self._inventory_open_ebay).grid(row=0, column=6, padx=3, sticky="ew")
        ttk.Button(controls, text="DELETE", command=self._inventory_delete_selected, style="Danger.TButton").grid(row=0, column=7, padx=3, sticky="ew")
        ttk.Button(controls, text="REFRESH", command=self._inventory_refresh_all).grid(row=0, column=8, padx=3, sticky="ew")

        self._inventory_refresh_all()

    def _inventory_build_tree(self, frame, key):
        columns = (
            "qty", "stock", "item", "location", "comment",
            "condition", "item_number", "status"
        )
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        vs = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        heads = {
            "qty":"QTY", "stock":"STOCK", "item":"ITEM", "location":"LOCATION",
            "comment":"COMMENT", "condition":"CONDITION", "item_number":"ITEM NUMBER",
            "ship_by_date":"SHIP BY", "status":"STATUS"
        }
        widths = {
            "qty":55, "stock":60, "item":430, "location":130, "comment":260,
            "condition":125, "item_number":125, "ship_by_date":110, "status":120
        }
        for c in columns:
            tree.heading(
                c,
                text=heads[c],
                command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col),
            )
            tree.column(c, width=widths[c], minwidth=45, stretch=False)
        tree.bind("<Double-1>", lambda e,tr=tree: self._inventory_double_click(e,tr))
        tree.bind("<Return>", lambda _e: self._inventory_edit_selected())
        tree.bind("<Shift-MouseWheel>", lambda e, tr=tree: tr.xview_scroll(int(-1 * (e.delta / 120)), "units"))
        tree.bind("<Button-3>", lambda e, tr=tree, k=key: self._inventory_context_menu(e, tr, k))
        self.inventory_trees[key] = tree

    def _inventory_double_click(self,event,tree):
        if tree.identify_region(event.x,event.y) not in ("cell","tree"):return "break"
        row=tree.identify_row(event.y)
        if not row:return "break"
        tree.selection_set(row);tree.focus(row);self._inventory_edit_selected()
        return "break"

    def _inventory_context_menu(self, event, tree, key):
        iid = tree.identify_row(event.y)
        if iid:
            try:
                self.inventory_notebook.select(
                    {"MASTER":0, "PENDING_LOCATION":1, "SOLD":2}.get(key, 0)
                )
            except Exception:
                pass
            tree.selection_set(iid)
            tree.focus(iid)
        if not tree.selection():
            return "break"

        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Edit Item", command=self._inventory_edit_selected)
        menu.add_command(label="Open eBay Listing", command=self._inventory_open_ebay)
        menu.add_separator()
        if key == "PENDING_LOCATION":
            menu.add_command(label="Assign Location", command=self._inventory_assign_location)
        elif key == "SOLD":
            menu.add_command(label="Unmark Sold / Restore", command=self._inventory_unmark_sold)
        else:
            menu.add_command(label="Assign / Change Location", command=self._inventory_assign_location)
            menu.add_command(label="Move to Pending Location", command=self._inventory_move_pending)
            menu.add_command(label="Mark Sold", command=self._inventory_mark_sold)
        menu.add_separator()
        menu.add_command(label="Copy Item Number", command=self._inventory_copy_selected_item_number)
        menu.add_command(label="Copy Row", command=lambda: self._copy_tree_selected_row(tree))
        menu.add_separator()
        menu.add_command(label="Delete", command=self._inventory_delete_selected)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _copy_tree_selected_row(self, tree):
        sel = tree.selection()
        if not sel:
            return
        vals = tree.item(sel[0], "values") or ()
        self.clipboard_clear()
        self.clipboard_append("\t".join(str(x) for x in vals))

    def _inventory_copy_selected_item_number(self):
        rid = self._inventory_selected_id()
        if not rid:
            return
        con = self._inventory_connect()
        try:
            row = con.execute("SELECT item_number FROM inventory_items WHERE id=?", (rid,)).fetchone()
            value = str(row[0] or "") if row else ""
        finally:
            con.close()
        if value:
            self.clipboard_clear()
            self.clipboard_append(value)

    def _inventory_active_key(self):
        try:
            idx = self.inventory_notebook.index(self.inventory_notebook.select())
            return ("MASTER", "PENDING_LOCATION", "SOLD")[idx]
        except Exception:
            return "MASTER"


    def _inventory_jump_to_item(self, item_number="", row_id=None):
        """
        Open Inventory, switch to the correct sub-tab, and select/scroll to the
        matching local row. This is used by Needs Attention OPEN / FIX.
        """
        con = self._inventory_connect()
        try:
            row = None
            if row_id is not None:
                row = con.execute(
                    "SELECT * FROM inventory_items WHERE id=?",
                    (int(row_id),),
                ).fetchone()
            if row is None and str(item_number or "").strip():
                rows = con.execute(
                    """SELECT * FROM inventory_items
                       WHERE trim(COALESCE(item_number,''))=?
                       ORDER BY CASE status
                           WHEN 'PENDING_SHIPPING' THEN 0
                           WHEN 'PENDING_LOCATION' THEN 1
                           WHEN 'SOLD' THEN 2
                           ELSE 3 END,
                           id DESC""",
                    (str(item_number).strip(),),
                ).fetchall()
                if rows:
                    row = rows[0]
            if row is None:
                return False
            row = dict(row)
        finally:
            con.close()

        status = str(row.get("status", "") or "").upper()
        if status == "PENDING_SHIPPING":
            self._select_top_tab(self.orders_tab)
            self._orders_refresh_view()
            return self._orders_jump_to_order(
                str(row.get("ebay_order_id", "") or ""),
                item_number=str(row.get("item_number", "") or ""),
                row_id=row.get("id"),
            )
        if status == "PENDING_LOCATION":
            key, tab_index = "PENDING_LOCATION", 1
        elif status == "SOLD":
            key, tab_index = "SOLD", 2
        else:
            key, tab_index = "MASTER", 0

        self._select_top_tab(self.inventory_tab)

        # Clear any prior inventory search so the exact row cannot be hidden by
        # whatever was searched last.
        self.inventory_search_var.set("")
        self._inventory_refresh_all()

        try:
            self.inventory_notebook.select(tab_index)
        except Exception:
            pass

        tree = self.inventory_trees.get(key)
        iid = str(row.get("id"))
        if tree is not None and tree.exists(iid):
            tree.selection_set(iid)
            tree.focus(iid)
            tree.see(iid)
            return True

        # Fallback: search the identifying value and try again.
        fallback = str(row.get("item_number") or row.get("item") or "").strip()
        if fallback:
            self.inventory_search_var.set(fallback)
            self._inventory_refresh_all()
            if tree is not None and tree.exists(iid):
                tree.selection_set(iid)
                tree.focus(iid)
                tree.see(iid)
                return True
        return False

    def _inventory_selected_id(self):
        tree = self.inventory_trees.get(self._inventory_active_key())
        if tree is None:
            return None
        sel = tree.selection()
        if not sel:
            return None
        try:
            return int(sel[0])
        except Exception:
            return None

    def _inventory_refresh_all(self):
        if not getattr(self, "inventory_trees", None):
            return
        search = str(self.inventory_search_var.get() or "").strip().lower()
        con = self._inventory_connect()
        try:
            colors = {r["location"]: r["color"] for r in con.execute("SELECT location,color FROM location_colors")}
            views = {
                "MASTER": "status NOT IN ('SOLD','PENDING_LOCATION','PENDING_SHIPPING','DEPLETED')",
                "PENDING_LOCATION": "status='PENDING_LOCATION'",
                "SOLD": "status='SOLD'",
            }
            total_counts = {}
            for key, where in views.items():
                tree = self.inventory_trees[key]
                tree.delete(*tree.get_children())
                sql = f"SELECT * FROM inventory_items WHERE {where}"
                args = []
                if search:
                    sql += " AND (lower(item) LIKE ? OR lower(location) LIKE ? OR lower(comment) LIKE ? OR lower(condition) LIKE ? OR lower(item_number) LIKE ?)"
                    like = f"%{search}%"
                    args = [like, like, like, like, like]
                sql += " ORDER BY location COLLATE NOCASE, item COLLATE NOCASE"
                rows = con.execute(sql, args).fetchall()
                total_counts[key] = len(rows)
                for row in rows:
                    loc = str(row["location"] or "")
                    tag = ""
                    if key == "SOLD":
                        tag = "sold_row"
                        try:
                            tree.tag_configure(
                                "sold_row",
                                background="#d98f8f",
                                foreground="#2b1717",
                            )
                        except Exception:
                            tag = ""
                    else:
                        if str(row["status"] or "").upper() == "AWAITING_SHIPMENT":
                            tag = "awaiting_shipment"
                            try:
                                tree.tag_configure(
                                    tag,
                                    background="#dceeff",
                                    foreground="#213547",
                                )
                            except Exception:
                                tag = ""
                        else:
                            color = str(row["color"] or colors.get(loc, "") or "")
                            if color:
                                tag = "loc_" + re.sub(r"[^A-Za-z0-9]", "_", color)
                                try:
                                    tree.tag_configure(tag, background=color)
                                except Exception:
                                    tag = ""
                    base_vals = (
                        "" if row["qty"] is None else row["qty"],
                        "" if row["stock"] is None else row["stock"],
                        row["item"] or "",
                        loc,
                        row["comment"] or "",
                        row["condition"] or "",
                        row["item_number"] or "",
                    )
                    vals = base_vals + (
                        str(row["status"] or "").replace("_", " "),
                    )
                    tree.insert("", "end", iid=str(row["id"]), values=vals, tags=(tag,) if tag else ())
                self._reapply_treeview_sort(tree)
            orders_to_ship = con.execute(
                """SELECT COUNT(DISTINCT CASE
                       WHEN trim(COALESCE(ebay_order_id,''))<>'' THEN ebay_order_id
                       ELSE 'LOCAL-' || id END)
                   FROM inventory_items WHERE status='PENDING_SHIPPING'"""
            ).fetchone()[0]
            self.inventory_status_var.set(
                f"Master: {total_counts.get('MASTER',0):,}  •  "
                f"Pending location: {total_counts.get('PENDING_LOCATION',0):,}  •  "
                f"Sold: {total_counts.get('SOLD',0):,}  •  "
                f"Orders to ship: {orders_to_ship:,}"
            )
        finally:
            con.close()
        try:
            self._refresh_dashboard()
        except Exception:
            pass
        try:
            self._orders_refresh_view()
        except Exception:
            pass

    def _inventory_item_dialog(self, existing=None, title="Inventory Item"):
        existing = dict(existing or {})
        win = tk.Toplevel(self)
        win.title(title)
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)
        frm = ttk.Frame(win, padding=14)
        frm.pack(fill="both", expand=True)
        fields = [
            ("qty", "QTY"), ("stock", "STOCK"), ("item", "ITEM"),
            ("location", "LOCATION"), ("comment", "COMMENT"),
            ("condition", "CONDITION"), ("item_number", "ITEM NUMBER"),
        ]
        vars_ = {}
        for r,(key,label) in enumerate(fields):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="e", padx=(0,8), pady=4)
            value = existing.get(key, "")
            if value is None: value = ""
            v = tk.StringVar(value=str(value))
            vars_[key]=v
            if key == "location":
                con=self._inventory_connect()
                try:
                    locations=[x[0] for x in con.execute("SELECT location FROM location_colors ORDER BY location COLLATE NOCASE")]
                finally: con.close()
                w=ttk.Combobox(frm, textvariable=v, values=locations, width=52)
            else:
                w=ttk.Entry(frm, textvariable=v, width=55)
            w.grid(row=r, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Leave LOCATION blank to place the item in PENDING LOCATION.", style="Subheader.TLabel").grid(row=len(fields), column=0, columnspan=2, sticky="w", pady=(6,8))
        result={}
        def save():
            if not vars_["item"].get().strip():
                messagebox.showerror(APP_NAME, "ITEM is required.", parent=win); return
            for k,v in vars_.items(): result[k]=v.get().strip()
            win.destroy()
        btn=ttk.Frame(frm); btn.grid(row=len(fields)+1,column=0,columnspan=2,sticky="e")
        ttk.Button(btn,text="CANCEL",command=win.destroy).pack(side="right",padx=(6,0))
        ttk.Button(btn,text="SAVE",command=save,style="Accent.TButton").pack(side="right")
        win.wait_window()
        return result or None

    @staticmethod
    def _inventory_num(value):
        s=str(value or "").strip()
        if not s: return None
        try: return float(s)
        except Exception: return None

    def _inventory_save_record(self, data, record_id=None, forced_status=None):
        location=str(data.get("location","") or "").strip()
        status=forced_status or ("MASTER" if location else "PENDING_LOCATION")
        item_number=str(data.get("item_number","") or "").strip()
        if status == "MASTER" and item_number:
            status="LISTED"
        con=self._inventory_connect()
        try:
            color=""
            if location:
                row=con.execute("SELECT color FROM location_colors WHERE location=?",(location,)).fetchone()
                color=str(row[0] or "") if row else ""
            vals=(self._inventory_num(data.get("qty")), self._inventory_num(data.get("stock")), str(data.get("item","")).strip(), location, str(data.get("comment","")).strip(), str(data.get("condition","")).strip(), item_number, status, color)
            if record_id:
                con.execute("""UPDATE inventory_items SET qty=?,stock=?,item=?,location=?,comment=?,condition=?,item_number=?,status=?,color=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""", vals+(int(record_id),))
            else:
                con.execute("""INSERT INTO inventory_items(qty,stock,item,location,comment,condition,item_number,status,color) VALUES(?,?,?,?,?,?,?,?,?)""", vals)
            con.commit()
        finally: con.close()
        self._audit(
            "INVENTORY SAVE",
            f"id={record_id or 'new'} item={item_number} stock={data.get('stock','')} location={location}",
        )
        self._inventory_refresh_all()

    def _inventory_add_manual(self):
        data=self._inventory_item_dialog(title="Add Inventory Item")
        if data: self._inventory_save_record(data)

    def _inventory_edit_selected(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try: row=con.execute("SELECT * FROM inventory_items WHERE id=?",(rid,)).fetchone()
        finally: con.close()
        if not row: return
        data=self._inventory_item_dialog(row,title="Edit Inventory Item")
        if data:
            status=str(row["status"] or "MASTER")
            if status=="SOLD": forced="SOLD"
            elif not str(data.get("location","")).strip(): forced="PENDING_LOCATION"
            else: forced="LISTED" if str(data.get("item_number","")).strip() else "MASTER"
            self._inventory_save_record(data,rid,forced)

    def _inventory_assign_location(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try:
            locations=[x[0] for x in con.execute("SELECT location FROM location_colors ORDER BY location COLLATE NOCASE")]
        finally: con.close()
        loc=simpledialog.askstring("Assign Inventory Location","Enter the physical location (for example JIMI 2):",parent=self)
        if loc is None: return
        loc=loc.strip()
        if not loc: return
        con=self._inventory_connect()
        try:
            row=con.execute("SELECT item_number FROM inventory_items WHERE id=?",(rid,)).fetchone()
            status="LISTED" if row and str(row[0] or "").strip() else "MASTER"
            color_row=con.execute("SELECT color FROM location_colors WHERE location=?",(loc,)).fetchone()
            color=str(color_row[0] or "") if color_row else ""
            con.execute("UPDATE inventory_items SET location=?,status=?,color=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(loc,status,color,rid))
            con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_move_pending(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try:
            con.execute("UPDATE inventory_items SET location='',status='PENDING_LOCATION',updated_at=CURRENT_TIMESTAMP WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_mark_sold(self):
        rid=self._inventory_selected_id()
        if not rid: return
        if not messagebox.askyesno("Inventory","Move this item to SOLD?",parent=self): return
        con=self._inventory_connect()
        try:
            con.execute("UPDATE inventory_items SET status='SOLD',date_sold=date('now'),updated_at=CURRENT_TIMESTAMP WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_unmark_sold(self):
        """Restore sold records; sale child rows merge their quantity back into parent stock."""
        rid = self._inventory_selected_id()
        if not rid:
            return

        con = self._inventory_connect()
        try:
            row = con.execute("SELECT * FROM inventory_items WHERE id=?", (rid,)).fetchone()
            if not row:
                return

            if str(row["status"] or "").upper() != "SOLD":
                messagebox.showinfo(
                    "Inventory",
                    "The selected inventory record is not marked SOLD.",
                    parent=self,
                )
                return

            parent_id = row["parent_item_id"]
            if parent_id:
                try:
                    sale_qty = int(row["sale_quantity"] if row["sale_quantity"] is not None else row["qty"] or 0)
                except Exception:
                    sale_qty = 0

                if not messagebox.askyesno(
                    "Inventory",
                    f"Return {sale_qty} unit(s) from this sold transaction back into inventory?\n\n"
                    "The sold transaction line will be removed and the parent item's STOCK will increase.",
                    parent=self,
                ):
                    return

                parent = con.execute(
                    "SELECT stock,item_number,location FROM inventory_items WHERE id=?",
                    (parent_id,),
                ).fetchone()
                if parent:
                    try:
                        stock = int(parent["stock"] or 0) + sale_qty
                    except Exception:
                        stock = sale_qty
                    new_status = (
                        "LISTED" if str(parent["item_number"] or "").strip()
                        else ("MASTER" if str(parent["location"] or "").strip() else "PENDING_LOCATION")
                    )
                    con.execute(
                        "UPDATE inventory_items SET stock=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                        (stock, new_status, parent_id),
                    )
                con.execute("DELETE FROM inventory_items WHERE id=?", (rid,))
                con.commit()
            else:
                location = str(row["location"] or "").strip()
                item_number = str(row["item_number"] or "").strip()
                new_status = "PENDING_LOCATION" if not location else ("LISTED" if item_number else "MASTER")

                if not messagebox.askyesno(
                    "Inventory",
                    "Restore this item from SOLD back to active inventory?\n\n"
                    "Its physical location and item information will be kept. "
                    "The sold date and matched eBay order will be cleared.",
                    parent=self,
                ):
                    return

                con.execute(
                    """UPDATE inventory_items
                       SET status=?,date_sold='',ebay_order_id='',updated_at=CURRENT_TIMESTAMP
                       WHERE id=?""",
                    (new_status, rid),
                )
                con.commit()
        finally:
            con.close()

        self._inventory_refresh_all()


    def _inventory_delete_selected(self):
        rid=self._inventory_selected_id()
        if not rid: return
        if not messagebox.askyesno("Inventory","Permanently remove this inventory record from the local database?",parent=self): return
        con=self._inventory_connect()
        try: con.execute("DELETE FROM inventory_items WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_open_ebay(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try: row=con.execute("SELECT item_number FROM inventory_items WHERE id=?",(rid,)).fetchone()
        finally: con.close()
        item_number=str(row[0] or "").strip() if row else ""
        if not item_number:
            messagebox.showinfo("Inventory","This record does not have an eBay Item Number yet.",parent=self); return
        webbrowser.open(f"https://www.ebay.com/itm/{item_number}")

    def _inventory_export_csv(self):
        path=filedialog.asksaveasfilename(title="Export Inventory CSV",defaultextension=".csv",filetypes=[("CSV files","*.csv")],initialfile="TradeComponents_Inventory.csv")
        if not path: return
        con=self._inventory_connect()
        try: rows=con.execute("SELECT * FROM inventory_items ORDER BY status,location,item").fetchall()
        finally: con.close()
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(["QTY","STOCK","ITEM","LOCATION","COMMENT","CONDITION","ITEM NUMBER","STATUS","DATE SOLD"])
            for r in rows: w.writerow([r["qty"],r["stock"],r["item"],r["location"],r["comment"],r["condition"],r["item_number"],r["status"],r["date_sold"]])
        messagebox.showinfo("Inventory",f"Inventory exported to:\n{path}",parent=self)

    def _inventory_ensure_published(self, listing_id, listing):
        """Automatically track every listing published by this app."""
        listing_id=str(listing_id or "").strip()
        if not listing_id: return
        con=self._inventory_connect()
        try:
            existing=con.execute("SELECT id FROM inventory_items WHERE item_number=? LIMIT 1",(listing_id,)).fetchone()
            if existing:
                con.execute("UPDATE inventory_items SET status=CASE WHEN status='SOLD' THEN status ELSE 'LISTED' END,updated_at=CURRENT_TIMESTAMP WHERE id=?",(existing[0],)); con.commit(); return
            qty=listing.get("quantity",1)
            title=str(listing.get("title","") or "").strip()
            condition=str(listing.get("condition","") or "").strip()
            con.execute("""INSERT INTO inventory_items(qty,stock,item,location,comment,condition,item_number,status,source_sheet)
                           VALUES(?,?,?,?,?,?,?,?,?)""",(qty,qty,title,"","",condition,listing_id,"PENDING_LOCATION","APP PUBLISH"))
            con.commit()
        finally: con.close()
        self.after(0,self._inventory_refresh_all)

    def _inventory_sync_active_apply(self, active_listings):
        """Reconcile local inventory against every current eBay active listing."""
        active_listings = [x for x in (active_listings or []) if isinstance(x, dict)]
        con = self._inventory_connect()
        marked_listed = 0
        added_missing = 0
        try:
            for listing in active_listings:
                item_number = str(listing.get("item_number", "") or "").strip()
                if not item_number:
                    continue

                row = con.execute(
                    """SELECT id,status,stock FROM inventory_items
                       WHERE item_number=? AND parent_item_id IS NULL
                       ORDER BY id LIMIT 1""",
                    (item_number,),
                ).fetchone()

                if row:
                    status = str(row["status"] or "MASTER").upper()
                    available = listing.get("quantity_available", None)
                    try:
                        available = max(0, int(available)) if available is not None else None
                    except Exception:
                        available = None

                    # eBay's current available quantity is authoritative for an
                    # active listing. This corrects local stock after partial sales
                    # without changing the original inventoried QTY.
                    if available is not None:
                        con.execute(
                            "UPDATE inventory_items SET stock=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                            (available, row["id"]),
                        )

                    if status not in ("PENDING_LOCATION", "PENDING_SHIPPING", "SOLD"):
                        if status != "LISTED":
                            marked_listed += 1
                        con.execute(
                            "UPDATE inventory_items SET status='LISTED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                            (row["id"],),
                        )
                else:
                    title = str(listing.get("title", "") or "").strip() or f"eBay Item {item_number}"
                    qty = listing.get("quantity_available", 1)
                    try:
                        qty = max(0, int(qty))
                    except Exception:
                        qty = 1
                    con.execute(
                        """INSERT INTO inventory_items(
                               qty,stock,item,location,comment,condition,item_number,status,source_sheet
                           ) VALUES(?,?,?,?,?,?,?,?,?)""",
                        (
                            qty, qty, title, "",
                            "Imported automatically from current eBay listings",
                            "", item_number, "PENDING_LOCATION", "EBAY ACTIVE SYNC"
                        ),
                    )
                    added_missing += 1
            con.commit()
        finally:
            con.close()

        self.after(0, self._inventory_refresh_all)
        return marked_listed, added_missing

    def _extract_order_ship_by_date(self, order):
        """
        Extract eBay's shipping/handling deadline when the Fulfillment response
        provides one. Newer and older order payloads expose timing fields in
        slightly different nested containers, so scan the known deadline keys.
        """
        deadline_keys = {
            "shipbydate",
            "handlebytime",
            "latestshipdate",
            "shippingfulfillmentstartdate",
        }
        found = []

        def walk(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    normalized = re.sub(r"[^a-z0-9]", "", str(key).casefold())
                    if normalized in deadline_keys and isinstance(child, str) and child.strip():
                        found.append(child.strip())
                    walk(child)
            elif isinstance(value, list):
                for child in value:
                    walk(child)

        walk(order)
        if not found:
            return ""

        parsed = []
        for raw in found:
            try:
                dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
                parsed.append((dt, raw))
            except Exception:
                pass
        if parsed:
            parsed.sort(key=lambda x: x[0])
            try:
                return parsed[0][0].astimezone().strftime("%Y-%m-%d")
            except Exception:
                return parsed[0][1][:10]
        return found[0][:10]

    def _inventory_sync_orders_apply(self, orders):
        """
        Quantity-aware order synchronization.

        The main inventory row represents currently available physical stock.
        Each eBay order line gets its own child row so a partial sale does not
        mark an entire multi-quantity inventory record sold.
        """
        con = self._inventory_connect()
        pending_count = 0
        sold_count = 0
        new_sale_lines = 0

        try:
            for order in orders or []:
                if not isinstance(order, dict):
                    continue

                order_id = str(order.get("orderId", "") or "").strip()
                ship_by_date = self._extract_order_ship_by_date(order)
                order_status = str(order.get("orderFulfillmentStatus", "") or "").upper()
                cancel_state = str(
                    ((order.get("cancelStatus") or {}).get("cancelState") or "")
                ).upper()
                is_canceled = cancel_state in ("CANCELED", "CANCELLED")
                is_fulfilled = order_status == "FULFILLED"
                child_status = (
                    "CANCELED_ORDER" if is_canceled
                    else ("SOLD" if is_fulfilled else "PENDING_SHIPPING")
                )

                for idx, li in enumerate(order.get("lineItems", []) or []):
                    if not isinstance(li, dict):
                        continue

                    legacy = str(li.get("legacyItemId", "") or "").strip()
                    if not legacy:
                        lr = li.get("legacyReference", {}) or {}
                        if isinstance(lr, dict):
                            legacy = str(lr.get("legacyItemId", "") or "").strip()
                    if not legacy:
                        itemid = str(li.get("itemId", "") or "")
                        m = re.search(r"(?:v1\|)?(\d{9,})", itemid)
                        legacy = m.group(1) if m else ""
                    if not legacy:
                        continue

                    try:
                        sold_qty = int(li.get("quantity", 1) or 1)
                    except Exception:
                        sold_qty = 1
                    sold_qty = max(1, sold_qty)

                    line_id = str(li.get("lineItemId", "") or "").strip()
                    if not line_id:
                        # Stable fallback prevents repeated syncs from subtracting twice.
                        line_id = f"{order_id}:{legacy}:{idx}"

                    existing_child = con.execute(
                        "SELECT id,status,ship_by_date FROM inventory_items WHERE ebay_order_line_id=? LIMIT 1",
                        (line_id,),
                    ).fetchone()

                    if existing_child:
                        if ship_by_date and str(existing_child["ship_by_date"] or "") != ship_by_date:
                            con.execute(
                                "UPDATE inventory_items SET ship_by_date=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                                (ship_by_date, existing_child["id"]),
                            )
                        old = str(existing_child["status"] or "").upper()
                        if is_canceled:
                            full_child = con.execute(
                                "SELECT * FROM inventory_items WHERE id=?",
                                (existing_child["id"],),
                            ).fetchone()
                            if full_child and old != "CANCELED_ORDER":
                                self._restore_canceled_sale_child(con, full_child)
                                canceled_count = 1
                            continue
                        if is_fulfilled and old != "SOLD":
                            con.execute(
                                """UPDATE inventory_items
                                   SET status='SOLD',
                                       date_sold=COALESCE(NULLIF(date_sold,''),date('now')),
                                       ebay_order_id=?,
                                       updated_at=CURRENT_TIMESTAMP
                                   WHERE id=?""",
                                (order_id, existing_child["id"]),
                            )
                            full_child = con.execute(
                                "SELECT * FROM inventory_items WHERE id=?",
                                (existing_child["id"],),
                            ).fetchone()
                            if full_child:
                                self._finalize_parent_after_shipment(con, full_child)
                            sold_count += 1
                        elif not is_fulfilled:
                            if old != "PENDING_SHIPPING":
                                con.execute(
                                    """UPDATE inventory_items
                                       SET status='PENDING_SHIPPING',
                                           ebay_order_id=?,
                                           updated_at=CURRENT_TIMESTAMP
                                       WHERE id=?""",
                                    (order_id, existing_child["id"]),
                                )
                                pending_count += 1
                            full_child = con.execute(
                                "SELECT * FROM inventory_items WHERE id=?",
                                (existing_child["id"],),
                            ).fetchone()
                            if full_child:
                                self._ensure_pending_parent_visible(con, full_child)
                        continue

                    if is_canceled:
                        # A canceled order is not an outstanding shipment and must
                        # not decrement local stock or create a Pending Shipping row.
                        continue

                    parent = con.execute(
                        """SELECT * FROM inventory_items
                           WHERE item_number=? AND parent_item_id IS NULL
                           ORDER BY CASE WHEN status='SOLD' THEN 1 ELSE 0 END, id
                           LIMIT 1""",
                        (legacy,),
                    ).fetchone()
                    if not parent:
                        continue

                    current_stock = parent["stock"]
                    try:
                        current_stock = int(current_stock if current_stock is not None else parent["qty"] or 0)
                    except Exception:
                        current_stock = 0
                    remaining = max(0, current_stock - sold_qty)

                    parent_status = str(parent["status"] or "MASTER").upper()
                    if remaining <= 0:
                        parent_status = (
                            "DEPLETED" if is_fulfilled else "AWAITING_SHIPMENT"
                        )
                    elif parent_status in (
                        "SOLD", "DEPLETED", "PENDING_SHIPPING",
                        "AWAITING_SHIPMENT"
                    ):
                        parent_status = "LISTED" if legacy else "MASTER"

                    con.execute(
                        """UPDATE inventory_items
                           SET stock=?,status=?,updated_at=CURRENT_TIMESTAMP
                           WHERE id=?""",
                        (remaining, parent_status, parent["id"]),
                    )

                    con.execute(
                        """INSERT INTO inventory_items(
                               qty,stock,item,location,comment,condition,item_number,
                               status,date_sold,ebay_order_id,source_sheet,color,
                               parent_item_id,ebay_order_line_id,sale_quantity,ship_by_date
                           ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            sold_qty,
                            0,
                            parent["item"],
                            parent["location"],
                            f"eBay order {order_id}",
                            parent["condition"],
                            legacy,
                            child_status,
                            time.strftime("%Y-%m-%d") if is_fulfilled else "",
                            order_id,
                            "EBAY ORDER SYNC",
                            parent["color"],
                            parent["id"],
                            line_id,
                            sold_qty,
                            ship_by_date,
                        ),
                    )
                    new_sale_lines += 1

                    new_child = con.execute(
                        """SELECT * FROM inventory_items
                           WHERE ebay_order_line_id=? LIMIT 1""",
                        (line_id,),
                    ).fetchone()
                    if new_child:
                        if is_fulfilled:
                            self._finalize_parent_after_shipment(con, new_child)
                        else:
                            self._ensure_pending_parent_visible(con, new_child)

                    if is_fulfilled:
                        sold_count += 1
                    else:
                        pending_count += 1

            con.commit()
        finally:
            con.close()

        self.after(0, self._inventory_refresh_all)
        return pending_count, sold_count, new_sale_lines


    def _pending_parent_status(self, parent, remaining):
        """
        Keep the physical inventory row visible while an exhausted sale is still
        waiting to ship. Partial-quantity parents remain normal active inventory.
        """
        try:
            remaining = int(remaining)
        except Exception:
            remaining = 0

        current = str(parent["status"] or "MASTER").upper()
        item_number = str(parent["item_number"] or "").strip()

        if remaining <= 0:
            return "AWAITING_SHIPMENT"

        if current in (
            "SOLD", "DEPLETED", "PENDING_SHIPPING",
            "AWAITING_SHIPMENT", "CANCELED_ORDER"
        ):
            return "LISTED" if item_number else "MASTER"
        return current or ("LISTED" if item_number else "MASTER")

    def _ensure_pending_parent_visible(self, con, child):
        """Repair old DEPLETED parents so Pending Shipping can jump to Inventory."""
        parent_id = child["parent_item_id"]
        if not parent_id:
            return

        parent = con.execute(
            "SELECT * FROM inventory_items WHERE id=?",
            (parent_id,),
        ).fetchone()
        if not parent:
            return

        try:
            remaining = int(
                parent["stock"]
                if parent["stock"] is not None
                else parent["qty"] or 0
            )
        except Exception:
            remaining = 0

        wanted = self._pending_parent_status(parent, remaining)
        current = str(parent["status"] or "").upper()
        if current != wanted and (
            remaining <= 0
            or current in ("DEPLETED", "SOLD", "PENDING_SHIPPING")
        ):
            con.execute(
                """UPDATE inventory_items
                   SET status=?,updated_at=CURRENT_TIMESTAMP
                   WHERE id=?""",
                (wanted, parent_id),
            )

    def _finalize_parent_after_shipment(self, con, child):
        """
        Once the sale child is fulfilled, remove an exhausted physical parent
        from Master. The SOLD child becomes the inventory-history line in Sold.
        """
        parent_id = child["parent_item_id"]
        if not parent_id:
            return

        parent = con.execute(
            "SELECT * FROM inventory_items WHERE id=?",
            (parent_id,),
        ).fetchone()
        if not parent:
            return

        try:
            remaining = int(
                parent["stock"]
                if parent["stock"] is not None
                else parent["qty"] or 0
            )
        except Exception:
            remaining = 0

        pending_left = con.execute(
            """SELECT COUNT(*) FROM inventory_items
               WHERE parent_item_id=? AND status='PENDING_SHIPPING'""",
            (parent_id,),
        ).fetchone()[0]

        if remaining <= 0:
            new_status = "AWAITING_SHIPMENT" if pending_left else "DEPLETED"
        else:
            current = str(parent["status"] or "").upper()
            if current in (
                "DEPLETED", "SOLD", "PENDING_SHIPPING", "AWAITING_SHIPMENT"
            ):
                new_status = (
                    "LISTED"
                    if str(parent["item_number"] or "").strip()
                    else "MASTER"
                )
            else:
                new_status = current or "MASTER"

        con.execute(
            """UPDATE inventory_items
               SET status=?,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (new_status, parent_id),
        )

    def _restore_canceled_sale_child(self, con, child):
        """Restore quantity from a canceled order-line child back to its parent."""
        parent_id = child["parent_item_id"]
        qty = int(child["sale_quantity"] or child["qty"] or 0)
        if parent_id and qty > 0:
            parent = con.execute(
                "SELECT id,stock,qty,status,item_number FROM inventory_items WHERE id=?",
                (parent_id,),
            ).fetchone()
            if parent:
                try:
                    current = int(parent["stock"] if parent["stock"] is not None else parent["qty"] or 0)
                except Exception:
                    current = 0
                new_stock = current + qty
                status = str(parent["status"] or "MASTER").upper()
                if status in ("DEPLETED", "AWAITING_SHIPMENT"):
                    status = "LISTED" if str(parent["item_number"] or "").strip() else "MASTER"
                con.execute(
                    "UPDATE inventory_items SET stock=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (new_stock, status, parent_id),
                )
        con.execute(
            """UPDATE inventory_items
               SET status='CANCELED_ORDER',
                   comment=trim(COALESCE(comment,'') || ' | Canceled/closed eBay order'),
                   updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (child["id"],),
        )

    def _reconcile_stale_pending_shipping(self, client, recent_orders):
        """
        Verify Pending Shipping rows against eBay. Fulfilled rows become Sold,
        canceled rows are removed from the shipping queue and their quantity is
        restored, and missing/archived rows are hidden from Pending Shipping
        rather than lingering forever.
        """
        recent_map = {
            str(o.get("orderId", "") or ""): o
            for o in (recent_orders or [])
            if isinstance(o, dict) and o.get("orderId")
        }
        con = self._inventory_connect()
        checked = moved_sold = canceled = archived = 0
        try:
            rows = con.execute(
                """SELECT * FROM inventory_items
                   WHERE status='PENDING_SHIPPING'
                     AND trim(COALESCE(ebay_order_id,''))<>''"""
            ).fetchall()

            for child in rows:
                order_id = str(child["ebay_order_id"] or "").strip()
                order = recent_map.get(order_id)

                if order is None:
                    try:
                        order = client.get_order_by_id(order_id)
                    except Exception as exc:
                        msg = str(exc)
                        # If eBay no longer resolves the order, stop showing it as
                        # an actionable shipment. Keep the row for audit history.
                        if "404" in msg or "not found" in msg.lower() or "resource" in msg.lower():
                            con.execute(
                                """UPDATE inventory_items
                                   SET status='ARCHIVED_ORDER',
                                       comment=trim(COALESCE(comment,'') || ' | No longer returned by eBay'),
                                       updated_at=CURRENT_TIMESTAMP
                                   WHERE id=?""",
                                (child["id"],),
                            )
                            archived += 1
                        continue

                checked += 1
                fulfillment = str(order.get("orderFulfillmentStatus", "") or "").upper()
                cancel_state = str(
                    ((order.get("cancelStatus") or {}).get("cancelState") or "")
                ).upper()

                if cancel_state in ("CANCELED", "CANCELLED"):
                    self._restore_canceled_sale_child(con, child)
                    canceled += 1
                elif fulfillment == "FULFILLED":
                    con.execute(
                        """UPDATE inventory_items
                           SET status='SOLD',
                               date_sold=COALESCE(NULLIF(date_sold,''),date('now')),
                               updated_at=CURRENT_TIMESTAMP
                           WHERE id=?""",
                        (child["id"],),
                    )
                    refreshed_child = con.execute(
                        "SELECT * FROM inventory_items WHERE id=?",
                        (child["id"],),
                    ).fetchone()
                    if refreshed_child:
                        self._finalize_parent_after_shipment(
                            con, refreshed_child
                        )
                    moved_sold += 1
                else:
                    self._ensure_pending_parent_visible(con, child)

            con.commit()
        finally:
            con.close()

        if moved_sold or canceled or archived:
            self._log(
                f"PENDING SHIPPING RECONCILE: checked {checked}, "
                f"sold {moved_sold}, canceled {canceled}, archived {archived}."
            )
        return checked, moved_sold, canceled, archived

    def _inventory_sync_ebay(
        self,
        silent=False,
        show_busy=False,
        busy_title="Syncing with eBay",
        busy_message="Synchronizing eBay and local inventory…",
    ):
        if self.worker and self.worker.is_alive():
            if not silent:
                messagebox.showinfo("Inventory", "Another operation is already running.", parent=self)
            return

        self._save_settings_ui_silent()
        if show_busy:
            self._show_busy(
                busy_title,
                busy_message,
                cancellable=True,
            )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                # Record order lines first. Then use eBay's current active
                # quantity as the authoritative remaining STOCK for live listings.
                self._log("INVENTORY SYNC: loading recent eBay orders...")
                orders = client.get_recent_orders(180)
                self._store_sales_orders(orders)
                pending, sold, new_sale_lines = self._inventory_sync_orders_apply(orders)
                stale_checked, stale_sold, stale_canceled, stale_archived = (
                    self._reconcile_stale_pending_shipping(client, orders)
                )

                self._log("INVENTORY SYNC: loading all current eBay listings...")
                active = client.get_all_active_listings()
                self.active_listings_cache = active
                self.recent_orders_cache = orders
                marked_listed, added_missing = self._inventory_sync_active_apply(active)
                try:
                    issues = self._detect_attention_issues(active)
                    self._store_attention_scan(issues)
                    self.after(0, self._populate_active_listings_tree)
                    self.after(0, self._populate_revamp_tree)
                    self.after(0, self._refresh_attention_trees)
                    self.after(0, self._refresh_sales_view)
                    self.after(0, self._refresh_dashboard)
                except Exception as attention_exc:
                    self._log("ATTENTION SCAN WARNING: " + str(attention_exc))

                if not silent:
                    self.after(
                        0,
                        lambda: messagebox.showinfo(
                            "Inventory Sync",
                            f"Full eBay reconciliation complete.\n\n"
                            f"Current active listings checked: {len(active):,}\n"
                            f"Recent orders checked: {len(orders):,}\n\n"
                            f"Existing inventory marked LISTED: {marked_listed:,}\n"
                            f"Active eBay listings added to Pending Location: {added_missing:,}\n"
                            f"New sale/order lines recorded: {new_sale_lines:,}\n"
                            f"Pending Shipping lines updated: {pending:,}\n"
                            f"Sold/shipped lines updated: {sold:,}\n"
                            f"Stale pending rows moved to Sold: {stale_sold:,}\n"
                            f"Canceled/closed rows removed from Pending Shipping: {stale_canceled + stale_archived:,}\n\n"
                            "Partial-quantity sales are tracked separately. The main inventory row keeps "
                            "the remaining STOCK, while only the quantity actually purchased appears in "
                            "Pending Shipping/Sold. Current active eBay quantity is used to reconcile "
                            "remaining STOCK.",
                            parent=self,
                        ),
                    )
            except Exception as exc:
                msg = str(exc)
                if "403" in msg or "scope" in msg.lower() or "fulfillment" in msg.lower():
                    msg = (
                        "Inventory sync needs the eBay OAuth permissions configured for this app.\n\n"
                        "sell.fulfillment is required for order/shipping status, sell.finances is requested for detailed monthly reporting, and the base api_scope "
                        "is used to read the full current eBay Active List.\n\n" + str(exc)
                    )
                self._log("INVENTORY EBAY SYNC ERROR: " + str(exc))
                if not silent:
                    self.after(
                        0,
                        lambda m=msg: messagebox.showerror("Inventory Sync", m, parent=self),
                    )
            finally:
                if show_busy:
                    self._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()


    def _startup_ebay_sync(self):
        """
        Reconcile with eBay automatically when the app opens if OAuth credentials
        are available. If OAuth is not configured, startup continues normally.
        """
        access = str(self.settings.get("access_token", "") or "").strip()
        refresh = str(self.settings.get("ebay_refresh_token", "") or "").strip()

        if access or refresh:
            self._log("STARTUP EBAY SYNC: OAuth credentials found; starting reconciliation.")
            self._inventory_sync_ebay(
                silent=True,
                show_busy=True,
                busy_title="Startup eBay Sync",
                busy_message=(
                    "Synchronizing active listings, recent orders, inventory, sales, "
                    "and Needs Attention before you begin working…"
                ),
            )
            self.after(2500, lambda: self._refresh_messages_from_ebay(silent=True))
        else:
            self._log("STARTUP EBAY SYNC: skipped because eBay OAuth is not configured.")

        # The startup sync is the first cycle. Subsequent automatic refreshes occur
        # every 15 minutes.
        self.after(15 * 60 * 1000, self._inventory_background_sync)

    def _inventory_background_sync(self):
        try:
            access = str(self.settings.get("access_token", "") or "").strip()
            refresh = str(self.settings.get("ebay_refresh_token", "") or "").strip()
            if access or refresh:
                self._inventory_sync_ebay(silent=True, show_busy=False)
        finally:
            self.after(15 * 60 * 1000, self._inventory_background_sync)

    def _build_listing_tab(self):
        outer = self.listing_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        f = ttk.Frame(canvas, padding=(8, 6, 14, 20))
        window_id = canvas.create_window((0, 0), window=f, anchor="nw")

        def _sync_scrollregion(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_width(event):
            canvas.itemconfigure(window_id, width=event.width)

        f.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        def _on_mousewheel(event):
            if event.delta:
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"

        # Keep mouse-wheel handling local to this tab.  Do not use bind_all:
        # global bindings can make the notebook/tab area respond while another
        # tab is active.
        canvas.bind("<MouseWheel>", _on_mousewheel)
        f.bind("<MouseWheel>", _on_mousewheel)

        def _bind_descendant_wheel(widget):
            try:
                widget.bind("<MouseWheel>", _on_mousewheel, add="+")
            except Exception:
                pass
            try:
                for child in widget.winfo_children():
                    _bind_descendant_wheel(child)
            except Exception:
                pass

        # Widgets created later may not exist yet; schedule once UI construction
        # for this tab has completed.
        self.after_idle(lambda: _bind_descendant_wheel(f))

        f.columnconfigure(1, weight=1)
        f.columnconfigure(3, weight=1)

        ttk.Label(
            f,
            text="Scroll down for listing details, pricing, shipping, eBay actions, and status.",
            style="Subheader.TLabel",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        # Photos are intentionally the first workflow section.  V4.04 uses a
        # local thumbnail manager; local grouping/scoring makes no AI/network calls.
        if PhotoManagerFrame is not None:
            self.photo_manager = PhotoManagerFrame(
                f,
                on_change=self._photos_changed,
                on_analyze=self._analyze_photos,
                log=self._log,
            )
            self.photo_manager.grid(
                row=1, column=0, columnspan=4, sticky="nsew", pady=(0, 8)
            )
            # Compatibility alias used by the analysis worker.
            self.analyze_btn = self.photo_manager.analyze_btn
        else:
            self.photo_manager = None
            missing_frame = ttk.LabelFrame(f, text="1. Item Photos", padding=8)
            missing_frame.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(0, 8))
            ttk.Label(
                missing_frame,
                text=(
                    "Local photo manager is unavailable because Pillow is not installed. "
                    "Run INSTALL_IMAGE_SUPPORT.bat, then restart the tool. "
                    + PHOTO_MANAGER_IMPORT_ERROR
                ),
                wraplength=900, justify="left",
            ).pack(anchor="w")

        self.vars = {}
        fields = [
            ("Brand / Manufacturer", "brand"),
            ("MPN / Part Number", "mpn"),
            ("Model", "model"),
            ("Basic Item Description", "item_description"),
            ("SKU / Custom Label", "sku"),
            ("Price", "price"),
            ("Quantity", "quantity"),
            ("Country of Origin", "country"),
            ("Category ID", "category_id"),
        ]

        r = 2
        for i, (label, key) in enumerate(fields):
            col = 0 if i % 2 == 0 else 2
            if i % 2 == 0 and i > 0:
                r += 1
            ttk.Label(f, text=label + ":").grid(row=r, column=col, sticky="w", padx=(0, 6), pady=4)
            v = tk.StringVar()
            self.vars[key] = v
            e = ttk.Entry(f, textvariable=v)
            e.grid(row=r, column=col + 1, sticky="ew", padx=(0, 14), pady=4)
            if key == "category_id":
                self.category_entry = e
                e.bind("<FocusOut>", lambda _e: self._sync_category_requirements_async())
            if key in ("brand", "mpn", "item_description"):
                v.trace_add("write", lambda *_: self._auto_title())
        self.category_suggestion_label = ttk.Label(
            f, text="", foreground="gray"
        )
        self.category_suggestion_label.grid(
            row=r + 1, column=2, columnspan=2, sticky="w", pady=(0, 2)
        )
        self.category_requirements_var = tk.StringVar(
            value="Category requirements not synced yet."
        )
        ttk.Label(
            f,
            textvariable=self.category_requirements_var,
            foreground="gray",
            wraplength=850,
        ).grid(row=r + 2, column=0, columnspan=4, sticky="w", pady=(0, 3))
        r += 2

        ttk.Label(f, text="Condition:").grid(row=r, column=0, sticky="w", pady=4)
        self.condition_var = tk.StringVar()
        self.condition_combo = ttk.Combobox(
            f,
            textvariable=self.condition_var,
            values=list(CONDITION_MAP.keys()),
            state="readonly",
        )
        self.condition_combo.grid(row=r, column=1, sticky="ew", padx=(0, 14), pady=4)

        ttk.Label(f, text="Title:").grid(row=r, column=2, sticky="w", pady=4)
        self.title_var = tk.StringVar()
        ttk.Entry(f, textvariable=self.title_var).grid(row=r, column=3, sticky="ew", pady=4)

        r += 1
        price_frame = ttk.LabelFrame(f, text="2. Competitive Price Research", padding=8)
        price_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        price_frame.columnconfigure(0, weight=1)
        price_frame.columnconfigure(1, weight=1)
        price_frame.columnconfigure(2, weight=1)
        self.price_research_var = tk.StringVar(
            value="Not researched yet. Current eBay Buy It Now listings will be used."
        )
        ttk.Label(
            price_frame, textvariable=self.price_research_var, wraplength=760, justify="left"
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))
        self.research_price_btn = ttk.Button(
            price_frame, text="RESEARCH + SUGGEST PRICE",
            command=self._research_price_manual, style="Accent.TButton"
        )
        self.research_price_btn.grid(row=1, column=0, sticky="ew", padx=(0, 5))
        ttk.Button(
            price_frame, text="Open Sold / Completed Comps on eBay",
            command=self._open_sold_comps
        ).grid(row=1, column=1, sticky="ew", padx=5)
        ttk.Button(
            price_frame, text="Clear Price Research",
            command=self._clear_price_research
        ).grid(row=1, column=2, sticky="ew", padx=(5, 0))

        r += 1
        offer_frame = ttk.LabelFrame(f, text="3. Sale Format — Buy It Now / Best Offer", padding=6)
        offer_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=4)
        for c in range(6):
            offer_frame.columnconfigure(c, weight=1)
        ttk.Label(offer_frame, text="Listing format: Buy It Now (Fixed Price)").grid(
            row=0, column=0, columnspan=2, sticky="w"
        )
        self.best_offer_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            offer_frame, text="Accept Best Offers", variable=self.best_offer_var
        ).grid(row=0, column=2, sticky="w")
        ttk.Label(offer_frame, text="Auto-accept $:").grid(row=0, column=3, sticky="e")
        self.auto_accept_var = tk.StringVar()
        ttk.Entry(offer_frame, textvariable=self.auto_accept_var, width=12).grid(
            row=0, column=4, sticky="ew", padx=(4, 10)
        )
        ttk.Label(offer_frame, text="Auto-decline $:").grid(row=0, column=5, sticky="e")
        self.auto_decline_var = tk.StringVar()
        ttk.Entry(offer_frame, textvariable=self.auto_decline_var, width=12).grid(
            row=0, column=6, sticky="ew", padx=(4, 0)
        )

        r += 1
        policy_frame = ttk.LabelFrame(f, text="4. eBay Business Policies", padding=6)
        policy_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=4)
        for c in range(6):
            policy_frame.columnconfigure(c, weight=1)
        self.fulfillment_policy_var = tk.StringVar()
        self.payment_policy_var = tk.StringVar()
        self.return_policy_var = tk.StringVar()
        ttk.Label(policy_frame, text="Shipping:").grid(row=0, column=0, sticky="e", padx=(0, 4))
        self.fulfillment_combo = ttk.Combobox(
            policy_frame, textvariable=self.fulfillment_policy_var, state="readonly"
        )
        self.fulfillment_combo.grid(row=0, column=1, sticky="ew", padx=(0, 8))
        ttk.Label(policy_frame, text="Payment:").grid(row=0, column=2, sticky="e", padx=(0, 4))
        self.payment_combo = ttk.Combobox(
            policy_frame, textvariable=self.payment_policy_var, state="readonly"
        )
        self.payment_combo.grid(row=0, column=3, sticky="ew", padx=(0, 8))
        ttk.Label(policy_frame, text="Returns:").grid(row=0, column=4, sticky="e", padx=(0, 4))
        self.return_combo = ttk.Combobox(
            policy_frame, textvariable=self.return_policy_var, state="readonly"
        )
        self.return_combo.grid(row=0, column=5, sticky="ew", padx=(0, 8))
        ttk.Button(
            policy_frame, text="Refresh Policies from eBay", command=self._refresh_policies
        ).grid(row=1, column=0, columnspan=6, sticky="e", pady=(6, 0))

        r += 1
        shipping_frame = ttk.LabelFrame(f, text="5. Shipping Package", padding=8)
        shipping_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        for c in range(12):
            shipping_frame.columnconfigure(c, weight=1)

        self.package_length_var = tk.StringVar()
        self.package_width_var = tk.StringVar()
        self.package_height_var = tk.StringVar()
        self.package_lb_var = tk.StringVar()
        self.package_oz_var = tk.StringVar()
        self.package_type_var = tk.StringVar(value="Standard package / thick envelope")

        ttk.Label(shipping_frame, text="Length (in):").grid(row=0, column=0, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_length_var, width=8).grid(row=0, column=1, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Width (in):").grid(row=0, column=2, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_width_var, width=8).grid(row=0, column=3, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Height (in):").grid(row=0, column=4, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_height_var, width=8).grid(row=0, column=5, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Weight:").grid(row=0, column=6, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_lb_var, width=7).grid(row=0, column=7, sticky="ew", padx=(4, 2))
        ttk.Label(shipping_frame, text="lb").grid(row=0, column=8, sticky="w")
        ttk.Entry(shipping_frame, textvariable=self.package_oz_var, width=7).grid(row=0, column=9, sticky="ew", padx=(4, 2))
        ttk.Label(shipping_frame, text="oz").grid(row=0, column=10, sticky="w")

        ttk.Label(shipping_frame, text="Package type:").grid(row=1, column=0, sticky="e", pady=(6, 0))
        self.package_type_combo = ttk.Combobox(
            shipping_frame,
            textvariable=self.package_type_var,
            values=list(PACKAGE_TYPE_MAP.keys()),
            state="readonly",
            width=32,
        )
        self.package_type_combo.grid(row=1, column=1, columnspan=4, sticky="ew", padx=(4, 10), pady=(6, 0))
        ttk.Label(
            shipping_frame,
            text="Used by eBay for calculated shipping; leave blank only when your policy does not need package data.",
            style="Subheader.TLabel",
        ).grid(row=1, column=5, columnspan=7, sticky="w", pady=(6, 0))

        r += 1
        ttk.Label(f, text="Condition Notes:").grid(row=r, column=0, sticky="nw", pady=4)
        self.condition_notes = tk.Text(f, height=4, wrap="word", bg="#fffdf8", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.condition_notes.grid(row=r, column=1, columnspan=3, sticky="ew", pady=4)

        r += 1
        ttk.Label(f, text="Extra Item Specifics:",).grid(row=r, column=0, sticky="nw", pady=4)
        specific_frame = ttk.Frame(f)
        specific_frame.grid(row=r, column=1, columnspan=3, sticky="ew", pady=4)
        specific_frame.columnconfigure(0, weight=1)
        self.specifics = tk.Text(specific_frame, height=6, wrap="none", bg="#fffdf8", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.specifics.grid(row=0, column=0, sticky="ew")
        ttk.Button(
            specific_frame,
            text="Sync Details",
            command=self._sync_category_requirements_async,
        ).grid(row=1, column=0, sticky="w", pady=(4, 2))
        ttk.Label(
            specific_frame,
            text=(
                "One per line: Connector Style=2 Row, 25-Pin. "
                "Required category details are checked against eBay before listing."
            ),
        ).grid(row=2, column=0, sticky="w", pady=(2, 0))

        r += 1
        button_frame = ttk.LabelFrame(f, text="6. Listing & eBay", padding=10)
        button_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=10)
        for c in range(5):
            button_frame.columnconfigure(c, weight=1)

        ttk.Button(
            button_frame, text="PREVIEW", command=self._preview
        ).grid(row=0, column=0, padx=4, pady=4, sticky="ew")

        ttk.Button(
            button_frame, text="SUGGEST CATEGORY", command=self._suggest_category_manual
        ).grid(row=0, column=1, padx=4, pady=4, sticky="ew")

        ttk.Button(
            button_frame, text="SYNC DETAILS", command=self._sync_category_requirements_async
        ).grid(row=0, column=2, padx=4, pady=4, sticky="ew")

        listing_tools_btn = ttk.Menubutton(button_frame, text="LISTING TOOLS ▾")
        listing_tools_menu = tk.Menu(listing_tools_btn, tearoff=False)
        listing_tools_btn["menu"] = listing_tools_menu
        listing_tools_btn.grid(row=0, column=3, padx=4, pady=4, sticky="ew")
        listing_tools_menu.add_command(label="Save Listing File", command=self._save_listing_file)
        listing_tools_menu.add_command(label="Load Listing File", command=self._load_listing_file)
        listing_tools_menu.add_separator()
        listing_tools_menu.add_command(label="New / Clear Listing", command=self._new_listing)
        listing_tools_menu.add_separator()
        listing_tools_menu.add_command(
            label="Open Seller Hub",
            command=lambda: webbrowser.open("https://www.ebay.com/sh/lst/active"),
        )

        self.stop_btn = ttk.Button(
            button_frame,
            text="STOP / CANCEL",
            command=self._stop,
            state="disabled",
            style="Danger.TButton",
        )
        self.stop_btn.grid(row=0, column=4, padx=4, pady=4, sticky="ew")

        self.create_btn = ttk.Button(
            button_frame,
            text="CREATE DRAFT",
            command=self._create_or_save_draft,
        )
        self.create_btn.grid(row=1, column=0, padx=4, pady=(8, 4), sticky="ew")

        self.publish_btn = ttk.Button(
            button_frame,
            text="PUBLISH",
            command=self._publish_to_ebay,
            state="normal",
            style="Accent.TButton",
        )
        self.publish_btn.grid(row=1, column=1, padx=4, pady=(8, 4), sticky="ew")

        self.save_changes_btn = ttk.Button(
            button_frame,
            text="SAVE CHANGES",
            command=self._save_changes_to_ebay,
            state="normal",
        )
        self.save_changes_btn.grid(row=1, column=2, padx=4, pady=(8, 4), sticky="ew")

        self.create_publish_btn = ttk.Button(
            button_frame,
            text="CREATE + PUBLISH",
            command=self._create_draft_and_publish,
            style="Primary.TButton",
        )
        self.create_publish_btn.grid(
            row=1, column=3, columnspan=2, padx=4, pady=(8, 4), sticky="ew"
        )

        r += 1
        log_frame = ttk.LabelFrame(f, text="Status", padding=6)
        log_frame.grid(row=r, column=0, columnspan=4, sticky="nsew", pady=(4, 0))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_box = tk.Text(log_frame, height=8, wrap="word", state="disabled", bg="#f7f4ef", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.log_box.grid(row=0, column=0, sticky="nsew")

    def _build_existing_tab(self):
        f = self.existing_tab
        f.columnconfigure(1, weight=1)
        f.columnconfigure(3, weight=1)
        f.rowconfigure(3, weight=1)
        f.rowconfigure(5, weight=1)

        ttk.Label(
            f,
            text=(
                "Load an Inventory-API-created offer by Offer ID or SKU, then edit it "
                "in the Listing Editor tab. Published listing changes are live after Save Changes."
            ),
            wraplength=850,
            justify="left",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 12))

        self.lookup_offer_var = tk.StringVar()
        self.lookup_sku_var = tk.StringVar()

        ttk.Label(f, text="Offer ID:").grid(row=1, column=0, sticky="e", padx=(0, 5))
        ttk.Entry(f, textvariable=self.lookup_offer_var).grid(row=1, column=1, sticky="ew", padx=(0, 10))
        ttk.Button(f, text="Load Offer ID", command=self._load_existing_by_offer_id).grid(
            row=1, column=2, sticky="w"
        )

        ttk.Label(f, text="SKU / Custom Label:").grid(row=2, column=0, sticky="e", padx=(0, 5))
        ttk.Entry(f, textvariable=self.lookup_sku_var).grid(row=2, column=1, sticky="ew", padx=(0, 10))
        ttk.Button(f, text="Find by SKU", command=self._load_existing_by_sku).grid(
            row=2, column=2, sticky="w"
        )

        history_box = ttk.LabelFrame(f, text="Created by This App / Inventory API Offers", padding=8)
        history_box.grid(row=3, column=0, columnspan=4, sticky="nsew", pady=(10, 8))
        history_box.columnconfigure(0, weight=1)
        history_box.rowconfigure(1, weight=1)

        history_actions = ttk.Frame(history_box)
        history_actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(
            history_actions, text="Refresh Local History", command=self._refresh_offer_history_table
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            history_actions, text="Refresh from eBay", command=self._refresh_offers_from_ebay
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            history_actions, text="Load Selected Offer", command=self._load_selected_history_offer
        ).pack(side="left")

        cols = ("offer_id", "sku", "status", "listing_id", "title", "price", "category")
        self.offer_history_tree = ttk.Treeview(
            history_box, columns=cols, show="headings", height=8
        )
        headings = {
            "offer_id": "Offer ID",
            "sku": "SKU",
            "status": "Status",
            "listing_id": "Listing ID",
            "title": "Title",
            "price": "Price",
            "category": "Category",
        }
        widths = {
            "offer_id": 145, "sku": 120, "status": 95, "listing_id": 125,
            "title": 280, "price": 80, "category": 90,
        }
        for c in cols:
            self.offer_history_tree.heading(
                c,
                text=headings[c],
                command=lambda col=c, tr=self.offer_history_tree:
                    self._sort_treeview_column(tr, col),
            )
            self.offer_history_tree.column(c, width=widths[c], anchor="w")
        self.offer_history_tree.grid(row=1, column=0, sticky="nsew")
        hscroll = ttk.Scrollbar(
            history_box, orient="horizontal", command=self.offer_history_tree.xview
        )
        self.offer_history_tree.configure(xscrollcommand=hscroll.set)
        hscroll.grid(row=2, column=0, sticky="ew")
        self.offer_history_tree.bind(
            "<Double-1>", lambda e: self._load_selected_history_offer()
        )

        self.existing_status_var = tk.StringVar(value="No eBay offer loaded.")
        ttk.Label(
            f, textvariable=self.existing_status_var, wraplength=850, justify="left"
        ).grid(row=4, column=0, columnspan=4, sticky="w", pady=10)

        info = tk.Text(f, wrap="word", height=10, state="disabled")
        info.grid(row=5, column=0, columnspan=4, sticky="nsew")
        self.existing_info = info
        self.after_idle(self._refresh_offer_history_table)

    def _refresh_offer_history_table(self):
        tree = getattr(self, "offer_history_tree", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        rows = load_offer_history()
        for row in rows:
            tree.insert(
                "",
                "end",
                values=(
                    row.get("offer_id", ""),
                    row.get("sku", ""),
                    row.get("status", ""),
                    row.get("listing_id", ""),
                    row.get("title", ""),
                    row.get("price", ""),
                    row.get("category_id", ""),
                ),
            )

    def _offer_history_context_menu(self, event, tree):
        iid = tree.identify_row(event.y)
        if iid:
            tree.selection_set(iid)
            tree.focus(iid)
        sel = tree.selection()
        if not sel:
            return "break"
        vals = tree.item(sel[0], "values") or ()
        offer_id = str(vals[0] or "") if len(vals) > 0 else ""
        listing_id = str(vals[3] or "") if len(vals) > 3 else ""
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Load / Edit Offer", command=self._load_selected_history_offer)
        if listing_id:
            menu.add_command(
                label="Open Live eBay Listing",
                command=lambda n=listing_id: webbrowser.open(f"https://www.ebay.com/itm/{n}"),
            )
            menu.add_command(
                label="End eBay Listing…",
                command=lambda n=listing_id: self._end_ebay_listing(n),
            )
        if offer_id:
            menu.add_command(
                label="Copy Offer ID",
                command=lambda n=offer_id: (self.clipboard_clear(), self.clipboard_append(n)),
            )
        menu.add_command(label="Copy Row", command=lambda: self._copy_tree_selected_row(tree))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _load_selected_history_offer(self):
        tree = getattr(self, "offer_history_tree", None)
        if tree is None:
            return
        sel = tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select an offer in the table first.")
            return
        values = tree.item(sel[0], "values")
        offer_id = str(values[0] or "")
        if not offer_id:
            return
        self.lookup_offer_var.set(offer_id)
        self._load_existing_by_offer_id()

    def _refresh_offers_from_ebay(self):
        if self.worker and self.worker.is_alive():
            self._close_progress_popup()
            return
        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._show_progress_popup(
            "Refreshing eBay Offers",
            "Loading Inventory API items and their Offer IDs..."
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                items = client.get_inventory_items(limit=100)
                total = len(items)
                for idx, inventory in enumerate(items, start=1):
                    client._check_cancel()
                    sku = str(inventory.get("sku", "") or "")
                    if not sku:
                        continue
                    self.after(
                        0,
                        lambda i=idx, n=total, s=sku:
                            self._update_progress_popup(
                                f"Checking SKU {i} of {n}: {s}"
                            )
                    )
                    offers = client.get_offers_by_sku(sku)
                    product = inventory.get("product", {}) or {}
                    for offer in offers:
                        price = (
                            ((offer.get("pricingSummary", {}) or {}).get("price", {}) or {})
                            .get("value", "")
                        )
                        listing = offer.get("listing", {}) or {}
                        upsert_offer_history({
                            "offer_id": str(offer.get("offerId", "") or ""),
                            "sku": sku,
                            "status": str(offer.get("status", "") or ""),
                            "listing_id": str(listing.get("listingId", "") or ""),
                            "title": str(product.get("title", "") or ""),
                            "price": str(price or ""),
                            "category_id": str(offer.get("categoryId", "") or ""),
                        })
                self.after(0, self._refresh_offer_history_table)
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        f"Offer refresh complete. Checked {total} Inventory API item(s)."
                    )
                )
            except Exception as exc:
                self._log(f"OFFER HISTORY REFRESH ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _set_existing_info(self, text_value):
        self.existing_info.configure(state="normal")
        self.existing_info.delete("1.0", "end")
        self.existing_info.insert("1.0", text_value)
        self.existing_info.configure(state="disabled")

    def _build_settings_tab(self):
        outer = self.settings_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        f = ttk.Frame(canvas, padding=(8, 6, 14, 24))
        window_id = canvas.create_window((0, 0), window=f, anchor="nw")

        def _sync_scrollregion(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_width(event):
            canvas.itemconfigure(window_id, width=event.width)

        f.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        def _on_mousewheel(event):
            if event.delta:
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"

        # Keep mouse-wheel handling local to this tab.  Do not use bind_all:
        # global bindings can make the notebook/tab area respond while another
        # tab is active.
        canvas.bind("<MouseWheel>", _on_mousewheel)
        f.bind("<MouseWheel>", _on_mousewheel)

        def _bind_descendant_wheel(widget):
            try:
                widget.bind("<MouseWheel>", _on_mousewheel, add="+")
            except Exception:
                pass
            try:
                for child in widget.winfo_children():
                    _bind_descendant_wheel(child)
            except Exception:
                pass

        # Widgets created later may not exist yet; schedule once UI construction
        # for this tab has completed.
        self.after_idle(lambda: _bind_descendant_wheel(f))

        f.columnconfigure(1, weight=1)

        self.setting_vars = {}
        settings_fields = [
            ("OAuth Access Token", "access_token"),
            ("Merchant Location Key", "merchant_location_key"),
            ("Payment Policy ID", "payment_policy_id"),
            ("Return Policy ID", "return_policy_id"),
            ("Fulfillment Policy ID", "fulfillment_policy_id"),
            ("Default Category ID", "default_category_id"),
            ("Marketplace", "marketplace_id"),
            ("Currency", "currency"),
            ("OpenAI API Key", "openai_api_key"),
            ("OpenAI Vision Model", "openai_model"),
            ("eBay App ID / Client ID", "ebay_client_id"),
            ("eBay Cert ID / Client Secret", "ebay_client_secret"),
            ("AI Photo Grouping Spend Cap ($)", "ai_grouping_spend_cap"),
            ("eBay Refresh Token (optional)", "ebay_refresh_token"),
            ("eBay OAuth RuName (optional)", "ebay_runame"),
        ]

        for r, (label, key) in enumerate(settings_fields):
            ttk.Label(f, text=label + ":").grid(row=r, column=0, sticky="w", padx=(0, 10), pady=6)
            v = tk.StringVar(value=self.settings.get(key, ""))
            self.setting_vars[key] = v
            show = "*" if key in ("access_token", "openai_api_key", "ebay_client_secret", "ebay_refresh_token") else ""
            ttk.Entry(f, textvariable=v, show=show).grid(row=r, column=1, sticky="ew", pady=6)

        r = len(settings_fields)
        ttk.Label(f, text="API Environment:").grid(row=r, column=0, sticky="w", pady=6)
        self.env_var = tk.StringVar(value=self.settings.get("api_environment", "production"))
        ttk.Combobox(
            f, textvariable=self.env_var, values=["production", "sandbox"], state="readonly"
        ).grid(row=r, column=1, sticky="w", pady=6)

        r += 1
        location_box = ttk.LabelFrame(f, text="Inventory Location / Merchant Location Key", padding=8)
        location_box.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(12, 6))
        location_box.columnconfigure(1, weight=1)

        self.location_choice_var = tk.StringVar()
        self.location_combo = ttk.Combobox(
            location_box, textvariable=self.location_choice_var, state="readonly"
        )
        ttk.Label(location_box, text="Existing locations:").grid(row=0, column=0, sticky="e", padx=(0, 6))
        self.location_combo.grid(row=0, column=1, sticky="ew")
        ttk.Button(
            location_box, text="Load Existing Locations", command=self._load_inventory_locations
        ).grid(row=0, column=2, padx=(6, 0))
        ttk.Button(
            location_box, text="Use Selected Location", command=self._use_selected_inventory_location
        ).grid(row=1, column=2, padx=(6, 0), pady=(6, 0))

        self.new_location_key_var = tk.StringVar(value="able-main-warehouse")
        self.new_location_name_var = tk.StringVar(value="Main Warehouse")
        self.new_location_postal_var = tk.StringVar()
        self.new_location_country_var = tk.StringVar(value="US")

        ttk.Label(location_box, text="New key:").grid(row=2, column=0, sticky="e", padx=(0, 6), pady=(12, 4))
        ttk.Entry(location_box, textvariable=self.new_location_key_var).grid(row=2, column=1, sticky="ew", pady=(12, 4))
        ttk.Label(location_box, text="Name:").grid(row=3, column=0, sticky="e", padx=(0, 6), pady=4)
        ttk.Entry(location_box, textvariable=self.new_location_name_var).grid(row=3, column=1, sticky="ew", pady=4)

        mini = ttk.Frame(location_box)
        mini.grid(row=4, column=1, sticky="ew", pady=4)
        mini.columnconfigure(1, weight=1)
        mini.columnconfigure(3, weight=1)
        ttk.Label(mini, text="Postal code:").grid(row=0, column=0, padx=(0, 4))
        ttk.Entry(mini, textvariable=self.new_location_postal_var, width=12).grid(row=0, column=1, sticky="ew", padx=(0, 8))
        ttk.Label(mini, text="Country:").grid(row=0, column=2, padx=(0, 4))
        ttk.Entry(mini, textvariable=self.new_location_country_var, width=8).grid(row=0, column=3, sticky="ew")

        ttk.Button(
            location_box, text="CREATE WAREHOUSE LOCATION",
            command=self._create_inventory_location, style="Accent.TButton"
        ).grid(row=5, column=1, sticky="e", pady=(8, 0))

        ttk.Label(
            location_box,
            text=(
                "The Merchant Location Key is a seller-defined permanent ID, not a secret key. "
                "For a normal warehouse, postal code + country are sufficient for eBay's Inventory API."
            ),
            wraplength=720, justify="left", style="Subheader.TLabel"
        ).grid(row=6, column=0, columnspan=3, sticky="w", pady=(8, 0))

        r += 1
        action_settings = ttk.Frame(f)
        action_settings.grid(row=r, column=1, sticky="e", pady=10)
        ttk.Button(action_settings, text="Save Settings", command=self._save_settings_ui).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(action_settings, text="Test eBay Connection", command=self._test_ebay_connection).grid(row=0, column=1)

        r += 1
        oauth_box = ttk.LabelFrame(f, text="Automatic eBay Login Refresh", padding=8)
        oauth_box.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(12, 6))
        oauth_box.columnconfigure(1, weight=1)

        ttk.Label(
            oauth_box,
            text=(
                "One-time setup: open eBay authorization, approve the same scopes, "
                "then paste the FINAL browser URL here. The app will extract the "
                "authorization code and securely exchange it for a refresh token."
            ),
            wraplength=760, justify="left"
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        oauth_actions = ttk.Frame(oauth_box)
        oauth_actions.grid(row=1, column=0, sticky="ew", padx=(0, 6))
        oauth_actions.columnconfigure(0, weight=1)
        oauth_actions.columnconfigure(1, weight=1)

        ttk.Button(
            oauth_actions,
            text="CHECK OAUTH SETUP",
            command=self._validate_oauth_setup,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))

        ttk.Button(
            oauth_actions,
            text="1. OPEN EBAY AUTHORIZATION",
            command=self._open_refresh_authorization,
            style="Accent.TButton",
        ).grid(row=0, column=1, sticky="ew", padx=(4, 0))

        self.oauth_return_url_var = tk.StringVar()
        ttk.Entry(
            oauth_box, textvariable=self.oauth_return_url_var
        ).grid(row=1, column=1, sticky="ew", padx=(0, 6))

        ttk.Button(
            oauth_box,
            text="2. SAVE REFRESH TOKEN",
            command=self._exchange_refresh_authorization,
            style="Accent.TButton",
        ).grid(row=1, column=2, sticky="ew")

        self.oauth_refresh_status_var = tk.StringVar(
            value="Automatic refresh is not configured yet."
        )
        ttk.Label(
            oauth_box,
            textvariable=self.oauth_refresh_status_var,
            wraplength=760,
            justify="left",
            style="Subheader.TLabel",
        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))

        if self.settings.get("ebay_refresh_token", "").strip():
            self.oauth_refresh_status_var.set(
                "Automatic refresh is configured. The app will refresh an expired "
                "eBay User Access Token automatically."
            )

        r += 1
        maintenance_box = ttk.LabelFrame(
            f, text="Local Data Maintenance", padding=8
        )
        maintenance_box.grid(
            row=r, column=0, columnspan=2, sticky="ew", pady=(12, 6)
        )
        maintenance_box.columnconfigure(3, weight=1)
        ttk.Button(
            maintenance_box,
            text="BACK UP NOW",
            command=self._manual_backup,
        ).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(
            maintenance_box,
            text="RESTORE BACKUP",
            command=self._restore_backup,
        ).grid(row=0, column=1, padx=6)
        ttk.Button(
            maintenance_box,
            text="OPEN ACTIVITY LOG",
            command=self._open_activity_log,
        ).grid(row=0, column=2, padx=6)
        ttk.Label(
            maintenance_box,
            text="Automatic inventory backup runs once per day. Ctrl+B creates a manual backup.",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(7, 0))

        r += 1

        note = (
            "The eBay access/refresh tokens, eBay app secret, and OpenAI API key are stored locally on this computer in your user profile. "
            "The program never asks for or stores your eBay password.\n\n"
            "The OpenAI key is used when you click ANALYZE PHOTOS + FILL DETAILS or AI GROUP BATCH. "
            "Selected photos are then sent to the OpenAI API for analysis.\n\n"
            "This program deliberately has NO publishOffer function. Creating a draft here does not make a listing live.\n\n"
            "Once eBay authorization is connected, use Refresh Policies from eBay so the program loads your existing shipping, payment, and return policies by name. "
            "See SETUP_GUIDE.txt included with this program."
        )
        ttk.Label(f, text=note, wraplength=760, justify="left").grid(
            row=r, column=0, columnspan=2, sticky="w", pady=(16, 0)
        )

    def _log(self, msg):
        def write():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", str(msg).rstrip() + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")

            # Every generic loading box now mirrors the latest progress/log step,
            # so the user does not need to scroll to the bottom status console.
            try:
                win = getattr(self, "_busy_window", None)
                if win is not None and win.winfo_exists():
                    status = self._busy_status_text(msg)
                    if status:
                        self._busy_status_var.set(status)
            except Exception:
                pass

        self.after(0, write)


    def _new_listing(self):
        for k, v in getattr(self, "vars", {}).items():
            v.set("")
        if hasattr(self, "vars"):
            self.vars["quantity"].set("1")
            self.vars["price"].set("")
            self.vars["category_id"].set(self.settings.get("default_category_id", ""))
        if hasattr(self, "condition_var"):
            self.condition_var.set("Used - Good")
        if hasattr(self, "condition_notes"):
            self.condition_notes.delete("1.0", "end")
        if hasattr(self, "specifics"):
            self.specifics.delete("1.0", "end")
        if hasattr(self, "title_var"):
            self.title_var.set("")
        if hasattr(self, "best_offer_var"):
            self.best_offer_var.set(True)
            self.auto_accept_var.set("")
            self.auto_decline_var.set("")
        if hasattr(self, "package_length_var"):
            self.package_length_var.set("")
            self.package_width_var.set("")
            self.package_height_var.set("")
            self.package_lb_var.set("")
            self.package_oz_var.set("")
            self.package_type_var.set("Standard package / thick envelope")
        self._clear_photos()
        self.existing_image_urls = []
        self.editing_offer_id = ""
        self.editing_offer_status = ""
        self.original_offer = None
        self.original_inventory_item = None
        if hasattr(self, "save_changes_btn"):
            self.save_changes_btn.config(state="normal")
        if hasattr(self, "publish_btn"):
            self.publish_btn.config(state="normal")
        self._update_draft_button_text()
        if hasattr(self, "existing_status_var"):
            self.existing_status_var.set("No eBay offer loaded.")
        self.last_category_name = ""
        self.last_price_research = None
        if hasattr(self, "price_research_var"):
            self.price_research_var.set(
                "Not researched yet. Current eBay Buy It Now listings will be used."
            )
        if hasattr(self, "category_suggestion_label"):
            self.category_suggestion_label.config(text="")
        if hasattr(self, "log_box"):
            self.log_box.configure(state="normal")
            self.log_box.delete("1.0", "end")
            self.log_box.configure(state="disabled")

    def _auto_title(self):
        if not hasattr(self, "vars"):
            return
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        desc = self.vars["item_description"].get().strip()
        parts = []
        for p in (brand, mpn, desc):
            if p and p.lower() not in [x.lower() for x in parts]:
                parts.append(p)
        title = " ".join(parts).upper()
        self.title_var.set(title[:80])

    def _photos_changed(self, paths):
        # Exact photos currently checked "Use", in eBay upload order.
        self.photos = [str(p) for p in paths]
        if hasattr(self, "photo_label"):
            try:
                self.photo_label.config(text=f"{len(self.photos)} photo(s) selected")
            except Exception:
                pass

    def _select_photos(self):
        if getattr(self, "photo_manager", None) is not None:
            self.photo_manager.add_files()
            return
        paths = filedialog.askopenfilenames(
            title="Select item photos",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.bmp *.tif *.tiff *.webp *.heic *.heif *.avif"),
                ("All files", "*.*"),
            ],
        )
        if paths:
            self.photos = list(paths)

    def _clear_photos(self):
        self.photos = []
        manager = getattr(self, "photo_manager", None)
        if manager is not None and manager.records:
            manager.clear()

    def _policy_id_from_selection(self, kind):
        var = {
            "fulfillment": self.fulfillment_policy_var,
            "payment": self.payment_policy_var,
            "return": self.return_policy_var,
        }[kind]
        selected = var.get().strip()
        mapping = self.policy_maps.get(kind, {})
        if selected in mapping:
            return mapping[selected]
        # Fall back to the manually stored ID until policies are loaded.
        fallback_key = {
            "fulfillment": "fulfillment_policy_id",
            "payment": "payment_policy_id",
            "return": "return_policy_id",
        }[kind]
        return self.settings.get(fallback_key, "").strip()

    def _select_policy_by_id(self, kind, policy_id):
        policy_id = str(policy_id or "")
        mapping = self.policy_maps.get(kind, {})
        for display, pid in mapping.items():
            if str(pid) == policy_id:
                {
                    "fulfillment": self.fulfillment_policy_var,
                    "payment": self.payment_policy_var,
                    "return": self.return_policy_var,
                }[kind].set(display)
                return
        # If not loaded yet, leave combo blank; ID remains available through settings.

    def _apply_policies(self, policies):
        combos = {
            "fulfillment": self.fulfillment_combo,
            "payment": self.payment_combo,
            "return": self.return_combo,
        }
        vars_ = {
            "fulfillment": self.fulfillment_policy_var,
            "payment": self.payment_policy_var,
            "return": self.return_policy_var,
        }
        setting_keys = {
            "fulfillment": "fulfillment_policy_id",
            "payment": "payment_policy_id",
            "return": "return_policy_id",
        }
        for kind in ("fulfillment", "payment", "return"):
            mapping = {}
            for p in policies.get(kind, []):
                display = f'{p.get("name") or "(unnamed policy)"}  [{p.get("id")}]'
                mapping[display] = p.get("id", "")
            self.policy_maps[kind] = mapping
            combos[kind]["values"] = list(mapping.keys())
            current_id = self.settings.get(setting_keys[kind], "")
            chosen = ""
            for display, pid in mapping.items():
                if str(pid) == str(current_id):
                    chosen = display
                    break
            if not chosen and mapping:
                chosen = next(iter(mapping))
            vars_[kind].set(chosen)

            # Keep selected IDs as defaults in settings.
            if chosen:
                self.settings[setting_keys[kind]] = mapping[chosen]
        save_settings(self.settings)
        self._log(
            "Loaded eBay business policies: "
            f'{len(policies.get("fulfillment", []))} shipping, '
            f'{len(policies.get("payment", []))} payment, '
            f'{len(policies.get("return", []))} return.'
        )

    def _refresh_policies(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter an eBay OAuth access token first.")
            return
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._show_progress_popup(
            "Refreshing eBay Details",
            "Loading eBay shipping, payment, and return policies..."
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                policies = client.get_business_policies()
                self.after(0, lambda: self._apply_policies(policies))
            except Exception as exc:
                self._log(f"POLICY LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _selected_photo_paths(self):
        """Return the exact photos checked 'Use' in the integrated photo manager."""
        pm = getattr(self, "photo_manager", None)

        if pm is not None and hasattr(pm, "selected_paths"):
            try:
                paths = list(pm.selected_paths)
                return [str(p) for p in paths if Path(str(p)).exists()]
            except Exception as exc:
                self._log(f"Photo selection sync error: {exc}")

        # Legacy fallback only.
        return [
            str(p)
            for p in getattr(self, "photos", [])
            if Path(str(p)).exists()
        ]

    def _sync_selected_photos(self):
        self.photos = list(self._selected_photo_paths())
        if hasattr(self, "photo_label"):
            self.photo_label.config(text=f"{len(self.photos)} photo(s) selected")
        return self.photos

    def _generate_description(self):
        item = self.vars["item_description"].get().strip()
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        subject = " ".join(x for x in (brand, mpn, item) if x).strip()
        quantity = self.vars["quantity"].get().strip()
        prefix = "These are" if quantity.isdigit() and int(quantity) > 1 else "This is a"
        first = f"{prefix} {subject}.".replace("  ", " ").strip()
        return first + "\n\n" + BOILERPLATE

    def _collect(self):
        self._sync_selected_photos()
        try:
            qty = int(self.vars["quantity"].get().strip())
            if qty < 0:
                raise ValueError
        except Exception:
            raise ValueError("Quantity must be a whole number 0 or greater.")
        try:
            price = float(self.vars["price"].get().strip())
            if price <= 0:
                raise ValueError
        except Exception:
            raise ValueError("Price must be a number greater than zero.")

        if self.best_offer_var.get():
            for label, raw in (
                ("Auto-accept price", self.auto_accept_var.get().strip()),
                ("Auto-decline price", self.auto_decline_var.get().strip()),
            ):
                if raw:
                    try:
                        if float(raw) <= 0:
                            raise ValueError
                    except Exception:
                        raise ValueError(f"{label} must be blank or a number greater than zero.")
            if self.auto_accept_var.get().strip() and self.auto_decline_var.get().strip():
                if float(self.auto_decline_var.get()) >= float(self.auto_accept_var.get()):
                    raise ValueError("Auto-decline price should be lower than auto-accept price.")

        # Shipping package validation.
        dim_raw = [
            self.package_length_var.get().strip(),
            self.package_width_var.get().strip(),
            self.package_height_var.get().strip(),
        ]
        any_dims = any(dim_raw)
        if any_dims and not all(dim_raw):
            raise ValueError("If you enter package dimensions, fill Length, Width, and Height.")
        dimensions = None
        if all(dim_raw):
            try:
                length, width, height = [float(x) for x in dim_raw]
                if min(length, width, height) <= 0:
                    raise ValueError
            except Exception:
                raise ValueError("Package dimensions must be numbers greater than zero.")
            dimensions = {"length": length, "width": width, "height": height}

        lb_raw = self.package_lb_var.get().strip()
        oz_raw = self.package_oz_var.get().strip()
        weight_oz = None
        if lb_raw or oz_raw:
            try:
                lbs = float(lb_raw or 0)
                oz = float(oz_raw or 0)
                if lbs < 0 or oz < 0:
                    raise ValueError
                weight_oz = lbs * 16.0 + oz
                if weight_oz <= 0:
                    raise ValueError
            except Exception:
                raise ValueError("Package weight must be a positive number of pounds/ounces.")

        title = self.title_var.get().strip()
        if not title:
            raise ValueError("A title is required.")
        if len(title) > 80:
            raise ValueError("The title is over 80 characters.")

        sku = self.vars["sku"].get().strip()
        if not sku:
            sku = sanitize_sku(
                "-".join(
                    x for x in (
                        self.vars["brand"].get(),
                        self.vars["mpn"].get(),
                        str(int(time.time())),
                    ) if x.strip()
                )
            )
            self.vars["sku"].set(sku)

        return {
            "brand": self.vars["brand"].get().strip(),
            "mpn": self.vars["mpn"].get().strip(),
            "model": self.vars["model"].get().strip(),
            "item_description": self.vars["item_description"].get().strip(),
            "sku": sku,
            "price": price,
            "quantity": qty,
            "country": self.vars["country"].get().strip(),
            "category_id": self.vars["category_id"].get().strip(),
            "condition": self.condition_var.get(),
            "condition_notes": self.condition_notes.get("1.0", "end").strip(),
            "specifics": self.specifics.get("1.0", "end").strip(),
            "title": title,
            "description": self._generate_description(),
            "photos": list(self.photos),
            "existing_image_urls": list(self.existing_image_urls),
            "best_offer_enabled": bool(self.best_offer_var.get()),
            "auto_accept_price": (
                float(self.auto_accept_var.get().strip())
                if self.best_offer_var.get() and self.auto_accept_var.get().strip()
                else None
            ),
            "auto_decline_price": (
                float(self.auto_decline_var.get().strip())
                if self.best_offer_var.get() and self.auto_decline_var.get().strip()
                else None
            ),
            "fulfillment_policy_id": self._policy_id_from_selection("fulfillment"),
            "payment_policy_id": self._policy_id_from_selection("payment"),
            "return_policy_id": self._policy_id_from_selection("return"),
            "package_dimensions": dimensions,
            "package_weight_oz": weight_oz,
            "package_type": PACKAGE_TYPE_MAP.get(
                self.package_type_var.get(), "PACKAGE_THICK_ENVELOPE"
            ),
        }

    def _does_not_apply_value(self, marketplace_id="EBAY_US"):
        # This build targets eBay US by default. The US product-identifier
        # substitute text documented by eBay is exactly "Does not apply".
        marketplace_id = str(marketplace_id or "EBAY_US")
        return "Does not apply"

    def _sync_category_specifics(self, client, listing, update_ui=False):
        """
        Normalize listing specifics against the chosen eBay leaf category.

        Required FREE_TEXT aspects that are missing are filled with eBay's
        marketplace-appropriate "Does not apply" placeholder. Selection-only
        required aspects are only auto-filled when eBay explicitly offers an
        equivalent value; otherwise the listing is stopped for review.
        """
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return {"required": 0, "recommended": 0, "filled": 0, "unresolved": []}

        aspects = client.get_item_aspects_for_category(category_id)
        if isinstance(aspects, dict):
            aspects = [aspects]
        aspects = [a for a in (aspects or []) if isinstance(a, dict)]

        existing = parse_specifics(listing.get("specifics", ""))
        existing_by_lower = {
            str(k).strip().lower(): (k, list(v) if isinstance(v, list) else [v])
            for k, v in existing.items()
        }

        dedicated = {
            "brand": str(listing.get("brand", "") or "").strip(),
            "mpn": str(listing.get("mpn", "") or "").strip(),
            "model": str(listing.get("model", "") or "").strip(),
            "country of origin": str(listing.get("country", "") or "").strip(),
        }

        normalized = {}
        required_count = 0
        recommended_count = 0
        filled_count = 0
        unresolved = []
        allowed_names = set()

        dna_generic = self._does_not_apply_value(
            self.settings.get("marketplace_id", "EBAY_US")
        )

        def find_dna(allowed):
            targets = {
                "does not apply",
                "doesn't apply",
                "not applicable",
                "n/a",
                "na",
            }
            for value in allowed:
                if str(value).strip().lower() in targets:
                    return str(value).strip()
            return ""

        for aspect in aspects:
            name = str(aspect.get("localizedAspectName", "") or "").strip()
            if not name:
                continue
            lower = name.lower()
            allowed_names.add(lower)

            constraint = aspect.get("aspectConstraint", {}) or {}
            if not isinstance(constraint, dict):
                constraint = {}

            required = bool(constraint.get("aspectRequired", False))
            usage = str(constraint.get("aspectUsage", "") or "").upper()
            mode = str(constraint.get("aspectMode", "") or "").upper()

            if required:
                required_count += 1
            elif usage == "RECOMMENDED":
                recommended_count += 1

            allowed = []
            for av in aspect.get("aspectValues", []) or []:
                if isinstance(av, dict):
                    value = str(av.get("localizedValue", "") or "").strip()
                    if value:
                        allowed.append(value)

            # Prefer the dedicated editor fields for common eBay aspects.
            value = dedicated.get(lower, "")
            if not value and lower in existing_by_lower:
                vals = existing_by_lower[lower][1]
                if vals:
                    value = str(vals[0]).strip()

            # Canonicalize selection-only values to eBay's exact spelling.
            if value and mode == "SELECTION_ONLY" and allowed:
                match = next((v for v in allowed if v.lower() == value.lower()), None)
                if match:
                    value = match
                elif required:
                    unresolved.append(
                        f"{name}: '{value}' is not an allowed value. "
                        f"Allowed examples: {', '.join(allowed[:12])}"
                    )
                    value = ""
                else:
                    # Drop an invalid optional value rather than sending data
                    # eBay says is not applicable to this category.
                    value = ""

            if required and not value:
                dna_allowed = find_dna(allowed)
                if dna_allowed:
                    value = dna_allowed
                    filled_count += 1
                elif mode != "SELECTION_ONLY":
                    value = dna_generic
                    filled_count += 1
                else:
                    unresolved.append(
                        f"{name}: required by eBay and must be chosen from "
                        f"{', '.join(allowed[:12]) or 'the category-specific allowed values'}"
                    )

            if value:
                normalized[name] = [value]

                if lower == "brand":
                    listing["brand"] = value
                elif lower == "mpn":
                    listing["mpn"] = value
                elif lower == "model":
                    listing["model"] = value
                elif lower == "country of origin":
                    listing["country"] = value

        # Preserve existing custom/recommended details only when eBay returned
        # that aspect name for this category. This prevents carrying item
        # specifics from one category into a completely different category.
        for lower, (original_name, values) in existing_by_lower.items():
            if lower in allowed_names and original_name not in normalized:
                normalized[original_name] = values

        listing["specifics"] = format_specifics(normalized)

        summary = {
            "required": required_count,
            "recommended": recommended_count,
            "filled": filled_count,
            "unresolved": unresolved,
            "aspect_count": len(aspects),
        }

        self._log(
            f"CATEGORY SYNC {category_id}: {len(aspects)} applicable aspect(s), "
            f"{required_count} required, {recommended_count} recommended, "
            f"{filled_count} missing required value(s) filled with Does not apply."
        )

        if update_ui:
            def apply_ui():
                self.vars["brand"].set(str(listing.get("brand", "") or ""))
                self.vars["mpn"].set(str(listing.get("mpn", "") or ""))
                self.vars["model"].set(str(listing.get("model", "") or ""))
                self.vars["country"].set(str(listing.get("country", "") or ""))
                self.specifics.delete("1.0", "end")
                self.specifics.insert("1.0", listing.get("specifics", ""))
                if hasattr(self, "category_requirements_var"):
                    self.category_requirements_var.set(
                        f"eBay category {category_id}: {len(aspects)} applicable specifics • "
                        f"{required_count} required • {recommended_count} recommended • "
                        f"{filled_count} missing required value(s) auto-filled."
                    )
            self.after(0, apply_ui)

        if unresolved:
            raise RuntimeError(
                "eBay requires category-specific details that cannot safely be "
                "filled with 'Does not apply':\n\n• "
                + "\n• ".join(unresolved)
            )

        return summary

    def _sync_category_requirements_async(self):
        category_id = str(self.vars.get("category_id").get() or "").strip()
        if not category_id:
            return
        if self.worker and self.worker.is_alive():
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        if hasattr(self, "category_requirements_var"):
            self.category_requirements_var.set(
                f"Checking eBay requirements for category {category_id}..."
            )

        # Build only the fields needed for metadata sync; no price/shipping
        # validation is needed for this UI operation.
        listing = {
            "category_id": category_id,
            "brand": self.vars["brand"].get().strip(),
            "mpn": self.vars["mpn"].get().strip(),
            "model": self.vars["model"].get().strip(),
            "country": self.vars["country"].get().strip(),
            "specifics": self.specifics.get("1.0", "end").strip(),
        }

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                summary = self._sync_category_specifics(client, listing, update_ui=True)
                policy = client.get_item_condition_policies(category_id)

                def finish():
                    self._apply_condition_policy(policy, category_id, show_message=False)
                    if hasattr(self, "category_requirements_var"):
                        self.category_requirements_var.set(
                            f"eBay category {category_id}: "
                            f"{summary.get('aspect_count', 0)} applicable specifics • "
                            f"{summary.get('required', 0)} required • "
                            f"{summary.get('recommended', 0)} recommended • "
                            f"{summary.get('filled', 0)} missing required value(s) auto-filled."
                        )
                self.after(0, finish)
            except Exception as exc:
                err = str(exc)
                self._log(f"CATEGORY REQUIREMENTS ERROR: {err}")
                self.after(
                    0,
                    lambda e=err: messagebox.showerror(
                        "eBay Category Requirements",
                        e,
                        parent=self,
                    )
                )

        threading.Thread(target=work, daemon=True).start()

    def _validate_category_product_identifiers(self, client, listing):
        """
        Validate Brand/MPN against eBay's leaf-category Taxonomy metadata before
        any Inventory API write. This converts error 25002/BrandMPN into a useful
        preflight message.
        """
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return True

        aspects = client.get_item_aspects_for_category(category_id)
        if isinstance(aspects, dict):
            aspects = [aspects]
        if not isinstance(aspects, list):
            aspects = []

        meta = {}
        for aspect in aspects:
            if not isinstance(aspect, dict):
                continue
            name = str(aspect.get("localizedAspectName", "") or "").strip()
            if not name:
                continue
            constraint = aspect.get("aspectConstraint", {}) or {}
            if not isinstance(constraint, dict):
                constraint = {}

            allowed = []
            for av in aspect.get("aspectValues", []) or []:
                if isinstance(av, dict) and av.get("localizedValue") is not None:
                    allowed.append(str(av.get("localizedValue")).strip())

            meta[name.lower()] = {
                "name": name,
                "required": bool(constraint.get("aspectRequired", False)),
                "usage": str(constraint.get("aspectUsage", "") or ""),
                "mode": str(constraint.get("aspectMode", "") or ""),
                "allowed": [x for x in allowed if x],
            }

        specifics = parse_specifics(listing.get("specifics", ""))

        # Reject a combined custom BrandMPN aspect early.
        for key in specifics:
            if str(key).strip().lower().replace(" ", "") == "brandmpn":
                raise RuntimeError(
                    "eBay does not accept 'BrandMPN' as one combined item specific.\\n\\n"
                    "Use the separate Brand / Manufacturer and MPN / Part Number fields."
                )

        def first_specific(name):
            for key, vals in specifics.items():
                if str(key).strip().lower() == name.lower():
                    if isinstance(vals, list) and vals:
                        return str(vals[0]).strip()
                    if vals:
                        return str(vals).strip()
            return ""

        brand = str(listing.get("brand", "") or "").strip() or first_specific("Brand")
        mpn = str(listing.get("mpn", "") or "").strip() or first_specific("MPN")

        brand_meta = meta.get("brand")
        mpn_meta = meta.get("mpn")

        brand_required = bool(brand_meta and brand_meta.get("required"))
        mpn_required = bool(mpn_meta and mpn_meta.get("required"))

        # If eBay requires either member of the Brand/MPN product identifier pair,
        # require both before attempting the listing.
        if brand_required or mpn_required:
            missing = []
            if not brand:
                missing.append("Brand / Manufacturer")
            if not mpn:
                missing.append("MPN / Part Number")
            if missing:
                raise RuntimeError(
                    f"eBay category {category_id} requires a valid Brand/MPN product "
                    "identifier pair.\\n\\nMissing: "
                    + ", ".join(missing)
                    + "\\n\\nFill those fields with the markings from the item, then try again."
                )

        # If the user supplies one side of a supported Brand/MPN pair, don't send
        # an incomplete pair that eBay can reject as BrandMPN.
        if brand_meta and mpn_meta and bool(brand) != bool(mpn):
            missing = "MPN / Part Number" if brand else "Brand / Manufacturer"
            raise RuntimeError(
                f"The selected category supports Brand + MPN as a product identifier pair.\\n\\n"
                f"You supplied only one side of the pair. Fill in {missing}, or clear "
                "both fields if they are genuinely not applicable and eBay permits that."
            )

        # For selection-only Brand fields, require an eBay-supported value.
        if brand and brand_meta and brand_meta.get("mode") == "SELECTION_ONLY":
            allowed = brand_meta.get("allowed", []) or []
            if allowed:
                match = next((v for v in allowed if v.lower() == brand.lower()), None)
                if match:
                    brand = match
                else:
                    preview = ", ".join(allowed[:15])
                    more = "..." if len(allowed) > 15 else ""
                    raise RuntimeError(
                        f"eBay does not accept Brand '{brand}' for category {category_id}.\\n\\n"
                        f"This category requires a predefined Brand value. Examples: "
                        f"{preview}{more}"
                    )

        listing["brand"] = brand
        listing["mpn"] = mpn

        self._log(
            "PRODUCT IDENTIFIER PREFLIGHT: "
            f"Brand={'present' if brand else 'blank'}, "
            f"MPN={'present' if mpn else 'blank'}, "
            f"Brand required={brand_required}, MPN required={mpn_required}."
        )
        return True

    def _condition_displays_for_ids(self, condition_ids):
        allowed = set(str(x) for x in condition_ids)
        displays = []
        for display, enum_value in CONDITION_MAP.items():
            if CONDITION_ID_BY_ENUM.get(enum_value) in allowed:
                displays.append(display)
        return displays

    def _apply_condition_policy(self, policy, category_id, show_message=False):
        if not isinstance(policy, dict):
            self._log(
                f"Condition policy type {type(policy).__name__} could not be applied."
            )
            return True

        conditions = policy.get("conditions", []) or []
        if isinstance(conditions, dict):
            conditions = [conditions]
        elif isinstance(conditions, (str, int, float)):
            conditions = [conditions]

        ids = []
        for entry in conditions:
            cid = entry.get("id") if isinstance(entry, dict) else entry
            if cid:
                ids.append(str(cid))
        displays = self._condition_displays_for_ids(ids)
        current = self.condition_var.get()

        if getattr(self, "condition_combo", None) is not None and displays:
            self.condition_combo["values"] = displays

        if displays and current not in displays:
            # Do not silently change the seller's meaning. Select the first valid
            # option only as a visible placeholder and tell the user to review.
            self.condition_var.set(displays[0])
            self._log(
                f"Condition '{current}' is not valid for category {category_id}. "
                f"Changed selector to '{displays[0]}' for review."
            )
            if show_message:
                messagebox.showwarning(
                    APP_NAME,
                    f"The previous condition '{current}' is not allowed in eBay category {category_id}.\\n\\n"
                    f"Valid choices shown by eBay:\\n"
                    + "\\n".join("• " + d for d in displays)
                    + f"\\n\\nThe selector is currently set to '{displays[0]}'. "
                      "Please choose the condition that accurately describes the item."
                )
            return False

        if show_message and displays:
            messagebox.showinfo(
                APP_NAME,
                f"Condition '{current}' is valid for category {category_id}."
            )
        return True

    def _validate_category_condition_sync(self, client, listing, show_message=False):
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return True
        policy = client.get_item_condition_policies(category_id)
        raw_conditions = policy.get("conditions", []) if isinstance(policy, dict) else []
        raw_conditions = raw_conditions or []
        if isinstance(raw_conditions, dict):
            raw_conditions = [raw_conditions]
        elif isinstance(raw_conditions, (str, int, float)):
            raw_conditions = [raw_conditions]

        allowed_ids = set()
        for entry in raw_conditions:
            cid = entry.get("id") if isinstance(entry, dict) else entry
            if cid:
                allowed_ids.add(str(cid))
        enum_value = CONDITION_MAP.get(listing.get("condition", ""))
        condition_id = CONDITION_ID_BY_ENUM.get(enum_value)

        # Some categories do not use Condition. If eBay says it is required but
        # gives us no usable values, stop instead of guessing.
        if not allowed_ids:
            if isinstance(policy, dict) and policy.get("required"):
                raise RuntimeError(
                    f"eBay says a condition is required for category {category_id}, "
                    "but no usable condition values were returned."
                )
            return True

        if condition_id not in allowed_ids:
            # Some eBay categories collapse granular "Used - Good/Excellent/etc."
            # into one broad "Used / Pre-owned" condition. Normalize that case
            # automatically because it preserves the seller's underlying meaning.
            current_name = str(listing.get("condition", "") or "")
            valid_names = self._condition_displays_for_ids(allowed_ids)

            compatible = None
            if current_name.lower().startswith("used"):
                compatible = next(
                    (name for name in valid_names if "used / pre-owned" in name.lower()),
                    None,
                )
            elif "parts" in current_name.lower():
                compatible = next(
                    (name for name in valid_names if "parts" in name.lower()),
                    None,
                )
            elif current_name.lower().startswith("new"):
                if "open" in current_name.lower():
                    compatible = next(
                        (name for name in valid_names if "open box" in name.lower()),
                        None,
                    )
                if compatible is None:
                    compatible = next(
                        (name for name in valid_names if name.lower() == "new"),
                        None,
                    )

            if compatible:
                self._log(
                    f"Condition normalization: '{current_name}' -> '{compatible}' "
                    f"for category {category_id}."
                )
                listing["condition"] = compatible
                enum_value = CONDITION_MAP.get(compatible)
                condition_id = CONDITION_ID_BY_ENUM.get(enum_value)
                self.after(0, lambda v=compatible: self.condition_var.set(v))

            if condition_id in allowed_ids:
                return True

            self.after(
                0,
                lambda p=policy, cid=category_id:
                    self._apply_condition_policy(p, cid, show_message=True)
            )
            valid_names = self._condition_displays_for_ids(allowed_ids)
            raise RuntimeError(
                f"Selected condition '{listing.get('condition')}' is not valid for category "
                f"{category_id}. Choose one of: {', '.join(valid_names) or 'the eBay-provided conditions'}."
            )
        return True

    def _category_query(self):
        parts = [
            self.vars["brand"].get().strip(),
            self.vars["mpn"].get().strip(),
            self.vars["model"].get().strip(),
            self.vars["item_description"].get().strip(),
            self.title_var.get().strip(),
        ]
        # Preserve order but remove duplicates / blanks.
        out = []
        seen = set()
        for p in parts:
            key = p.lower()
            if p and key not in seen:
                out.append(p)
                seen.add(key)
        return " ".join(out)[:350]

    def _apply_category_suggestion(self, suggestion):
        cid = suggestion.get("category_id", "")
        breadcrumb = suggestion.get("breadcrumb", "") or suggestion.get("category_name", "")
        if cid:
            self.vars["category_id"].set(cid)
            self.last_category_name = breadcrumb
            self.category_suggestion_label.config(
                text=f"eBay suggestion: {breadcrumb}  (Category {cid})"
            )
            self._log(f"eBay selected category {cid}: {breadcrumb}")

            # Immediately synchronize the category's applicable item specifics
            # and allowed condition choices.
            self._sync_category_requirements_async()

    def _suggest_category_manual(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(
                APP_NAME,
                "An eBay OAuth access token is required to ask eBay for category suggestions."
            )
            return
        query = self._category_query()
        if not query:
            messagebox.showerror(
                APP_NAME,
                "Enter or analyze enough item information to identify the item first."
            )
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log(f"Category search query: {query}")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                suggestion = client.suggest_category(query)
                self.after(0, lambda: self._apply_category_suggestion(suggestion))
            except Exception as exc:
                self._log(f"CATEGORY SUGGESTION ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()


    def _price_research_query(self):
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        model = self.vars["model"].get().strip()
        desc = self.vars["item_description"].get().strip()

        # Exact part number is the best signal for obscure surplus inventory.
        if mpn:
            return " ".join(x for x in (brand, mpn) if x).strip()
        if model:
            return " ".join(x for x in (brand, model, desc) if x).strip()
        return " ".join(x for x in (brand, desc) if x).strip() or self.title_var.get().strip()

    def _clear_price_research(self):
        self.last_price_research = None
        self.price_research_var.set(
            "Not researched yet. Current eBay Buy It Now listings will be used."
        )

    def _open_sold_comps(self):
        query = self._price_research_query()
        if not query:
            messagebox.showerror(APP_NAME, "Identify the item before opening sold comps.")
            return
        params = {
            "_nkw": query,
            "LH_Sold": "1",
            "LH_Complete": "1",
        }
        category_id = self.vars["category_id"].get().strip()
        if category_id:
            params["_sacat"] = category_id
        webbrowser.open("https://www.ebay.com/sch/i.html?" + parse.urlencode(params))

    def _apply_price_research(self, result):
        self.last_price_research = result
        suggested = float(result["suggested"])
        self.vars["price"].set(f"{suggested:.2f}")
        summary = (
            f"Suggested ${suggested:.2f} from {result['used_count']} usable active comps "
            f"({result['count']} returned). "
            f"Low ${result['low']:.2f} • Median ${result['median']:.2f} • "
            f"High ${result['high']:.2f}. "
            "Target is competitive lower-middle pricing, not automatic lowest-price undercutting."
        )
        self.price_research_var.set(summary)
        self._log("PRICE RESEARCH: " + summary)
        for comp in result.get("comparables", [])[:5]:
            self._log(f"  ${comp['price']:.2f} | {comp['title'][:100]}")

    def _research_price_manual(self):
        self._sync_selected_photos()
        if self.worker and self.worker.is_alive():
            return
        query = self._price_research_query()
        if not query:
            messagebox.showerror(
                APP_NAME, "Analyze the photos or enter enough item information first."
            )
            return
        self._save_settings_ui_silent()
        if not self.settings.get("ebay_client_id", "").strip() or not self.settings.get("ebay_client_secret", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Price research needs your eBay App ID and Cert ID in eBay Settings. "
                "Those become available after the developer application is approved."
            )
            return

        self.cancel_event.clear()
        self.research_price_btn.config(state="disabled")
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                result = client.research_price(
                    query, self.vars["category_id"].get().strip()
                )
                self.after(0, lambda: self._apply_price_research(result))
            except Exception as exc:
                self._log(f"PRICE RESEARCH ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.research_price_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _analyze_photos(self):
        self._log("ANALYZE SELECTED clicked.")
        self._show_progress_popup(
            "AI Photo Analysis",
            "Preparing selected photos for OpenAI analysis..."
        )
        self._sync_selected_photos()
        self._log(f"Photos currently checked Use: {len(self.photos)}")
        if not self.photos:
            messagebox.showerror(
                APP_NAME,
                "No photos are currently checked 'Use'.\n\n"
                "Check at least one thumbnail in the Photo Manager and try again."
            )
            self._close_progress_popup()
            return
        if self.worker and self.worker.is_alive():
            self._log("Analyze did not start because another background operation is still running.")
            messagebox.showinfo(
                APP_NAME,
                "Another operation is still running. Wait for it to finish or press STOP / CANCEL."
            )
            return
        if not self.photos:
            messagebox.showerror(APP_NAME, "Select/check at least one photo in the Photo Manager first.")
            return

        self._save_settings_ui_silent()
        if not self.settings.get("openai_api_key", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Open the eBay Settings tab and enter your OpenAI API key first."
            )
            return


        self.cancel_event.clear()
        if getattr(self, "analyze_btn", None) is not None:
            self.analyze_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log("Starting photo analysis. Nothing is being sent to eBay.")

        def work():
            try:
                analyzer = PhotoAnalyzer(
                    self.settings.copy(), self.cancel_event, self._log
                )
                result = analyzer.analyze(self.photos)
                if self.cancel_event.is_set():
                    raise RuntimeError("Cancelled by user.")

                def apply_result():
                    mapping = {
                        "brand": "brand",
                        "mpn": "mpn",
                        "model": "model",
                        "item_description": "item_description",
                        "country": "country",
                    }
                    for source, dest in mapping.items():
                        value = str(result.get(source, "") or "").strip()
                        if value:
                            self.vars[dest].set(value)

                    title = str(result.get("title", "") or "").strip()
                    if title:
                        self.title_var.set(title[:80])

                    condition = result.get("condition", "")
                    if condition in CONDITION_MAP:
                        self.condition_var.set(condition)

                    self.condition_notes.delete("1.0", "end")
                    self.condition_notes.insert(
                        "1.0", str(result.get("condition_notes", "") or "").strip()
                    )

                    self.specifics.delete("1.0", "end")
                    self.specifics.insert(
                        "1.0", str(result.get("specifics", "") or "").strip()
                    )

                    notes = str(result.get("review_notes", "") or "").strip()
                    usage = result.get("_usage", {}) or {}
                    cost = float(usage.get("estimated_cost", 0.0) or 0.0)
                    self.session_ai_cost += cost
                    self.session_ai_analyses += 1
                    avg = self.session_ai_cost / self.session_ai_analyses
                    per_five = int(5.0 / avg) if avg > 0 else 0

                    self._log(
                        "Photo analysis complete. REVIEW EVERY FILLED FIELD "
                        "before creating the eBay draft."
                    )
                    self._log(
                        f"AI COST: ${cost:.4f} this analysis | "
                        f"{usage.get('input_tokens', 0):,} input tokens | "
                        f"{usage.get('output_tokens', 0):,} output tokens"
                    )
                    self._log(
                        f"SESSION AI SPEND: ${self.session_ai_cost:.4f} across "
                        f"{self.session_ai_analyses} analysis(es) | "
                        f"At this average, $5 ≈ {per_five:,} analyses"
                    )
                    if notes:
                        self._log("AI REVIEW NOTES: " + notes)

                    # Once the AI has identified the item, let eBay's own Taxonomy
                    # service choose the best category when eBay authorization exists.
                    category_message = ""
                    if self.settings.get("access_token", "").strip():
                        try:
                            client = EbayClient(
                                self.settings.copy(), self.cancel_event, self._log
                            )
                            suggestion = client.suggest_category(self._category_query())
                            self._apply_category_suggestion(suggestion)
                            category_message = (
                                f"\n\neBay suggested category:\n"
                                f"{suggestion.get('breadcrumb', '')} "
                                f"({suggestion.get('category_id', '')})"
                            )
                        except Exception as cat_exc:
                            self._log(f"Automatic category suggestion failed: {cat_exc}")
                            category_message = (
                                "\n\nI could not automatically choose the eBay category. "
                                "You can use 'Suggest eBay Category' after checking your eBay token."
                            )
                    else:
                        category_message = (
                            "\n\nCategory selection will become automatic once your eBay "
                            "OAuth token is entered."
                        )

                    price_message = ""
                    if (
                        self.settings.get("ebay_client_id", "").strip()
                        and self.settings.get("ebay_client_secret", "").strip()
                    ):
                        try:
                            price_client = EbayClient(
                                self.settings.copy(), self.cancel_event, self._log
                            )
                            price_result = price_client.research_price(
                                self._price_research_query(),
                                self.vars["category_id"].get().strip(),
                            )
                            self._apply_price_research(price_result)
                            price_message = (
                                f"\n\nCompetitive price suggestion: "
                                f"${price_result['suggested']:.2f} "
                                f"(median ${price_result['median']:.2f}, "
                                f"{price_result['used_count']} usable active comps)"
                            )
                        except Exception as price_exc:
                            self._log(f"Automatic price research failed: {price_exc}")
                            price_message = (
                                "\n\nAutomatic price research could not complete. "
                                "Use RESEARCH + SUGGEST PRICE after checking your eBay app credentials."
                            )
                    else:
                        price_message = (
                            "\n\nPrice research will become automatic once your eBay "
                            "App ID and Cert ID are entered."
                        )

                    messagebox.showinfo(
                        APP_NAME,
                        "Photo analysis finished and the listing fields were filled.\n\n"
                        f"OpenAI model: {usage.get('model', self.settings.get('openai_model', ''))}\n"
                        f"ACTUAL AI COST: ${cost:.4f}\n"
                        f"Input tokens: {usage.get('input_tokens', 0):,} | "
                        f"Output tokens: {usage.get('output_tokens', 0):,}\n"
                        f"Session AI spend: ${self.session_ai_cost:.4f}\n"
                        f"At this session average, $5 ≈ {per_five:,} analyses.\n\n"
                        "Please review the title, part number, condition and item specifics "
                        "before creating an eBay draft."
                        + category_message
                        + price_message
                        + (f"\n\nReview notes:\n{notes}" if notes else "")
                    )

                self.after(0, apply_result)
            except Exception as exc:
                self._log(f"PHOTO ANALYSIS STOPPED / ERROR: {exc}")
                def show_analyze_error(e=str(exc)):
                    self._close_progress_popup()
                    messagebox.showerror(APP_NAME, e)
                self.after(0, show_analyze_error)
            finally:
                if getattr(self, "analyze_btn", None) is not None:
                    self.after(0, lambda: self.analyze_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)


        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _preview(self):
        try:
            d = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        # Gather visual sources in exact gallery order.
        visual_sources = []
        pm = getattr(self, "photo_manager", None)
        if pm is not None:
            try:
                visual_sources = pm.ordered_image_sources()
            except Exception:
                visual_sources = []
        if not visual_sources:
            visual_sources = [("local", p) for p in d.get("photos", [])]
            if not visual_sources:
                visual_sources = [("remote", u) for u in self.existing_image_urls]

        win = tk.Toplevel(self)
        win.title("eBay-style Listing Preview — approximate")
        win.geometry("1180x820")
        win.minsize(900, 650)

        canvas = tk.Canvas(win, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        root = ttk.Frame(canvas, padding=18)
        root_id = canvas.create_window((0, 0), window=root, anchor="nw")
        root.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(root_id, width=e.width))

        banner = ttk.Frame(root, padding=(0, 0, 0, 12))
        banner.grid(row=0, column=0, columnspan=2, sticky="ew")
        ttk.Label(
            banner,
            text="Approximate eBay buyer-view preview",
            style="Header.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            banner,
            text=(
                "This mimics the information hierarchy of an eBay listing so you can "
                "review it before publishing. Final eBay fonts/layout may differ."
            ),
            style="Subheader.TLabel",
        ).pack(anchor="w")

        root.columnconfigure(0, weight=3)
        root.columnconfigure(1, weight=2)

        # Image gallery
        gallery = ttk.Frame(root)
        gallery.grid(row=1, column=0, sticky="nsew", padx=(0, 18))
        gallery.columnconfigure(0, weight=1)

        main_photo = ttk.Label(
            gallery,
            text="No listing photo",
            anchor="center",
            relief="solid",
            padding=8,
        )
        main_photo.grid(row=0, column=0, sticky="nsew")
        main_photo._img_ref = None

        thumb_row = ttk.Frame(gallery)
        thumb_row.grid(row=1, column=0, sticky="w", pady=(8, 0))
        thumb_refs = []

        def load_preview_image(kind, value, max_size=(620, 520)):
            try:
                if kind == "local":
                    im = _open_oriented(value)
                else:
                    req = request.Request(value, headers={"User-Agent": "Mozilla/5.0"})
                    with request.urlopen(req, timeout=20) as resp:
                        import io
                        im = Image.open(io.BytesIO(resp.read()))
                        im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail(max_size, Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(im)
            except Exception:
                return None

        def select_source(kind, value):
            img = load_preview_image(kind, value)
            if img:
                main_photo._img_ref = img
                main_photo.configure(image=img, text="")
            else:
                main_photo.configure(image="", text="Photo preview unavailable")

        for idx, (kind, value) in enumerate(visual_sources[:12]):
            img = load_preview_image(kind, value, (90, 90))
            if img:
                thumb_refs.append(img)
                b = ttk.Button(
                    thumb_row,
                    image=img,
                    command=lambda k=kind, v=value: select_source(k, v),
                )
            else:
                b = ttk.Button(
                    thumb_row,
                    text=f"#{idx + 1}",
                    command=lambda k=kind, v=value: select_source(k, v),
                )
            b.grid(row=0, column=idx, padx=(0, 5))

        if visual_sources:
            select_source(*visual_sources[0])

        # Buyer-side detail panel
        details = ttk.Frame(root, padding=4)
        details.grid(row=1, column=1, sticky="nsew")
        ttk.Label(
            details,
            text=d["title"],
            wraplength=430,
            justify="left",
            font=("Segoe UI Semibold", 17),
        ).pack(anchor="w", pady=(0, 6))
        ttk.Label(
            details,
            text=f"Condition: {d['condition']}",
            font=("Segoe UI", 10),
        ).pack(anchor="w", pady=(0, 12))
        ttk.Label(
            details,
            text=f"${float(d['price']):,.2f}",
            font=("Segoe UI Semibold", 24),
        ).pack(anchor="w", pady=(0, 6))
        ttk.Label(
            details,
            text="Buy It Now",
            font=("Segoe UI Semibold", 12),
        ).pack(anchor="w")

        if d["best_offer_enabled"]:
            offer_text = "Best Offer accepted"
            if d["auto_accept_price"] is not None:
                offer_text += f" • auto-accept ≥ ${d['auto_accept_price']:.2f}"
            ttk.Label(details, text=offer_text).pack(anchor="w", pady=(4, 12))
        else:
            ttk.Label(details, text="Best Offer disabled").pack(anchor="w", pady=(4, 12))

        ttk.Separator(details).pack(fill="x", pady=8)
        ttk.Label(details, text=f"Quantity available: {d['quantity']}").pack(anchor="w", pady=3)
        package_text = "Package dimensions not entered"
        if d["package_dimensions"]:
            pd = d["package_dimensions"]
            package_text = (
                f"Package: {pd['length']} × {pd['width']} × {pd['height']} in"
            )
        if d["package_weight_oz"] is not None:
            package_text += f" • {d['package_weight_oz'] / 16:.2f} lb"
        ttk.Label(details, text=package_text, wraplength=430).pack(anchor="w", pady=3)
        ttk.Label(
            details,
            text=(
                f"Shipping policy: {d['fulfillment_policy_id'] or '[not selected]'}\\n"
                f"Returns: {d['return_policy_id'] or '[not selected]'}\\n"
                f"Payment: {d['payment_policy_id'] or '[not selected]'}"
            ),
            justify="left",
        ).pack(anchor="w", pady=8)

        # Lower listing information
        lower = ttk.Frame(root)
        lower.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(22, 0))
        lower.columnconfigure(0, weight=1)

        specifics_box = ttk.LabelFrame(lower, text="Item specifics", padding=12)
        specifics_box.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        specifics = parse_specifics(d["specifics"])
        common = [
            ("Brand", d["brand"]),
            ("MPN", d["mpn"]),
            ("Model", d["model"]),
            ("Country of Origin", d["country"]),
            ("SKU / Custom Label", d["sku"]),
            ("eBay Category ID", d["category_id"]),
        ]
        sr = 0
        for name, value in common:
            if value:
                ttk.Label(specifics_box, text=name + ":").grid(
                    row=sr, column=0, sticky="nw", padx=(0, 12), pady=2
                )
                ttk.Label(specifics_box, text=str(value), wraplength=850).grid(
                    row=sr, column=1, sticky="nw", pady=2
                )
                sr += 1
        for name, values in specifics.items():
            ttk.Label(specifics_box, text=name + ":").grid(
                row=sr, column=0, sticky="nw", padx=(0, 12), pady=2
            )
            ttk.Label(
                specifics_box,
                text=", ".join(str(v) for v in values),
                wraplength=850,
            ).grid(row=sr, column=1, sticky="nw", pady=2)
            sr += 1

        if d["condition_notes"]:
            cond_box = ttk.LabelFrame(lower, text="Seller's condition description", padding=12)
            cond_box.grid(row=1, column=0, sticky="ew", pady=(0, 12))
            ttk.Label(
                cond_box,
                text=d["condition_notes"],
                wraplength=1000,
                justify="left",
            ).pack(anchor="w")

        desc_box = ttk.LabelFrame(lower, text="Item description", padding=12)
        desc_box.grid(row=2, column=0, sticky="ew")
        ttk.Label(
            desc_box,
            text=d["description"],
            wraplength=1040,
            justify="left",
        ).pack(anchor="w")

        # Keep refs alive.
        win._thumb_refs = thumb_refs


    def _save_listing_file(self):
        try:
            d = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        path = filedialog.asksaveasfilename(
            title="Save listing",
            defaultextension=".json",
            filetypes=[("Listing JSON", "*.json")],
            initialfile=(d["sku"] or "listing") + ".json",
        )
        if path:
            Path(path).write_text(json.dumps(d, indent=2), encoding="utf-8")
            self._log(f"Saved listing file: {path}")

    def _load_listing_file(self):
        path = filedialog.askopenfilename(
            title="Load listing",
            filetypes=[("Listing JSON", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            d = json.loads(Path(path).read_text(encoding="utf-8"))
            for key in self.vars:
                if key in d:
                    self.vars[key].set(str(d[key]))
            self.condition_var.set(d.get("condition", "Used - Good"))
            self.title_var.set(d.get("title", ""))
            self.condition_notes.delete("1.0", "end")
            self.condition_notes.insert("1.0", d.get("condition_notes", ""))
            self.specifics.delete("1.0", "end")
            self.specifics.insert("1.0", d.get("specifics", ""))
            self.best_offer_var.set(bool(d.get("best_offer_enabled", True)))
            self.auto_accept_var.set(
                "" if d.get("auto_accept_price") is None else str(d.get("auto_accept_price"))
            )
            self.auto_decline_var.set(
                "" if d.get("auto_decline_price") is None else str(d.get("auto_decline_price"))
            )
            dims = d.get("package_dimensions") or {}
            self.package_length_var.set(str(dims.get("length", "") or ""))
            self.package_width_var.set(str(dims.get("width", "") or ""))
            self.package_height_var.set(str(dims.get("height", "") or ""))
            weight_oz = d.get("package_weight_oz")
            if weight_oz is not None:
                total = float(weight_oz)
                whole_lb = int(total // 16)
                remain_oz = total - whole_lb * 16
                self.package_lb_var.set(str(whole_lb))
                self.package_oz_var.set(f"{remain_oz:.2f}".rstrip("0").rstrip("."))
            else:
                self.package_lb_var.set("")
                self.package_oz_var.set("")
            api_type = d.get("package_type", "PACKAGE_THICK_ENVELOPE")
            display_type = "Standard package / thick envelope"
            for display, api_value in PACKAGE_TYPE_MAP.items():
                if api_value == api_type:
                    display_type = display
                    break
            self.package_type_var.set(display_type)
            self.existing_image_urls = list(d.get("existing_image_urls", []) or [])
            self.photos = [p for p in d.get("photos", []) if Path(p).exists()]
            if getattr(self, "photo_manager", None) is not None:
                self.photo_manager.set_paths(self.photos)
            self._log(f"Loaded listing file: {path}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Could not load listing:\n{exc}")

    def _condition_display_from_api(self, api_value):
        for display, api in CONDITION_MAP.items():
            if api == api_value:
                return display
        return "Used - Good"

    def _specifics_text_from_aspects(self, aspects):
        lines = []
        for key, values in (aspects or {}).items():
            if key in ("Brand", "MPN", "Model", "Country of Origin"):
                continue
            if isinstance(values, list):
                value = ", ".join(str(v) for v in values)
            else:
                value = str(values)
            lines.append(f"{key}={value}")
        return "\n".join(lines)

    def _load_offer_into_editor(self, offer, inventory):
        self.original_offer = offer
        self.original_inventory_item = inventory
        self.editing_offer_id = str(offer.get("offerId", "") or "")
        self.editing_offer_status = str(offer.get("status", "") or "")
        sku = str(offer.get("sku", "") or inventory.get("sku", "") or "")

        product = inventory.get("product", {}) or {}
        aspects = product.get("aspects", {}) or {}
        self.vars["sku"].set(sku)
        self.vars["brand"].set(str(product.get("brand", "") or (aspects.get("Brand", [""])[0] if aspects.get("Brand") else "")))
        self.vars["mpn"].set(str(product.get("mpn", "") or (aspects.get("MPN", [""])[0] if aspects.get("MPN") else "")))
        self.vars["model"].set(str((aspects.get("Model", [""])[0] if aspects.get("Model") else "")))
        self.vars["country"].set(str((aspects.get("Country of Origin", [""])[0] if aspects.get("Country of Origin") else "")))
        self.vars["item_description"].set("")  # title/description remain editable below
        self.title_var.set(str(product.get("title", "") or ""))

        price = ((offer.get("pricingSummary", {}) or {}).get("price", {}) or {}).get("value", "")
        self.vars["price"].set(str(price))
        quantity = offer.get("availableQuantity")
        if quantity is None:
            quantity = (
                ((inventory.get("availability", {}) or {}).get("shipToLocationAvailability", {}) or {})
                .get("quantity", 1)
            )
        self.vars["quantity"].set(str(quantity))
        self.vars["category_id"].set(str(offer.get("categoryId", "") or ""))
        self.category_suggestion_label.config(
            text=f"Loaded from eBay (Category {self.vars['category_id'].get()})"
        )

        self.condition_var.set(
            self._condition_display_from_api(str(inventory.get("condition", "") or ""))
        )
        self.condition_notes.delete("1.0", "end")
        self.condition_notes.insert("1.0", str(inventory.get("conditionDescription", "") or ""))
        self.specifics.delete("1.0", "end")
        self.specifics.insert("1.0", self._specifics_text_from_aspects(aspects))

        package = inventory.get("packageWeightAndSize", {}) or {}
        dims = package.get("dimensions", {}) or {}
        self.package_length_var.set(str(dims.get("length", "") or ""))
        self.package_width_var.set(str(dims.get("width", "") or ""))
        self.package_height_var.set(str(dims.get("height", "") or ""))

        weight = package.get("weight", {}) or {}
        weight_value = weight.get("value")
        weight_unit = str(weight.get("unit", "") or "").upper()
        lbs = ""
        oz = ""
        if weight_value not in (None, ""):
            try:
                w = float(weight_value)
                if weight_unit == "POUND":
                    total_oz = w * 16.0
                elif weight_unit == "KILOGRAM":
                    total_oz = w * 35.27396195
                elif weight_unit == "GRAM":
                    total_oz = w * 0.03527396195
                else:
                    total_oz = w
                whole_lb = int(total_oz // 16)
                remain_oz = total_oz - whole_lb * 16
                lbs = str(whole_lb)
                oz = f"{remain_oz:.2f}".rstrip("0").rstrip(".")
            except Exception:
                pass
        self.package_lb_var.set(lbs)
        self.package_oz_var.set(oz)

        api_package_type = str(package.get("packageType", "") or "")
        display_package_type = "Standard package / thick envelope"
        for display, api_value in PACKAGE_TYPE_MAP.items():
            if api_value == api_package_type:
                display_package_type = display
                break
        self.package_type_var.set(display_package_type)

        self.existing_image_urls = list(product.get("imageUrls", []) or [])
        self.photos = []
        if getattr(self, "photo_manager", None) is not None:
            if self.existing_image_urls:
                self.photo_manager.set_remote_urls(self.existing_image_urls)
            else:
                self.photo_manager.clear()

        listing_policies = offer.get("listingPolicies", {}) or {}
        self._select_policy_by_id("fulfillment", listing_policies.get("fulfillmentPolicyId"))
        self._select_policy_by_id("payment", listing_policies.get("paymentPolicyId"))
        self._select_policy_by_id("return", listing_policies.get("returnPolicyId"))

        terms = listing_policies.get("bestOfferTerms", {}) or {}
        self.best_offer_var.set(bool(terms.get("bestOfferEnabled", False)))
        auto_accept = (terms.get("autoAcceptPrice", {}) or {}).get("value", "")
        auto_decline = (terms.get("autoDeclinePrice", {}) or {}).get("value", "")
        self.auto_accept_var.set(str(auto_accept or ""))
        self.auto_decline_var.set(str(auto_decline or ""))

        # Preserve the actual offer description rather than replacing it simply by loading.
        # The standard generated description is shown/used if the user changes listing details.
        loaded_desc = str(offer.get("listingDescription", "") or product.get("description", "") or "")
        if loaded_desc:
            # Set a short descriptive phrase only when safely derivable from the title is not possible.
            self.vars["item_description"].set(str(product.get("subtitle", "") or ""))

        status_text = (
            f"Loaded Offer {self.editing_offer_id} | SKU {sku} | "
            f"Status {self.editing_offer_status}"
        )
        listing = offer.get("listing", {}) or {}
        if listing.get("listingId"):
            status_text += f" | Listing ID {listing.get('listingId')}"
        upsert_offer_history({
            "offer_id": self.editing_offer_id,
            "sku": sku,
            "status": self.editing_offer_status,
            "listing_id": str(listing.get("listingId", "") or ""),
            "title": self.title_var.get(),
            "price": str(price or ""),
            "category_id": self.vars["category_id"].get(),
        })
        self._refresh_offer_history_table()
        self.existing_status_var.set(status_text)
        self._update_draft_button_text()

        # Refresh category-specific condition choices immediately for loaded offers.
        loaded_category = self.vars["category_id"].get().strip()
        if loaded_category:
            def refresh_loaded_condition_policy():
                try:
                    client = EbayClient(
                        self.settings.copy(), self.cancel_event, self._log
                    )
                    policy = client.get_item_condition_policies(loaded_category)
                    self.after(
                        0,
                        lambda p=policy, c=loaded_category:
                            self._apply_condition_policy(
                                p, c, show_message=True
                            )
                    )
                except Exception as exc:
                    self._log(
                        f"Could not refresh condition policy for loaded offer: {exc}"
                    )
            threading.Thread(
                target=refresh_loaded_condition_policy, daemon=True
            ).start()
        self._set_existing_info(
            status_text
            + "\n\nTitle: " + self.title_var.get()
            + "\nPrice: $" + str(price)
            + "\nCategory ID: " + self.vars["category_id"].get()
            + "\nBest Offer: " + ("Enabled" if self.best_offer_var.get() else "Disabled")
            + "\nShipping package: "
            + (
                f"{self.package_length_var.get()} x {self.package_width_var.get()} x {self.package_height_var.get()} in, "
                f"{self.package_lb_var.get() or '0'} lb {self.package_oz_var.get() or '0'} oz"
                if any((self.package_length_var.get(), self.package_width_var.get(), self.package_height_var.get(), self.package_lb_var.get(), self.package_oz_var.get()))
                else "[not set]"
            )
            + "\nExisting eBay photos: " + str(len(self.existing_image_urls))
            + "\n\nThe Listing Editor tab is now populated. "
              "Use SAVE CHANGES TO EBAY when you are ready."
        )
        self.save_changes_btn.config(state="normal")
        if hasattr(self, "publish_btn"):
            self.publish_btn.config(
                state="normal"
                if self.editing_offer_id and self.editing_offer_status.upper() != "PUBLISHED"
                else "disabled"
            )
        self.notebook.select(self.listing_tab)
        self._log(status_text)

    def _fetch_and_load_offer(self, offer_id):
        self._save_settings_ui_silent()
        client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
        offer = client.get_offer(offer_id)
        sku = offer.get("sku")
        if not sku:
            raise RuntimeError("eBay returned the offer but did not include its SKU.")
        inventory = client.get_inventory_item(sku)
        self.after(0, lambda: self._load_offer_into_editor(offer, inventory))

    def _load_existing_by_offer_id(self):
        offer_id = self.lookup_offer_var.get().strip()
        if not offer_id:
            messagebox.showerror(APP_NAME, "Enter an Offer ID.")
            return
        self._run_existing_lookup(lambda: self._fetch_and_load_offer(offer_id))

    def _load_existing_by_sku(self):
        sku = self.lookup_sku_var.get().strip()
        if not sku:
            messagebox.showerror(APP_NAME, "Enter a SKU / Custom Label.")
            return

        def lookup():
            self._save_settings_ui_silent()
            client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
            offers = client.get_offers_by_sku(sku)
            if not offers:
                raise RuntimeError(f"No Inventory API offers were found for SKU {sku}.")
            if len(offers) > 1:
                self._log(
                    f"Multiple offers found for SKU {sku}; loading the first offer "
                    f"for marketplace {self.settings.get('marketplace_id', 'EBAY_US')}."
                )
            offer = offers[0]
            inventory = client.get_inventory_item(sku)
            self.after(0, lambda: self._load_offer_into_editor(offer, inventory))

        self._run_existing_lookup(lookup)

    def _run_existing_lookup(self, fn):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter an eBay OAuth access token first.")
            return
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                fn()
            except Exception as exc:
                self._log(f"EXISTING LISTING LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_changes_to_ebay(self):
        self._sync_selected_photos()
        if not self.editing_offer_id or not self.original_offer:
            messagebox.showinfo(
                APP_NAME,
                "There is no existing eBay offer loaded to revise.\n\n"
                "Load one from the Existing eBay Listing tab first."
            )
            return
        if self.worker and self.worker.is_alive():
            return
        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        is_live = self.editing_offer_status.upper() == "PUBLISHED"
        warning = (
            "This offer is PUBLISHED. A successful update will change the LIVE eBay listing immediately."
            if is_live
            else "This offer is currently unpublished. Changes will update the eBay offer but will not publish it."
        )
        if not messagebox.askyesno(
            APP_NAME,
            warning
            + "\n\nContinue saving these changes to eBay?\n\n"
              "The program still does not contain a Publish command."
        ):
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.save_changes_btn.config(state="normal")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log(f"Updating existing eBay offer {self.editing_offer_id}...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                # Preserve the exact gallery order, mixing existing eBay images
                # and newly added local images without unnecessary re-uploading.
                sources = (
                    self.photo_manager.ordered_image_sources()
                    if getattr(self, "photo_manager", None) is not None
                    else []
                )
                urls = []
                if sources:
                    for kind, value in sources:
                        client._check_cancel()
                        if kind == "remote":
                            urls.append(value)
                        else:
                            urls.append(client.upload_image(value))
                    listing["image_urls"] = urls
                elif listing["photos"]:
                    listing["image_urls"] = [
                        client.upload_image(p) for p in listing["photos"]
                    ]
                else:
                    listing["image_urls"] = list(self.existing_image_urls)

                if not listing["image_urls"]:
                    raise RuntimeError(
                        "The listing has no eBay photos. Select at least one photo before saving."
                    )

                client._check_cancel()
                self._sync_category_specifics(client, listing, update_ui=True)
                self._validate_category_product_identifiers(client, listing)
                self._validate_category_condition_sync(client, listing)
                client.create_inventory_item(listing["sku"], listing)

                client._check_cancel()
                client.update_offer(
                    self.editing_offer_id, listing, self.original_offer
                )

                client._check_cancel()
                self._log(
                    f"SUCCESS: Offer {self.editing_offer_id} updated."
                    + (" The live listing was revised." if is_live else " The offer remains unpublished.")
                )
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        "Changes saved to eBay successfully.\n\n"
                        + (
                            "This was a published offer, so the live listing was revised."
                            if is_live
                            else "The offer remains unpublished."
                        )
                    )
                )
                # Reload from eBay so the editor has the authoritative current object.
                updated_offer = client.get_offer(self.editing_offer_id)
                updated_inventory = client.get_inventory_item(listing["sku"])
                self.after(
                    0,
                    lambda: self._load_offer_into_editor(
                        updated_offer, updated_inventory
                    )
                )
            except Exception as exc:
                self._log(f"UPDATE ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(
                    0,
                    lambda: self.save_changes_btn.config(
                        state="normal" if self.editing_offer_id else "disabled"
                    )
                )
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _format_inventory_location(self, loc):
        key = str(loc.get("merchantLocationKey", "") or "")
        name = str(loc.get("name", "") or "")
        status = str(loc.get("merchantLocationStatus", "") or "")
        address = ((loc.get("location", {}) or {}).get("address", {}) or {})
        postal = str(address.get("postalCode", "") or "")
        country = str(address.get("country", "") or "")
        return f"{name or key}  [{key}]  {postal} {country}  {status}".strip()

    def _load_inventory_locations(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter your eBay User Access Token first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                locations = client.get_inventory_locations()
                mapping = {}
                for loc in locations:
                    key = str(loc.get("merchantLocationKey", "") or "")
                    if key:
                        mapping[self._format_inventory_location(loc)] = key

                def done():
                    self.inventory_location_map = mapping
                    self.location_combo["values"] = list(mapping.keys())
                    if mapping:
                        # Prefer currently configured key.
                        current = self.settings.get("merchant_location_key", "")
                        choice = ""
                        for display, key in mapping.items():
                            if key == current:
                                choice = display
                                break
                        if not choice:
                            choice = next(iter(mapping))
                        self.location_choice_var.set(choice)
                        messagebox.showinfo(
                            APP_NAME,
                            f"Found {len(mapping)} eBay inventory location(s).\\n\\n"
                            "Choose one and click Use Selected Location."
                        )
                    else:
                        self.location_choice_var.set("")
                        messagebox.showinfo(
                            APP_NAME,
                            "No Inventory API locations were found.\\n\\n"
                            "Create a warehouse location in the section below."
                        )
                self.after(0, done)
            except Exception as exc:
                self._log(f"LOCATION LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _use_selected_inventory_location(self):
        display = self.location_choice_var.get().strip()
        mapping = getattr(self, "inventory_location_map", {})
        key = mapping.get(display)
        if not key:
            messagebox.showerror(APP_NAME, "Load and select an inventory location first.")
            return
        self.setting_vars["merchant_location_key"].set(key)
        self.settings["merchant_location_key"] = key
        save_settings(self.settings)
        messagebox.showinfo(
            APP_NAME,
            f"Merchant Location Key set to:\\n\\n{key}"
        )

    def _create_inventory_location(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()

        key = self.new_location_key_var.get().strip()
        name = self.new_location_name_var.get().strip()
        postal = self.new_location_postal_var.get().strip()
        country = self.new_location_country_var.get().strip() or "US"

        if not key or not name or not postal:
            messagebox.showerror(
                APP_NAME,
                "Enter a Merchant Location Key, location name, and postal code."
            )
            return

        if not messagebox.askyesno(
            APP_NAME,
            "Create this eBay Inventory API warehouse?\\n\\n"
            f"Merchant Location Key: {key}\\n"
            f"Name: {name}\\n"
            f"Postal Code: {postal}\\n"
            f"Country: {country}\\n\\n"
            "The Merchant Location Key cannot be renamed later."
        ):
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                created_key = client.create_warehouse_location(key, name, postal, country)

                def done():
                    self.setting_vars["merchant_location_key"].set(created_key)
                    self.settings["merchant_location_key"] = created_key
                    save_settings(self.settings)
                    messagebox.showinfo(
                        APP_NAME,
                        "Warehouse location created successfully.\\n\\n"
                        f"Merchant Location Key: {created_key}\\n\\n"
                        "The app saved this as your default location."
                    )
                    self._load_inventory_locations()
                self.after(0, done)
            except Exception as exc:
                self._log(f"LOCATION CREATE ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _ebay_oauth_scope_list(self):
        # Scopes selected for this app's current feature set.
        return [
            "https://api.ebay.com/oauth/api_scope",
            "https://api.ebay.com/oauth/api_scope/sell.inventory",
            "https://api.ebay.com/oauth/api_scope/sell.account",
            "https://api.ebay.com/oauth/api_scope/sell.fulfillment",
            "https://api.ebay.com/oauth/api_scope/sell.finances",
        ]

    def _validate_oauth_setup(self, show_success=True):
        """
        Validate the values we can verify locally before opening eBay.
        This does not expose or transmit the Client Secret.
        """
        self._save_settings_ui_silent()
        env = self.settings.get("api_environment", "production").strip()
        client_id = self.settings.get("ebay_client_id", "").strip()
        client_secret = self.settings.get("ebay_client_secret", "").strip()
        runame = self.settings.get("ebay_runame", "").strip()

        problems = []
        if env not in ("production", "sandbox"):
            problems.append("API Environment must be production or sandbox.")
        if not client_id:
            problems.append("App ID / Client ID is blank.")
        if not client_secret:
            problems.append("Cert ID / Client Secret is blank.")
        if not runame:
            problems.append("OAuth RuName is blank.")
        if "http://" in runame.lower() or "https://" in runame.lower():
            problems.append(
                "OAuth RuName should be the eBay-generated RuName value, not an https:// URL."
            )
        if any(ch.isspace() for ch in runame):
            problems.append("OAuth RuName contains spaces; copy the exact eBay-generated RuName.")

        if problems:
            messagebox.showerror(
                APP_NAME,
                "OAuth setup needs attention:\n\n- " + "\n- ".join(problems)
                + "\n\nUse the Production App ID, Production Cert ID, and the "
                  "OAuth-enabled Production RuName from the same eBay application."
            )
            return False

        if show_success:
            messagebox.showinfo(
                APP_NAME,
                "OAuth setup looks structurally correct.\n\n"
                f"Environment: {env}\n"
                f"App ID ending: ...{client_id[-8:]}\n"
                f"RuName: {runame}\n\n"
                "This check does not display your Client Secret."
            )
        return True

    def _open_refresh_authorization(self):
        if not self._validate_oauth_setup(show_success=False):
            return
        self._save_settings_ui_silent()
        client_id = self.settings.get("ebay_client_id", "").strip()
        runame = self.settings.get("ebay_runame", "").strip()

        if not client_id:
            messagebox.showerror(
                APP_NAME, "Enter your Production eBay App ID / Client ID first."
            )
            return
        if not runame:
            messagebox.showerror(
                APP_NAME,
                "Enter your Production OAuth RuName first. "
                "It is shown on eBay's User Tokens / OAuth configuration page."
            )
            return

        endpoint = (
            "https://auth.ebay.com/oauth2/authorize"
            if self.settings.get("api_environment", "production") == "production"
            else "https://auth.sandbox.ebay.com/oauth2/authorize"
        )

        params = {
            "client_id": client_id,
            "response_type": "code",
            "redirect_uri": runame,
            "scope": " ".join(self._ebay_oauth_scope_list()),
            "prompt": "login",
        }

        # eBay documents scope as a URL-encoded, space-separated list.
        # Use quote() rather than quote_plus() so spaces become %20, not '+'.
        url = endpoint + "?" + parse.urlencode(params, quote_via=parse.quote)

        self._log("Opening eBay OAuth consent request.")
        self._log(
            "OAuth setup: environment="
            + self.settings.get("api_environment", "production")
            + " | Client ID suffix="
            + (client_id[-8:] if len(client_id) >= 8 else "[short]")
            + " | RuName="
            + runame
        )
        webbrowser.open(url)

        messagebox.showinfo(
            APP_NAME,
            "eBay authorization opened in your browser.\n\n"
            "1. Sign into the seller account.\n"
            "2. Click Agree / Grant Access.\n"
            "3. When eBay redirects you to the final page, copy the ENTIRE URL "
            "from the browser address bar.\n"
            "4. Paste it into the box beside 'SAVE REFRESH TOKEN'.\n\n"
            "The URL should contain a parameter named code=...\n\n"
            "If eBay shows invalid_request before the consent page, verify that "
            "App ID and RuName are both from the same PRODUCTION keyset."
        )

    def _extract_authorization_code(self, pasted):
        raw = str(pasted or "").strip()
        if not raw:
            return ""

        # Accept either the entire final redirect URL or just the code itself.
        if "://" not in raw and "code=" not in raw:
            return parse.unquote(raw)

        try:
            parsed_url = parse.urlparse(raw)
            query = parse.parse_qs(parsed_url.query)
            code_values = query.get("code", [])
            if code_values:
                return parse.unquote(code_values[0])
        except Exception:
            pass

        # Last fallback if user pasted an incomplete URL fragment.
        match = re.search(r"(?:^|[?&])code=([^&]+)", raw)
        if match:
            return parse.unquote(match.group(1))
        return ""

    def _exchange_refresh_authorization(self):
        if self.worker and self.worker.is_alive():
            return

        self._save_settings_ui_silent()
        pasted = self.oauth_return_url_var.get().strip()
        code = self._extract_authorization_code(pasted)
        runame = self.settings.get("ebay_runame", "").strip()

        if not code:
            messagebox.showerror(
                APP_NAME,
                "I could not find an authorization code.\n\n"
                "Paste the full final eBay browser URL after you click Agree. "
                "It should contain code=..."
            )
            return

        if not runame:
            messagebox.showerror(APP_NAME, "Enter your OAuth RuName first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log("Exchanging one-time eBay authorization code for refresh token...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                tokens = client.exchange_authorization_code(code, runame)

                def done():
                    self.settings["access_token"] = tokens["access_token"]
                    self.settings["ebay_refresh_token"] = tokens["refresh_token"]

                    if "access_token" in self.setting_vars:
                        self.setting_vars["access_token"].set(tokens["access_token"])
                    if "ebay_refresh_token" in self.setting_vars:
                        self.setting_vars["ebay_refresh_token"].set(tokens["refresh_token"])

                    save_settings(self.settings)
                    self.oauth_return_url_var.set("")
                    self.oauth_refresh_status_var.set(
                        "Automatic refresh is configured. The app will renew expired "
                        "eBay User Access Tokens automatically."
                    )

                    refresh_days = (
                        tokens["refresh_token_expires_in"] / 86400
                        if tokens["refresh_token_expires_in"] else 0
                    )
                    messagebox.showinfo(
                        APP_NAME,
                        "Automatic eBay token refresh is configured.\n\n"
                        f"Current access token lifetime: about "
                        f"{tokens['expires_in'] / 3600:.1f} hours\n"
                        + (
                            f"Refresh-token lifetime reported by eBay: "
                            f"about {refresh_days:.0f} days\n\n"
                            if refresh_days else "\n"
                        )
                        + "You should no longer need to manually paste a new "
                        "access token every couple of hours."
                    )

                self.after(0, done)
            except Exception as exc:
                self._log(f"OAUTH REFRESH SETUP ERROR: {exc}")
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        APP_NAME,
                        "Automatic refresh setup failed:\n\n" + e
                    )
                )
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _test_ebay_connection(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter a Production eBay OAuth User Access Token first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log("Testing eBay connection (read-only)...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                tree_id = client.get_default_category_tree_id()
                policies = client.get_business_policies()

                def done():
                    self._apply_policies(policies)
                    messagebox.showinfo(
                        APP_NAME,
                        "eBay connection works.\n\n"
                        f"Marketplace: {self.settings.get('marketplace_id', 'EBAY_US')}\n"
                        f"Category tree: {tree_id}\n"
                        f"Shipping policies: {len(policies.get('fulfillment', []))}\n"
                        f"Payment policies: {len(policies.get('payment', []))}\n"
                        f"Return policies: {len(policies.get('return', []))}\n\n"
                        "No listing was created or changed."
                    )
                self.after(0, done)
            except Exception as exc:
                self._log(f"EBAY CONNECTION TEST ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, "eBay connection test failed:\n\n" + e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_settings_ui(self):
        for key, var in self.setting_vars.items():
            self.settings[key] = var.get().strip()
        self.settings["api_environment"] = self.env_var.get()
        save_settings(self.settings)
        if not self.vars["category_id"].get().strip():
            self.vars["category_id"].set(self.settings.get("default_category_id", ""))
        messagebox.showinfo(APP_NAME, "Settings saved locally.")

    def _stop(self):
        self._close_progress_popup()
        self.cancel_event.set()
        self._log("STOP requested. The current AI/eBay network request may finish, but no new steps will start.")

    def _draft_stage_error(self, stage, exc):
        msg = str(exc)
        is_404 = (
            "404" in msg
            and (
                "2002" in msg
                or "Resource not found" in msg
                or "Resource not resolved" in msg
                or "HTTP 404 Not Found" in msg
            )
        )
        if not is_404:
            return msg

        explanations = {
            "inventory preflight": "The Inventory API route itself could not be resolved.",
            "photo upload": "The failure happened while uploading a photo through eBay's Media API.",
            "category specifics metadata": "The failure happened while loading the complete set of category-specific item details.",
            "brand/mpn metadata": "The failure happened while validating Brand/MPN against the category.",
            "condition metadata": "The failure happened while loading valid conditions for the selected category.",
            "inventory item": "The failure happened while creating/updating the Inventory Item.",
            "offer": "The failure happened while creating the unpublished Offer.",
        }
        return (
            f"eBay returned HTTP 404 / error 2002 during: {stage.upper()}\n\n"
            + explanations.get(stage, "eBay could not resolve the API resource used in this stage.")
            + "\n\nThis is a resource/URI routing error, not the normal expired-token "
              "(401) or insufficient-permission (403) response."
        )

    def _update_draft_button_text(self):
        if not hasattr(self, "create_btn"):
            return
        if str(getattr(self, "editing_offer_id", "") or "").strip():
            self.create_btn.config(text="SAVE DRAFT")
        else:
            self.create_btn.config(text="CREATE DRAFT")

    def _create_or_save_draft(self):
        if str(getattr(self, "editing_offer_id", "") or "").strip():
            self._save_changes_to_ebay()
        else:
            self._create_draft()

    def _clear_after_successful_publish(self):
        """Reset the Listing Editor after a listing is live; drafts stay loaded."""
        try:
            self._new_listing()
            self._select_top_tab(self.listing_tab)
            self._log("LISTING EDITOR CLEARED AFTER SUCCESSFUL PUBLISH")
        except Exception as exc:
            self._log("POST-PUBLISH CLEAR WARNING: " + str(exc))

    def _create_draft_and_publish(self):
        if self.worker and self.worker.is_alive():
            return

        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        if not messagebox.askyesno(
            APP_NAME,
            "CREATE DRAFT AND PUBLISH LIVE?\n\n"
            f"Title: {listing.get('title', '')}\n"
            f"Price: ${float(listing.get('price', 0) or 0):.2f}\n"
            f"Quantity: {listing.get('quantity', '')}\n\n"
            "This will create the eBay inventory item and offer, then immediately "
            "publish it as a LIVE eBay listing.\n\n"
            "Are you sure you want to continue?",
        ):
            return

        self._create_draft(
            publish_after=True,
            confirmation_already_done=True,
        )

    def _create_draft(self, publish_after=False, confirmation_already_done=False):
        self._sync_selected_photos()
        self._show_progress_popup(
            "Creating eBay Draft",
            "Validating listing details and preparing photos..."
        )
        if self.worker and self.worker.is_alive():
            return
        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            self._close_progress_popup()
            return

        if not listing["photos"]:
            messagebox.showerror(APP_NAME, "Select/check at least one photo in the Photo Manager before creating an eBay draft.")
            self._close_progress_popup()
            return

        if not listing["category_id"]:
            messagebox.showerror(APP_NAME, "Enter an eBay leaf Category ID before creating the draft.")
            self._close_progress_popup()
            return

        if not confirmation_already_done:
            if not messagebox.askyesno(
                APP_NAME,
                "Create an UNPUBLISHED eBay offer?\n\n"
                "This will upload the selected photos and create/update eBay inventory data. "
                "It will NOT publish a live listing.",
            ):
                self._close_progress_popup()
                return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.create_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log("Starting draft creation. Nothing will be published.")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                current_stage = "inventory preflight"
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Checking eBay Inventory API access..."
                    )
                )
                client.check_inventory_api()

                current_stage = "photo upload"
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Uploading photos to eBay..."
                    )
                )
                urls = []
                total_photos = len(listing["photos"])
                for photo_index, p in enumerate(listing["photos"], start=1):
                    client._check_cancel()
                    self.after(
                        0,
                        lambda i=photo_index, n=total_photos, name=Path(p).name:
                            self._update_progress_popup(
                                f"Uploading photo {i} of {n}: {name}"
                            )
                    )
                    urls.append(client.upload_image(p))
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Photos uploaded. Creating/updating eBay inventory item..."
                    )
                )
                listing["image_urls"] = urls

                client._check_cancel()
                current_stage = "category specifics metadata"
                self._log("DRAFT STAGE: Syncing all category-specific item details...")
                self._sync_category_specifics(client, listing, update_ui=True)

                current_stage = "brand/mpn metadata"
                self._log("DRAFT STAGE: Validating category-specific Brand/MPN requirements...")
                self._validate_category_product_identifiers(client, listing)
                self._log("DRAFT STAGE COMPLETE: Product identifiers accepted for preflight.")
                current_stage = "condition metadata"
                self._log("DRAFT STAGE: Validating category-specific item condition...")
                self._validate_category_condition_sync(client, listing)
                self._log("DRAFT STAGE COMPLETE: Item condition accepted for category.")
                current_stage = "inventory item"
                self._log("DRAFT STAGE: Creating/updating Inventory Item...")
                client.create_inventory_item(listing["sku"], listing)
                self._log("DRAFT STAGE COMPLETE: Inventory Item accepted by eBay.")
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Inventory item accepted. Creating unpublished eBay offer..."
                    )
                )

                client._check_cancel()
                current_stage = "offer"
                self._log("DRAFT STAGE: Creating unpublished Offer...")
                offer_id = client.create_offer(listing["sku"], listing)
                self._log("DRAFT STAGE COMPLETE: Unpublished Offer created.")

                client._check_cancel()
                self.editing_offer_id = str(offer_id)
                self.editing_offer_status = "UNPUBLISHED"
                upsert_offer_history({
                    "offer_id": str(offer_id),
                    "sku": listing["sku"],
                    "status": "UNPUBLISHED",
                    "listing_id": "",
                    "title": listing["title"],
                    "price": f"{float(listing['price']):.2f}",
                    "category_id": listing["category_id"],
                })
                self.after(0, self._refresh_offer_history_table)
                self._log(f"SUCCESS: Unpublished Buy It Now offer created. Offer ID: {offer_id}")
                self.after(0, lambda: self.publish_btn.config(state="normal"))
                self.after(0, self._update_draft_button_text)

                if publish_after:
                    self.after(
                        0,
                        lambda: self._update_progress_popup(
                            "Draft created. Publishing the offer to eBay..."
                        )
                    )
                    listing_id = client.publish_offer(offer_id)
                    self.editing_offer_status = "PUBLISHED"
                    upsert_offer_history({
                        "offer_id": str(offer_id),
                        "sku": listing["sku"],
                        "status": "PUBLISHED",
                        "listing_id": listing_id,
                        "title": listing["title"],
                        "price": f"{float(listing['price']):.2f}",
                        "category_id": listing["category_id"],
                    })
                    self.after(0, self._refresh_offer_history_table)
                    self._log(
                        f"SUCCESS: Draft created and published. "
                        f"Listing ID: {listing_id}"
                    )
                    self.after(
                        0,
                        lambda lid=listing_id, data=listing: self._show_live_listing_success(
                            lid,
                            title="Draft created and listing published successfully",
                            listing_data=data,
                        ),
                    )
                    self.after(0, self._clear_after_successful_publish)
                else:
                    self._log(
                        "The program did NOT publish the offer. "
                        "Use PUBLISH TO EBAY only after review."
                    )
                    self.after(
                        0,
                        lambda: messagebox.showinfo(
                            APP_NAME,
                            f"eBay draft/unpublished offer created successfully.\n\n"
                            f"Offer ID: {offer_id}\n\nIt is NOT live.",
                        ),
                    )
            except Exception as exc:
                stage = locals().get("current_stage", "unknown draft stage")
                self._log(f"STOPPED / ERROR during {stage}: {exc}")
                err_text = self._draft_stage_error(stage, exc)

                def show_draft_error():
                    if "25002" in err_text and "BrandMPN" in err_text:
                        messagebox.showerror(
                            APP_NAME,
                            "eBay rejected the Brand/MPN product identifier.\n\n"
                            "Check that Brand / Manufacturer and MPN / Part Number are "
                            "both present and copied exactly from the item. Do not enter "
                            "'BrandMPN' as one combined Extra Item Specific.\n\n"
                            "The listing was not published."
                        )
                    else:
                        messagebox.showerror(APP_NAME, err_text)

                self.after(0, show_draft_error)
            finally:
                self.after(0, lambda: self.create_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _prepare_offer_for_publish(self, client, listing, offer_id):
        """
        Synchronize the editor state to eBay before publishOffer.

        This prevents an older unpublished offer/inventory item from being
        published with stale category, condition, photos, price, or policies.
        """
        self._log("PUBLISH PREFLIGHT: syncing category-specific item details...")
        self._sync_category_specifics(client, listing, update_ui=True)
        self._log("PUBLISH PREFLIGHT: validating category-specific Brand/MPN requirements...")
        self._validate_category_product_identifiers(client, listing)
        self._log("PUBLISH PREFLIGHT: validating category-specific condition...")
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Checking eBay category and allowed item conditions..."
            )
        )
        self._validate_category_condition_sync(client, listing, show_message=False)

        # Build the image URL set in current gallery order. Existing eBay-hosted
        # images are reused; only new local files are uploaded.
        sources = (
            self.photo_manager.ordered_image_sources()
            if getattr(self, "photo_manager", None) is not None
            else []
        )
        urls = []
        if sources:
            total = len(sources)
            for idx, (kind, value) in enumerate(sources, start=1):
                client._check_cancel()
                if kind == "remote":
                    urls.append(value)
                else:
                    self.after(
                        0,
                        lambda i=idx, n=total:
                            self._update_progress_popup(
                                f"Uploading new photo {i} of {n} before publishing..."
                            )
                    )
                    urls.append(client.upload_image(value))
        elif listing.get("photos"):
            urls = [client.upload_image(p) for p in listing["photos"]]
        else:
            urls = list(self.existing_image_urls)

        listing["image_urls"] = urls

        self._log("PUBLISH PREFLIGHT: updating Inventory Item...")
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Synchronizing inventory item with the current editor..."
            )
        )
        client.create_inventory_item(listing["sku"], listing)

        self._log(
            "PUBLISH PREFLIGHT: updating unpublished Offer "
            f"(listing={type(listing).__name__}, "
            f"original_offer={type(getattr(self, 'original_offer', None)).__name__})..."
        )
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Synchronizing price, quantity, category and business policies..."
            )
        )
        original_offer = getattr(self, "original_offer", None)
        if not isinstance(original_offer, dict):
            self._log(
                "PUBLISH PREFLIGHT: reloading original eBay Offer before update..."
            )
            original_offer = client.get_offer(offer_id)
        client.update_offer(offer_id, listing, original_offer)
        self._log("PUBLISH PREFLIGHT COMPLETE.")

    def _show_live_listing_success(self, listing_id, title="Listing published successfully", listing_data=None):
        listing_id = str(listing_id or "").strip()
        url = f"https://www.ebay.com/itm/{listing_id}" if listing_id else ""
        if listing_data:
            try:
                self._inventory_ensure_published(listing_id, listing_data)
            except Exception as exc:
                self._log(f"Inventory auto-add warning: {exc}")

        win = tk.Toplevel(self)
        win.title(APP_NAME)
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)

        body = ttk.Frame(win, padding=18)
        body.pack(fill="both", expand=True)

        ttk.Label(
            body,
            text=title,
            font=("TkDefaultFont", 11, "bold"),
        ).pack(anchor="w", pady=(0, 10))

        ttk.Label(
            body,
            text=f"eBay Listing ID: {listing_id}",
        ).pack(anchor="w", pady=(0, 12))

        if url:
            ttk.Label(
                body,
                text=url,
                foreground="#1a5fb4",
                cursor="hand2",
            ).pack(anchor="w", pady=(0, 14))

        buttons = ttk.Frame(body)
        buttons.pack(fill="x")

        if url:
            ttk.Button(
                buttons,
                text="OPEN LIVE LISTING",
                command=lambda: webbrowser.open(url),
                style="Accent.TButton",
            ).pack(side="left", padx=(0, 8))
            ttk.Button(
                buttons,
                text="VIEW IN INVENTORY",
                command=lambda: (win.destroy(), self.notebook.select(self.inventory_tab), self.inventory_notebook.select(1), self._inventory_refresh_all()),
            ).pack(side="left", padx=(0, 8))

        ttk.Button(
            buttons,
            text="OK",
            command=win.destroy,
        ).pack(side="right")

        win.update_idletasks()
        x = self.winfo_rootx() + max(30, (self.winfo_width() - win.winfo_width()) // 2)
        y = self.winfo_rooty() + max(30, (self.winfo_height() - win.winfo_height()) // 2)
        win.geometry(f"+{x}+{y}")

    def _publish_to_ebay(self):
        if self.worker and self.worker.is_alive():
            return
        offer_id = str(self.editing_offer_id or "").strip()
        if not offer_id:
            messagebox.showinfo(
                APP_NAME,
                "Nothing is ready to publish yet.\n\n"
                "Create an eBay draft first, or load an existing unpublished offer."
            )
            return
        if self.editing_offer_status.upper() == "PUBLISHED":
            messagebox.showinfo(APP_NAME, "This offer is already published.")
            return

        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        # The old typed PUBLISH gate has been removed.
        # One explicit Yes/No confirmation remains before going live.
        if not messagebox.askyesno(
            APP_NAME,
            "Publish this listing to eBay now?\\n\\n"
            f"Title: {listing['title']}\\n"
            f"Price: ${float(listing['price']):.2f}\\n"
            f"Quantity: {listing['quantity']}\\n"
            f"Offer ID: {offer_id}\\n\\n"
            "This will create a live eBay listing."
        ):
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.publish_btn.config(state="normal")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log(f"Explicit publish requested for Offer ID {offer_id}.")
        self._show_progress_popup(
            "Publishing to eBay",
            "Running pre-publish validation and synchronizing the listing..."
        )

        def work():
            try:
                client = EbayClient(
                    self.settings.copy(), self.cancel_event, self._log
                )

                # Re-read the latest editor state in the UI thread before publish.
                self._prepare_offer_for_publish(client, listing, offer_id)

                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Preflight passed. Publishing the offer to eBay..."
                    )
                )
                listing_id = client.publish_offer(offer_id)
                self.editing_offer_status = "PUBLISHED"
                upsert_offer_history({
                    "offer_id": offer_id,
                    "sku": listing["sku"],
                    "status": "PUBLISHED",
                    "listing_id": listing_id,
                    "title": listing["title"],
                    "price": f"{float(listing['price']):.2f}",
                    "category_id": listing["category_id"],
                })
                self.after(0, self._refresh_offer_history_table)
                self._log(
                    f"SUCCESS: Offer {offer_id} is LIVE. eBay Listing ID: {listing_id}"
                )
                self.after(
                    0,
                    lambda lid=listing_id, data=listing: self._show_live_listing_success(lid, listing_data=data),
                )
                self.after(0, self._clear_after_successful_publish)
            except Exception as exc:
                self._log(f"PUBLISH ERROR: {exc}")
                err_text = str(exc)

                def show_publish_error():
                    if "25021" in err_text or "condition" in err_text.lower() and "category" in err_text.lower():
                        messagebox.showerror(
                            APP_NAME,
                            "eBay will not publish this offer because the selected item "
                            "condition is not allowed in this category.\n\n"
                            "The Condition dropdown has been refreshed from eBay's category "
                            "policy when possible. Choose the condition that accurately "
                            "describes the item, then press PUBLISH TO EBAY again.\n\n"
                            "The offer remains unpublished."
                        )
                    else:
                        messagebox.showerror(APP_NAME, err_text)

                self.after(0, show_publish_error)
                self.after(
                    0,
                    lambda: self.publish_btn.config(
                        state="normal"
                        if self.editing_offer_status.upper() != "PUBLISHED"
                        else "disabled"
                    ),
                )
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_settings_ui_silent(self):
        for key, var in self.setting_vars.items():
            self.settings[key] = var.get().strip()
        self.settings["api_environment"] = self.env_var.get()
        save_settings(self.settings)


if __name__ == "__main__":
    app = ListingTool()
    app.mainloop()
