﻿$ErrorActionPreference = "Stop"
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Trade Components eBay Listing Tool.lnk"
$script = Join-Path $appDir "ebay_listing_tool.py"
$icon = Join-Path $appDir "TradeComponents_icon.ico"

function Find-WindowedPython {
    foreach ($name in @("pyw.exe", "pythonw.exe", "python3w.exe")) {
        try {
            $cmd = Get-Command $name -ErrorAction Stop
            if ($cmd.Source) { return $cmd.Source }
        } catch {}
    }
    return $null
}

$pythonw = Find-WindowedPython
if (-not $pythonw) {
    throw "Could not find pyw.exe or pythonw.exe. Python 3 must be installed/enabled."
}

$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($shortcutPath)
$s.TargetPath = $pythonw
$s.Arguments = "`"$script`""
$s.WorkingDirectory = $appDir
$s.IconLocation = "$icon,0"
$s.Description = "Trade Components eBay Listing Tool"
$s.WindowStyle = 1
$s.Save()

Write-Host ""
Write-Host "Desktop shortcut created:"
Write-Host $shortcutPath
Write-Host ""
Write-Host "The shortcut launches with windowed Python so the Trade Components icon can be used on the taskbar."
