@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_DESKTOP_SHORTCUT.ps1"
if errorlevel 1 (
  echo.
  echo Could not create the desktop shortcut.
  pause
  exit /b 1
)
echo.
echo Done. You can now launch the tool from the desktop icon.
pause
