Option Explicit
Dim fso, shell, folder, scriptPath, cmd, pythonExe
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = folder & "\ebay_listing_tool.py"

pythonExe = FindPythonWindowed(shell)

If pythonExe = "" Then
    MsgBox "Python could not be found. Install/enable Python 3, then try again.", 16, "Trade Components eBay Listing Tool"
    WScript.Quit 1
End If

cmd = Chr(34) & pythonExe & Chr(34) & " " & Chr(34) & scriptPath & Chr(34)
shell.Run cmd, 0, False

Function FindPythonWindowed(sh)
    Dim candidates, i, result, execObj, line
    candidates = Array("pyw.exe", "pythonw.exe", "python3w.exe")

    For i = 0 To UBound(candidates)
        Set execObj = sh.Exec("cmd /c where " & candidates(i) & " 2>nul")
        result = Trim(execObj.StdOut.ReadAll)
        If result <> "" Then
            line = Split(result, vbCrLf)(0)
            FindPythonWindowed = Trim(line)
            Exit Function
        End If
    Next

    FindPythonWindowed = ""
End Function
