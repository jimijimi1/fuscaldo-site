@echo off
setlocal
title Install Trade Components Image Support

echo.
echo Trade Components eBay Listing Tool - Image Support Installer
echo =============================================================
echo.
echo This installs only:
echo   - Pillow
echo   - pillow-heif
echo.
echo No AI model or separate application is being installed.
echo.

set "PYTHON_CMD="

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=py"
    goto :found
)

where python >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=python"
    goto :found
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=python3"
    goto :found
)

echo Python could not be found from Command Prompt.
echo.
echo If the listing tool already runs when you double-click it, Python may be
echo installed but not exposed to command-line programs.
echo.
echo Recommended fix:
echo   1. Install the official Python 3 release from python.org
echo   2. During setup, CHECK "Add python.exe to PATH"
echo   3. Re-run this installer
echo.
echo If this is a managed work computer, ask IT to install Python 3 from
echo python.org and enable the Python Launcher / PATH entry.
echo.
pause
exit /b 1

:found
echo Found Python command: %PYTHON_CMD%
echo.

%PYTHON_CMD% -m pip --version >nul 2>nul
if not %errorlevel%==0 (
    echo pip was not found. Attempting to enable it with ensurepip...
    %PYTHON_CMD% -m ensurepip --upgrade
)

echo.
echo Installing image support...
%PYTHON_CMD% -m pip install --upgrade Pillow pillow-heif

if errorlevel 1 (
    echo.
    echo Installation failed.
    echo.
    echo If your company blocks Python package downloads, the computer may need
    echo IT approval for pip access. The rest of the listing tool can still run,
    echo but the V4.04+ thumbnail/photo-management features need Pillow.
    echo.
    pause
    exit /b 1
)

echo.
echo Image support installed successfully.
echo You can now run START_TOOL.bat.
echo.
pause
endlocal
