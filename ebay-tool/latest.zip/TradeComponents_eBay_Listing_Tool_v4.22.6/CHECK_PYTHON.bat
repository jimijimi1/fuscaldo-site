@echo off
setlocal
title Trade Components Python Diagnostic
echo Python command diagnostic
echo =========================
echo.

echo Checking py:
where py
py --version
echo.

echo Checking python:
where python
python --version
echo.

echo Checking python3:
where python3
python3 --version
echo.

echo Checking pip through Python launcher:
py -m pip --version
echo.

echo Press any key to close.
pause >nul
endlocal
