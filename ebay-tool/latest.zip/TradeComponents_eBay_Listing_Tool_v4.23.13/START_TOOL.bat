@echo off
setlocal
title Trade Components eBay Listing Tool V4.23.13

set "PYTHON_CMD="

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=py"
    goto :run
)

where python >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=python"
    goto :run
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=python3"
    goto :run
)

echo.
echo Python could not be found from Command Prompt.
echo.
echo Install Python 3 from python.org and check "Add python.exe to PATH",
echo or ask IT to install/enable Python on this computer.
echo.
pause
exit /b 1

:run
%PYTHON_CMD% "%~dp0ebay_listing_tool.py"

if errorlevel 1 (
    echo.
    echo The listing tool exited with an error.
    echo.
    echo If the message mentions Pillow, run INSTALL_IMAGE_SUPPORT.bat once.
    echo.
    pause
)
endlocal
