Trade Components eBay Listing Tool V4.22.0

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.


V4.22.0 OPERATIONS INTEGRATION
------------------------------
- New Dashboard for daily work counts and one-click Sync + Scan.
- New Listings area with sortable/searchable current eBay Active Listings.
- Existing Inventory API offer editor moved under Listings > Edit Existing / Offers.
- New Revamp Queue with configurable listing-age threshold and specific reasons.
- MARK REVIEWED resets age-based revamp reminders without changing the eBay listing.
- New Needs Attention center with OPEN / IGNORED / RESOLVED issue lifecycle.
- Attention scan checks listings, inventory, quantities, locations, shipping age,
  duplicate item numbers, old listings, photo counts, and SKU gaps.
- Normal 15-minute eBay sync now refreshes Listings, Revamp Queue, Attention, and Dashboard.
