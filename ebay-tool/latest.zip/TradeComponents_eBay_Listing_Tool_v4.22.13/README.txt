Trade Components eBay Listing Tool V4.22.13

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.


V4.22.13 OPERATIONS INTEGRATION
------------------------------
- New Dashboard for daily work counts and one-click Sync + Scan.
- New Listings area with sortable/searchable current eBay Active Listings.
- Existing Inventory API offer editor moved under Listings > Edit Existing / Offers.
- New Revamp Queue with configurable listing-age threshold and specific reasons.
- MARK REVIEWED resets age-based revamp reminders without changing the eBay listing.
- New Needs Attention center with OPEN / IGNORED / RESOLVED issue lifecycle.
- Attention scan checks listings, inventory, quantities, locations, shipping age,
  duplicate item numbers, old listings, photo counts, and SKU gaps.
- Normal 15-minute eBay sync now refreshes Listings, Revamp Queue, Attention, and Dashboard.


V4.22.13 SALES + ATTENTION AUTOMATION
------------------------------------
- Sales tab with monthly sales, order count, unit count, month-over-month and year-over-year comparisons.
- 6/12/24 month charts and historical eBay order refresh.
- Right-click issue menus: Open/Fix, Open eBay, Ignore, Always Ignore Type, Resolve, Restore.
- Persistent issue suppression rules with a Rules manager.
- Auto Fix Safe button runs deterministic/reversible synchronization only.
- Sales orders are cached locally and refreshed during normal eBay synchronization.

V4.22.13 REMEMBERED INVENTORY MATCHING
------------------------------------
Active listings with a missing/no-location inventory match are compared against
remembered inventory rows using title similarity, token overlap, quantity, and
SKU/custom-label hints. High-confidence unique matches are shown as a reviewable
"Possible remembered inventory match" rather than a generic no-location error.
OPEN / FIX lets the user confirm the match, preserving the location/stock and
updating the eBay item number. Old item numbers are retained in COMMENT.

V4.22.13 ISSUE NAVIGATION + END LISTINGS
---------------------------------------
- Needs Attention OPEN / FIX now jumps to the exact local inventory row and automatically
  switches to MASTER LIST, PENDING LOCATION, PENDING SHIPPING, or SOLD as appropriate.
- Previous Inventory search text is cleared so the target row cannot remain hidden.
- Listings and Revamp Queue now support END LISTING with confirmation.
- Active Listings and Revamp Queue have right-click menus with Open on eBay, Jump to
  Inventory Item, and End eBay Listing.
- Needs Attention right-click also gains Jump to Inventory Item and End eBay Listing
  when the issue points to a currently active listing.
- Ending a listing keeps local inventory intact; a local LISTED row becomes MASTER
  (or PENDING LOCATION if it has no location). It is never marked SOLD automatically.

V4.22.13 WORKFLOW / SALES REPORT UPDATE
-------------------------------------
- Fixed 24-month sales refresh failure by respecting eBay Fulfillment API's strict
  two-year creation-date limit.
- Added sell.finances OAuth scope for detailed gross/net/fees monthly reporting.
- Sales can generate a polished printable monthly HTML report with gross sales,
  net eBay proceeds, selling fees, shipping-label costs, refunds, credits, orders,
  units, and a fee breakdown.
- Top tabs are now Dashboard / Listing Editor / Listings / Inventory / Sales /
  Needs Attention / Settings. Revamp Queue lives under Listings.
- Revamp observations and Pending Location items no longer clutter Needs Attention.
- Attention table keeps the user's sort after resolving/ignoring items.
- "Always Ignore This Issue Type" reports how many current issues it ignored.
- False "0 photos" warnings are suppressed when eBay did not actually return photo data.
- Listing button says CREATE DRAFT before an offer exists and SAVE DRAFT afterward.
- Added right-click quick-action menus to Inventory, Sales, and Existing Offers;
  Listings, Revamp and Needs Attention already have context menus.

V4.22.13 LOADING FEEDBACK + REPORT DATE FIX
------------------------------------------
- Fixed Monthly Sales Report YYYY-MM validation; valid inputs such as 2026-08 now work.
- Added a reusable modal loading/progress box for long-running operations.
- Sales refresh, monthly report generation, active-listing refresh, Needs Attention
  Sync + Scan, ending a listing, and safe auto-fix work now show visible progress
  instead of appearing stalled.
- Long cancellable operations expose STOP / CANCEL in the loading box.

V4.22.13 STARTUP SYNC + LOADING WINDOW RELIABILITY
-------------------------------------------------
- Fixed long-running loading boxes that could remain on screen after completion.
- Every patched worker now closes its loading window from a finally block, so success,
  errors, and cancellations all clean up the modal reliably.
- STOP / CANCEL immediately releases the loading window while signalling the worker
  to stop; a cancelled operation no longer leaves the UI trapped.
- Starting a new long operation clears stale cancellation state from an earlier cancel.
- Added automatic eBay reconciliation shortly after startup whenever an OAuth access
  token or refresh token is configured.
- Startup sync updates active listings, recent orders, inventory, sales, Needs Attention,
  and dashboard data; normal background reconciliation continues every 15 minutes.
- Startup sync is skipped quietly when eBay OAuth has not been configured.
- Sales history refresh now also uses the standard visible loading box.

V4.22.13 FINANCES API FIX
------------------------
- Fixed Monthly Sales Report 404 errors caused by sending Finances API calls to
  api.ebay.com. eBay's Finances API uses the dedicated apiz.ebay.com gateway
  (apiz.sandbox.ebay.com in Sandbox).
- Detailed monthly gross/net/fee reports now call the correct transaction endpoint.
- Added a clearer diagnostic if eBay still returns a 404.

V4.22.13 SELLER HUB-STYLE MONTHLY REPORTING
------------------------------------------
- Reworked the monthly printable report to follow Seller Hub Performance reporting
  instead of using raw Finances transaction-date cash movement as the headline basis.
- Uses the 2026 Finances order_earnings_summary resource for gross seller amount,
  selling expenses, buyer refunds, and net order earnings.
- Requests Fulfillment TAX_BREAKDOWN data to calculate taxes/fees collected by eBay.
- Headline report now mirrors Seller Hub terminology:
  Total Sales (includes taxes) / Taxes & Fees Collected by eBay /
  Selling Costs (includes shipping) / Net Sales / Quantity Sold / Average Sales Price.
- Raw Finances transaction fee categories remain only as supplemental detail because
  individual charges/credits can post in a different month than Seller Hub Performance.

V4.22.13 AI BATCH REVIEW FIX
---------------------------
- Fixed Batch Photo Review windows that could appear blank after AI Group.
- The review window now paints the group list immediately, then renders thumbnails
  progressively instead of decoding an entire large group on the Tk UI thread.
- Large AI-created groups remain responsive and display loading progress while previews render.
- AI Group now uses the standard visible/cancellable loading box and always closes it.
- Added validation so a completed AI request cannot silently open an empty review window.
- Group metadata is aligned defensively with the actual path groups.
- Suspiciously large AI groups are logged for manual review rather than freezing the UI.

V4.22.13 AI SORT + BATCH WORKFLOW
---------------------------------
- Removed the hard AI Sort photo-count limit. AI Sort can now process all selected
  photos rather than stopping at 125.
- Large sorts may cost more and take longer, so the existing AI cost/progress feedback
  remains important.
- Batch Review now remembers which groups have already been used.
- Used groups are labeled with a check mark in the group list.
- After using a group, Batch Review stays open and automatically advances to the next
  unused group instead of making the remaining groups feel like they disappeared.

V4.22.13 ANALYZE WORKFLOW
-------------------------
- Removed the extra approval/confirmation step from Analyze Selected.
- Analyze now begins immediately when invoked and applies the returned item analysis
  directly to the listing fields, while retaining normal progress/cancel feedback.
- Publish confirmation remains unchanged.

V4.22.13 AI SORT LIMIT + POST-PUBLISH RESET
-------------------------------------------
- Removed the actual remaining 125-photo guard inside AI Sort + Pick Best.
- AI Sort can now process all photos supplied to it; large runs may take longer/cost more.
- Listing Editor automatically resets after a listing is successfully published live.
- Creating or saving an unpublished draft does NOT clear the Listing Editor.
- Both PUBLISH and CREATE + PUBLISH success paths trigger the post-publish reset.

V4.22.13 PENDING SHIPPING WORKFLOW
----------------------------------
- Dashboard Pending Shipping now opens Inventory directly on PENDING SHIPPING.
- Dashboard Pending Location and Sold cards also jump directly to their matching tabs.
- Added SHIP BY column to Pending Shipping.
- Order reconciliation stores and refreshes eBay's available ship/handle-by deadline
  whenever that deadline is present in the Fulfillment order payload.
