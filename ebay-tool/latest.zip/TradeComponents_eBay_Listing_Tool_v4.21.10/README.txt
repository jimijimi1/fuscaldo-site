Trade Components eBay Listing Tool V4.21.10

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.
