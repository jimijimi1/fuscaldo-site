V4.23.31
- Orders can now be marked Pulled / Not Pulled without changing inventory quantities or statuses.
- Pulled state is stored locally and survives refreshes/restarts.
- Orders table includes a sortable PULLED column, detail status, toolbar toggle, and right-click toggle.


V4.23.30 EMERGENCY HOTKEY + EBAY-STYLE MESSAGE COMPOSER
- Emergency test hotkey detection now handles Windows/Tk modifier-state differences directly.
- Ctrl+Alt+Shift+F12 three times within 5 seconds remains the primary sequence.
- Ctrl+Alt+Shift+E three times is a fallback for keyboards/firmware that reserve F12.
- Both routes still require the locally configured emergency password and V4.23.30 remains TEST MODE ONLY.
- Messages now use an inline reply composer directly below the conversation, similar to eBay.
- Reply length now matches the current eBay Trading API MemberMessage.Body limit of 2,000 characters.
- Live character counter and Ctrl+Enter send are included.
- Failed sends preserve the complete draft in the reply box; drafts are also remembered per conversation during the session.
- The composer clears only after eBay confirms the send succeeded.

Trade Components eBay Listing Tool V4.23.30

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.


V4.23.30 OPERATIONS INTEGRATION
------------------------------
- New Dashboard for daily work counts and one-click Sync + Scan.
- New Listings area with sortable/searchable current eBay Active Listings.
- Existing Inventory API offer editor moved under Listings > Edit Existing / Offers.
- New Revamp Queue with configurable listing-age threshold and specific reasons.
- MARK REVIEWED resets age-based revamp reminders without changing the eBay listing.
- New Needs Attention center with OPEN / IGNORED / RESOLVED issue lifecycle.
- Attention scan checks listings, inventory, quantities, locations, shipping age,
  duplicate item numbers, old listings, photo counts, and SKU gaps.
- Normal 15-minute eBay sync now refreshes Listings, Revamp Queue, Attention, and Dashboard.


V4.23.30 SALES + ATTENTION AUTOMATION
------------------------------------
- Sales tab with monthly sales, order count, unit count, month-over-month and year-over-year comparisons.
- 6/12/24 month charts and historical eBay order refresh.
- Right-click issue menus: Open/Fix, Open eBay, Ignore, Always Ignore Type, Resolve, Restore.
- Persistent issue suppression rules with a Rules manager.
- Auto Fix Safe button runs deterministic/reversible synchronization only.
- Sales orders are cached locally and refreshed during normal eBay synchronization.

V4.23.30 REMEMBERED INVENTORY MATCHING
------------------------------------
Active listings with a missing/no-location inventory match are compared against
remembered inventory rows using title similarity, token overlap, quantity, and
SKU/custom-label hints. High-confidence unique matches are shown as a reviewable
"Possible remembered inventory match" rather than a generic no-location error.
OPEN / FIX lets the user confirm the match, preserving the location/stock and
updating the eBay item number. Old item numbers are retained in COMMENT.

V4.23.30 ISSUE NAVIGATION + END LISTINGS
---------------------------------------
- Needs Attention OPEN / FIX now jumps to the exact local inventory row and automatically
  switches to MASTER LIST, PENDING LOCATION, PENDING SHIPPING, or SOLD as appropriate.
- Previous Inventory search text is cleared so the target row cannot remain hidden.
- Listings and Revamp Queue now support END LISTING with confirmation.
- Active Listings and Revamp Queue have right-click menus with Open on eBay, Jump to
  Inventory Item, and End eBay Listing.
- Needs Attention right-click also gains Jump to Inventory Item and End eBay Listing
  when the issue points to a currently active listing.
- Ending a listing keeps local inventory intact; a local LISTED row becomes MASTER
  (or PENDING LOCATION if it has no location). It is never marked SOLD automatically.

V4.23.30 WORKFLOW / SALES REPORT UPDATE
-------------------------------------
- Fixed 24-month sales refresh failure by respecting eBay Fulfillment API's strict
  two-year creation-date limit.
- Added sell.finances OAuth scope for detailed gross/net/fees monthly reporting.
- Sales can generate a polished printable monthly HTML report with gross sales,
  net eBay proceeds, selling fees, shipping-label costs, refunds, credits, orders,
  units, and a fee breakdown.
- Top tabs are now Dashboard / Listing Editor / Listings / Inventory / Sales /
  Needs Attention / Settings. Revamp Queue lives under Listings.
- Revamp observations and Pending Location items no longer clutter Needs Attention.
- Attention table keeps the user's sort after resolving/ignoring items.
- "Always Ignore This Issue Type" reports how many current issues it ignored.
- False "0 photos" warnings are suppressed when eBay did not actually return photo data.
- Listing button says CREATE DRAFT before an offer exists and SAVE DRAFT afterward.
- Added right-click quick-action menus to Inventory, Sales, and Existing Offers;
  Listings, Revamp and Needs Attention already have context menus.

V4.23.30 LOADING FEEDBACK + REPORT DATE FIX
------------------------------------------
- Fixed Monthly Sales Report YYYY-MM validation; valid inputs such as 2026-08 now work.
- Added a reusable modal loading/progress box for long-running operations.
- Sales refresh, monthly report generation, active-listing refresh, Needs Attention
  Sync + Scan, ending a listing, and safe auto-fix work now show visible progress
  instead of appearing stalled.
- Long cancellable operations expose STOP / CANCEL in the loading box.

V4.23.30 STARTUP SYNC + LOADING WINDOW RELIABILITY
-------------------------------------------------
- Fixed long-running loading boxes that could remain on screen after completion.
- Every patched worker now closes its loading window from a finally block, so success,
  errors, and cancellations all clean up the modal reliably.
- STOP / CANCEL immediately releases the loading window while signalling the worker
  to stop; a cancelled operation no longer leaves the UI trapped.
- Starting a new long operation clears stale cancellation state from an earlier cancel.
- Added automatic eBay reconciliation shortly after startup whenever an OAuth access
  token or refresh token is configured.
- Startup sync updates active listings, recent orders, inventory, sales, Needs Attention,
  and dashboard data; normal background reconciliation continues every 15 minutes.
- Startup sync is skipped quietly when eBay OAuth has not been configured.
- Sales history refresh now also uses the standard visible loading box.

V4.23.30 FINANCES API FIX
------------------------
- Fixed Monthly Sales Report 404 errors caused by sending Finances API calls to
  api.ebay.com. eBay's Finances API uses the dedicated apiz.ebay.com gateway
  (apiz.sandbox.ebay.com in Sandbox).
- Detailed monthly gross/net/fee reports now call the correct transaction endpoint.
- Added a clearer diagnostic if eBay still returns a 404.

V4.23.30 SELLER HUB-STYLE MONTHLY REPORTING
------------------------------------------
- Reworked the monthly printable report to follow Seller Hub Performance reporting
  instead of using raw Finances transaction-date cash movement as the headline basis.
- Uses the 2026 Finances order_earnings_summary resource for gross seller amount,
  selling expenses, buyer refunds, and net order earnings.
- Requests Fulfillment TAX_BREAKDOWN data to calculate taxes/fees collected by eBay.
- Headline report now mirrors Seller Hub terminology:
  Total Sales (includes taxes) / Taxes & Fees Collected by eBay /
  Selling Costs (includes shipping) / Net Sales / Quantity Sold / Average Sales Price.
- Raw Finances transaction fee categories remain only as supplemental detail because
  individual charges/credits can post in a different month than Seller Hub Performance.

V4.23.30 AI BATCH REVIEW FIX
---------------------------
- Fixed Batch Photo Review windows that could appear blank after AI Group.
- The review window now paints the group list immediately, then renders thumbnails
  progressively instead of decoding an entire large group on the Tk UI thread.
- Large AI-created groups remain responsive and display loading progress while previews render.
- AI Group now uses the standard visible/cancellable loading box and always closes it.
- Added validation so a completed AI request cannot silently open an empty review window.
- Group metadata is aligned defensively with the actual path groups.
- Suspiciously large AI groups are logged for manual review rather than freezing the UI.

V4.23.30 AI SORT + BATCH WORKFLOW
---------------------------------
- Removed the hard AI Sort photo-count limit. AI Sort can now process all selected
  photos rather than stopping at 125.
- Large sorts may cost more and take longer, so the existing AI cost/progress feedback
  remains important.
- Batch Review now remembers which groups have already been used.
- Used groups are labeled with a check mark in the group list.
- After using a group, Batch Review stays open and automatically advances to the next
  unused group instead of making the remaining groups feel like they disappeared.

V4.23.30 ANALYZE WORKFLOW
-------------------------
- Removed the extra approval/confirmation step from Analyze Selected.
- Analyze now begins immediately when invoked and applies the returned item analysis
  directly to the listing fields, while retaining normal progress/cancel feedback.
- Publish confirmation remains unchanged.

V4.23.30 AI SORT LIMIT + POST-PUBLISH RESET
-------------------------------------------
- Removed the actual remaining 125-photo guard inside AI Sort + Pick Best.
- AI Sort can now process all photos supplied to it; large runs may take longer/cost more.
- Listing Editor automatically resets after a listing is successfully published live.
- Creating or saving an unpublished draft does NOT clear the Listing Editor.
- Both PUBLISH and CREATE + PUBLISH success paths trigger the post-publish reset.

V4.23.30 PENDING SHIPPING WORKFLOW
----------------------------------
- Dashboard Pending Shipping now opens Inventory directly on PENDING SHIPPING.
- Dashboard Pending Location and Sold cards also jump directly to their matching tabs.
- Added SHIP BY column to Pending Shipping.
- Order reconciliation stores and refreshes eBay's available ship/handle-by deadline
  whenever that deadline is present in the Fulfillment order payload.

V4.23.30 MESSAGES + QUEUE CLEANUP
--------------------------------
- Added top-level eBay Messages inbox: refresh, search, unread/read/replied state,
  preview, reply, open eBay item, jump to inventory, mark read/unread, right-click actions.
- Uses GetMyMessages and AddMemberMessageAAQToPartner through Trading API.
- Inventory double-click now validates row/cell region so rapid header sorting won't open a selected item.
- Pending Shipping now defaults to earliest SHIP BY first, then item name.
- Any user-selected sort is reapplied after inventory refresh.
- Inventory/order startup reconciliation looks back 180 days to better clear stale pending-shipping records.
- Messages quietly refresh after startup when OAuth is available.

V4.23.30 STARTUP FIX
-------------------
- Fixed the V4.23.0 startup crash caused by the new Messages notebook page being
  referenced before its ttk.Frame had been created.
- No feature changes; this is a launch-repair release for V4.23.0.

V4.23.30 MESSAGES + END-LISTING ISSUE CLEANUP
--------------------------------------------
- Fixed GetMyMessages error 20106. The app now retrieves recent message headers by
  date first, then requests full message bodies by explicit MessageIDs in batches of 10.
- Ending an eBay listing now automatically resolves Needs Attention issues tied to
  that eBay Item Number.
- Needs Attention refreshes immediately after a listing is successfully ended.

V4.23.30 CODEBASE CLEANUP
------------------------
- Split the 13k-line monolithic Python file into a GUI/controller module and a
  reusable core module.
- Core module now owns shared utilities, photo manager, batch review, AI grouping/
  analysis, and EbayClient.
- Main ebay_listing_tool.py now focuses on ListingTool application workflows/UI.
- End-listing API code now reuses the common Trading API request/auth/error handler
  instead of maintaining a second duplicate implementation.
- Added CODE_STRUCTURE.txt for future maintenance.
- This is a conservative refactor: settings, inventory DB, updater, and user-facing
  workflows are intentionally unchanged.

V4.23.30 UPDATER COMPATIBILITY FIX
---------------------------------
- Fixed Vunknown verification caused by the V4.23.3 module split.
- ebay_listing_tool.py now keeps a literal APP_VERSION for compatibility with
  older installed updaters.
- The updated verifier can read APP_VERSION from either ebay_listing_tool.py or
  trade_components_core.py.
- No inventory/settings/user-data changes.

V4.23.30 MESSAGE DISPLAY + REPORT AUTHORIZATION
----------------------------------------------
- eBay message bodies are now displayed as readable plain text instead of raw
  HTML/CSS email templates.
- Message retrieval prefers eBay's plain-text Content field and sanitizes Text
  when eBay returns an HTML-formatted body.
- The OAuth request now includes sell.finances in addition to
  sell.finances and sell.fulfillment for the newer Order Earnings report resource.
- Report permission errors now explain the exact one-time reauthorization steps.

V4.23.30 OAUTH SCOPE CORRECTION
------------------------------
- Removed the sell.finances.readonly scope from the OAuth request.
- eBay rejected that scope with invalid_scope.
- The app now requests the five scopes actually needed:
  base api_scope, sell.inventory, sell.account, sell.fulfillment, sell.finances.
- No user data or inventory changes.

V4.23.30 MESSAGE BODY PARSER
---------------------------
- Fixed eBay message templates that still displayed CSS after the previous cleanup.
- HTML entities are decoded before parsing, which handles eBay payloads containing
  escaped <style>/<head> markup.
- Message rendering now uses a stdlib HTML parser that ignores style/script/head/template
  content and keeps only visible text.
- Added malformed-template CSS cleanup and a right-click "Copy Raw Message (Diagnostics)"
  action for future edge cases.

V4.23.30 REPORT FALLBACK + PENDING SHIPPING RECONCILIATION
----------------------------------------------------------
- Monthly report no longer fails outright when eBay returns 403/1100 for the newer
  Finances order_earnings_summary resource.
- Added compatibility reporting using Trading GetOrders (tax-inclusive totals at
  compatibility 1477) plus regular Finances transactions for selling costs.
- Report states which data path was used.
- Added direct Fulfillment order lookup for stale Pending Shipping rows.
- Fulfilled stale rows move to Sold; canceled orders leave Pending Shipping and
  restore sold quantity; orders no longer resolvable by eBay are archived out of
  the shipping queue while preserving the audit row.
- Canceled orders are no longer created as new Pending Shipping rows.

V4.23.30 CONVERSATION MESSAGES + SCROLLING
------------------------------------------
- Messages now groups entries by buyer + item into conversations instead of showing
  each eBay message as an isolated row.
- Selecting a conversation opens a chat-style back-and-forth panel with readable bubbles.
- The parser extracts the newest buyer message and quoted "Your previous message" reply
  from eBay's repeated email-style templates, with duplicate text suppressed.
- Needs Attention columns no longer stretch/shrink to hide overflow. Its bottom
  horizontal scrollbar now moves through the full ISSUE/ITEM/ACTION text.
- Shift+mouse-wheel scrolls horizontally in Needs Attention, Messages, and Inventory.
- Inventory's bottom horizontal scrollbar now remains useful for wide rows as well.

V4.23.30 CHAT TRANSCRIPT + SCROLL FIXES
----------------------------------------
- Message bubbles now show only the newest message section instead of repeating the
  full eBay quoted transcript inside every record.
- "Your previous message" is extracted separately as a seller bubble to preserve a
  clean back-and-forth view.
- Message wheel scrolling is bound to the canvas and every chat bubble/label, and the
  scrollregion is refreshed after rendering so the right-side scrollbar works.
- Needs Attention text columns are wider/fixed and horizontally scrollable so the
  right side of Issue/Item/Suggested Action is no longer inaccessible.

V4.23.30 AI GROUP REVIEW RELIABILITY
-------------------------------------
- Hardened Batch Photo Review against partial-window failures that previously looked
  like OpenAI had returned no groups.
- Group paths are normalized and verified before the review window opens.
- The group list is populated first with a metadata-free fallback if necessary.
- Thumbnail rendering now has a safe wrapper: a rendering exception shows a visible
  warning inside the group instead of leaving the entire review area blank.
- Opening Batch Review is wrapped so constructor errors produce a real error dialog
  while preserving the grouped batch for another attempt.
- Added log line showing exactly how many groups and local photo paths reached review.
- Used groups remain visibly marked and advancing uses the safe renderer.

V4.23.30 AI GROUP REVIEW LAUNCH FIX
-----------------------------------
- Fixed Batch Review constructor failure:
  BatchReviewWindow referenced _on_batch_mousewheel but that handler was missing.
- Added the missing thumbnail-canvas mousewheel handler.
- AI-created groups should now open normally in the review window instead of
  failing after grouping has already completed.

V4.23.30 PERSISTENT BATCH GROUP EDITS
-------------------------------------
- Manual Batch Review changes now save back to the main photo manager immediately.
- Merge Group, Split, Move, New Group, and manual group sorting all persist.
- Closing the Batch Review window saves the current group structure before destroying it.
- Reopening Review Groups now restores the edited/merged group structure instead of the
  original AI grouping.
- The master review-window reference is cleared on close to prevent stale-window state.

V4.23.30 MESSAGE MANAGEMENT + CLEANER THREADS
---------------------------------------------
- Opening a conversation automatically marks unread messages read on eBay.
- Added DELETE button and right-click Delete Conversation via DeleteMyMessages.
- Seller bubbles stop at seller signatures/usernames so buyer transcript history
  no longer gets absorbed into blue "You" bubbles.
- Automated sender "eBay" notices use a dedicated compact formatter that keeps
  actionable order/shipping details while dropping most footer/help/legal noise.
- Automated eBay notices are not treated as replyable buyer conversations.

V4.23.30 FULL MESSAGE TEXT
--------------------------
- eBay message retrieval now prefers the full Text payload over Content because
  Content can be a shortened preview ending in "...".
- Both eBay Text and Content are retained internally for fallback/diagnostics.
- Conversation rendering automatically chooses the fullest available payload before
  extracting buyer/seller bubbles.
- Includes V4.23.14 message deletion, auto-read-on-open, cleaner seller bubbles,
  and compact formatting for automated eBay notices.

V4.23.30 FULL BUYER TEXT + DUPLICATE SELLER CLEANUP
---------------------------------------------------
- Buyer bubbles are now extracted independently from every eBay message-body variant
  (Text / Content / retained HTML body) and the fullest non-truncated message wins.
- This fixes cases where the longest raw payload was a full HTML transcript but its
  visible "New message" line still ended in "...".
- Seller reply extraction now collapses exact repeated paragraph/block copies that
  occasionally appear in eBay's "Your previous message" section.
- Copy Conversation uses the same full buyer-message extraction.

V4.23.30 DEDICATED ORDERS WORKSPACE
-----------------------------------
- Top navigation is now:
  Dashboard > Listing Editor > Inventory > Orders > Listings > Messages >
  Needs Attention > Sales > Settings.
- Pending Shipping was removed from the Inventory sub-tabs and promoted to its own
  full Orders workspace.
- Orders are grouped by eBay Order ID and show Ship By, buyer, item(s), quantity,
  order total, location, payment status, and fulfillment status.
- Selecting an order displays detailed pricing, buyer/ship-to address, line items,
  local inventory/location details, estimated delivery/shipping information, and
  payment details when eBay returns them.
- PURCHASE LABEL opens eBay's order-specific single-label flow:
  https://www.ebay.com/ship/single/{order_id}
  so the browser lands on the package-details / shipping-label workflow instead of
  the Seller Hub order list.
- Dashboard "Orders to Ship" opens the Orders workspace and counts unique orders.
- Pending-shipping inventory jumps now route to the matching row in Orders.

V4.23.30 FULL BUYER CONVERSATIONS
---------------------------------
- Buyer/seller chat text now uses Trading API GetMemberMessages in addition to
  GetMyMessages.
- GetMyMessages remains authoritative for inbox MessageIDs, automated eBay notices,
  read/unread state, and deletion.
- GetMemberMessages supplies the complete plain-text buyer question body and the
  seller response associated with that exchange, avoiding the shortened "..." inbox
  previews returned inside some My Messages templates.
- The app matches exchanges back to My Messages by eBay item, sender, and nearest
  timestamp, then renders buyer question -> seller response in chat order.
- If GetMemberMessages is unavailable for an older/sold conversation, the existing
  My Messages parser remains as a fallback.
- No additional OAuth scope is required; GetMemberMessages is a Trading API call and
  uses the base api_scope already requested by the app.

V4.23.30 PENDING ORDERS STAY IN MASTER INVENTORY
-------------------------------------------------
- A sale no longer removes an exhausted physical inventory row from Master as soon
  as the buyer pays.
- If stock reaches zero while the order is still awaiting shipment, the physical
  parent row remains in Master with status AWAITING SHIPMENT.
- Orders keeps its separate Pending Shipping child/order record at the same time.
- Jump to Inventory from Orders now lands on that physical Master row.
- When eBay reports the order fulfilled/shipped, the exhausted parent becomes
  DEPLETED (leaves Master) and the sold child becomes the history line in SOLD.
- Partial-quantity sales still leave the parent in Master with its remaining stock.
- Existing Pending Shipping records created by older builds are repaired
  automatically so their DEPLETED parents become visible again.
- AWAITING SHIPMENT rows are highlighted light blue in Master.

V4.23.30 PAGINATED LISTING THUMBNAILS
--------------------------------------
- Active Listings now shows the main eBay thumbnail beside every visible listing.
- Listings are paginated instead of rendering the entire catalog at once.
- Default page size is 25 with selectable 25 / 50 / 100 rows per page.
- Only thumbnails on the current page are downloaded/rendered.
- Thumbnail downloads run in background threads with a four-download concurrency cap.
- Resized thumbnails are cached locally under the existing image-cache folder, so
  revisiting pages is much faster and does not repeatedly download the same images.
- Text/listing rows render immediately; thumbnails fill in afterward so image loading
  does not block the main Tkinter UI.
- Changing search or page size resets to Page 1.

V4.23.30 LIVE STATUS IN ALL LOADING BOXES
------------------------------------------
- Every generic loading/progress dialog now has a small live status line beneath
  the progress bar.
- The line automatically mirrors the latest normal application progress/log message,
  so refreshes, syncs, message operations, reports, order work, listing work, and
  other long-running jobs show what step is currently happening.
- The full bottom log/status console remains unchanged and keeps the complete detail.
- Long technical lines are shortened only inside the compact loading-box status line.

V4.23.30 INTERESTED-BUYER OFFERS + LISTING SORT + PHOTO FIX
------------------------------------------------------------
- Active Listings refresh checks eBay Negotiation API eligibility and marks eligible
  listings in a new OFFER column.
- SEND OFFER supports percent discount or exact offer price, quantity, optional
  message, counteroffer toggle, confirmation, and the normal eBay all-eligible-buyers flow.
- EBAY_US offers use eBay's current 4-day supported duration.
- Buyer Offer History stores offer terms, eBay offer ID/status, date, and only the
  masked/immutable buyer reference returned by eBay.
- Added Buyer Offer History sub-tab and per-listing history popup.
- Added global pre-pagination sorting: newest/oldest, price, quantity, title,
  and offer-eligible-first.
- Fixed listing thumbnails by using PictureDetails.GalleryURL when the active-list
  response omits PictureURL. PHOTOS shows 1+ when only gallery-image presence is known.
- Negotiation API uses the sell.inventory OAuth scope already included in this app.

V4.23.30 OFFERS WORKSPACE + WORKFLOW TOOLS
-------------------------------------------
- Listings now has one consolidated Offers tab with three sub-tabs:
  Offer Eligible / Buyer Offer History / Edit Existing & Inventory Offers.
- Added quick stock adjustment directly from Orders.
- Added multi-select Active Listings and bulk END SELECTED; MARK REVIEWED now handles
  one or many selected listings.
- Added useful Listings filters: offer eligible, 180+ days, no SKU, zero stock,
  low stock (1-2), and eBay/local stock mismatch.
- Existing Needs Attention scanning already covers quantity mismatches, zero-stock
  active records, missing inventory, duplicate item numbers, probable remembered
  inventory matches, and stale shipping issues.
- Added human-readable local activity.log for important changes.
- Added automatic once-daily inventory DB backup (keeps about 45 days), manual backup,
  restore-with-safety-copy, and Settings controls.
- Added keyboard shortcuts:
  Ctrl+F focus search on Listings/Inventory/Orders/Messages,
  Ctrl+R refresh the current operational tab,
  Ctrl+B make a manual inventory backup.
- Dashboard alerts, inventory notes, and a one-click next-task workflow remain omitted
  by design per user preference.

V4.23.30 SAFE SORTING + OFFER SEND FIX
---------------------------------------
- Fixed eBay Negotiation API error 150009. Seller-initiated offers now always send
  allowCounterOffer=false because eBay rejects true for this offer type.
- Removed the counteroffer checkbox from Send Offer and replaced it with a short note.
- Fast/double clicking sortable column headers can no longer trigger a row's
  double-click action (open listing, send offer, open/fix, edit inventory, etc.).
- Added a reusable safe double-click guard across Active Listings, Offer Eligible,
  Buyer Offer History, Revamp, Messages, Needs Attention, Orders, Inventory, and
  Inventory-API Offer History.
- Every Treeview/list table present at startup is now automatically given sortable
  column headings, including tables that previously did not explicitly wire sorting.
- Dynamically-created buyer-offer history tables are sortable as well.

V4.23.30 EXACT LISTING SORT ORDER
---------------------------------
- Fixed an interaction where a previous column-heading sort could silently re-sort
  the current page after the global Newest/Oldest sort had already run.
- Choosing Newest/Oldest now clears any stale per-column sort state.
- Clicking a column heading changes the selector to "Column sort" so the UI always
  reflects the sorting mode actually being used.
- Refresh Listings resets to a true global Newest first order.
- Newest/Oldest is deterministic by exact eBay StartTime with item number as a
  tie-breaker.

V4.23.30 UNIVERSAL LIST SORTING
--------------------------------
- Every Treeview/list table uses the same click-heading sorting behavior.
- Inventory, Active Listings, Orders, Offer Eligible, Buyer Offer History, Messages,
  Revamp, Needs Attention, Sales/list tables, and dynamically-created tables are
  all wired through the same sorter.
- Click a heading once to sort; click the same heading again to reverse.
- The active sort column now shows ▲ or ▼ so it is obvious what the table is using.
- Rebuilt/refreshed tables retain and re-show their current sort direction where applicable.
- Added small sort-hint text to Listings and Inventory for discoverability.

V4.23.30 PHOTO WORKFLOW + BACKGROUND EBAY CHECKS
-------------------------------------------------
- Batch Group Review now supports selecting multiple photos:
  plain click selects one, Ctrl-click toggles additional photos, and each Select
  button can add/remove a photo from the multi-selection.
- Move Selected moves the whole selected set and stays on the source group being
  worked on instead of jumping to the destination group.
- Split Selected can create one new group from multiple selected photos.
- USED group markers persist when the group viewer is closed/reopened.
- Large Photo Viewer now supports Ctrl+mouse-wheel zoom, scroll/pan, FIT, arrow keys,
  Previous/Next buttons, and clicking the left/right side to move through photos
  checked Use.
- Added right-click menus directly to the Listing Editor photo gallery/preview with
  View Large, Set Main, Use toggle, move, remove, select/clear, AI Sort, and Review Groups.
- Keyboard shortcuts are now application-wide (bind_all) so focused Entry/Text
  controls do not swallow them. Ctrl+F search, Ctrl+R refresh, Ctrl+B backup.
- Automatic inventory backup was already present; it now re-checks every six hours
  so one backup per calendar day is still created if the program stays open overnight.
- Listing Editor scrolls back to the very top after a successful publish clears it.
- Background eBay checks now run automatically:
  Messages every 5 minutes; Orders/Inventory/Listings every 10 minutes.
- Messages tab shows unread count, e.g. Messages (2).
- Orders tab shows newly-seen order count since the tab was last opened, e.g. Orders (1).

V4.23.30 BULLETPROOF EBAY TOKEN REFRESH
----------------------------------------
- Access-token expiry time is now stored after OAuth setup and after every refresh.
- Every REST and Trading API request proactively refreshes the token about five
  minutes before expiry instead of waiting for a failed eBay call.
- Existing installs with an older refresh token migrate automatically; no new
  authorization should be required just because this build was installed.
- Every new EbayClient instance reloads the newest persisted authentication values,
  preventing stale GUI/runtime copies from reusing an expired token.
- Fixed a major stale-token bug: Save Settings could previously overwrite an access
  token that had been refreshed by a background worker. It now preserves the newer
  persisted token unless the user actually edited the token field.
- Refresh-attempt state is reset per outbound request instead of effectively being
  consumed for an entire long-running client instance.
- Trading API token-expired responses returned inside HTTP 200 XML are detected and
  retried after automatic refresh, not just HTTP 401/403 failures.
- OAuth refresh failures now log eBay's actual response body so a genuinely revoked
  or invalid refresh token can be distinguished from a normal two-hour access-token
  expiration.
- App updates do not intentionally clear or replace OAuth settings.


V4.23.30
- Fixes eBay pre-sale/Ask Seller Question replies: threads enriched with GetMemberMessages now reply through AddMemberMessageRTQ + ParentMessageID instead of incorrectly forcing AddMemberMessageAAQToPartner.
- Adds Emergency Protection TEST MODE. Hidden sequence is Ctrl+Alt+Shift+F12 three times within five seconds, then the locally-configured emergency password.
- Safe test exports one combined Master + Sold Excel workbook to the Windows Desktop, creates an emergency inventory DB backup, and simulates shutdown/credential/purge stages.
- V4.23.30 cannot perform destructive emergency deletion; this is intentional for initial validation.
