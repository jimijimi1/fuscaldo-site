Trade Components eBay Listing Tool V4.22.3

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.


V4.22.3 OPERATIONS INTEGRATION
------------------------------
- New Dashboard for daily work counts and one-click Sync + Scan.
- New Listings area with sortable/searchable current eBay Active Listings.
- Existing Inventory API offer editor moved under Listings > Edit Existing / Offers.
- New Revamp Queue with configurable listing-age threshold and specific reasons.
- MARK REVIEWED resets age-based revamp reminders without changing the eBay listing.
- New Needs Attention center with OPEN / IGNORED / RESOLVED issue lifecycle.
- Attention scan checks listings, inventory, quantities, locations, shipping age,
  duplicate item numbers, old listings, photo counts, and SKU gaps.
- Normal 15-minute eBay sync now refreshes Listings, Revamp Queue, Attention, and Dashboard.


V4.22.3 SALES + ATTENTION AUTOMATION
------------------------------------
- Sales tab with monthly sales, order count, unit count, month-over-month and year-over-year comparisons.
- 6/12/24 month charts and historical eBay order refresh.
- Right-click issue menus: Open/Fix, Open eBay, Ignore, Always Ignore Type, Resolve, Restore.
- Persistent issue suppression rules with a Rules manager.
- Auto Fix Safe button runs deterministic/reversible synchronization only.
- Sales orders are cached locally and refreshed during normal eBay synchronization.

V4.22.3 REMEMBERED INVENTORY MATCHING
------------------------------------
Active listings with a missing/no-location inventory match are compared against
remembered inventory rows using title similarity, token overlap, quantity, and
SKU/custom-label hints. High-confidence unique matches are shown as a reviewable
"Possible remembered inventory match" rather than a generic no-location error.
OPEN / FIX lets the user confirm the match, preserving the location/stock and
updating the eBay item number. Old item numbers are retained in COMMENT.

V4.22.3 ISSUE NAVIGATION + END LISTINGS
---------------------------------------
- Needs Attention OPEN / FIX now jumps to the exact local inventory row and automatically
  switches to MASTER LIST, PENDING LOCATION, PENDING SHIPPING, or SOLD as appropriate.
- Previous Inventory search text is cleared so the target row cannot remain hidden.
- Listings and Revamp Queue now support END LISTING with confirmation.
- Active Listings and Revamp Queue have right-click menus with Open on eBay, Jump to
  Inventory Item, and End eBay Listing.
- Needs Attention right-click also gains Jump to Inventory Item and End eBay Listing
  when the issue points to a currently active listing.
- Ending a listing keeps local inventory intact; a local LISTED row becomes MASTER
  (or PENDING LOCATION if it has no location). It is never marked SOLD automatically.
