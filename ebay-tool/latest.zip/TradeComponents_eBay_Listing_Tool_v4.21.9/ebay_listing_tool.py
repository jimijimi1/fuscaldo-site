#!/usr/bin/env python3
"""
Trade Components eBay Listing Tool
Version 4.21.9

Uses only Python's standard library.
Analyzes item photos, researches current eBay prices, creates eBay Inventory API
offers, and can publish only through an explicit manual confirmation workflow.
"""

import base64
import csv
import sqlite3
import html
import json
import xml.etree.ElementTree as ET
import mimetypes
import os
import re
import shutil
import statistics
import subprocess
import sys
import math
import threading
import tempfile
import time
import uuid
import webbrowser
import zipfile
from pathlib import Path
from urllib import request, error, parse

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP_NAME = "Trade Components eBay Listing Tool V4.21.9"
APP_VERSION = "4.21.9"
UPDATE_MANIFEST_URL = "https://fuscaldo.org/ebay-tool/version.json"
UPDATE_BASE_URL = "https://fuscaldo.org/ebay-tool/"
APP_DIR = Path.home() / ".trade_components_ebay_tool"
CONFIG_FILE = APP_DIR / "settings.json"
OFFER_HISTORY_FILE = APP_DIR / "offer_history.json"
IMAGE_CACHE_DIR = APP_DIR / "ebay_image_cache"
INVENTORY_DB_FILE = APP_DIR / "inventory.db"

# Standard OpenAI API pricing, USD per 1M tokens.
# Updated 2026-09-08. Unknown models fall back to the configured Luna rates
# only for display and are explicitly marked as estimates.
AI_MODEL_PRICING = {
    "gpt-5.6-luna": {"input": 0.20, "cached": 0.02, "output": 1.20},
    "gpt-5.6-terra": {"input": 2.00, "cached": 0.20, "output": 12.00},
    "gpt-5.6-sol": {"input": 4.00, "cached": 0.40, "output": 20.00},
    "gpt-5.6": {"input": 4.00, "cached": 0.40, "output": 20.00},
    "gpt-4.1-mini": {"input": 0.40, "cached": 0.10, "output": 1.60},
    "gpt-4.1": {"input": 2.00, "cached": 0.50, "output": 8.00},
}

def ai_cost_from_usage(model, usage):
    """Return (cost, input, cached, output, exact_known_rate)."""
    usage = usage or {}
    input_tokens = int(usage.get("input_tokens", 0) or 0)
    output_tokens = int(usage.get("output_tokens", 0) or 0)
    details = usage.get("input_tokens_details", {}) or {}
    cached = int(details.get("cached_tokens", 0) or 0)
    uncached = max(0, input_tokens - cached)

    model_key = str(model or "").strip().lower()
    rates = AI_MODEL_PRICING.get(model_key)
    known = rates is not None
    if rates is None:
        rates = AI_MODEL_PRICING["gpt-5.6-luna"]

    cost = (
        (uncached / 1_000_000) * rates["input"]
        + (cached / 1_000_000) * rates["cached"]
        + (output_tokens / 1_000_000) * rates["output"]
    )
    return cost, input_tokens, cached, output_tokens, known

DEFAULT_SETTINGS = {
    "marketplace_id": "EBAY_US",
    "currency": "USD",
    "merchant_location_key": "",
    "payment_policy_id": "",
    "return_policy_id": "",
    "fulfillment_policy_id": "",
    "default_category_id": "",
    "access_token": "",
    "api_environment": "production",
    "openai_api_key": "",
    "openai_model": "gpt-5.6-luna",
    "ebay_client_id": "",
    "ebay_client_secret": "",
    "ai_grouping_spend_cap": "1.00",
    "ebay_refresh_token": "",
    "ebay_runame": ""
}

CONDITION_MAP = {
    "New": "NEW",
    "New - Open Box": "NEW_OTHER",
    "Used / Pre-owned": "USED_EXCELLENT",
    "Very Good": "USED_VERY_GOOD",
    "Good": "USED_GOOD",
    "Acceptable": "USED_ACCEPTABLE",
    "For Parts / Not Working": "FOR_PARTS_OR_NOT_WORKING",
}

CONDITION_ID_BY_ENUM = {
    "NEW": "1000",
    "NEW_OTHER": "1500",
    "USED_EXCELLENT": "3000",
    "USED_VERY_GOOD": "4000",
    "USED_GOOD": "5000",
    "USED_ACCEPTABLE": "6000",
    "FOR_PARTS_OR_NOT_WORKING": "7000",
}

PACKAGE_TYPE_MAP = {
    "Standard package / thick envelope": "PACKAGE_THICK_ENVELOPE",
    "Mailing box": "MAILING_BOX",
    "Parcel or padded envelope": "PARCEL_OR_PADDED_ENVELOPE",
    "Padded bag": "PADDED_BAGS",
    "Large envelope": "LARGE_ENVELOPE",
    "Letter": "LETTER",
    "USPS Flat Rate Envelope": "USPS_FLAT_RATE_ENVELOPE",
    "USPS Large Package": "USPS_LARGE_PACK",
    "Very Large Package": "VERY_LARGE_PACK",
    "Extra Large Package": "EXTRA_LARGE_PACK",
    "Bulky goods": "BULKY_GOODS",
    "One-way pallet": "ONE_WAY_PALLET",
    "Euro pallet": "EUROPALLET",
}

BOILERPLATE = """Please review all photos carefully. If you know any more information about this item, please feel free to send us a message. Here at Trade Recycling we like to build good business relationships with our customers, so if you have any problems with your purchase please contact us first before leaving negative feedback. We will make sure we do our best to do right by our customer.

We are happy to work with any shipping provider that you wish, just send us a message and we will work out the details. We do not cover shipping costs.

Thank you.

Other Information:
Some stickers may be removed from the items before we ship them. All payments must be received within 7 Days of auctions end. WE ONLY ACCEPT PAYMENTS THROUGH EBAY (unless paying in cash for local pick-up). We only charge actual shipping costs and do not charge for handling. If you have any questions, feel free to send us a message and we'll get back to you as soon as we can!"""


def ensure_app_dir():
    APP_DIR.mkdir(parents=True, exist_ok=True)


def ensure_inventory_db():
    """Create the local inventory database, seeding it from the imported Master File on first run."""
    ensure_app_dir()
    if not INVENTORY_DB_FILE.exists():
        seed = Path(__file__).resolve().parent / "inventory_seed.db"
        if seed.exists():
            shutil.copy2(seed, INVENTORY_DB_FILE)
        else:
            con = sqlite3.connect(INVENTORY_DB_FILE)
            con.executescript("""
                CREATE TABLE IF NOT EXISTS inventory_items(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    qty REAL, stock REAL, item TEXT NOT NULL, location TEXT,
                    comment TEXT, condition TEXT, item_number TEXT,
                    status TEXT NOT NULL DEFAULT 'MASTER', date_sold TEXT,
                    ebay_order_id TEXT, source_sheet TEXT, source_row INTEGER,
                    color TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS location_colors(
                    location TEXT PRIMARY KEY, color TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_inventory_status ON inventory_items(status);
                CREATE INDEX IF NOT EXISTS idx_inventory_item_number ON inventory_items(item_number);
                CREATE INDEX IF NOT EXISTS idx_inventory_location ON inventory_items(location);
            """)
            con.commit()
            con.close()
    # Lightweight schema migrations for inventory features added after the
    # original seed database was created.
    con = sqlite3.connect(INVENTORY_DB_FILE)
    try:
        cols = {r[1] for r in con.execute("PRAGMA table_info(inventory_items)").fetchall()}
        migrations = {
            "parent_item_id": "ALTER TABLE inventory_items ADD COLUMN parent_item_id INTEGER",
            "ebay_order_line_id": "ALTER TABLE inventory_items ADD COLUMN ebay_order_line_id TEXT",
            "sale_quantity": "ALTER TABLE inventory_items ADD COLUMN sale_quantity REAL",
        }
        for name, sql in migrations.items():
            if name not in cols:
                con.execute(sql)
        con.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_order_line "
            "ON inventory_items(ebay_order_line_id) WHERE ebay_order_line_id IS NOT NULL"
        )
        con.commit()
    finally:
        con.close()
    return INVENTORY_DB_FILE


def load_settings():
    ensure_app_dir()
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            merged = DEFAULT_SETTINGS.copy()
            merged.update(data)
            return merged
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()


def save_settings(data):
    ensure_app_dir()
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_offer_history():
    ensure_app_dir()
    if OFFER_HISTORY_FILE.exists():
        try:
            data = json.loads(OFFER_HISTORY_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []
    return []


def save_offer_history(rows):
    ensure_app_dir()
    OFFER_HISTORY_FILE.write_text(json.dumps(rows, indent=2), encoding="utf-8")


def upsert_offer_history(entry):
    rows = load_offer_history()
    offer_id = str(entry.get("offer_id", "") or "")
    sku = str(entry.get("sku", "") or "")
    replaced = False
    for i, row in enumerate(rows):
        if offer_id and str(row.get("offer_id", "")) == offer_id:
            merged = dict(row)
            merged.update(entry)
            rows[i] = merged
            replaced = True
            break
    if not replaced:
        rows.insert(0, dict(entry))
    # Keep a practical local history size.
    save_offer_history(rows[:500])


def sanitize_sku(text):
    text = re.sub(r"[^A-Za-z0-9._-]+", "-", text.strip())
    text = re.sub(r"-+", "-", text).strip("-")
    return text[:50] or f"ITEM-{int(time.time())}"


def parse_specifics(text):
    aspects = {}
    for raw in text.splitlines():
        raw = raw.strip()
        if not raw or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        key, value = key.strip(), value.strip()
        if key and value:
            aspects[key] = [value]
    return aspects


def format_specifics(aspects):
    """Convert eBay aspects dict back to the editor's Name=Value text format."""
    lines = []
    for key, values in (aspects or {}).items():
        if not key:
            continue
        if isinstance(values, list):
            value = ", ".join(str(v).strip() for v in values if str(v).strip())
        else:
            value = str(values).strip()
        if value:
            lines.append(f"{key}={value}")
    return "\n".join(lines)


def encode_multipart(field_name, filename, data, content_type):
    boundary = "----TradeComponents" + uuid.uuid4().hex
    crlf = b"\r\n"
    body = bytearray()
    body.extend(("--" + boundary).encode() + crlf)
    body.extend(
        f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"'.encode()
        + crlf
    )
    body.extend(f"Content-Type: {content_type}".encode() + crlf + crlf)
    body.extend(data)
    body.extend(crlf + ("--" + boundary + "--").encode() + crlf)
    return bytes(body), f"multipart/form-data; boundary={boundary}"


# ============================================================================
# Integrated local photo manager (V4.21.0)
# No AI/network calls are made by this section.
# ============================================================================

try:
    from PIL import Image, ImageTk, ImageOps, ImageStat, ImageFilter
    PHOTO_MANAGER_IMPORT_ERROR = ""
except ImportError as exc:
    Image = ImageTk = ImageOps = ImageStat = ImageFilter = None
    PHOTO_MANAGER_IMPORT_ERROR = (
        "Pillow is required for the local photo manager. "
        "Run INSTALL_IMAGE_SUPPORT.bat once."
    )

try:
    if Image is not None:
        import pillow_heif
        pillow_heif.register_heif_opener()
        HEIF_AVAILABLE = True
    else:
        HEIF_AVAILABLE = False
except Exception:
    HEIF_AVAILABLE = False

SUPPORTED_EXTS = {
    ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp",
    ".heic", ".heif", ".avif",
}

THUMB_SIZE = (118, 118)
PREVIEW_SIZE = (380, 380)


def _open_oriented(path: str | Path):
    im = Image.open(path)
    return ImageOps.exif_transpose(im).convert("RGB")


def _dhash(im: Image.Image, hash_size: int = 8) -> int:
    small = im.convert("L").resize((hash_size + 1, hash_size), Image.Resampling.BILINEAR)
    px = list(small.getdata())
    value = 0
    bit = 0
    stride = hash_size + 1
    for y in range(hash_size):
        row = y * stride
        for x in range(hash_size):
            if px[row + x] > px[row + x + 1]:
                value |= 1 << bit
            bit += 1
    return value


def _color_hist(im: Image.Image):
    small = im.resize((96, 96), Image.Resampling.BILINEAR)
    hist = small.histogram()
    # PIL RGB hist has 256 bins per channel. Collapse to 16 bins/channel.
    out = []
    for channel in range(3):
        base = channel * 256
        vals = hist[base:base + 256]
        for b in range(16):
            out.append(sum(vals[b * 16:(b + 1) * 16]))
    total = float(sum(out)) or 1.0
    return tuple(v / total for v in out)



_LOCAL_PHOTO_ANALYSIS_CACHE = {}


def _analysis_cache_key(path):
    p = Path(path)
    try:
        st = p.stat()
        return (str(p.resolve()), int(st.st_size), int(st.st_mtime_ns))
    except Exception:
        return (str(p), 0, 0)


def _feature(path: str | Path):
    key = ("feature",) + _analysis_cache_key(path)
    cached = _LOCAL_PHOTO_ANALYSIS_CACHE.get(key)
    if cached is not None:
        return cached

    im = _open_oriented(path)
    result = {
        "hash": _dhash(im),
        "hist": _color_hist(im),
        "aspect": im.width / max(1, im.height),
    }
    _LOCAL_PHOTO_ANALYSIS_CACHE[key] = result

    # Prevent an all-day warehouse session from growing forever.
    if len(_LOCAL_PHOTO_ANALYSIS_CACHE) > 2500:
        for stale_key in list(_LOCAL_PHOTO_ANALYSIS_CACHE.keys())[:400]:
            _LOCAL_PHOTO_ANALYSIS_CACHE.pop(stale_key, None)

    return result


def _hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def _similarity(a, b) -> float:
    hash_sim = 1.0 - (_hamming(a["hash"], b["hash"]) / 64.0)
    hist_sim = sum(min(x, y) for x, y in zip(a["hist"], b["hist"]))
    aspect_delta = abs(math.log(max(a["aspect"], 0.01) / max(b["aspect"], 0.01)))
    aspect_sim = max(0.0, 1.0 - aspect_delta / 1.25)
    return 0.50 * hash_sim + 0.42 * hist_sim + 0.08 * aspect_sim


def _quality_uncached(path: str | Path):
    """Return local, non-semantic image-quality scores in 0..100."""
    im = _open_oriented(path)
    im.thumbnail((420, 420), Image.Resampling.LANCZOS)
    gray = im.convert("L")
    stat = ImageStat.Stat(gray)
    mean = float(stat.mean[0])
    std = float(stat.stddev[0])

    # Exposure: broad plateau around useful midtones, with penalties at extremes.
    exposure = max(0.0, 1.0 - abs(mean - 145.0) / 145.0)
    contrast = min(1.0, std / 62.0)

    # Sharpness proxy from edge variance. This is inexpensive and works well for
    # choosing between repeated handheld shots, though it is not content-aware.
    edges = gray.filter(ImageFilter.FIND_EDGES)
    edge_var = float(ImageStat.Stat(edges).var[0])
    sharpness = min(1.0, math.log1p(edge_var) / math.log(1500.0))

    # Clipped pixels.
    hist = gray.histogram()
    total = float(sum(hist)) or 1.0
    clipped_dark = sum(hist[:10]) / total
    clipped_light = sum(hist[246:]) / total
    clipping = min(1.0, (clipped_dark + clipped_light) * 2.5)

    # Approximate compositional centering based on edge-energy center of mass.
    # Blank/background areas contribute little; product edges contribute more.
    edge_small = edges.resize((64, 64), Image.Resampling.BILINEAR)
    vals = list(edge_small.getdata())
    weights = [max(0, v - 18) for v in vals]
    wsum = float(sum(weights))
    if wsum > 0:
        cx = sum((i % 64) * w for i, w in enumerate(weights)) / wsum
        cy = sum((i // 64) * w for i, w in enumerate(weights)) / wsum
        dist = math.hypot(cx - 31.5, cy - 31.5) / math.hypot(31.5, 31.5)
        centering = max(0.0, 1.0 - dist)
    else:
        centering = 0.5

    score = (
        0.43 * sharpness
        + 0.25 * exposure
        + 0.14 * contrast
        + 0.18 * centering
        - 0.18 * clipping
    )
    score = max(0.0, min(1.0, score))
    return {
        "score": round(score * 100, 1),
        "sharpness": round(sharpness * 100, 1),
        "exposure": round(exposure * 100, 1),
        "contrast": round(contrast * 100, 1),
        "centering": round(centering * 100, 1),
        "clipping": round(clipping * 100, 1),
    }


def _quality(path: str | Path):
    key = ("quality",) + _analysis_cache_key(path)
    cached = _LOCAL_PHOTO_ANALYSIS_CACHE.get(key)
    if cached is not None:
        return dict(cached)

    result = _quality_uncached(path)
    _LOCAL_PHOTO_ANALYSIS_CACHE[key] = dict(result)

    if len(_LOCAL_PHOTO_ANALYSIS_CACHE) > 2500:
        for stale_key in list(_LOCAL_PHOTO_ANALYSIS_CACHE.keys())[:400]:
            _LOCAL_PHOTO_ANALYSIS_CACHE.pop(stale_key, None)

    return result


def group_photos(paths, progress=None):
    """Conservatively group visually similar photos without AI.

    It intentionally prefers *over-splitting* to incorrectly merging two products.
    The user can merge/move photos in Batch Review afterward.
    """
    paths = [str(Path(p)) for p in paths]
    features = {}
    valid = []
    for i, p in enumerate(paths):
        try:
            features[p] = _feature(p)
            valid.append(p)
        except Exception:
            continue
        if progress:
            progress(i + 1, len(paths), "Reading photo features")

    groups = []
    # Greedy conservative clustering. Compare against a few members of each group
    # so different angles can still connect through an intermediate view.
    for i, p in enumerate(valid):
        f = features[p]
        best_idx = None
        best_sim = -1.0
        for gi, group in enumerate(groups):
            candidates = group[-5:] + group[:2]
            sim = max((_similarity(f, features[q]) for q in candidates), default=0.0)
            if sim > best_sim:
                best_sim = sim
                best_idx = gi

        # Slightly relaxed threshold for adjacent shots: camera rolls usually keep
        # multiple angles of one item together, but we remain conservative.
        previous_same = False
        if i > 0 and groups:
            prev = valid[i - 1]
            prev_sim = _similarity(f, features[prev])
            previous_same = prev_sim >= 0.945

        if best_idx is not None and (best_sim >= 0.955 or (previous_same and best_sim >= 0.945)):
            groups[best_idx].append(p)
        else:
            groups.append([p])

        if progress:
            progress(i + 1, len(valid), "Building likely item groups")

    return groups, features


def rank_and_select(paths, target=12, progress=None):
    """Score photos and mark a diverse recommended subset; never delete anything."""
    paths = list(paths)
    q = {}
    f = {}
    for i, p in enumerate(paths):
        try:
            q[p] = _quality(p)
            f[p] = _feature(p)
        except Exception:
            q[p] = {"score": 0.0, "error": True}
            f[p] = None
        if progress:
            progress(i + 1, len(paths), "Scoring sharpness / exposure / framing")

    ranked = sorted(paths, key=lambda p: q[p].get("score", 0), reverse=True)
    selected = []
    redundant = set()
    for p in ranked:
        if len(selected) >= target:
            break
        if not selected:
            selected.append(p)
            continue
        if f[p] is None:
            continue
        maxsim = max((_similarity(f[p], f[s]) for s in selected if f[s] is not None), default=0)
        if maxsim >= 0.90:
            redundant.add(p)
            continue
        selected.append(p)

    # If diversity filtering left too few, fill with the highest-quality remaining shots.
    if len(selected) < min(target, len(ranked)):
        for p in ranked:
            if p not in selected:
                selected.append(p)
            if len(selected) >= min(target, len(ranked)):
                break

    selected_set = set(selected)
    for p in ranked:
        if p not in selected_set and f[p] is not None:
            if max((_similarity(f[p], f[s]) for s in selected if f[s] is not None), default=0) >= 0.90:
                redundant.add(p)

    return ranked, selected, q, redundant


class BatchReviewWindow(tk.Toplevel):
    """
    Review item groups produced by either OpenAI or the free/local grouper.

    Selection is intentionally explicit:
      - click the thumbnail
      - click its Select button
    Either action updates the selected-photo label and enables Move/Split.
    """

    def __init__(
        self,
        master,
        groups,
        on_use_group,
        log=None,
        group_meta=None,
        source_label="Grouping",
    ):
        super().__init__(master)
        self.title(f"Batch Photo Review — {source_label}")
        self.geometry("1180x780")
        self.minsize(920, 640)

        self.groups = [list(g) for g in groups if g]
        self.on_use_group = on_use_group
        self.log = log or (lambda x: None)
        self.group_meta = list(group_meta or [])
        self.source_label = source_label

        self.current_group = 0
        self.selected_path = None
        self._thumb_refs = []
        self._cards = {}

        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        if source_label.lower().startswith("openai"):
            intro = (
                "OpenAI item grouping — review these suggestions before creating listings. "
                "AI is deciding which photos appear to show the same item; nothing is deleted."
            )
        else:
            intro = (
                "Local visual grouping — conservative/free fallback. It may over-split different "
                "angles of the same item. Use OpenAI grouping when product identification matters."
            )

        ttk.Label(
            self,
            text=intro,
            wraplength=1060,
        ).grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 6))

        left = ttk.Frame(self, padding=(10, 0, 8, 10))
        left.grid(row=1, column=0, sticky="ns")
        ttk.Label(left, text="Likely item groups").pack(anchor="w")

        self.group_list = tk.Listbox(
            left, width=38, height=25, exportselection=False
        )
        self.group_list.pack(fill="y", expand=True, pady=(4, 8))
        self.group_list.bind("<<ListboxSelect>>", self._group_changed)

        ttk.Button(
            left, text="Sort This Group by Quality", command=self._sort_current_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left, text="New Empty Group", command=self._new_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left, text="Merge This Group Into…", command=self._merge_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left,
            text="Use This Group as Current Item",
            command=self._use_group,
            style="Accent.TButton",
        ).pack(fill="x", pady=(10, 2))
        ttk.Button(
            left,
            text="Use Group + AI Sort/Pick Best",
            command=self._use_group_and_sort,
        ).pack(fill="x", pady=2)

        right = ttk.Frame(self, padding=(0, 0, 10, 10))
        right.grid(row=1, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)

        self.group_info_var = tk.StringVar(value="")
        ttk.Label(
            right,
            textvariable=self.group_info_var,
            wraplength=760,
            justify="left",
            style="Subheader.TLabel",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))

        self.canvas = tk.Canvas(right, highlightthickness=0)
        scroll = ttk.Scrollbar(right, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scroll.set)
        self.canvas.grid(row=1, column=0, sticky="nsew")
        scroll.grid(row=1, column=1, sticky="ns")

        self.grid_frame = ttk.Frame(self.canvas, padding=6)
        self.grid_window = self.canvas.create_window(
            (0, 0), window=self.grid_frame, anchor="nw"
        )
        self.grid_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self.grid_window, width=e.width),
        )
        self.canvas.bind("<MouseWheel>", self._on_batch_mousewheel)
        self.grid_frame.bind("<MouseWheel>", self._on_batch_mousewheel)

        controls = ttk.LabelFrame(right, text="Selected Photo", padding=8)
        controls.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        controls.columnconfigure(1, weight=1)

        self.selected_var = tk.StringVar(value="None — click a thumbnail or Select")
        ttk.Label(
            controls,
            textvariable=self.selected_var,
            wraplength=760,
            justify="left",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 7))

        ttk.Label(controls, text="Move selected photo to:").grid(
            row=1, column=0, padx=(0, 5), sticky="e"
        )
        self.move_var = tk.StringVar()
        self.move_combo = ttk.Combobox(
            controls, textvariable=self.move_var, state="readonly", width=28
        )
        self.move_combo.grid(row=1, column=1, padx=(0, 5), sticky="w")

        self.move_btn = ttk.Button(
            controls, text="Move to Group", command=self._move_selected, state="disabled"
        )
        self.move_btn.grid(row=1, column=2, sticky="w", padx=(0, 5))

        self.split_btn = ttk.Button(
            controls,
            text="Make New Group from Selected Photo",
            command=self._split_selected,
            state="disabled",
        )
        self.split_btn.grid(row=1, column=3, sticky="w")

        self._refresh_group_list()
        if self.groups:
            self.group_list.selection_set(0)
            self.group_list.activate(0)
            self._show_group(0)

    def _meta_for_group(self, idx):
        if 0 <= idx < len(self.group_meta):
            meta = self.group_meta[idx]
            return meta if isinstance(meta, dict) else {}
        return {}

    def _refresh_group_list(self):
        current = min(self.current_group, max(0, len(self.groups) - 1))
        self.group_list.delete(0, "end")

        for i, group in enumerate(self.groups):
            meta = self._meta_for_group(i)
            label = str(meta.get("label", "") or "").strip()
            confidence = meta.get("confidence")
            extra = ""
            if label:
                extra += f" — {label[:34]}"
            if isinstance(confidence, (int, float)) and confidence > 0:
                extra += f" ({confidence:.0%})"
            self.group_list.insert(
                "end",
                f"Group {i + 1} — {len(group)} photo(s){extra}"
            )

        self.move_combo["values"] = [
            f"Group {i + 1}" for i in range(len(self.groups))
        ]
        if self.groups:
            self.current_group = current
            self.move_var.set(
                f"Group {min(self.current_group + 1, len(self.groups))}"
            )

    def _group_changed(self, event=None):
        sel = self.group_list.curselection()
        if sel:
            self._show_group(int(sel[0]))

    def _show_group(self, idx):
        if idx < 0 or idx >= len(self.groups):
            return

        self.current_group = idx
        self._clear_photo_selection()

        for child in self.grid_frame.winfo_children():
            child.destroy()
        self._thumb_refs.clear()
        self._cards.clear()

        group = self.groups[idx]
        meta = self._meta_for_group(idx)
        label = str(meta.get("label", "") or "").strip()
        confidence = meta.get("confidence")

        info = f"Group {idx + 1}: {len(group)} photo(s)"
        if label:
            info += f"  •  AI label: {label}"
        if isinstance(confidence, (int, float)) and confidence > 0:
            info += f"  •  average confidence: {confidence:.0%}"
        self.group_info_var.set(info)

        width = max(650, self.canvas.winfo_width())
        cols = max(3, width // 185)

        for i, p in enumerate(group):
            # tk.Frame gives us a visible selection border.
            card = tk.Frame(
                self.grid_frame,
                bd=2,
                relief="groove",
                highlightthickness=2,
                highlightbackground="#c9c9c9",
                highlightcolor="#c9c9c9",
            )
            card.grid(
                row=i // cols,
                column=i % cols,
                sticky="n",
                padx=5,
                pady=5,
            )
            self._cards[str(p)] = card

            try:
                im = _open_oriented(p)
                im.thumbnail((150, 150), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(im)
                self._thumb_refs.append(photo)
                lab = ttk.Label(card, image=photo, cursor="hand2")
            except Exception:
                lab = ttk.Label(
                    card, text="Preview unavailable", width=20, anchor="center"
                )

            lab.pack(padx=4, pady=(4, 2))
            name = Path(p).name
            ttk.Label(
                card, text=name[:26], width=27, anchor="center"
            ).pack(padx=3)

            select_btn = ttk.Button(
                card,
                text="Select",
                command=lambda path=p: self._select(path),
            )
            select_btn.pack(fill="x", padx=4, pady=(3, 4))

            card.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")
            lab.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")
            select_btn.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")

            # Clicking the image/card itself now selects it too.
            lab.bind("<Button-1>", lambda e, path=p: self._select(path))
            card.bind("<Button-1>", lambda e, path=p: self._select(path))

        self.canvas.yview_moveto(0)

    def _clear_photo_selection(self):
        self.selected_path = None
        self.selected_var.set("None — click a thumbnail or Select")
        if hasattr(self, "move_btn"):
            self.move_btn.config(state="disabled")
        if hasattr(self, "split_btn"):
            self.split_btn.config(state="disabled")

    def _select(self, path):
        path = str(path)
        self.selected_path = path
        self.selected_var.set(
            f"{Path(path).name}  •  currently in Group {self.current_group + 1}"
        )
        self.title(
            f"Batch Photo Review — selected: {Path(path).name}"
        )
        self.move_btn.config(state="normal")
        self.split_btn.config(state="normal")

        # Visible selection border.
        for p, card in self._cards.items():
            selected = (p == path)
            try:
                card.configure(
                    highlightbackground=("#1f6aa5" if selected else "#c9c9c9"),
                    highlightcolor=("#1f6aa5" if selected else "#c9c9c9"),
                )
            except Exception:
                pass

    def _new_group(self):
        self.groups.append([])
        self.group_meta.append({})
        self._refresh_group_list()

    def _split_selected(self):
        path = self.selected_path
        if not path:
            messagebox.showinfo(
                "Batch Review",
                "Click the photo thumbnail or its Select button first.",
                parent=self,
            )
            return

        src = self.current_group
        if path not in self.groups[src]:
            messagebox.showerror(
                "Batch Review",
                "The selected photo is no longer in the current group. Select it again.",
                parent=self,
            )
            self._clear_photo_selection()
            return

        self.groups[src].remove(path)
        self.groups.append([path])
        self.group_meta.append({"label": "Manual split"})

        # Drop empty source groups and matching metadata.
        if not self.groups[src]:
            del self.groups[src]
            if src < len(self.group_meta):
                del self.group_meta[src]

        self.current_group = min(src, len(self.groups) - 1)
        self._refresh_group_list()
        if self.groups:
            self.group_list.selection_clear(0, "end")
            self.group_list.selection_set(self.current_group)
            self._show_group(self.current_group)

    def _move_selected(self):
        path = self.selected_path
        if not path:
            messagebox.showinfo(
                "Batch Review",
                "Click the photo thumbnail or its Select button first.",
                parent=self,
            )
            return

        try:
            dst = int(self.move_var.get().replace("Group", "").strip()) - 1
        except Exception:
            messagebox.showerror(
                "Batch Review", "Choose a destination group first.", parent=self
            )
            return

        src = self.current_group
        if dst == src:
            messagebox.showinfo(
                "Batch Review",
                "That photo is already in the selected destination group.",
                parent=self,
            )
            return
        if not (0 <= dst < len(self.groups)):
            return
        if path not in self.groups[src]:
            messagebox.showerror(
                "Batch Review",
                "The selected photo is no longer in this group. Select it again.",
                parent=self,
            )
            self._clear_photo_selection()
            return

        self.groups[src].remove(path)
        self.groups[dst].append(path)

        # If source becomes empty, remove it and adjust destination/current indexes.
        if not self.groups[src]:
            del self.groups[src]
            if src < len(self.group_meta):
                del self.group_meta[src]
            if src < dst:
                dst -= 1

        self.current_group = max(0, min(dst, len(self.groups) - 1))
        self._refresh_group_list()
        self.group_list.selection_clear(0, "end")
        self.group_list.selection_set(self.current_group)
        self.group_list.activate(self.current_group)
        self._show_group(self.current_group)

        self.log(
            f"Moved {Path(path).name} to Group {self.current_group + 1}."
        )

    def _merge_group(self):
        if len(self.groups) < 2:
            return

        target = simpledialog.askinteger(
            "Merge Group",
            f"Merge Group {self.current_group + 1} into which group number?",
            parent=self,
            minvalue=1,
            maxvalue=len(self.groups),
        )
        if not target:
            return

        src = self.current_group
        dst = target - 1
        if dst == src:
            return

        self.groups[dst].extend(self.groups[src])

        # Prefer destination metadata but keep a useful label if it was blank.
        src_meta = self._meta_for_group(src)
        dst_meta = self._meta_for_group(dst)
        if not dst_meta.get("label") and src_meta.get("label"):
            dst_meta["label"] = src_meta.get("label")

        del self.groups[src]
        if src < len(self.group_meta):
            del self.group_meta[src]
        if src < dst:
            dst -= 1

        self.current_group = max(0, min(dst, len(self.groups) - 1))
        self._refresh_group_list()
        self.group_list.selection_clear(0, "end")
        self.group_list.selection_set(self.current_group)
        self._show_group(self.current_group)

    def _sort_current_group(self):
        if not self.groups:
            return
        idx = self.current_group
        paths = list(self.groups[idx])
        if len(paths) < 2:
            return

        self.config(cursor="watch")
        self.update_idletasks()

        def work():
            try:
                ranked, selected, quality, redundant = rank_and_select(
                    paths, target=len(paths)
                )
                self.groups[idx] = list(ranked)
                self.log(
                    f"Sorted Group {idx + 1} by local photo quality."
                )
                self.after(0, lambda: self._show_group(idx))
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Batch Review", e, parent=self
                    ),
                )
            finally:
                self.after(0, lambda: self.config(cursor=""))

        threading.Thread(target=work, daemon=True).start()

    def _use_group(self):
        if not self.groups:
            return
        group = list(self.groups[self.current_group])
        if not group:
            return
        self.on_use_group(group)
        self.destroy()

    def _use_group_and_sort(self):
        if not self.groups:
            return
        group = list(self.groups[self.current_group])
        if not group:
            return
        self.on_use_group(group)
        # Give the main photo manager a moment to rebuild its thumbnails.
        try:
            self.master.after(150, self.master.ai_sort_best)
        except Exception:
            pass
        self.destroy()


class _IntegratedPhotoManagerFrame(ttk.LabelFrame):
    """eBay-style local thumbnail manager for one listing's photos."""
    def __init__(self, master, on_change, on_analyze=None, log=None, **kwargs):
        super().__init__(master, text="1. Item Photos", padding=8, **kwargs)
        self.on_change = on_change
        self.on_analyze = on_analyze
        self.log = log or (lambda x: None)
        self.records = []  # {path, included, quality, redundant}
        self.selected_index = None
        self.drag_from = None
        self._thumb_refs = []
        self._check_vars = []
        self._preview_ref = None
        self.busy = False

        # Gallery performance caches. Thumbnails are tiny compared with originals,
        # and are reused across selection/reorder/check-state refreshes.
        self._gallery_thumb_cache = {}
        self._gallery_last_cols = None

        # Multi-item batch state lives separately from the current listing.
        # This lets the user build Listing #1, then reopen the same groups for
        # Listing #2 without re-importing hundreds of photos.
        self.batch_paths = []
        self.batch_groups = []
        self.batch_group_meta = []
        self.batch_source_label = ""

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=0)
        self.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        for c in range(6):
            toolbar.columnconfigure(c, weight=1)

        ttk.Button(toolbar, text="ADD PHOTOS", command=self.add_files).grid(
            row=0, column=0, padx=3, sticky="ew"
        )
        ttk.Button(toolbar, text="BATCH", command=self.import_batch).grid(
            row=0, column=1, padx=3, sticky="ew"
        )

        self.ai_group_btn = ttk.Button(
            toolbar,
            text="AI GROUP",
            command=self._ai_group_current_batch,
            style="Accent.TButton",
        )
        self.ai_group_btn.grid(row=0, column=2, padx=3, sticky="ew")

        ttk.Button(
            toolbar,
            text="AI SORT",
            command=self.ai_sort_best,
            style="Accent.TButton",
        ).grid(row=0, column=3, padx=3, sticky="ew")

        self.analyze_btn = None
        if on_analyze:
            self.analyze_btn = ttk.Button(
                toolbar,
                text="ANALYZE",
                command=on_analyze,
                style="Accent.TButton",
            )
            self.analyze_btn.grid(row=0, column=4, padx=3, sticky="ew")

        tools_btn = ttk.Menubutton(toolbar, text="PHOTO TOOLS ▾")
        tools_menu = tk.Menu(tools_btn, tearoff=False)
        tools_btn["menu"] = tools_menu
        tools_btn.grid(row=0, column=5, padx=3, sticky="ew")

        tools_menu.add_command(label="One Item Folder", command=self.add_one_folder)
        tools_menu.add_separator()
        tools_menu.add_command(label="Local Group (Free)", command=self._local_group_current_batch)
        tools_menu.add_command(label="Review Groups", command=self._open_batch_review)
        tools_menu.add_command(label="Local Sort + Pick", command=self.sort_best)
        tools_menu.add_command(label="Move Redundant to Rejected", command=self._move_redundant_to_rejected)
        tools_menu.add_separator()
        tools_menu.add_command(label="Select All Photos", command=self.select_all_photos)
        tools_menu.add_command(label="Clear Selection", command=self.clear_photo_selection)
        tools_menu.add_command(label="View Large", command=self.view_selected_large)
        tools_menu.add_separator()
        tools_menu.add_command(label="Remove Selected Files", command=self.move_selected_to_rejected)
        tools_menu.add_command(label="Remove Unselected Files", command=self.move_unselected_to_rejected)
        tools_menu.add_separator()
        tools_menu.add_command(label="Clear Current Photo Set", command=self.clear)

        # Keep these compatibility button attributes because older state-update
        # paths still reference them; they no longer need to be visible.
        self.review_groups_btn = ttk.Button(
            toolbar, text="REVIEW GROUPS", command=self._open_batch_review, state="disabled"
        )
        self.reject_redundant_btn = ttk.Button(
            toolbar, text="MOVE REDUNDANT TO REJECTED",
            command=self._move_redundant_to_rejected, state="disabled"
        )

        self.count_var = tk.StringVar(value="No local photos selected")
        ttk.Label(toolbar, textvariable=self.count_var, style="Subheader.TLabel").grid(row=1, column=0, columnspan=6, padx=4, pady=(7, 0), sticky="ew")

        left = ttk.Frame(self)
        left.grid(row=1, column=0, sticky="nsew")
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(left, height=330, highlightthickness=0)
        vbar = ttk.Scrollbar(left, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        self.gallery = ttk.Frame(self.canvas, padding=4)
        self.gallery_win = self.canvas.create_window((0, 0), window=self.gallery, anchor="nw")
        self.gallery.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._canvas_resized)
        self.canvas.bind("<MouseWheel>", self._on_gallery_mousewheel)
        self.gallery.bind("<MouseWheel>", self._on_gallery_mousewheel)

        side = ttk.LabelFrame(self, text="Selected Photo", padding=6)
        side.grid(row=1, column=1, sticky="ns", padx=(8, 0))
        self.preview = ttk.Label(side, text="Click a thumbnail\nto preview", anchor="center", width=42)
        self.preview.pack(fill="both", expand=True)
        self.detail_var = tk.StringVar(value="")
        ttk.Label(side, textvariable=self.detail_var, wraplength=330, justify="left").pack(fill="x", pady=6)
        ctl = ttk.Frame(side)
        ctl.pack(fill="x")
        ttk.Button(ctl, text="Set Main", command=self.set_main).grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(ctl, text="←", width=4, command=lambda: self.move_selected(-1)).grid(row=0, column=1, padx=2)
        ttk.Button(ctl, text="→", width=4, command=lambda: self.move_selected(1)).grid(row=0, column=2, padx=2)
        ttk.Button(ctl, text="Remove", command=self.remove_selected).grid(row=0, column=3, padx=2)
        for c in range(4):
            ctl.columnconfigure(c, weight=1)

        bottom = ttk.Frame(self)
        bottom.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        self.target_var = tk.IntVar(value=12)
        ttk.Label(bottom, text="Recommended listing photos:").pack(side="left")
        ttk.Spinbox(bottom, from_=1, to=24, textvariable=self.target_var, width=5).pack(side="left", padx=(5, 12))
        ttk.Label(
            bottom,
            text="Drag thumbnails to reorder. Photo #1 is the eBay main image. Double-click sets Main; more actions are under PHOTO TOOLS.",
        ).pack(side="left")

    @property
    def get_selected_listing_photos(self):
        """Return photos currently selected for listing use, in gallery order."""

        def normalize_path_collection(value):
            # Some internal names are methods in older builds.
            if callable(value):
                try:
                    value = value()
                except TypeError:
                    return []
            if value is None:
                return []
            if isinstance(value, (str, Path)):
                return [str(value)]
            try:
                return [str(p) for p in list(value)]
            except TypeError:
                return []

        # First prefer explicit selected/used path providers.
        for attr in ("selected_paths", "used_paths"):
            if hasattr(self, attr):
                out = normalize_path_collection(getattr(self, attr))
                if out:
                    return out

        # Then inspect photo record containers.
        for attr in ("photos", "items", "photo_items", "records"):
            value = getattr(self, attr, None)
            if callable(value):
                try:
                    value = value()
                except TypeError:
                    value = None
            if not value:
                continue

            out = []
            try:
                iterable = list(value)
            except TypeError:
                continue

            for item in iterable:
                if isinstance(item, (str, Path)):
                    out.append(str(item))
                    continue

                if isinstance(item, dict):
                    path = item.get("path") or item.get("filepath") or item.get("file")
                    enabled = item.get(
                        "use",
                        item.get("selected", item.get("checked", True))
                    )
                    if hasattr(enabled, "get"):
                        try:
                            enabled = enabled.get()
                        except Exception:
                            enabled = True
                    if path and bool(enabled):
                        out.append(str(path))
                    continue

                path = (
                    getattr(item, "path", None)
                    or getattr(item, "filepath", None)
                    or getattr(item, "file", None)
                )

                enabled = True
                for flag in ("use", "selected", "checked", "enabled"):
                    if hasattr(item, flag):
                        raw = getattr(item, flag)
                        if callable(raw):
                            try:
                                raw = raw()
                            except TypeError:
                                pass
                        try:
                            enabled = bool(raw.get()) if hasattr(raw, "get") else bool(raw)
                        except Exception:
                            enabled = bool(raw)
                        break

                if path and enabled:
                    out.append(str(path))

            if out:
                return out

        # Fallback to all currently imported paths.
        provider = getattr(self, "_current_all_photo_paths", None)
        if callable(provider):
            try:
                return [str(p) for p in provider()]
            except Exception:
                pass

        return []


    def _get_ai_settings(self):
        """Return current app settings through the callback supplied by the main window."""
        provider = getattr(self, "settings_provider", None)
        if callable(provider):
            return provider()
        # Fallback used by some integrated builds.
        master = self.master
        while master is not None:
            if hasattr(master, "settings"):
                return master.settings
            master = getattr(master, "master", None)
        return {}

    def _ai_grouping_cap(self):
        settings = self._get_ai_settings()
        try:
            value = float(settings.get("ai_grouping_spend_cap", "1.00") or 1.00)
        except Exception:
            value = 1.00
        return max(0.05, value)

    def _current_all_photo_paths(self):
        """Return the retained multi-item batch, or current listing photos as fallback."""
        if getattr(self, "batch_paths", None):
            return [
                str(p)
                for p in self.batch_paths
                if Path(str(p)).exists()
            ]

        # Fallback to the current item only when no separate batch is loaded.
        records = getattr(self, "records", []) or []
        return [
            str(r.get("path"))
            for r in records
            if isinstance(r, dict)
            and r.get("path")
            and not r.get("remote_url")
            and Path(str(r.get("path"))).exists()
        ]

    def _apply_ai_groups_to_review(self, result):
        """Store OpenAI groups and open the real Batch Review window."""
        rich_groups = result.get("groups", []) or []
        path_groups = [
            [str(p) for p in (g.get("paths", []) or []) if Path(str(p)).exists()]
            for g in rich_groups
            if isinstance(g, dict) and g.get("paths")
        ]
        path_groups = [g for g in path_groups if g]

        # Do not silently lose a photo if an AI response omitted its assignment.
        assigned = {p for group in path_groups for p in group}
        leftovers = [
            p for p in self._current_all_photo_paths()
            if p not in assigned
        ]
        for p in leftovers:
            path_groups.append([p])
            rich_groups.append({
                "label": "Unassigned / review manually",
                "paths": [p],
                "confidence": 0.0,
            })

        self.batch_groups = path_groups
        self.batch_group_meta = list(rich_groups[:len(path_groups)])
        self.batch_source_label = "OpenAI grouping"
        self.review_groups_btn.config(
            state="normal" if self.batch_groups else "disabled"
        )

        self._open_batch_review()

    def _ai_group_current_batch(self):
        paths = self._current_all_photo_paths()
        if not paths:
            messagebox.showerror(APP_NAME, "Click Batch / Multiple Items and import a folder first.")
            return

        if len(paths) > 500:
            messagebox.showerror(
                APP_NAME,
                f"AI grouping is limited to 500 photos per pass. "
                f"You currently have {len(paths)} imported photos."
            )
            return

        settings = self._get_ai_settings()
        if not settings.get("openai_api_key", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Enter your OpenAI API key in the eBay Settings tab first."
            )
            return

        cancel_event = getattr(self, "cancel_event", None)
        if cancel_event is None:
            cancel_event = threading.Event()
            self.cancel_event = cancel_event

        log_fn = getattr(self, "log", None)
        if not callable(log_fn):
            log_fn = lambda msg: None

        grouper = AIPhotoGrouper(settings, cancel_event, log_fn)
        cap = self._ai_grouping_cap()
        estimate = grouper.estimate_cost(len(paths))

        if estimate > cap:
            messagebox.showerror(
                APP_NAME,
                f"Estimated grouping cost ${estimate:.2f} exceeds your "
                f"${cap:.2f} hard cap.\n\nIncrease the cap in eBay Settings "
                "or process fewer photos."
            )
            return

        if not messagebox.askyesno(
            APP_NAME,
            f"AI-group {len(paths)} photos by likely item?\n\n"
            f"Estimated cost: about ${estimate:.2f}\n"
            f"Hard spend cap: ${cap:.2f}\n\n"
            "Compact thumbnails will be sent to OpenAI. "
            "No original photo will be deleted."
        ):
            return

        cancel_event.clear()

        # Disable the button during work if present.
        btn = getattr(self, "ai_group_btn", None)
        if btn is not None:
            try:
                btn.config(state="disabled")
            except Exception:
                pass

        log_fn(
            f"Starting AI grouping for {len(paths)} photos | "
            f"estimate ${estimate:.2f} | cap ${cap:.2f}"
        )

        def work():
            try:
                result = grouper.group(paths, spend_cap=cap)

                def apply():
                    self._apply_ai_groups_to_review(result)
                    log_fn(
                        f"AI grouping complete: {len(result.get('groups', []))} groups | "
                        f"actual cost ${result.get('cost', 0.0):.4f}"
                    )
                    messagebox.showinfo(
                        APP_NAME,
                        f"AI grouping complete.\n\n"
                        f"Photos: {len(paths)}\n"
                        f"Likely groups: {len(result.get('groups', []))}\n"
                        f"OpenAI model: {result.get('model', settings.get('openai_model', ''))}\n"
                        f"ACTUAL AI COST: ${result.get('cost', 0.0):.4f}\n"
                        f"Input tokens: {result.get('input_tokens', 0):,}\n"
                        f"Output tokens: {result.get('output_tokens', 0):,}\n"
                        f"Spend cap: ${cap:.2f}\n\n"
                        "Review and correct the groups before making listings."
                    )

                self.after(0, apply)
            except Exception as exc:
                log_fn(f"AI GROUPING ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                if btn is not None:
                    self.after(0, lambda: btn.config(state="normal"))
                self.after(
                    0,
                    lambda: self.count_var.set(
                        f"{len(self.batch_paths)} batch photo(s) retained"
                        if self.batch_paths
                        else self.count_var.get()
                    ),
                )

        threading.Thread(target=work, daemon=True).start()

    @property
    def selected_paths(self):
        """Local photos currently checked Use, in gallery/upload order."""
        return [
            str(r["path"])
            for r in self.records
            if r.get("included", True)
            and not r.get("remote_url")
            and Path(str(r["path"])).exists()
        ]

    @property
    def selected_existing_urls(self):
        """Existing eBay image URLs currently checked Use, in gallery order."""
        return [
            str(r.get("remote_url"))
            for r in self.records
            if r.get("included", True) and r.get("remote_url")
        ]

    def ordered_image_sources(self):
        """Return mixed local/remote sources in exact gallery order."""
        out = []
        for r in self.records:
            if not r.get("included", True):
                continue
            if r.get("remote_url"):
                out.append(("remote", str(r["remote_url"])))
            elif Path(str(r.get("path", ""))).exists():
                out.append(("local", str(r["path"])))
        return out

    def set_paths(self, paths, all_included=True):
        seen = set()
        records = []
        for p in paths:
            p = str(Path(p))
            if p not in seen and Path(p).exists():
                records.append({"path": p, "included": all_included, "quality": None, "redundant": False})
                seen.add(p)
        self.records = records
        if hasattr(self, "reject_redundant_btn"):
            self.reject_redundant_btn.config(state="disabled")
        self.selected_index = 0 if records else None
        self._refresh()
        self._emit_change()

    def set_remote_urls(self, urls):
        """Display existing eBay photos as normal thumbnails without re-uploading them."""
        ensure_app_dir()
        IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        records = []
        for idx, url in enumerate(urls or []):
            url = str(url or "").strip()
            if not url:
                continue
            suffix = ".jpg"
            cache_path = IMAGE_CACHE_DIR / f"{abs(hash(url))}_{idx}{suffix}"
            try:
                if not cache_path.exists():
                    req = request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                    with request.urlopen(req, timeout=30) as resp:
                        cache_path.write_bytes(resp.read())
                records.append({
                    "path": str(cache_path),
                    "remote_url": url,
                    "included": True,
                    "quality": None,
                    "redundant": False,
                })
            except Exception as exc:
                self.log(f"Could not cache existing eBay image {idx + 1}: {exc}")
        self.records = records
        self.selected_index = 0 if records else None
        self._refresh()
        self._emit_change()

    def add_paths(self, paths):
        existing = {r["path"] for r in self.records}
        for p in paths:
            p = str(Path(p))
            if p not in existing and Path(p).exists():
                self.records.append({"path": p, "included": True, "quality": None, "redundant": False})
                existing.add(p)
        if self.selected_index is None and self.records:
            self.selected_index = 0
        self._refresh()
        self._emit_change()

    def add_files(self):
        paths = filedialog.askopenfilenames(
            title="Add item photos",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp *.heic *.heif *.avif"), ("All files", "*.*")],
        )
        if paths:
            self.add_paths(paths)

    def add_one_folder(self):
        folder = filedialog.askdirectory(title="Choose folder containing photos for ONE item")
        if not folder:
            return
        paths = self._folder_images(folder)
        if not paths:
            messagebox.showinfo("Photos", "No supported image files were found.", parent=self)
            return
        self.set_paths(paths)

    def import_batch(self):
        folder = filedialog.askdirectory(
            title="Choose folder containing MULTIPLE items"
        )
        if not folder:
            return

        paths = self._folder_images(folder)
        if not paths:
            messagebox.showinfo(
                "Photos",
                "No supported image files were found.",
                parent=self,
            )
            return

        if len(paths) > 500:
            messagebox.showerror(
                "Batch Photos",
                f"This folder contains {len(paths)} photos.\\n\\n"
                "AI grouping is capped at 500 photos per pass. "
                "Split this folder into smaller batches first.",
                parent=self,
            )
            return

        self.batch_paths = list(paths)
        self.batch_groups = []
        self.batch_group_meta = []
        self.batch_source_label = ""
        self.review_groups_btn.config(state="disabled")

        self.count_var.set(
            f"{len(paths)} batch photo(s) ready — click AI GROUP BATCH"
        )
        self.log(
            f"Imported {len(paths)} photos as a multi-item batch. "
            "No grouping has been run yet."
        )

        messagebox.showinfo(
            "Batch Photos Ready",
            f"Imported {len(paths)} photos.\\n\\n"
            "Recommended next step: AI GROUP BATCH.\\n\\n"
            "LOCAL GROUP (FREE) is still available as a conservative fallback, "
            "but it may split different angles of the same item into separate groups.",
            parent=self,
        )

    def _folder_images(self, folder):
        files = []
        for p in Path(folder).iterdir():
            if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS:
                files.append(p)
        # Filename order is usually camera capture order; use mtime as a tie-breaker.
        files.sort(key=lambda p: (p.name.lower(), p.stat().st_mtime))
        return [str(p) for p in files]

    def _local_group_current_batch(self):
        paths = self._current_all_photo_paths()
        if not paths:
            messagebox.showinfo(
                "Batch Grouping",
                "Import a Batch / Multiple Items folder first.",
                parent=self,
            )
            return
        self._run_batch_grouping(paths)

    def _run_batch_grouping(self, paths):
        """Free/local conservative grouping fallback."""
        if self.busy:
            return

        self.busy = True
        self.log(
            f"Locally grouping {len(paths)} batch photos. No AI/network use."
        )
        self.count_var.set(f"Local grouping {len(paths)} photos…")

        def progress(done, total, label):
            self.after(
                0,
                lambda: self.count_var.set(
                    f"{label}: {done}/{total}"
                ),
            )

        def work():
            try:
                groups, _ = group_photos(paths, progress=progress)
                self.batch_groups = [list(g) for g in groups if g]
                self.batch_group_meta = [
                    {
                        "label": "Local visual similarity",
                        "confidence": 0.0,
                        "paths": list(g),
                    }
                    for g in self.batch_groups
                ]
                self.batch_source_label = "Local visual grouping"
                self.log(
                    f"Local grouping produced {len(self.batch_groups)} "
                    "likely group(s)."
                )
                self.after(
                    0,
                    lambda: self.review_groups_btn.config(
                        state="normal" if self.batch_groups else "disabled"
                    ),
                )
                self.after(0, self._open_batch_review)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Batch Grouping", e, parent=self
                    ),
                )
            finally:
                self.busy = False
                self.after(
                    0,
                    lambda: self.count_var.set(
                        f"{len(self.batch_paths)} batch photo(s) retained"
                    ),
                )

        threading.Thread(target=work, daemon=True).start()

    def _open_batch_review(self):
        if not getattr(self, "batch_groups", None):
            messagebox.showinfo(
                "Batch Review",
                "No grouped batch is available yet.\\n\\n"
                "Import Batch / Multiple Items, then run AI GROUP BATCH "
                "or LOCAL GROUP (FREE).",
                parent=self,
            )
            return

        BatchReviewWindow(
            self,
            self.batch_groups,
            self._use_batch_group,
            self.log,
            group_meta=self.batch_group_meta,
            source_label=self.batch_source_label or "Batch grouping",
        )

    def _use_batch_group(self, paths):
        self.set_paths(paths)
        self.log(
            f"Loaded {len(paths)} photos from selected batch group into current listing. "
            "The full batch is retained; click REVIEW GROUPS later for the next item."
        )

    def _find_app_controller(self):
        widget = self
        seen = set()
        while widget is not None and id(widget) not in seen:
            seen.add(id(widget))
            if (
                hasattr(widget, "settings")
                and hasattr(widget, "_show_progress_popup")
                and hasattr(widget, "_close_progress_popup")
            ):
                return widget
            widget = getattr(widget, "master", None)
        return None

    def ai_sort_best(self):
        self.log("AI SORT + PICK BEST clicked.")

        if self.busy:
            self.log("AI SORT: another photo operation is already running.")
            return

        app = self._find_app_controller()
        if app is None:
            messagebox.showerror(
                "AI Sort + Pick Best",
                "Could not reach the main application controller.",
                parent=self,
            )
            return

        paths = [
            str(r.get("path"))
            for r in self.records
            if isinstance(r, dict)
            and r.get("path")
            and not r.get("remote_url")
            and Path(str(r.get("path"))).exists()
        ]

        self.log(f"AI SORT: {len(paths)} local photo(s) available.")

        if not paths:
            messagebox.showinfo(
                "AI Sort + Pick Best",
                "Load photos for one item first.",
                parent=self,
            )
            return

        if not str(app.settings.get("openai_api_key", "") or "").strip():
            messagebox.showerror(
                "AI Sort + Pick Best",
                "Add your OpenAI API key in eBay Settings first.",
                parent=self,
            )
            return

        try:
            app.cancel_event.clear()
        except Exception:
            pass

        self.busy = True
        try:
            app._show_progress_popup(
                "AI Sort + Pick Best",
                f"Reviewing {len(paths)} photos and identifying distinct views..."
            )
        except Exception as exc:
            self.log(f"AI SORT loader warning: {exc}")

        def work():
            try:
                self.log("AI SORT: sending request to OpenAI...")
                analyzer = PhotoAnalyzer(
                    app.settings.copy(),
                    app.cancel_event,
                    self.log,
                )

                try:
                    target = max(1, min(int(self.recommended_var.get() or 12), 24))
                except Exception:
                    target = 12

                result = analyzer.select_best_views(paths, max_final=target)
                selected_paths = list(result.get("selected_paths", []) or [])

                if not selected_paths:
                    raise RuntimeError("AI completed but returned no selected photos.")

                selected_set = set(selected_paths)
                by_path = {
                    str(r.get("path")): r
                    for r in self.records
                    if isinstance(r, dict) and r.get("path")
                }

                new_records = []

                for p in selected_paths:
                    rec = by_path.get(str(p))
                    if rec is not None:
                        rec["included"] = True
                        rec["redundant"] = False
                        new_records.append(rec)

                for rec in self.records:
                    p = str(rec.get("path"))
                    if rec.get("remote_url"):
                        new_records.append(rec)
                    elif p not in selected_set:
                        rec["included"] = False
                        rec["redundant"] = True
                        new_records.append(rec)

                self.records = new_records
                self.selected_index = 0 if new_records else None

                def finish():
                    try:
                        self._refresh()
                        self._emit_change()

                        if hasattr(self, "reject_redundant_btn"):
                            self.reject_redundant_btn.config(
                                state="normal"
                                if any(r.get("redundant") for r in self.records)
                                else "disabled"
                            )

                        views = result.get("view_groups", []) or []
                        notes = str(result.get("notes", "") or "")
                        usage = result.get("_usage", {}) or {}
                        ai_cost = float(usage.get("estimated_cost", 0.0) or 0.0)

                        msg = f"Selected {len(selected_paths)} best photo(s)"
                        if views:
                            msg += f" across {len(views)} distinct view group(s)."
                        else:
                            msg += "."
                        msg += (
                            f"\n\nOpenAI model: "
                            f"{usage.get('model', app.settings.get('openai_model', ''))}"
                            f"\nACTUAL AI COST: ${ai_cost:.4f}"
                            f"\nInput tokens: {usage.get('input_tokens', 0):,}"
                            f" | Output tokens: {usage.get('output_tokens', 0):,}"
                        )
                        if notes:
                            msg += f"\n\n{notes}"

                        self.log(
                            f"AI COST: ${ai_cost:.4f} for AI Sort + Pick Best | "
                            f"{usage.get('input_tokens', 0):,} input | "
                            f"{usage.get('output_tokens', 0):,} output"
                        )
                        self.log(
                            f"AI SORT COMPLETE: selected {len(selected_paths)} "
                            f"of {len(paths)} photo(s)."
                        )
                        messagebox.showinfo(
                            "AI Sort + Pick Best",
                            msg,
                            parent=self,
                        )
                    finally:
                        try:
                            app._close_progress_popup()
                        except Exception:
                            pass

                self.after(0, finish)

            except Exception as exc:
                err = str(exc)
                self.log(f"AI SORT ERROR: {err}")

                def fail():
                    try:
                        messagebox.showerror(
                            "AI Sort + Pick Best",
                            err,
                            parent=self,
                        )
                    finally:
                        try:
                            app._close_progress_popup()
                        except Exception:
                            pass

                self.after(0, fail)

            finally:
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def sort_best(self):
        if self.busy:
            return
        if not self.records:
            messagebox.showinfo("Photos", "Add photos first.", parent=self)
            return
        self.busy = True
        paths = [r["path"] for r in self.records]
        target = max(1, min(24, int(self.target_var.get() or 12)))
        self.log(f"Locally scoring {len(paths)} photos and selecting up to {target} diverse shots.")

        def progress(done, total, label):
            self.after(0, lambda: self.count_var.set(f"{label}: {done}/{total}"))

        def work():
            try:
                ranked, selected, quality, redundant = rank_and_select(paths, target, progress)
                by_path = {r["path"]: r for r in self.records}
                new_records = []
                selected_set = set(selected)
                for p in ranked:
                    rec = by_path[p]
                    rec["quality"] = quality.get(p)
                    rec["included"] = p in selected_set
                    rec["redundant"] = p in redundant and p not in selected_set
                    new_records.append(rec)
                # Ensure the best recommended photo is first / main.
                new_records.sort(key=lambda r: (not r["included"], -(r["quality"] or {}).get("score", 0)))
                self.records = new_records
                self.selected_index = 0 if self.records else None
                self.after(0, self._refresh)
                self.after(0, self._emit_change)
                self.after(
                    0,
                    lambda: self.reject_redundant_btn.config(
                        state="normal"
                        if any(r.get("redundant") for r in self.records)
                        else "disabled"
                    ),
                )
                self.log(
                    f"Selected {len(selected)} recommended photo(s); kept all {len(paths)} originals available for manual changes."
                )
            except Exception as exc:
                self.after(0, lambda e=str(exc): messagebox.showerror("Photo Sort", e, parent=self))
            finally:
                self.busy = False
                self.after(0, self._update_count)
        threading.Thread(target=work, daemon=True).start()

    def _move_records_to_rejected(self, records, label):
        """
        Remove chosen local photos from the active gallery/batch immediately.

        The app also tries to move originals to a sibling Rejected Photos folder.
        If Windows/filesystem locking prevents the physical move, the photo still
        disappears from the active viewer so it no longer has to be rendered.
        """
        records = [
            r for r in (records or [])
            if not r.get("remote_url")
            and r.get("path")
        ]

        if not records:
            messagebox.showinfo(
                "Photo Cleanup",
                f"No local {label.lower()} photos are available to remove.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Photo Cleanup",
            f"Remove {len(records)} {label.lower()} photo(s) from the active viewer?\n\n"
            "The app will also try to move the originals into a 'Rejected Photos' "
            "folder beside the source files.\n\n"
            "Even if Windows prevents a file from being moved, it will still be "
            "removed from the active viewer/batch.",
            parent=self,
        ):
            return

        target_paths = {
            str(r.get("path"))
            for r in records
            if str(r.get("path", "")).strip()
        }

        moved_to_rejected = set()
        originals_left_in_place = []
        move_errors = []

        for raw_path in sorted(target_paths):
            src = Path(raw_path)
            if not src.exists():
                continue
            try:
                rejected = src.parent / "Rejected Photos"
                rejected.mkdir(parents=True, exist_ok=True)

                dst = rejected / src.name
                n = 2
                while dst.exists():
                    dst = rejected / f"{src.stem}_{n}{src.suffix}"
                    n += 1

                shutil.move(str(src), str(dst))
                moved_to_rejected.add(raw_path)
            except Exception as exc:
                # Viewer cleanup is independent of physical file movement.
                originals_left_in_place.append(raw_path)
                move_errors.append((raw_path, str(exc)))

        # Always remove the selected paths from the current UI/batch state.
        self.records = [
            r for r in self.records
            if str(r.get("path")) not in target_paths
        ]

        self.batch_paths = [
            p for p in self.batch_paths
            if str(p) not in target_paths
        ]

        self.batch_groups = [
            [p for p in group if str(p) not in target_paths]
            for group in self.batch_groups
        ]
        self.batch_groups = [g for g in self.batch_groups if g]

        # Release cached thumbnails immediately.
        for key in list(self._gallery_thumb_cache.keys()):
            try:
                if str(key[0]) in target_paths:
                    self._gallery_thumb_cache.pop(key, None)
            except Exception:
                pass

        self.selected_index = 0 if self.records else None
        self._refresh()
        self._emit_change()

        removed_count = len(target_paths)
        msg = f"Removed {removed_count} photo(s) from the active viewer/batch."

        if moved_to_rejected:
            msg += (
                f"\n\n{len(moved_to_rejected)} original file(s) were moved to "
                "'Rejected Photos'."
            )

        if originals_left_in_place:
            msg += (
                f"\n\n{len(originals_left_in_place)} original file(s) could not be "
                "moved, so those originals were left where they are. They are still "
                "removed from this working photo set."
            )
            self.log("PHOTO MOVE WARNINGS: " + repr(move_errors[:20]))

        messagebox.showinfo("Photo Cleanup", msg, parent=self)


    def move_selected_to_rejected(self):
        self._move_records_to_rejected(
            [r for r in self.records if r.get("included", True)],
            "SELECTED",
        )

    def move_unselected_to_rejected(self):
        self._move_records_to_rejected(
            [r for r in self.records if not r.get("included", True)],
            "UNSELECTED",
        )

    def _move_redundant_to_rejected(self):
        """
        Move photos marked redundant by SORT + PICK BEST into a sibling
        'Rejected Photos' folder. This is deliberately safer than permanent delete.
        """
        redundant_records = [
            r for r in self.records
            if r.get("redundant")
            and not r.get("remote_url")
            and Path(str(r.get("path", ""))).exists()
        ]

        if not redundant_records:
            messagebox.showinfo(
                "Redundant Photos",
                "No redundant local photos are currently flagged.\\n\\n"
                "Run AI SORT + PICK BEST or LOCAL SORT + PICK first.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Move Redundant Photos",
            f"Move {len(redundant_records)} redundant photo(s) to a "
            "'Rejected Photos' folder?\\n\\n"
            "They will be removed from this listing/batch but NOT permanently deleted.",
            parent=self,
        ):
            return

        moved_originals = set()
        failures = []

        for rec in redundant_records:
            src = Path(str(rec["path"]))
            try:
                rejected = src.parent / "Rejected Photos"
                rejected.mkdir(parents=True, exist_ok=True)

                dst = rejected / src.name
                n = 2
                while dst.exists():
                    dst = rejected / f"{src.stem}_{n}{src.suffix}"
                    n += 1

                shutil.move(str(src), str(dst))
                moved_originals.add(str(src))
            except Exception as exc:
                failures.append((str(src), str(exc)))

        if moved_originals:
            self.records = [
                r for r in self.records
                if str(r.get("path")) not in moved_originals
            ]

            self.batch_paths = [
                p for p in self.batch_paths
                if str(p) not in moved_originals
            ]

            new_groups = []
            for group in self.batch_groups:
                kept = [p for p in group if str(p) not in moved_originals]
                if kept:
                    new_groups.append(kept)
            self.batch_groups = new_groups

            self.selected_index = 0 if self.records else None
            self.reject_redundant_btn.config(state="disabled")
            self._refresh()
            self._emit_change()

        message = (
            f"Moved {len(moved_originals)} redundant photo(s) into "
            "'Rejected Photos'."
        )
        if failures:
            message += (
                f"\\n\\n{len(failures)} photo(s) could not be moved. "
                "Details were written to Status."
            )
            self.log("Redundant photo move failures: " + repr(failures[:15]))

        messagebox.showinfo("Redundant Photos", message, parent=self)

    def view_selected_large(self):
        """Open the currently highlighted photo in the lazy large viewer."""
        if not self.records:
            messagebox.showinfo(
                "Large Photo Viewer",
                "No photos are loaded.",
                parent=self,
            )
            return

        idx = self.selected_index
        if idx is None or not (0 <= idx < len(self.records)):
            idx = 0

        self.view_photo_large(idx)

    def view_photo_large(self, index=0):
        """
        Lazy full-size viewer.

        Only the active image is decoded at a larger size, so large batches do
        not keep full-resolution photos in memory. Previous/Next navigates only
        the photos currently checked Use.
        """
        if not self.records:
            return

        try:
            index = int(index)
        except Exception:
            index = 0

        if index < 0 or index >= len(self.records):
            index = 0

        # Prefer currently selected/Use photos for navigation.
        included_indices = [
            i for i, r in enumerate(self.records)
            if r.get("included", True)
        ]
        if not included_indices:
            included_indices = list(range(len(self.records)))

        if index not in included_indices:
            # Show requested image once, then navigation starts from closest selected.
            nav_indices = [index] + [i for i in included_indices if i != index]
        else:
            nav_indices = included_indices

        try:
            nav_pos = nav_indices.index(index)
        except ValueError:
            nav_pos = 0

        win = tk.Toplevel(self)
        win.title("Large Photo Viewer")
        win.transient(self.winfo_toplevel())
        win.geometry("1100x820")
        win.minsize(700, 520)

        win.columnconfigure(0, weight=1)
        win.rowconfigure(0, weight=1)

        image_frame = ttk.Frame(win, padding=8)
        image_frame.grid(row=0, column=0, sticky="nsew")
        image_frame.columnconfigure(0, weight=1)
        image_frame.rowconfigure(0, weight=1)

        image_label = ttk.Label(image_frame, anchor="center")
        image_label.grid(row=0, column=0, sticky="nsew")

        info_var = tk.StringVar(value="")
        ttk.Label(
            image_frame,
            textvariable=info_var,
            anchor="center",
        ).grid(row=1, column=0, sticky="ew", pady=(6, 0))

        controls = ttk.Frame(win, padding=(8, 0, 8, 8))
        controls.grid(row=1, column=0, sticky="ew")
        controls.columnconfigure(1, weight=1)

        state = {
            "nav_indices": nav_indices,
            "nav_pos": nav_pos,
            "photo_ref": None,
            "resize_after": None,
        }

        def render_current():
            if not state["nav_indices"]:
                return
            idx = state["nav_indices"][state["nav_pos"]]
            rec = self.records[idx]
            path = str(rec.get("path", "") or "")
            if not path or not Path(path).exists():
                image_label.configure(text="Image file is unavailable.", image="")
                info_var.set(f"Photo #{idx + 1}")
                return

            # Render no larger than the current window; do not cache full-size.
            win.update_idletasks()
            max_w = max(500, image_frame.winfo_width() - 20)
            max_h = max(400, image_frame.winfo_height() - 70)

            try:
                im = _open_oriented(path)
                original_size = (im.width, im.height)
                im.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(im)
                state["photo_ref"] = photo
                image_label.configure(image=photo, text="")
                info_var.set(
                    f"Photo #{idx + 1} of {len(self.records)}  •  "
                    f"{Path(path).name}  •  "
                    f"{original_size[0]}×{original_size[1]}  •  "
                    f"{'Use' if rec.get('included', True) else 'Not selected'}"
                )
                self.selected_index = idx
            except Exception as exc:
                image_label.configure(
                    text=f"Could not display image:\n{exc}",
                    image="",
                )
                info_var.set(f"Photo #{idx + 1} • {Path(path).name}")

        def prev_photo():
            if not state["nav_indices"]:
                return
            state["nav_pos"] = (
                state["nav_pos"] - 1
            ) % len(state["nav_indices"])
            render_current()

        def next_photo():
            if not state["nav_indices"]:
                return
            state["nav_pos"] = (
                state["nav_pos"] + 1
            ) % len(state["nav_indices"])
            render_current()

        def on_resize(_event=None):
            # Debounce expensive re-decoding while a user drags the window edge.
            if state["resize_after"] is not None:
                try:
                    win.after_cancel(state["resize_after"])
                except Exception:
                    pass
            state["resize_after"] = win.after(180, render_current)

        ttk.Button(
            controls,
            text="◀ PREVIOUS",
            command=prev_photo,
        ).grid(row=0, column=0, padx=(0, 6))

        ttk.Label(
            controls,
            text="Previous/Next cycles through photos currently checked Use.",
            anchor="center",
        ).grid(row=0, column=1, sticky="ew")

        ttk.Button(
            controls,
            text="NEXT ▶",
            command=next_photo,
        ).grid(row=0, column=2, padx=(6, 0))

        ttk.Button(
            controls,
            text="CLOSE",
            command=win.destroy,
        ).grid(row=0, column=3, padx=(12, 0))

        win.bind("<Left>", lambda _e: prev_photo())
        win.bind("<Right>", lambda _e: next_photo())
        win.bind("<Escape>", lambda _e: win.destroy())
        image_frame.bind("<Configure>", on_resize)

        render_current()
        try:
            win.focus_set()
        except Exception:
            pass

    def select_all_photos(self):
        """Check Use on every photo currently loaded in the viewer."""
        changed = False
        for rec in self.records:
            if not rec.get("included", True):
                rec["included"] = True
                changed = True

        if changed:
            self._refresh()
            self._emit_change()

        self.log(
            f"Selected all {len(self.records)} photo(s) in the current viewer."
        )

    def clear_photo_selection(self):
        """Uncheck Use on every photo without deleting/removing the files."""
        changed = False
        for rec in self.records:
            if rec.get("included", True):
                rec["included"] = False
                changed = True

        if changed:
            self._refresh()
            self._emit_change()

        self.log(
            f"Cleared Use selection for {len(self.records)} photo(s). "
            "No files were removed."
        )

    def clear(self):
        # Clear only the current listing photos. A retained multi-item batch is
        # intentionally kept so the next product group can be opened afterward.
        self.records = []
        self.selected_index = None
        self._refresh()
        self._emit_change()
        if self.batch_paths:
            self.count_var.set(
                f"Current item cleared • {len(self.batch_paths)} batch photo(s) retained"
            )

    def show_existing_count(self, count):
        if not self.records and count:
            self.count_var.set(
                f"{count} existing eBay photo(s) will be preserved unless you add replacements"
            )

    def _on_gallery_mousewheel(self, event):
        """Scroll the thumbnail gallery when the pointer is anywhere over it."""
        if getattr(event, "delta", 0):
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        return "break"

    def _canvas_resized(self, event):
        self.canvas.itemconfigure(self.gallery_win, width=event.width)

        # Window resize events can fire dozens of times per second. Rebuilding
        # hundreds of thumbnail widgets on every pixel was a major slowdown.
        new_cols = max(2, max(500, event.width) // 155)
        if new_cols != self._gallery_last_cols:
            self._gallery_last_cols = new_cols
            self._refresh()

    def _refresh(self):
        for child in self.gallery.winfo_children():
            child.destroy()
        self._thumb_refs.clear()
        self._check_vars.clear()
        width = max(500, self.canvas.winfo_width())
        cols = max(2, width // 155)
        self._gallery_last_cols = cols
        for idx, rec in enumerate(self.records):
            card = ttk.Frame(self.gallery, padding=4, relief="ridge")
            card.grid(row=idx // cols, column=idx % cols, padx=4, pady=4, sticky="n")
            try:
                path = str(rec["path"])
                try:
                    stat = Path(path).stat()
                    cache_key = (
                        path,
                        int(stat.st_size),
                        int(stat.st_mtime_ns),
                        tuple(THUMB_SIZE),
                    )
                except Exception:
                    cache_key = (path, 0, 0, tuple(THUMB_SIZE))

                cached_im = self._gallery_thumb_cache.get(cache_key)
                if cached_im is None:
                    cached_im = _open_oriented(path)
                    cached_im.thumbnail(THUMB_SIZE, Image.Resampling.LANCZOS)
                    cached_im = cached_im.copy()
                    self._gallery_thumb_cache[cache_key] = cached_im

                    # 700 cached listing thumbnails is still modest memory use.
                    if len(self._gallery_thumb_cache) > 700:
                        for stale in list(self._gallery_thumb_cache.keys())[:120]:
                            self._gallery_thumb_cache.pop(stale, None)

                photo = ImageTk.PhotoImage(cached_im)
                self._thumb_refs.append(photo)
                lab = ttk.Label(card, image=photo, cursor="hand2")
            except Exception as exc:
                lab = ttk.Label(card, text="Preview\nunavailable", width=16, anchor="center")
            lab.pack()
            title = "MAIN" if idx == 0 else f"#{idx + 1}"
            if rec.get("remote_url"):
                title += "  • eBay"
            q = rec.get("quality") or {}
            if q:
                title += f"  Q {q.get('score', 0):.0f}"
            ttk.Label(card, text=title).pack()
            use_var = tk.BooleanVar(value=rec.get("included", True))
            self._check_vars.append(use_var)
            check = ttk.Checkbutton(card, text="Use", variable=use_var, command=lambda i=idx, v=use_var: self._toggle(i, v))
            check.pack()

            # Keep scrolling working even when the pointer is directly over a card,
            # thumbnail, or its Use checkbox.
            card.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            lab.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            check.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            if rec.get("redundant"):
                ttk.Label(card, text="similar/redundant").pack()
            # Store the record index on each visual element so pointer-based
            # drag/drop can determine which thumbnail is under the mouse.
            card._photo_index = idx
            lab._photo_index = idx

            lab.bind("<Button-1>", lambda e, i=idx: self._select(i))
            lab.bind(
                "<Double-1>",
                lambda e, i=idx: self.view_photo_large(i),
                add="+",
            )
            lab.bind("<Double-Button-1>", lambda e, i=idx: self._set_main_index(i))

            # True drag/drop: press on a thumbnail, move over another card,
            # then release. Tk keeps an implicit mouse grab on the source
            # widget, so release coordinates are resolved using root coordinates.
            lab.bind("<ButtonPress-1>", lambda e, i=idx: self._drag_start_event(e, i), add="+")
            lab.bind("<B1-Motion>", self._drag_motion, add="+")
            lab.bind("<ButtonRelease-1>", self._drag_release, add="+")
        self._update_count()
        self._show_preview()

    def _toggle(self, idx, var):
        if 0 <= idx < len(self.records):
            self.records[idx]["included"] = bool(var.get())
            # Main should never be silently excluded; if user clears it, the first included becomes main.
            if idx == 0 and not self.records[idx]["included"]:
                for j in range(1, len(self.records)):
                    if self.records[j].get("included", True):
                        self.records.insert(0, self.records.pop(j))
                        break
            self._emit_change()
            self._refresh()

    def _select(self, idx):
        self.selected_index = idx
        self._show_preview()

    def _show_preview(self):
        if self.selected_index is None or not (0 <= self.selected_index < len(self.records)):
            self.preview.configure(image="", text="Click a thumbnail\nto preview")
            self.detail_var.set("")
            return
        rec = self.records[self.selected_index]
        try:
            im = _open_oriented(rec["path"])
            original_size = im.size
            im.thumbnail(PREVIEW_SIZE, Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(im)
            self._preview_ref = photo
            self.preview.configure(image=photo, text="")
            q = rec.get("quality") or {}
            detail = f"{Path(rec['path']).name}\n{original_size[0]} × {original_size[1]} px"
            if q:
                detail += (
                    f"\nOverall {q.get('score', 0):.1f}/100"
                    f" • Sharp {q.get('sharpness', 0):.0f}"
                    f" • Exposure {q.get('exposure', 0):.0f}"
                    f" • Center {q.get('centering', 0):.0f}"
                )
            self.detail_var.set(detail)
        except Exception as exc:
            self.preview.configure(image="", text="Preview unavailable")
            note = str(exc)
            if Path(rec["path"]).suffix.lower() in {".heic", ".heif"} and not HEIF_AVAILABLE:
                note += "\nInstall pillow-heif for HEIC support."
            self.detail_var.set(f"{Path(rec['path']).name}\n{note}")

    def set_main(self):
        if self.selected_index is not None:
            self._set_main_index(self.selected_index)

    def _set_main_index(self, idx):
        if 0 <= idx < len(self.records):
            rec = self.records.pop(idx)
            rec["included"] = True
            self.records.insert(0, rec)
            self.selected_index = 0
            self._refresh()
            self._emit_change()

    def move_selected(self, delta):
        if self.selected_index is None:
            return
        src = self.selected_index
        dst = max(0, min(len(self.records) - 1, src + delta))
        if dst == src:
            return
        self.records[src], self.records[dst] = self.records[dst], self.records[src]
        self.selected_index = dst
        self._refresh()
        self._emit_change()

    def remove_selected(self):
        if self.selected_index is None:
            return
        del self.records[self.selected_index]
        if self.records:
            self.selected_index = min(self.selected_index, len(self.records) - 1)
        else:
            self.selected_index = None
        self._refresh()
        self._emit_change()

    def _drag_start_event(self, event, idx):
        self.drag_from = idx
        self.selected_index = idx
        try:
            event.widget.configure(cursor="fleur")
        except Exception:
            pass

    def _drag_motion(self, event):
        """Give lightweight feedback while a thumbnail is being dragged."""
        if self.drag_from is None:
            return
        try:
            event.widget.configure(cursor="fleur")
        except Exception:
            pass

    def _photo_index_under_pointer(self, root_x, root_y):
        """Find the thumbnail card underneath screen coordinates."""
        try:
            widget = self.winfo_containing(root_x, root_y)
        except Exception:
            return None

        # Walk upward until we find a card/label carrying a photo index.
        while widget is not None:
            if hasattr(widget, "_photo_index"):
                try:
                    return int(widget._photo_index)
                except Exception:
                    return None
            if widget == self:
                break
            widget = getattr(widget, "master", None)
        return None

    def _drag_release(self, event):
        src = self.drag_from
        self.drag_from = None
        try:
            event.widget.configure(cursor="hand2")
        except Exception:
            pass

        if src is None:
            return

        dst = self._photo_index_under_pointer(event.x_root, event.y_root)
        if dst is None or dst == src:
            self.selected_index = src
            self._show_preview()
            return

        if not (0 <= src < len(self.records) and 0 <= dst < len(self.records)):
            return

        rec = self.records.pop(src)

        # Insert at the visible destination position. Adjust for the list
        # shrinking when dragging toward the right/down.
        if src < dst:
            dst -= 1
        dst = max(0, min(dst, len(self.records)))
        self.records.insert(dst, rec)
        self.selected_index = dst

        self._refresh()
        self._emit_change()
        self.log(
            f"Photo reordered: {Path(rec['path']).name} is now position {dst + 1}"
        )


    def _emit_change(self):
        paths = list(self.selected_paths)
        try:
            self.on_change(paths)
        except Exception as exc:
            self.log(f"Photo selection callback error: {exc}")

    def _update_count(self):
        total = len(self.records)
        local_used = len(self.selected_paths)
        ebay_used = len(self.selected_existing_urls)
        if total:
            if ebay_used:
                self.count_var.set(
                    f"{local_used} local + {ebay_used} existing eBay photo(s) selected / {total} total"
                )
            else:
                self.count_var.set(f"{local_used} selected / {total} total")
        else:
            self.count_var.set("No photos selected")


# Expose the integrated manager only when Pillow loaded successfully.
PhotoManagerFrame = _IntegratedPhotoManagerFrame if Image is not None else None



class AIPhotoGrouper:
    """
    Cloud-assisted photo grouping for large mixed-item batches.

    Strategy:
      1. Locally create compact JPEG thumbnails.
      2. Send them to OpenAI in bounded batches.
      3. Ask only for item-group assignments and view labels.
      4. Merge batch groups conservatively using textual fingerprints.
      5. Track actual token cost and enforce a hard per-job spend cap.
    """

    def __init__(self, settings, cancel_event, log):
        self.s = settings
        self.cancel_event = cancel_event
        self.log = log

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    @staticmethod
    def _responses_output_text(response):
        pieces = []
        for item in response.get("output", []) or []:
            for content in item.get("content", []) or []:
                if content.get("type") == "output_text":
                    pieces.append(content.get("text", ""))
        return "\n".join(pieces).strip()

    @staticmethod
    def _cost_from_usage(model, usage):
        cost, input_tokens, cached_tokens, output_tokens, known = ai_cost_from_usage(
            model, usage
        )
        return cost, input_tokens, output_tokens, cached_tokens, known

    def _thumbnail_data_url(self, path, max_side=512, jpeg_quality=68):
        if Image is None:
            raise RuntimeError("Pillow is required for AI batch grouping.")
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((max_side, max_side))
            import io
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=jpeg_quality, optimize=True)
            raw = base64.b64encode(buf.getvalue()).decode("ascii")
        return "data:image/jpeg;base64," + raw

    def estimate_cost(self, photo_count):
        """
        Conservative planning estimate, not the final bill.
        Uses thumbnail/batch design rather than original full-resolution images.
        """
        # Tuned intentionally conservatively: roughly $0.0012/image plus response overhead.
        # 500 images ~= $0.60 planned estimate, leaving headroom under the $1 cap.
        return 0.015 + max(0, int(photo_count)) * 0.0012

    def _call_group_batch(self, indexed_paths):
        self._check_cancel()
        key = self.s.get("openai_api_key", "").strip()
        if not key:
            raise RuntimeError("No OpenAI API key is configured.")

        model = self.s.get("openai_model", "gpt-4.1-mini").strip() or "gpt-5.6-luna"

        content = [{
            "type": "input_text",
            "text": (
                "Group these product-listing photos by the physical/product item they appear "
                "to represent. Photos can show different angles of the same item. Be conservative: "
                "if uncertain whether two photos are the same item/model, keep them in separate "
                "groups rather than merging them. Use visible manufacturer, model/part-number "
                "labels, housing shape, connectors, markings and damage patterns when available. "
                "For each photo return: photo_index, group_key, view_label, confidence. "
                "group_key should be a short stable textual fingerprint such as "
                "'Fluke-87V-meter' or 'unknown-black-backplane-A'. view_label can be front, rear, "
                "side, top, bottom, label, connector, detail, packaging, or unknown. "
                "Do not describe unrelated scene content. Return only the requested JSON."
            )
        }]

        for idx, path in indexed_paths:
            self._check_cancel()
            content.append({"type": "input_text", "text": f"PHOTO_INDEX={idx}"})
            content.append({
                "type": "input_image",
                "image_url": self._thumbnail_data_url(path),
                "detail": "low",
            })

        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "assignments": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "photo_index": {"type": "integer"},
                            "group_key": {"type": "string"},
                            "view_label": {"type": "string"},
                            "confidence": {"type": "number"},
                        },
                        "required": ["photo_index", "group_key", "view_label", "confidence"],
                    },
                }
            },
            "required": ["assignments"],
        }

        payload = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "photo_item_grouping",
                    "strict": True,
                    "schema": schema,
                }
            },
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=180) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI grouping error {exc.code}:\n{body}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"OpenAI grouping network error: {exc}") from exc

        out = self._responses_output_text(raw)
        if not out:
            raise RuntimeError("AI grouping returned no structured result.")
        try:
            parsed = json.loads(out)
        except Exception as exc:
            raise RuntimeError("Could not parse AI grouping result.") from exc

        cost, input_tokens, output_tokens, cached_tokens, known_rate = (
            self._cost_from_usage(model, raw.get("usage", {}))
        )
        return (
            parsed.get("assignments", []) or [],
            cost,
            input_tokens,
            output_tokens,
            cached_tokens,
            known_rate,
        )

    def group(self, photo_paths, spend_cap=1.00, batch_size=24):
        self._check_cancel()
        paths = list(photo_paths)
        if not paths:
            return {"groups": [], "cost": 0.0, "input_tokens": 0, "output_tokens": 0}

        estimate = self.estimate_cost(len(paths))
        if estimate > spend_cap:
            raise RuntimeError(
                f"Estimated AI grouping cost ${estimate:.2f} exceeds the configured "
                f"${spend_cap:.2f} hard cap. Increase the cap or process fewer photos."
            )

        total_cost = 0.0
        total_in = 0
        total_out = 0
        assignments = []

        for start in range(0, len(paths), batch_size):
            self._check_cancel()
            if total_cost >= spend_cap:
                raise RuntimeError(
                    f"AI grouping stopped at the ${spend_cap:.2f} spend cap before "
                    "starting another batch."
                )
            batch = [(i, paths[i]) for i in range(start, min(start + batch_size, len(paths)))]
            self.log(
                f"AI grouping photos {start + 1}-{start + len(batch)} of {len(paths)}..."
            )
            (
                batch_assignments,
                cost,
                inp,
                outp,
                cached_inp,
                known_rate,
            ) = self._call_group_batch(batch)
            total_cost += cost
            total_in += inp
            total_out += outp

            if total_cost > spend_cap:
                raise RuntimeError(
                    f"AI grouping reached ${total_cost:.4f}, above the configured "
                    f"${spend_cap:.2f} cap. No additional batches will be sent."
                )
            assignments.extend(batch_assignments)
            self.log(
                f"Grouping batch cost ${cost:.4f} | running total ${total_cost:.4f}"
            )

        # Merge by normalized group_key. Because the model is conservative, this
        # intentionally permits duplicate/adjacent groups for the user to merge manually.
        grouped = {}
        meta = {}
        for a in assignments:
            idx = int(a.get("photo_index", -1))
            if not (0 <= idx < len(paths)):
                continue
            raw_key = str(a.get("group_key", "") or "").strip() or f"uncertain-{idx}"
            norm = re.sub(r"[^a-z0-9]+", "-", raw_key.lower()).strip("-") or f"uncertain-{idx}"
            grouped.setdefault(norm, []).append(paths[idx])
            meta.setdefault(norm, {
                "label": raw_key,
                "views": {},
                "confidence": [],
            })
            meta[norm]["views"][str(paths[idx])] = str(a.get("view_label", "unknown") or "unknown")
            try:
                meta[norm]["confidence"].append(float(a.get("confidence", 0.0) or 0.0))
            except Exception:
                pass

        groups = []
        for key, group_paths in grouped.items():
            confs = meta[key]["confidence"]
            groups.append({
                "key": key,
                "label": meta[key]["label"],
                "paths": group_paths,
                "views": meta[key]["views"],
                "confidence": (sum(confs) / len(confs)) if confs else 0.0,
            })

        groups.sort(key=lambda g: (-len(g["paths"]), g["label"].lower()))
        return {
            "groups": groups,
            "cost": total_cost,
            "input_tokens": total_in,
            "output_tokens": total_out,
            "estimate": estimate,
            "model": self.s.get("openai_model", "gpt-5.6-luna"),
        }



class PhotoAnalyzer:
    """Analyze listing photos with the OpenAI Responses API using only urllib."""

    def __init__(self, settings, cancel_event, log):
        self.s = settings
        self.cancel_event = cancel_event
        self.log = log

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    @staticmethod
    def _data_url(path):
        path = Path(path)
        mime = mimetypes.guess_type(path.name)[0] or "image/jpeg"
        raw = base64.b64encode(path.read_bytes()).decode("ascii")
        return f"data:{mime};base64,{raw}"

    @staticmethod
    def _extract_output_text(response):
        pieces = []
        for item in response.get("output", []):
            for content in item.get("content", []) or []:
                if content.get("type") == "output_text":
                    pieces.append(content.get("text", ""))
        return "\n".join(pieces).strip()

    def analyze(self, photo_paths):
        self._check_cancel()
        key = self.s.get("openai_api_key", "").strip()
        if not key:
            raise RuntimeError(
                "No OpenAI API key is configured. Open the eBay Settings tab "
                "and paste an API key."
            )

        model = self.s.get("openai_model", "gpt-4.1-mini").strip() or "gpt-5.6-luna"
        self.log(f"Analyzing {len(photo_paths)} photo(s) with {model}...")

        content = [{
            "type": "input_text",
            "text": (
                "You are helping create a conservative eBay listing for surplus "
                "industrial/electronic inventory. Analyze ALL supplied photos as one item. "
                "Read labels, manufacturer markings, model/part numbers, connector counts, "
                "ratings, dimensions if visibly printed, country of origin, date codes, "
                "and other useful markings. Do NOT invent specifications that are not "
                "visible or strongly supported. If uncertain, leave the field empty or "
                "mention uncertainty in review_notes. Condition must be based only on "
                "visible cosmetic evidence; do not claim the item was tested or working. "
                "Create an eBay-style title no longer than 80 characters. "
                "item_description must be a short generic noun phrase. "
                "specifics must contain useful eBay item-specific Name=Value pairs, one "
                "per line, excluding Brand, MPN, Model, and Country of Origin. "
                "condition_notes must be factual and cautious. "
                "Return only the requested structured data."
            ),
        }]

        for p in photo_paths[:12]:
            self._check_cancel()
            content.append({
                "type": "input_image",
                "image_url": self._data_url(p),
                "detail": "high",
            })

        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "brand": {"type": "string"},
                "mpn": {"type": "string"},
                "model": {"type": "string"},
                "item_description": {"type": "string"},
                "country": {"type": "string"},
                "title": {"type": "string"},
                "condition": {
                    "type": "string",
                    "enum": [
                        "New", "New - Open Box", "Used - Excellent",
                        "Used - Very Good", "Used - Good",
                        "Used - Acceptable", "For Parts / Not Working"
                    ]
                },
                "condition_notes": {"type": "string"},
                "specifics": {"type": "string"},
                "review_notes": {"type": "string"},
            },
            "required": [
                "brand", "mpn", "model", "item_description", "country", "title",
                "condition", "condition_notes", "specifics", "review_notes"
            ],
        }

        payload = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "ebay_listing_photo_analysis",
                    "strict": True,
                    "schema": schema,
                }
            },
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=120) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI API error {exc.code}:\n{body}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"OpenAI network error: {exc}") from exc

        self._check_cancel()
        out = self._extract_output_text(raw)
        if not out:
            raise RuntimeError("Photo analysis completed, but no structured result was returned.")

        try:
            result = json.loads(out)
        except Exception as exc:
            raise RuntimeError("Could not parse the AI photo-analysis result.") from exc

        result["title"] = (result.get("title") or "")[:80]

        estimated_cost, input_tokens, cached_tokens, output_tokens, known_rate = (
            ai_cost_from_usage(model, raw.get("usage", {}) or {})
        )
        result["_usage"] = {
            "model": model,
            "input_tokens": input_tokens,
            "cached_input_tokens": cached_tokens,
            "output_tokens": output_tokens,
            "estimated_cost": estimated_cost,
            "known_rate": known_rate,
        }
        return result

    def select_best_views(self, paths, max_final=12):
        """
        AI-assisted curation for ONE physical item.

        The AI groups photos by meaningful product view/angle and chooses the
        single best representative from each similar set, then chooses the
        strongest hero image for eBay position #1.
        """
        paths = [str(p) for p in paths if Path(str(p)).exists()]
        if not paths:
            raise RuntimeError("No photos were supplied for AI sorting.")
        if len(paths) > 125:
            raise RuntimeError(
                "AI Sort + Pick Best is limited to 125 photos for one physical item. "
                "Use Batch / Multiple Items first for larger mixed sets."
            )

        # Cheap local prefilter when there are a lot of nearly-duplicate shots.
        # It deliberately keeps 75% so AI still has enough visual variety to
        # recognize angles instead of local math deciding the final set.
        candidates = list(paths)
        if len(paths) > 20:
            scored = []
            for p in paths:
                try:
                    q = _quality(p)
                    scored.append((float(q.get("score", 0.0)), p))
                except Exception:
                    scored.append((0.0, p))
            scored.sort(reverse=True)
            keep_n = max(14, int(len(scored) * 0.75))
            candidates = [p for _, p in scored[:keep_n]]

        content = [{
            "type": "input_text",
            "text": (
                "You are curating eBay listing photos for ONE physical product. "
                "Group the supplied photos by meaningful VIEW/ANGLE, not merely "
                "by superficial visual similarity. Examples: front, rear, left "
                "side, right side, top, underside, connector end, label close-up, "
                "part-number close-up, damage/flaw detail, packaging. "
                "Within each view group choose exactly ONE best representative "
                "based on sharpness, framing, glare, lighting, centering, useful "
                "detail, obstruction, and how clearly the item is shown. "
                "Do NOT keep multiple near-identical photos of the same angle. "
                "Choose the strongest overall hero image for eBay photo #1. "
                "Keep unique label, connector, marking, and damage-detail photos "
                "even if they are less attractive because they convey unique information. "
                f"Return no more than {int(max_final)} final photos. "
                "Return ONLY JSON using exactly this shape: "
                '{"hero_index":0,"selected_indices":[0,3,5],'
                '"view_groups":[{"view":"front three-quarter","indices":[0,1,2],'
                '"best_index":0,"reason":"sharpest and least glare"}],'
                '"notes":"brief summary"}'
            ),
        }]

        for idx, p in enumerate(candidates):
            # Use a resized analysis copy to reduce upload size/cost while keeping
            # enough detail for angle, glare, framing, and sharpness judgment.
            im = _open_oriented(p)
            im.thumbnail((1200, 1200), Image.Resampling.LANCZOS)
            import io
            buf = io.BytesIO()
            im.convert("RGB").save(buf, format="JPEG", quality=82)
            b64 = base64.b64encode(buf.getvalue()).decode("ascii")

            content.append({
                "type": "input_text",
                "text": f"IMAGE_INDEX={idx} FILE={Path(p).name}",
            })
            content.append({
                "type": "input_image",
                "image_url": f"data:image/jpeg;base64,{b64}",
                "detail": "low",
            })

        body = {
            "model": self.s.get("openai_model", "gpt-4.1-mini"),
            "input": [{"role": "user", "content": content}],
            "max_output_tokens": 2200,
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Authorization": "Bearer " + self.s.get("openai_api_key", "").strip(),
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=180) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI API error {exc.code}:\n{raw}") from exc

        output_text = ""
        for item in result.get("output", []) or []:
            if not isinstance(item, dict):
                continue
            for part in item.get("content", []) or []:
                if isinstance(part, dict) and part.get("type") in ("output_text", "text"):
                    output_text += str(part.get("text", "") or "")

        cleaned = output_text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        try:
            parsed = json.loads(cleaned)
        except Exception as exc:
            raise RuntimeError(
                "OpenAI returned an unreadable AI photo-sort response.\n\n"
                + cleaned[:900]
            ) from exc

        chosen = []
        for raw_idx in parsed.get("selected_indices", []) or []:
            try:
                idx = int(raw_idx)
            except Exception:
                continue
            if 0 <= idx < len(candidates) and idx not in chosen:
                chosen.append(idx)

        try:
            hero = int(parsed.get("hero_index"))
        except Exception:
            hero = None

        if hero is not None and 0 <= hero < len(candidates):
            if hero in chosen:
                chosen.remove(hero)
            chosen.insert(0, hero)

        if not chosen:
            raise RuntimeError("AI did not select any photos.")

        chosen = chosen[:max_final]
        selected_paths = [candidates[i] for i in chosen]

        model = str(body.get("model", "") or "")
        ai_cost, input_tokens, cached_tokens, output_tokens, known_rate = (
            ai_cost_from_usage(model, result.get("usage", {}) or {})
        )

        return {
            "selected_paths": selected_paths,
            "rejected_paths": [p for p in paths if p not in selected_paths],
            "view_groups": parsed.get("view_groups", []) or [],
            "notes": str(parsed.get("notes", "") or ""),
            "_usage": {
                "model": model,
                "input_tokens": input_tokens,
                "cached_input_tokens": cached_tokens,
                "output_tokens": output_tokens,
                "estimated_cost": ai_cost,
                "known_rate": known_rate,
            },
        }



class EbayClient:
    def __init__(self, settings, cancel_event, log):
        self.s = settings
        self.cancel_event = cancel_event
        self.log = log
        self._refresh_attempted = False
        if settings.get("api_environment") == "sandbox":
            self.api_base = "https://api.sandbox.ebay.com"
            self.media_api_base = "https://apim.sandbox.ebay.com"
        else:
            self.api_base = "https://api.ebay.com"
            self.media_api_base = "https://apim.ebay.com"

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    def exchange_authorization_code(self, authorization_code, runame):
        """
        Exchange a one-time OAuth authorization code for:
          - User Access Token
          - Refresh Token
        """
        self._check_cancel()
        code = str(authorization_code or "").strip()
        runame = str(runame or "").strip()
        client_id = self.s.get("ebay_client_id", "").strip()
        client_secret = self.s.get("ebay_client_secret", "").strip()

        if not client_id or not client_secret:
            raise RuntimeError("Production App ID and Cert ID are required.")
        if not runame:
            raise RuntimeError("OAuth RuName is required.")
        if not code:
            raise RuntimeError("Authorization code is required.")

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        body = parse.urlencode({
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": runame,
        }).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(
                f"eBay authorization-code exchange error {exc.code}:\n{raw}"
            ) from exc
        except error.URLError as exc:
            raise RuntimeError(
                f"eBay authorization-code exchange network error: {exc}"
            ) from exc

        access_token = str(data.get("access_token", "") or "").strip()
        refresh_token = str(data.get("refresh_token", "") or "").strip()
        expires_in = int(data.get("expires_in", 0) or 0)
        refresh_expires_in = int(data.get("refresh_token_expires_in", 0) or 0)

        if not access_token or not refresh_token:
            raise RuntimeError(
                "eBay did not return both an access token and a refresh token."
            )

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_in": expires_in,
            "refresh_token_expires_in": refresh_expires_in,
        }

    def _refresh_user_access_token(self):
        """Use a long-lived eBay refresh token to mint a new short-lived access token."""
        refresh_token = self.s.get("ebay_refresh_token", "").strip()
        client_id = self.s.get("ebay_client_id", "").strip()
        client_secret = self.s.get("ebay_client_secret", "").strip()
        if not refresh_token or not client_id or not client_secret:
            return False

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "scope": " ".join([
                "https://api.ebay.com/oauth/api_scope",
                "https://api.ebay.com/oauth/api_scope/sell.inventory",
                "https://api.ebay.com/oauth/api_scope/sell.account",
                "https://api.ebay.com/oauth/api_scope/sell.fulfillment",
            ]),
        }
        body = parse.urlencode(payload).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            self.log(f"Automatic eBay token refresh failed: {exc}")
            return False

        new_token = str(data.get("access_token", "") or "").strip()
        if not new_token:
            return False

        self.s["access_token"] = new_token
        # Persist the new access token locally so subsequent client instances use it.
        try:
            current = load_settings()
            current.update(self.s)
            save_settings(current)
        except Exception:
            pass

        self.log("eBay access token refreshed automatically.")
        return True

    def _call_once(self, method, url, body=None, content_type="application/json", extra_headers=None):
        self._check_cancel()
        token = self.s.get("access_token", "").strip()
        if not token:
            raise RuntimeError("No eBay OAuth access token is configured.")

        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Language": "en-US",
        }
        if content_type:
            headers["Content-Type"] = content_type
        if extra_headers:
            headers.update(extra_headers)

        req = request.Request(url, data=body, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=45) as resp:
                raw = resp.read()
                text = raw.decode("utf-8", "replace") if raw else ""
                data = json.loads(text) if text.strip() else {}
                return resp.status, dict(resp.headers), data
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")

            # If a seller access token expired, transparently refresh it once
            # when a refresh token has been configured.
            if exc.code in (401, 403) and not self._refresh_attempted:
                self._refresh_attempted = True
                if self._refresh_user_access_token():
                    token = self.s.get("access_token", "").strip()
                    retry_headers = dict(headers)
                    retry_headers["Authorization"] = f"Bearer {token}"
                    retry_req = request.Request(
                        url, data=body, headers=retry_headers, method=method
                    )
                    try:
                        with request.urlopen(retry_req, timeout=45) as resp:
                            retry_raw = resp.read()
                            retry_text = retry_raw.decode("utf-8", "replace") if retry_raw else ""
                            retry_data = json.loads(retry_text) if retry_text.strip() else {}
                            return resp.status, dict(resp.headers), retry_data
                    except error.HTTPError as retry_exc:
                        raw = retry_exc.read().decode("utf-8", "replace")
                        exc = retry_exc

            try:
                details = json.loads(raw)
                pretty = json.dumps(details, indent=2)
            except Exception:
                if "<html" in raw.lower() or "<!doctype html" in raw.lower():
                    pretty = (
                        "eBay returned a temporary HTML server error page. "
                        "This is usually an eBay-side failure, not a bad listing field."
                    )
                else:
                    pretty = raw
            raise RuntimeError(f"eBay API error {exc.code}:\\n{pretty}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Network error: {exc}") from exc

    def _call(self, method, url, body=None, content_type="application/json", extra_headers=None):
        """Retry temporary eBay 502/503/504 failures before surfacing an error."""
        attempts = ((1, 0), (2, 2), (3, 5), (4, 10))
        self.log(f"eBay request: {method} {url}")
        last_error = None

        for attempt, delay in attempts:
            self._check_cancel()
            if delay:
                self.log(
                    f"eBay temporary API/server error. Retrying in {delay} seconds "
                    f"(attempt {attempt} of 4)..."
                )
                time.sleep(delay)

            try:
                return self._call_once(method, url, body, content_type, extra_headers)
            except RuntimeError as exc:
                last_error = exc
                msg = str(exc)
                transient = any(
                    token in msg
                    for token in (
                        "eBay API error 500:",
                        "eBay API error 502:",
                        "eBay API error 503:",
                        "eBay API error 504:",
                        '"errorId": 25001',
                        "Core Inventory Service internal error",
                        "A system error has occurred.",
                        '"errorId": 20500',
                        '"domain": "API_ACCOUNT"',
                        '"message": "System error."',
                    )
                )
                if not transient or attempt == 4:
                    if (
                        '"errorId": 20500' in msg
                        or '"domain": "API_ACCOUNT"' in msg
                    ):
                        raise RuntimeError(
                            "eBay's Account API returned system error 20500 after "
                            "multiple retries.\n\n"
                            "This is normally an eBay-side temporary failure while "
                            "loading business policies, not a problem with your listing "
                            "or saved policy IDs. Your existing settings were left unchanged.\n\n"
                            "Try Refresh eBay Details again in a few minutes."
                        ) from exc
                    raise

        raise last_error


    def _get_application_token(self):
        """Mint an eBay Application access token for public Buy/Browse APIs."""
        self._check_cancel()
        client_id = self.s.get("ebay_client_id", "").strip()
        client_secret = self.s.get("ebay_client_secret", "").strip()
        if not client_id or not client_secret:
            raise RuntimeError(
                "Price research needs your eBay App ID (Client ID) and Cert ID "
                "(Client Secret) in eBay Settings."
            )

        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        body = parse.urlencode({
            "grant_type": "client_credentials",
            "scope": "https://api.ebay.com/oauth/api_scope",
        }).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(
                f"eBay application-token error {exc.code}:\n{raw}"
            ) from exc
        except error.URLError as exc:
            raise RuntimeError(f"eBay application-token network error: {exc}") from exc

        token = data.get("access_token")
        if not token:
            raise RuntimeError("eBay did not return an Application access token.")
        return token

    def _buy_call(self, url):
        """GET an eBay Buy API endpoint using an Application access token."""
        self._check_cancel()
        token = self._get_application_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "X-EBAY-C-MARKETPLACE-ID": self.s.get("marketplace_id", "EBAY_US"),
        }
        req = request.Request(url, headers=headers, method="GET")
        try:
            with request.urlopen(req, timeout=45) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"eBay Browse API error {exc.code}:\n{raw}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"eBay Browse API network error: {exc}") from exc

    @staticmethod
    def _percentile(values, p):
        values = sorted(values)
        if not values:
            return None
        if len(values) == 1:
            return values[0]
        pos = (len(values) - 1) * p
        lo = int(math.floor(pos))
        hi = int(math.ceil(pos))
        if lo == hi:
            return values[lo]
        frac = pos - lo
        return values[lo] * (1 - frac) + values[hi] * frac

    def research_price(self, query, category_id=""):
        """
        Research current active Buy It Now listings on eBay.

        Recommendation goal: competitive, but not necessarily lowest.
        Uses a lower-middle market position after basic outlier rejection.
        """
        self._check_cancel()
        query = (query or "").strip()
        if not query:
            raise RuntimeError("There is not enough item information for price research.")

        params = {
            "q": query,
            "limit": "50",
            "filter": "buyingOptions:{FIXED_PRICE}",
        }
        if str(category_id or "").strip():
            params["category_ids"] = str(category_id).strip()

        url = (
            self.api_base
            + "/buy/browse/v1/item_summary/search?"
            + parse.urlencode(params)
        )
        self.log(f"Researching active eBay prices for: {query}")
        response = self._buy_call(url)
        items = response.get("itemSummaries", []) or []

        comps = []
        for item in items:
            price = (item.get("price", {}) or {})
            try:
                value = float(price.get("value"))
            except (TypeError, ValueError):
                continue
            currency = str(price.get("currency", "") or "")
            if value <= 0:
                continue
            if self.s.get("currency", "USD") and currency and currency != self.s.get("currency", "USD"):
                continue
            comps.append({
                "title": str(item.get("title", "") or ""),
                "price": value,
                "currency": currency or self.s.get("currency", "USD"),
                "url": str(item.get("itemWebUrl", "") or ""),
                "condition": str(item.get("condition", "") or ""),
            })

        if not comps:
            raise RuntimeError("eBay returned no usable active Buy It Now price matches.")

        values = sorted(c["price"] for c in comps)
        median_all = statistics.median(values)

        # Conservative outlier filter. Rare surplus parts can legitimately have
        # wide spreads, so don't make this too aggressive.
        filtered = [
            v for v in values
            if v >= median_all * 0.35 and v <= median_all * 3.0
        ]
        if len(filtered) < 3:
            filtered = values[:]

        low = min(filtered)
        median = statistics.median(filtered)
        high = max(filtered)

        if len(filtered) >= 5:
            raw_target = self._percentile(filtered, 0.40)
        elif len(filtered) >= 3:
            raw_target = statistics.median(filtered)
        else:
            raw_target = sum(filtered) / len(filtered)

        # Retail-style rounding without intentionally becoming the lowest offer.
        if raw_target >= 10:
            suggested = max(0.99, round(raw_target) - 0.01)
        else:
            suggested = max(0.99, round(raw_target, 2))

        # Never deliberately recommend below the observed low.
        if suggested < low:
            suggested = low

        comps_sorted = sorted(comps, key=lambda x: x["price"])
        return {
            "query": query,
            "count": len(comps),
            "used_count": len(filtered),
            "low": low,
            "median": median,
            "high": high,
            "suggested": suggested,
            "comparables": comps_sorted[:10],
        }

    def publish_offer(self, offer_id):
        """Explicitly publish one previously-created unpublished offer."""
        self._check_cancel()
        offer_id = str(offer_id or "").strip()
        if not offer_id:
            raise RuntimeError("No unpublished Offer ID is available to publish.")
        self.log(f"Publishing eBay offer {offer_id}...")
        _, _, response = self._call(
            "POST",
            self.api_base
            + "/sell/inventory/v1/offer/"
            + parse.quote(offer_id, safe="")
            + "/publish",
            b"",
            "application/json",
        )
        listing_id = str(response.get("listingId", "") or "")
        if not listing_id:
            raise RuntimeError(
                "eBay accepted the publish request but did not return a listingId."
            )
        return listing_id

    def get_inventory_locations(self):
        """Retrieve all Inventory API locations for the seller."""
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/location?limit=100&offset=0"
        self.log("Loading eBay inventory locations...")
        _, _, response = self._call("GET", url, None, None)
        return response.get("locations", []) or []

    def create_warehouse_location(self, merchant_key, name, postal_code, country="US"):
        """Create a normal WAREHOUSE inventory location."""
        self._check_cancel()
        merchant_key = str(merchant_key or "").strip()
        name = str(name or "").strip()
        postal_code = str(postal_code or "").strip()
        country = str(country or "US").strip().upper()

        if not merchant_key:
            raise RuntimeError("Merchant Location Key is required.")
        if len(merchant_key) > 50:
            raise RuntimeError("Merchant Location Key cannot exceed 50 characters.")
        if not name:
            raise RuntimeError("Location name is required.")
        if not postal_code or not country:
            raise RuntimeError("Postal code and country are required.")

        payload = {
            "location": {
                "address": {
                    "postalCode": postal_code,
                    "country": country,
                }
            },
            "name": name,
            "merchantLocationStatus": "ENABLED",
            "locationTypes": ["WAREHOUSE"],
        }

        url = (
            self.api_base
            + "/sell/inventory/v1/location/"
            + parse.quote(merchant_key, safe="")
        )
        self.log(f"Creating eBay warehouse location '{merchant_key}'...")
        self._call(
            "POST",
            url,
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )
        return merchant_key

    def get_business_policies(self):
        """Return the seller's fulfillment, payment, and return policies."""
        self._check_cancel()
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        endpoints = {
            "fulfillment": ("fulfillment_policy", "fulfillmentPolicies", "fulfillmentPolicyId"),
            "payment": ("payment_policy", "paymentPolicies", "paymentPolicyId"),
            "return": ("return_policy", "returnPolicies", "returnPolicyId"),
        }
        result = {}
        for kind, (endpoint, list_key, id_key) in endpoints.items():
            url = (
                self.api_base
                + f"/sell/account/v1/{endpoint}?marketplace_id="
                + parse.quote(marketplace, safe="")
            )
            self.log(f"Loading eBay {kind} policies...")
            _, _, response = self._call("GET", url, None, None)
            policies = response.get(list_key, []) or []
            # Be tolerant of response-wrapper changes.
            if not policies:
                for value in response.values():
                    if isinstance(value, list) and value and isinstance(value[0], dict):
                        if id_key in value[0]:
                            policies = value
                            break
            result[kind] = [
                {
                    "id": str(p.get(id_key, "") or ""),
                    "name": str(p.get("name", "") or ""),
                    "raw": p,
                }
                for p in policies
                if p.get(id_key)
            ]
        return result

    def check_inventory_api(self):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/getVersion"
        self.log("DRAFT PREFLIGHT: Checking eBay Inventory API access...")
        try:
            _, _, response = self._call("GET", url, None, None)
        except Exception as exc:
            msg = str(exc)
            if "404" in msg and ("2002" in msg or "Resource not found" in msg or "Resource not resolved" in msg):
                raise RuntimeError(
                    "eBay Inventory API preflight returned HTTP 404 / error 2002.\n\n"
                    "eBay could not resolve the Inventory API resource. Check Production/Sandbox "
                    "and confirm OAuth was authorized with sell.inventory."
                ) from exc
            if "401" in msg or "1001" in msg:
                raise RuntimeError(
                    "eBay rejected the access token during Inventory API preflight. "
                    "Refresh or re-authorize OAuth."
                ) from exc
            if "403" in msg or "1100" in msg:
                raise RuntimeError(
                    "eBay denied Inventory API access. Re-authorize OAuth with sell.inventory."
                ) from exc
            raise
        self.log("DRAFT PREFLIGHT COMPLETE: Inventory API responded successfully.")
        return response

    def get_all_active_listings(self):
        """
        Retrieve the seller's complete current Active List with Trading API
        GetMyeBaySelling. This includes listings created in Seller Hub/eBay UI,
        not only listings created through Inventory API.
        """
        self._check_cancel()
        token = self.s.get("access_token", "").strip()
        if not token:
            raise RuntimeError("No eBay OAuth access token is configured.")

        endpoint = (
            "https://api.sandbox.ebay.com/ws/api.dll"
            if self.s.get("api_environment") == "sandbox"
            else "https://api.ebay.com/ws/api.dll"
        )

        page = 1
        per_page = 200
        results = []

        while True:
            self._check_cancel()
            xml_text = (
                '<?xml version="1.0" encoding="utf-8"?>'
                '<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">'
                '<DetailLevel>ReturnAll</DetailLevel>'
                '<ActiveList><Include>true</Include><Pagination>'
                f'<EntriesPerPage>{per_page}</EntriesPerPage>'
                f'<PageNumber>{page}</PageNumber>'
                '</Pagination></ActiveList>'
                '</GetMyeBaySellingRequest>'
            )
            body = xml_text.encode("utf-8")

            def make_request(access_token):
                return request.Request(
                    endpoint,
                    data=body,
                    headers={
                        "X-EBAY-API-CALL-NAME": "GetMyeBaySelling",
                        "X-EBAY-API-COMPATIBILITY-LEVEL": "1477",
                        "X-EBAY-API-SITEID": "0",
                        "X-EBAY-API-IAF-TOKEN": access_token,
                        "Content-Type": "text/xml",
                        "Accept": "text/xml",
                    },
                    method="POST",
                )

            try:
                with request.urlopen(make_request(token), timeout=60) as resp:
                    raw = resp.read().decode("utf-8", "replace")
            except error.HTTPError as exc:
                if exc.code in (401, 403) and not self._refresh_attempted:
                    self._refresh_attempted = True
                    if self._refresh_user_access_token():
                        token = self.s.get("access_token", "").strip()
                        with request.urlopen(make_request(token), timeout=60) as resp:
                            raw = resp.read().decode("utf-8", "replace")
                    else:
                        raise
                else:
                    detail = exc.read().decode("utf-8", "replace")
                    raise RuntimeError(
                        f"eBay Trading API error {exc.code} while loading current listings:\n"
                        + detail[:2000]
                    ) from exc

            root = ET.fromstring(raw)
            ns = {"e": "urn:ebay:apis:eBLBaseComponents"}
            ack = (root.findtext("e:Ack", default="", namespaces=ns) or "").upper()
            if ack not in ("SUCCESS", "WARNING"):
                errors = []
                for er in root.findall("e:Errors", ns):
                    code = er.findtext("e:ErrorCode", default="", namespaces=ns)
                    msg = (
                        er.findtext("e:LongMessage", default="", namespaces=ns)
                        or er.findtext("e:ShortMessage", default="", namespaces=ns)
                    )
                    errors.append(f"{code}: {msg}".strip(": "))
                raise RuntimeError(
                    "eBay could not load current active listings.\n\n" + "\n".join(errors)
                )

            items = root.findall(".//e:ActiveList/e:ItemArray/e:Item", ns)
            for item in items:
                item_id = (item.findtext("e:ItemID", default="", namespaces=ns) or "").strip()
                if not item_id:
                    continue
                title = (item.findtext("e:Title", default="", namespaces=ns) or "").strip()
                sku = (item.findtext("e:SKU", default="", namespaces=ns) or "").strip()
                qty_text = (
                    item.findtext("e:QuantityAvailable", default="", namespaces=ns)
                    or item.findtext("e:Quantity", default="1", namespaces=ns)
                    or "1"
                )
                try:
                    qty = int(float(qty_text))
                except Exception:
                    qty = 1
                results.append({
                    "item_number": item_id,
                    "title": title,
                    "sku": sku,
                    "quantity_available": qty,
                })

            total_pages_text = root.findtext(
                ".//e:ActiveList/e:PaginationResult/e:TotalNumberOfPages",
                default="1",
                namespaces=ns,
            )
            try:
                total_pages = max(1, int(total_pages_text or 1))
            except Exception:
                total_pages = 1

            if page >= total_pages:
                break
            page += 1

        return results

    def get_recent_orders(self, days=90):
        """Return recent seller orders for local inventory status synchronization."""
        self._check_cancel()
        days = max(1, min(int(days or 90), 90))
        start_ts = time.time() - (days * 86400)
        start_iso = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(start_ts))
        filter_value = f"creationdate:[{start_iso}..]"
        offset = 0
        orders = []
        while True:
            query = parse.urlencode({
                "filter": filter_value,
                "limit": "50",
                "offset": str(offset),
            })
            url = self.api_base + "/sell/fulfillment/v1/order?" + query
            _, _, response = self._call("GET", url, None, None)
            if not isinstance(response, dict):
                break
            batch = response.get("orders", []) or []
            orders.extend([o for o in batch if isinstance(o, dict)])
            total = int(response.get("total", len(orders)) or len(orders))
            offset += len(batch)
            if not batch or offset >= total:
                break
        return orders

    def get_offer(self, offer_id):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/offer/" + parse.quote(str(offer_id), safe="")
        _, _, response = self._call("GET", url, None, None)
        return response

    def get_offers_by_sku(self, sku):
        self._check_cancel()
        url = (
            self.api_base
            + "/sell/inventory/v1/offer?sku="
            + parse.quote(str(sku), safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        return response.get("offers", []) or []

    def get_inventory_item(self, sku):
        self._check_cancel()
        url = (
            self.api_base
            + "/sell/inventory/v1/inventory_item/"
            + parse.quote(str(sku), safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        return response

    def get_item_condition_policies(self, category_id):
        """Retrieve and normalize eBay category-specific item conditions."""
        self._check_cancel()
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        category_id = str(category_id or "").strip()
        if not category_id:
            raise RuntimeError("Category ID is required to retrieve condition policies.")

        filter_value = f"categoryIds:{{{category_id}}}"
        url = (
            self.api_base
            + "/sell/metadata/v1/marketplace/"
            + parse.quote(marketplace, safe="")
            + "/get_item_condition_policies?filter="
            + parse.quote(filter_value, safe="")
        )

        self.log(f"Loading valid eBay conditions for category {category_id}...")
        _, _, response = self._call("GET", url, None, None)

        if not isinstance(response, dict):
            self.log(
                f"Condition metadata returned {type(response).__name__}, not an object."
            )
            return {"required": False, "conditions": []}

        raw_policies = response.get("itemConditionPolicies", []) or []
        if isinstance(raw_policies, dict):
            raw_policies = [raw_policies]
        elif isinstance(raw_policies, str):
            raw_policies = []
        elif not isinstance(raw_policies, list):
            try:
                raw_policies = list(raw_policies)
            except Exception:
                raw_policies = []

        policies = [p for p in raw_policies if isinstance(p, dict)]

        policy = next(
            (
                p for p in policies
                if str(p.get("categoryId", "") or "") == category_id
            ),
            policies[0] if policies else None,
        )
        if not isinstance(policy, dict):
            return {"required": False, "conditions": []}

        raw_conditions = policy.get("itemConditions", []) or []
        if isinstance(raw_conditions, dict):
            raw_conditions = [raw_conditions]
        elif isinstance(raw_conditions, (str, int, float)):
            raw_conditions = [raw_conditions]
        elif not isinstance(raw_conditions, list):
            try:
                raw_conditions = list(raw_conditions)
            except Exception:
                raw_conditions = []

        enum_to_id = {
            "NEW": "1000",
            "NEW_OTHER": "1500",
            "NEW_WITH_DEFECTS": "1750",
            "CERTIFIED_REFURBISHED": "2000",
            "EXCELLENT_REFURBISHED": "2010",
            "VERY_GOOD_REFURBISHED": "2020",
            "GOOD_REFURBISHED": "2030",
            "SELLER_REFURBISHED": "2500",
            "USED_EXCELLENT": "3000",
            "USED_VERY_GOOD": "4000",
            "USED_GOOD": "5000",
            "USED_ACCEPTABLE": "6000",
            "FOR_PARTS_OR_NOT_WORKING": "7000",
        }

        normalized = []
        for entry in raw_conditions:
            cid = ""
            desc = ""
            help_text = ""

            if isinstance(entry, dict):
                cid = str(
                    entry.get("conditionId")
                    or entry.get("id")
                    or entry.get("condition")
                    or ""
                ).strip()
                desc = str(
                    entry.get("conditionDescription")
                    or entry.get("description")
                    or entry.get("displayName")
                    or ""
                ).strip()
                help_text = str(
                    entry.get("conditionHelpText")
                    or entry.get("help")
                    or ""
                ).strip()

            elif isinstance(entry, (str, int, float)):
                raw = str(entry).strip()
                if raw.isdigit():
                    cid = raw
                else:
                    cid = enum_to_id.get(raw.upper(), "")
                    desc = raw

            if cid:
                normalized.append({
                    "id": cid,
                    "description": desc,
                    "help": help_text,
                })
            else:
                self.log(
                    "Skipped unrecognized eBay condition metadata entry: "
                    f"{type(entry).__name__} {str(entry)[:100]}"
                )

        self.log(
            f"Condition metadata normalized: {len(normalized)} value(s) "
            f"for category {category_id}."
        )

        return {
            "required": bool(policy.get("itemConditionRequired", False)),
            "conditions": normalized,
        }

    def get_inventory_items(self, limit=100):
        """Retrieve up to limit Inventory API records for this seller."""
        self._check_cancel()
        limit = max(1, min(100, int(limit or 100)))
        url = self.api_base + f"/sell/inventory/v1/inventory_item?limit={limit}&offset=0"
        _, _, response = self._call("GET", url, None, None)
        return response.get("inventoryItems", []) or []

    def get_item_aspects_for_category(self, category_id):
        """Return Taxonomy aspect metadata for one eBay leaf category."""
        self._check_cancel()
        category_id = str(category_id or "").strip()
        if not category_id:
            raise RuntimeError("Category ID is required to retrieve item specifics.")

        tree_id = self.get_default_category_tree_id()
        self.log(
            f"Loading eBay category aspects for category {category_id} "
            f"(tree {tree_id})..."
        )

        # eBay documentation/examples have used both v1_beta and v1 for this
        # Taxonomy method. Try the current beta route first, then the stable route
        # before concluding the category/resource is bad.
        urls = [
            (
                self.api_base
                + "/commerce/taxonomy/v1_beta/category_tree/"
                + parse.quote(tree_id, safe="")
                + "/get_item_aspects_for_category?category_id="
                + parse.quote(category_id, safe="")
            ),
            (
                self.api_base
                + "/commerce/taxonomy/v1/category_tree/"
                + parse.quote(tree_id, safe="")
                + "/get_item_aspects_for_category?category_id="
                + parse.quote(category_id, safe="")
            ),
        ]

        errors = []
        for url in urls:
            try:
                _, _, response = self._call("GET", url, None, None)
                if not isinstance(response, dict):
                    raise RuntimeError(
                        "eBay Taxonomy returned an unexpected response while "
                        "checking item specifics."
                    )
                aspects = response.get("aspects", []) or []
                self.log(
                    f"Category {category_id}: eBay returned {len(aspects)} aspect(s)."
                )
                return aspects
            except Exception as exc:
                msg = str(exc)
                errors.append(msg)
                if not (
                    "404" in msg
                    or "2002" in msg
                    or "Resource not found" in msg
                    or "Resource not resolved" in msg
                ):
                    raise

        raise RuntimeError(
            f"eBay could not load item-specific metadata for category {category_id}.\n\n"
            "The category may be stale, non-leaf, or not part of the current "
            "marketplace category tree. Re-run Suggest eBay Category and choose "
            "the most specific leaf category before listing."
        )


    def get_default_category_tree_id(self):
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        url = (
            self.api_base
            + "/commerce/taxonomy/v1/get_default_category_tree_id?marketplace_id="
            + parse.quote(marketplace, safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        tree_id = response.get("categoryTreeId")
        if not tree_id:
            raise RuntimeError("eBay did not return a default category tree ID.")
        return str(tree_id)

    def suggest_category(self, query):
        self._check_cancel()
        query = (query or "").strip()
        if not query:
            raise RuntimeError("There is not enough item information to request an eBay category.")

        self.log("Asking eBay for category suggestions...")
        tree_id = self.get_default_category_tree_id()
        url = (
            self.api_base
            + "/commerce/taxonomy/v1/category_tree/"
            + parse.quote(tree_id, safe="")
            + "/get_category_suggestions?q="
            + parse.quote(query, safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        suggestions = response.get("categorySuggestions", []) or []
        if not suggestions:
            raise RuntimeError("eBay returned no category suggestions for this item.")

        best = suggestions[0]
        category = best.get("category", {}) or {}
        category_id = str(category.get("categoryId", "") or "")
        category_name = str(category.get("categoryName", "") or "")
        ancestors = best.get("categoryTreeNodeAncestors", []) or []
        breadcrumb = " > ".join(
            [str(a.get("categoryName", "")) for a in ancestors if a.get("categoryName")]
            + ([category_name] if category_name else [])
        )
        if not category_id:
            raise RuntimeError("eBay's top category suggestion did not include a category ID.")
        return {
            "category_id": category_id,
            "category_name": category_name,
            "breadcrumb": breadcrumb or category_name,
            "suggestions": suggestions[:5],
        }

    def upload_image(self, path):
        self._check_cancel()
        path = Path(path)
        data = path.read_bytes()
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        body, multipart_type = encode_multipart("image", path.name, data, ctype)
        url = self.media_api_base + "/commerce/media/v1_beta/image/create_image_from_file"
        self.log(f"Uploading photo to eBay Picture Services: {path.name}")
        self.log(
            "Media API host: "
            + ("Sandbox apim.sandbox.ebay.com" if self.s.get("api_environment") == "sandbox"
               else "Production apim.ebay.com")
        )
        try:
            status, headers, response = self._call("POST", url, body, multipart_type)
        except RuntimeError as exc:
            if "eBay API error 404:" in str(exc):
                raise RuntimeError(
                    "eBay Media API returned 404 while uploading a photo.\n\n"
                    "V4.21.0 uses eBay's dedicated Media API host (apim.ebay.com). "
                    "If this still occurs, verify the OAuth token includes sell.inventory "
                    "and that Production/Sandbox credentials are not mixed."
                ) from exc
            raise
        image_url = response.get("imageUrl")
        if not image_url:
            # Some responses may require retrieving the created image resource.
            location = headers.get("Location") or headers.get("location")
            if location:
                image_id = location.rstrip("/").split("/")[-1]
                _, _, details = self._call(
                    "GET",
                    self.media_api_base + f"/commerce/media/v1_beta/image/{parse.quote(image_id)}",
                    None,
                    None,
                )
                image_url = details.get("imageUrl")
        if not image_url:
            raise RuntimeError(f"eBay accepted {path.name}, but no image URL was returned.")
        return image_url

    def create_inventory_item(self, sku, listing):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/inventory_item/" + parse.quote(sku, safe="")
        aspects = parse_specifics(listing["specifics"])

        # Never send a combined "BrandMPN" item specific. eBay models Brand and
        # MPN as two separate values/fields.
        for key in list(aspects.keys()):
            if str(key).strip().lower().replace(" ", "") == "brandmpn":
                raise RuntimeError(
                    "Remove the combined Extra Item Specific 'BrandMPN'.\n\n"
                    "Enter the manufacturer in Brand / Manufacturer and the part "
                    "number in MPN / Part Number as separate fields."
                )

        # If Brand/MPN were entered only in Extra Item Specifics, copy them into
        # the product identifier fields too. This keeps both representations in sync.
        def _first_aspect_value(name):
            for k, values in aspects.items():
                if str(k).strip().lower() == name.lower():
                    if isinstance(values, list) and values:
                        return str(values[0]).strip()
                    if values:
                        return str(values).strip()
            return ""

        if not listing.get("brand"):
            listing["brand"] = _first_aspect_value("Brand")
        if not listing.get("mpn"):
            listing["mpn"] = _first_aspect_value("MPN")

        # Common specifics get included automatically unless already supplied.
        if listing["brand"] and "Brand" not in aspects:
            aspects["Brand"] = [listing["brand"]]
        if listing["mpn"] and "MPN" not in aspects:
            aspects["MPN"] = [listing["mpn"]]
        if listing["model"] and "Model" not in aspects:
            aspects["Model"] = [listing["model"]]
        if listing["country"] and "Country of Origin" not in aspects:
            aspects["Country of Origin"] = [listing["country"]]

        product = {
            "title": listing["title"][:80],
            "description": listing["description"],
            "aspects": aspects,
            "imageUrls": listing["image_urls"],
        }
        if listing["brand"]:
            product["brand"] = listing["brand"]
        if listing["mpn"]:
            product["mpn"] = listing["mpn"]

        payload = {
            "availability": {
                "shipToLocationAvailability": {
                    "quantity": int(listing["quantity"])
                }
            },
            "condition": CONDITION_MAP[listing["condition"]],
            "product": product,
        }

        package = {}
        if listing.get("package_dimensions"):
            dims = listing["package_dimensions"]
            package["dimensions"] = {
                "length": float(dims["length"]),
                "width": float(dims["width"]),
                "height": float(dims["height"]),
                "unit": "INCH",
            }
        if listing.get("package_weight_oz") is not None:
            package["weight"] = {
                "value": float(listing["package_weight_oz"]),
                "unit": "OUNCE",
            }
        if package:
            package["packageType"] = listing.get("package_type") or "PACKAGE_THICK_ENVELOPE"
            payload["packageWeightAndSize"] = package

        # eBay ignores conditionDescription for some "new" conditions.
        if listing["condition_notes"].strip():
            payload["conditionDescription"] = listing["condition_notes"].strip()

        self.log("Creating/updating eBay inventory item...")
        self._call(
            "PUT",
            url,
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )

    def _listing_policies_payload(self, listing):
        policies = {
            "paymentPolicyId": listing["payment_policy_id"].strip(),
            "returnPolicyId": listing["return_policy_id"].strip(),
            "fulfillmentPolicyId": listing["fulfillment_policy_id"].strip(),
        }
        if listing.get("best_offer_enabled"):
            terms = {"bestOfferEnabled": True}
            currency = self.s.get("currency", "USD")
            if listing.get("auto_accept_price") is not None:
                terms["autoAcceptPrice"] = {
                    "value": f'{float(listing["auto_accept_price"]):.2f}',
                    "currency": currency,
                }
            if listing.get("auto_decline_price") is not None:
                terms["autoDeclinePrice"] = {
                    "value": f'{float(listing["auto_decline_price"]):.2f}',
                    "currency": currency,
                }
            policies["bestOfferTerms"] = terms
        else:
            policies["bestOfferTerms"] = {"bestOfferEnabled": False}
        return policies

    def _validate_offer_requirements(self, listing):
        s = self.s
        required = {
            "Category ID": listing.get("category_id"),
            "Merchant Location Key": s.get("merchant_location_key"),
            "Payment Policy": listing.get("payment_policy_id"),
            "Return Policy": listing.get("return_policy_id"),
            "Fulfillment / Shipping Policy": listing.get("fulfillment_policy_id"),
        }
        missing = [k for k, v in required.items() if not str(v or "").strip()]
        if missing:
            raise RuntimeError(
                "Missing required eBay setup value(s):\n- " + "\n- ".join(missing)
            )

    def create_offer(self, sku, listing):
        self._check_cancel()
        self._validate_offer_requirements(listing)
        s = self.s
        payload = {
            "sku": sku,
            "marketplaceId": s.get("marketplace_id", "EBAY_US"),
            "format": "FIXED_PRICE",
            "categoryId": listing["category_id"].strip(),
            "merchantLocationKey": s["merchant_location_key"].strip(),
            "availableQuantity": int(listing["quantity"]),
            "listingDescription": listing["description"],
            "listingDuration": "GTC",
            "pricingSummary": {
                "price": {
                    "value": f'{float(listing["price"]):.2f}',
                    "currency": s.get("currency", "USD"),
                }
            },
            "listingPolicies": self._listing_policies_payload(listing),
        }
        self.log("Creating UNPUBLISHED Buy It Now eBay offer...")
        _, _, response = self._call(
            "POST",
            self.api_base + "/sell/inventory/v1/offer",
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )
        offer_id = response.get("offerId")
        if not offer_id:
            raise RuntimeError(
                "The Inventory item was created, but eBay did not return an offerId."
            )
        return offer_id

    def update_offer(self, offer_id, listing, original_offer):
        """Completely replace an existing offer while preserving fetched settings."""
        self._check_cancel()

        if not isinstance(listing, dict):
            raise RuntimeError(
                "Internal offer-update error: listing data must be a dictionary, "
                f"but received {type(listing).__name__}. "
                "The offer was not changed."
            )
        if original_offer is not None and not isinstance(original_offer, dict):
            raise RuntimeError(
                "Internal offer-update error: original eBay offer must be a dictionary, "
                f"but received {type(original_offer).__name__}. "
                "The offer was not changed."
            )

        self._validate_offer_requirements(listing)
        s = self.s

        # eBay recommends starting with the object returned by getOffer because
        # updateOffer is a complete replacement. Remove response-only identifiers.
        payload = dict(original_offer or {})
        for key in ("offerId", "status", "listing", "sku"):
            payload.pop(key, None)

        payload["marketplaceId"] = payload.get(
            "marketplaceId", s.get("marketplace_id", "EBAY_US")
        )
        payload["format"] = "FIXED_PRICE"
        payload["categoryId"] = listing["category_id"].strip()
        payload["merchantLocationKey"] = s["merchant_location_key"].strip()
        payload["availableQuantity"] = int(listing["quantity"])
        payload["listingDescription"] = listing["description"]
        payload["listingDuration"] = payload.get("listingDuration") or "GTC"
        payload["pricingSummary"] = {
            "price": {
                "value": f'{float(listing["price"]):.2f}',
                "currency": s.get("currency", "USD"),
            }
        }
        payload["listingPolicies"] = self._listing_policies_payload(listing)

        self.log(f"Updating eBay offer {offer_id}...")
        self._call(
            "PUT",
            self.api_base + "/sell/inventory/v1/offer/" + parse.quote(str(offer_id), safe=""),
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )


class ListingTool(tk.Tk):
    def __init__(self):
        self._set_windows_app_identity()
        super().__init__()
        self.title(APP_NAME)
        self._set_window_icon()
        self.geometry("1180x900")
        self.minsize(1040, 760)

        self.settings = load_settings()
        self.photos = []
        self.cancel_event = threading.Event()
        self.worker = None
        self.session_ai_cost = 0.0
        self.session_ai_analyses = 0
        self.last_category_name = ""
        self.existing_image_urls = []
        self.editing_offer_id = ""
        self.editing_offer_status = ""
        self.original_offer = None
        self.original_inventory_item = None
        self.policy_maps = {"fulfillment": {}, "payment": {}, "return": {}}
        self.inventory_db_path = ensure_inventory_db()
        self.inventory_trees = {}
        self.inventory_search_var = tk.StringVar(value="")
        self.inventory_status_var = tk.StringVar(value="")

        self._configure_style()
        self._build_ui()
        self._install_text_context_menus()
        self._validate_ui_callbacks()
        self.bind('<Control-s>', lambda e: self._save_listing_file())
        self.bind('<Control-p>', lambda e: self._preview())
        self._new_listing()
        self.after(2500, self._inventory_background_sync)
        self.after(5000, lambda: self._check_for_updates(silent=True))

    @staticmethod
    def _set_windows_app_identity():
        """Give Windows a stable app identity so the taskbar can show our custom icon."""
        if os.name != "nt":
            return
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "TradeComponents.eBayListingTool"
            )
        except Exception:
            pass

    def _sort_treeview_column(self, tree, column):
        """Sort a Treeview by the clicked column; repeated clicks reverse direction."""
        if tree is None:
            return

        if not hasattr(self, "_tree_sort_states"):
            self._tree_sort_states = {}

        key = (str(tree), column)
        reverse = not self._tree_sort_states.get(key, False)
        self._tree_sort_states[key] = reverse

        def sort_key(iid):
            raw = str(tree.set(iid, column) or "").strip()
            cleaned = raw.replace(",", "").replace("$", "").replace("%", "")
            try:
                return (0, float(cleaned))
            except Exception:
                pass
            # Natural-ish text sort so A2 comes before A10.
            parts = re.split(r"(\d+)", raw.casefold())
            cooked = []
            for part in parts:
                if part.isdigit():
                    cooked.append((0, int(part)))
                else:
                    cooked.append((1, part))
            return (1, cooked)

        children = list(tree.get_children(""))
        children.sort(key=sort_key, reverse=reverse)
        for index, iid in enumerate(children):
            tree.move(iid, "", index)


    @staticmethod
    def _version_tuple(value):
        nums = re.findall(r"\d+", str(value or ""))
        return tuple(int(x) for x in nums[:4]) or (0,)

    def _fetch_update_manifest(self):
        req = request.Request(
            UPDATE_MANIFEST_URL,
            headers={
                "User-Agent": f"TradeComponents-eBay-Listing-Tool/{APP_VERSION}",
                "Cache-Control": "no-cache",
            },
            method="GET",
        )
        with request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8", "replace")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise RuntimeError("The update manifest is not a JSON object.")

        version = str(data.get("version", "") or "").strip()
        filename = str(data.get("file", "") or "").strip()
        if not version or not filename:
            raise RuntimeError("version.json must contain both 'version' and 'file'.")
        if "/" in filename or "\\" in filename or filename.startswith("."):
            raise RuntimeError("The update filename in version.json is invalid.")
        if not filename.lower().endswith(".zip"):
            raise RuntimeError("The update file must be a .zip archive.")

        return {
            "version": version,
            "file": filename,
            "sha256": str(data.get("sha256", "") or "").strip().lower(),
        }

    def _check_for_updates(self, silent=False):
        def work():
            try:
                manifest = self._fetch_update_manifest()
                latest = manifest["version"]
                newer = self._version_tuple(latest) > self._version_tuple(APP_VERSION)

                if not newer:
                    if not silent:
                        self.after(
                            0,
                            lambda: messagebox.showinfo(
                                "Software Update",
                                f"You're up to date.\n\nInstalled version: V{APP_VERSION}",
                                parent=self,
                            ),
                        )
                    return

                def prompt():
                    install = messagebox.askyesno(
                        "Software Update",
                        f"A newer version is available.\n\n"
                        f"Installed: V{APP_VERSION}\n"
                        f"Available: V{latest}\n\n"
                        "Download and install it now?\n\n"
                        "Your local settings, API keys, inventory database, and image cache "
                        "are stored separately and will not be replaced.",
                        parent=self,
                    )
                    if install:
                        self._download_and_install_update(manifest)

                self.after(0, prompt)
            except Exception as exc:
                if not silent:
                    self.after(
                        0,
                        lambda e=str(exc): messagebox.showerror(
                            "Software Update",
                            "Could not check for updates.\n\n" + e,
                            parent=self,
                        ),
                    )
                else:
                    self._log("UPDATE CHECK: " + str(exc))

        threading.Thread(target=work, daemon=True).start()

    def _download_and_install_update(self, manifest):
        latest = manifest["version"]
        filename = manifest["file"]
        url = parse.urljoin(UPDATE_BASE_URL, filename)

        progress = tk.Toplevel(self)
        progress.title("Software Update")
        progress.transient(self)
        progress.resizable(False, False)
        progress.geometry("430x150")
        ttk.Label(
            progress,
            text=f"Downloading V{latest}…",
            style="Section.TLabel",
        ).pack(anchor="w", padx=18, pady=(18, 6))
        status_var = tk.StringVar(value="Connecting to fuscaldo.org…")
        ttk.Label(progress, textvariable=status_var).pack(anchor="w", padx=18, pady=(0, 8))
        bar = ttk.Progressbar(progress, mode="indeterminate")
        bar.pack(fill="x", padx=18, pady=(0, 16))
        bar.start(12)

        def fail(message):
            try:
                bar.stop()
                progress.destroy()
            except Exception:
                pass
            messagebox.showerror("Software Update", message, parent=self)

        def work():
            try:
                temp_root = Path(tempfile.mkdtemp(prefix="trade_components_update_"))
                zip_file = temp_root / "update.zip"
                extract_dir = temp_root / "payload"
                extract_dir.mkdir(parents=True, exist_ok=True)

                req = request.Request(
                    url,
                    headers={
                        "User-Agent": f"TradeComponents-eBay-Listing-Tool/{APP_VERSION}",
                        "Cache-Control": "no-cache",
                    },
                    method="GET",
                )
                with request.urlopen(req, timeout=90) as resp, open(zip_file, "wb") as out:
                    shutil.copyfileobj(resp, out)

                if zip_file.stat().st_size < 1000:
                    raise RuntimeError("The downloaded update file is unexpectedly small.")

                expected_hash = manifest.get("sha256", "")
                if expected_hash:
                    import hashlib
                    h = hashlib.sha256()
                    with open(zip_file, "rb") as fh:
                        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                            h.update(chunk)
                    if h.hexdigest().lower() != expected_hash:
                        raise RuntimeError(
                            "The update checksum does not match version.json. "
                            "The update was not installed."
                        )

                with zipfile.ZipFile(zip_file, "r") as zf:
                    members = zf.infolist()
                    if not members:
                        raise RuntimeError("The downloaded update ZIP is empty.")
                    extract_root = extract_dir.resolve()
                    for member in members:
                        candidate = (extract_dir / member.filename).resolve()
                        if candidate != extract_root and extract_root not in candidate.parents:
                            raise RuntimeError("The update ZIP contains an unsafe file path.")
                    zf.extractall(extract_dir)

                entries = [p for p in extract_dir.iterdir() if p.name != "__MACOSX"]
                payload_dir = entries[0] if len(entries) == 1 and entries[0].is_dir() else extract_dir
                if not (payload_dir / "ebay_listing_tool.py").exists():
                    raise RuntimeError("The update ZIP does not contain ebay_listing_tool.py.")

                target_dir = Path(__file__).resolve().parent
                updater_ps1 = temp_root / "install_update.ps1"
                launcher = target_dir / "LAUNCH_TOOL.vbs"
                start_bat = target_dir / "START_TOOL.bat"

                ps_lines = [
                    "param([int]$PidToWait,[string]$SourceDir,[string]$TargetDir,[string]$Launcher,[string]$StartBat)",
                    '$ErrorActionPreference = "Stop"',
                    "try {",
                    "  Wait-Process -Id $PidToWait -ErrorAction SilentlyContinue",
                    "  Start-Sleep -Milliseconds 700",
                    "  Get-ChildItem -LiteralPath $SourceDir -Force | ForEach-Object {",
                    "    Copy-Item -LiteralPath $_.FullName -Destination $TargetDir -Recurse -Force",
                    "  }",
                    "  if (Test-Path -LiteralPath $Launcher) {",
                    '    Start-Process "$env:WINDIR\\System32\\wscript.exe" -ArgumentList (\'"\' + $Launcher + \'"\') -WorkingDirectory $TargetDir',
                    "  } elseif (Test-Path -LiteralPath $StartBat) {",
                    "    Start-Process -FilePath $StartBat -WorkingDirectory $TargetDir",
                    "  }",
                    "} catch {",
                    "  Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue",
                    '  [System.Windows.MessageBox]::Show(("Update failed:`n`n" + $_.Exception.Message),"Trade Components Update") | Out-Null',
                    "}",
                ]
                updater_ps1.write_text("\n".join(ps_lines), encoding="utf-8-sig")

                args = [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy", "Bypass",
                    "-File", str(updater_ps1),
                    "-PidToWait", str(os.getpid()),
                    "-SourceDir", str(payload_dir),
                    "-TargetDir", str(target_dir),
                    "-Launcher", str(launcher),
                    "-StartBat", str(start_bat),
                ]

                creationflags = 0
                if os.name == "nt":
                    creationflags = (
                        getattr(subprocess, "DETACHED_PROCESS", 0)
                        | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                    )

                subprocess.Popen(
                    args,
                    cwd=str(target_dir),
                    creationflags=creationflags,
                    close_fds=True,
                )

                def finish():
                    try:
                        bar.stop()
                        progress.destroy()
                    except Exception:
                        pass
                    messagebox.showinfo(
                        "Software Update",
                        f"V{latest} has been downloaded and staged.\n\n"
                        "The app will now close, install the update, and reopen automatically.",
                        parent=self,
                    )
                    self.destroy()

                self.after(0, finish)

            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): fail(
                        "The update could not be installed.\n\n" + e
                    ),
                )

        threading.Thread(target=work, daemon=True).start()

    def _set_window_icon(self):
        """Load the bundled PNG/ICO so both the window and desktop shortcut use the updated icon."""
        try:
            base_dir = Path(__file__).resolve().parent
            png_icon = base_dir / "TradeComponents_icon.png"
            ico_icon = base_dir / "TradeComponents_icon.ico"
            self._icon_photo_ref = None
            if png_icon.exists():
                try:
                    self._icon_photo_ref = tk.PhotoImage(file=str(png_icon))
                    self.iconphoto(True, self._icon_photo_ref)
                except Exception:
                    self._icon_photo_ref = None
            if ico_icon.exists():
                try:
                    self.iconbitmap(default=str(ico_icon))
                    self.iconbitmap(str(ico_icon))
                except Exception:
                    pass

            # Windows can initially inherit the Python executable icon while the
            # window is being created. Re-apply our icon once Tk has registered
            # the top-level window with the shell.
            if os.name == "nt":
                try:
                    self.after(
                        250,
                        lambda: self.iconbitmap(str(ico_icon)) if ico_icon.exists() else None,
                    )
                except Exception:
                    pass
        except Exception:
            pass

    def _configure_style(self):
        """A restrained, native-looking visual refresh without third-party UI packages."""
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        default_font = ("Segoe UI", 10)
        heading_font = ("Segoe UI Semibold", 11)
        title_font = ("Segoe UI Semibold", 18)
        small_font = ("Segoe UI", 9)

        shell_bg = "#f4f1ec"
        card_bg = "#fbfaf7"
        tab_bg = "#e7e1d8"
        accent = "#315f8f"
        accent_soft = "#e7eef6"
        text_dark = "#2f3a46"

        try:
            self.configure(bg=shell_bg)
        except Exception:
            pass

        style.configure(".", font=default_font, background=shell_bg, foreground=text_dark)
        style.configure("TFrame", background=shell_bg)
        style.configure("TLabel", background=shell_bg, foreground=text_dark)
        style.configure("Header.TLabel", font=title_font, background=shell_bg, foreground="#163761")
        style.configure("Subheader.TLabel", font=small_font, background=shell_bg, foreground="#4b5d73")
        style.configure("Section.TLabel", font=heading_font, background=shell_bg, foreground=accent)

        style.configure("TNotebook", padding=6, background=shell_bg, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 9), background=tab_bg, foreground=text_dark, borderwidth=0)
        style.map(
            "TNotebook.Tab",
            background=[("selected", "#ffffff"), ("active", accent_soft)],
            foreground=[("selected", accent), ("active", accent)],
        )

        style.configure("TLabelframe", padding=10, background=card_bg, borderwidth=1, relief="groove")
        style.configure("TLabelframe.Label", font=heading_font, background=shell_bg, foreground=accent)
        style.configure("TButton", padding=(12, 8), background="#fdfcf9", foreground=text_dark, borderwidth=1)
        style.map("TButton", background=[("active", accent_soft)])
        style.configure("Accent.TButton", font=("Segoe UI Semibold", 10), padding=(12, 8), background=accent_soft, foreground=accent)
        style.map("Accent.TButton", background=[("active", "#d8e9ff")])
        style.configure("Danger.TButton", font=("Segoe UI Semibold", 10), padding=(12, 8))
        style.configure("TEntry", fieldbackground="#ffffff")
        style.configure("TCombobox", fieldbackground="#ffffff")
        style.configure("Treeview", rowheight=24, fieldbackground="#ffffff", background="#ffffff")
        style.configure("Treeview.Heading", font=heading_font)

    def _install_text_context_menus(self):
        """Add familiar right-click editing commands to Entry/Text/Spinbox widgets."""

        def popup(event):
            widget = event.widget
            menu = tk.Menu(self, tearoff=False)

            can_edit = True
            try:
                state = str(widget.cget("state"))
                if state in ("disabled", "readonly"):
                    can_edit = False
            except Exception:
                pass

            def do_cut():
                try:
                    widget.event_generate("<<Cut>>")
                except Exception:
                    pass

            def do_copy():
                try:
                    widget.event_generate("<<Copy>>")
                except Exception:
                    pass

            def do_paste():
                try:
                    widget.event_generate("<<Paste>>")
                except Exception:
                    pass

            def do_select_all():
                try:
                    if isinstance(widget, tk.Text):
                        widget.tag_add("sel", "1.0", "end-1c")
                        widget.mark_set("insert", "1.0")
                        widget.see("insert")
                    else:
                        widget.selection_range(0, "end")
                        widget.icursor("end")
                except Exception:
                    pass

            menu.add_command(label="Cut", command=do_cut, state="normal" if can_edit else "disabled")
            menu.add_command(label="Copy", command=do_copy)
            menu.add_command(label="Paste", command=do_paste, state="normal" if can_edit else "disabled")
            menu.add_separator()
            menu.add_command(label="Select All", command=do_select_all)

            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                try:
                    menu.grab_release()
                except Exception:
                    pass
            return "break"

        # Windows/macOS/Linux-friendly class bindings.
        for cls in ("Entry", "TEntry", "Text", "Spinbox", "TSpinbox"):
            try:
                self.bind_class(cls, "<Button-3>", popup, add="+")
            except Exception:
                pass
            try:
                self.bind_class(cls, "<Button-2>", popup, add="+")
            except Exception:
                pass

    def _validate_ui_callbacks(self):
        """Catch missing integrated UI callbacks immediately during development."""
        pm = getattr(self, "photo_manager", None)
        if pm is not None:
            required = ("_ai_group_current_batch",)
            missing = [name for name in required if not callable(getattr(pm, name, None))]
            if missing:
                raise RuntimeError(
                    "Integrated photo manager is missing required callback(s): "
                    + ", ".join(missing)
                )
        if getattr(self, "photo_manager", None) is not None:
            if getattr(self.photo_manager, "analyze_btn", None) is None:
                raise RuntimeError("Photo Manager Analyze button was not initialized.")
            self.analyze_btn = self.photo_manager.analyze_btn

        try:
            probe = self._selected_photo_paths()
            if not isinstance(probe, list):
                raise RuntimeError("selected-photo bridge did not return a list")
        except Exception as exc:
            raise RuntimeError("Main photo bridge startup test failed: " + str(exc))



    def _show_progress_popup(self, title, message):
        try:
            if getattr(self, "_progress_popup", None) is not None:
                self._progress_popup.destroy()
        except Exception:
            pass

        win = tk.Toplevel(self)
        win.title(title)
        win.resizable(False, False)
        win.transient(self)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        win.protocol("WM_DELETE_WINDOW", lambda: None)

        frame = ttk.Frame(win, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)

        self._progress_message_var = tk.StringVar(value=message)
        ttk.Label(frame, text=title, style="Section.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            frame,
            textvariable=self._progress_message_var,
            wraplength=420,
            justify="left"
        ).grid(row=1, column=0, sticky="w", pady=(6, 10))

        self._progress_bar = ttk.Progressbar(frame, mode="indeterminate", length=420)
        self._progress_bar.grid(row=2, column=0, sticky="ew")
        self._progress_bar.start(12)

        ttk.Button(frame, text="STOP / CANCEL", command=self._stop).grid(
            row=3, column=0, sticky="e", pady=(10, 0)
        )

        self._progress_popup = win
        self.update_idletasks()

    def _update_progress_popup(self, message):
        if hasattr(self, "_progress_message_var"):
            self._progress_message_var.set(message)
        try:
            if getattr(self, "_progress_popup", None) is not None:
                self._progress_popup.update_idletasks()
        except Exception:
            pass

    def _close_progress_popup(self):
        """Close any active progress popup. Safe to call repeatedly."""
        bar = getattr(self, "_progress_bar", None)
        win = getattr(self, "_progress_popup", None)

        self._progress_bar = None
        self._progress_popup = None

        try:
            if bar is not None:
                bar.stop()
        except Exception:
            pass

        try:
            if win is not None and win.winfo_exists():
                win.destroy()
        except Exception:
            pass


    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self, padding=(14, 8, 14, 6))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(
            header, text="Trade Components eBay Listing Tool", style="Header.TLabel"
        ).grid(row=0, column=0, sticky="w")
        ttk.Button(
            header,
            text="CHECK FOR UPDATES",
            command=self._check_for_updates,
        ).grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))
        ttk.Label(
            header,
            text="V4.21.9  •  AI-assisted surplus listing workflow  •  Draft-first safety",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        notebook = ttk.Notebook(self)
        notebook.grid(row=1, column=0, sticky="nsew", padx=12, pady=(4, 12))

        self.listing_tab = ttk.Frame(notebook, padding=10)
        self.inventory_tab = ttk.Frame(notebook, padding=10)
        self.existing_tab = ttk.Frame(notebook, padding=10)
        self.settings_tab = ttk.Frame(notebook, padding=10)
        notebook.add(self.listing_tab, text="Listing Editor")
        notebook.add(self.inventory_tab, text="Inventory")
        notebook.add(self.existing_tab, text="Existing eBay Listing")
        notebook.add(self.settings_tab, text="eBay Settings")
        self.notebook = notebook

        # Wheel movement over the notebook tab strip must never change tabs.
        # Scrolling belongs only to the content canvas of the active page.
        notebook.bind("<MouseWheel>", lambda event: "break")

        self._build_listing_tab()
        self._build_inventory_tab()
        self._build_existing_tab()
        self._build_settings_tab()

    def _inventory_connect(self):
        con = sqlite3.connect(self.inventory_db_path)
        con.row_factory = sqlite3.Row
        return con

    def _build_inventory_tab(self):
        outer = self.inventory_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        top = ttk.Frame(outer)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Inventory", style="Header.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 14))
        ttk.Label(top, text="Search:").grid(row=0, column=1, sticky="e")
        search = ttk.Entry(top, textvariable=self.inventory_search_var, width=38)
        search.grid(row=0, column=2, sticky="ew", padx=(6, 8))
        search.bind("<KeyRelease>", lambda _e: self._inventory_refresh_all())
        ttk.Button(top, text="SYNC EBAY STATUS", command=self._inventory_sync_ebay).grid(row=0, column=3, padx=3)
        ttk.Button(top, text="EXPORT CSV", command=self._inventory_export_csv).grid(row=0, column=4, padx=3)

        status = ttk.Label(
            outer,
            textvariable=self.inventory_status_var,
            style="Subheader.TLabel",
            anchor="w",
        )
        status.grid(row=1, column=0, sticky="ew", pady=(0, 6))

        nb = ttk.Notebook(outer)
        nb.grid(row=2, column=0, sticky="nsew")
        self.inventory_notebook = nb

        for key, label in (
            ("MASTER", "MASTER LIST"),
            ("PENDING_LOCATION", "PENDING LOCATION"),
            ("PENDING_SHIPPING", "PENDING SHIPPING"),
            ("SOLD", "SOLD"),
        ):
            frame = ttk.Frame(nb, padding=5)
            frame.columnconfigure(0, weight=1)
            frame.rowconfigure(0, weight=1)
            nb.add(frame, text=label)
            self._inventory_build_tree(frame, key)

        controls = ttk.Frame(outer)
        controls.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        for col in range(9):
            controls.columnconfigure(col, weight=1)
        ttk.Button(controls, text="ADD ITEM", command=self._inventory_add_manual).grid(row=0, column=0, padx=3, sticky="ew")
        ttk.Button(controls, text="EDIT ITEM", command=self._inventory_edit_selected).grid(row=0, column=1, padx=3, sticky="ew")
        ttk.Button(controls, text="ASSIGN LOCATION", command=self._inventory_assign_location).grid(row=0, column=2, padx=3, sticky="ew")
        ttk.Button(controls, text="MOVE TO PENDING", command=self._inventory_move_pending).grid(row=0, column=3, padx=3, sticky="ew")
        ttk.Button(controls, text="MARK SOLD", command=self._inventory_mark_sold).grid(row=0, column=4, padx=3, sticky="ew")
        ttk.Button(controls, text="UNMARK SOLD", command=self._inventory_unmark_sold).grid(row=0, column=5, padx=3, sticky="ew")
        ttk.Button(controls, text="OPEN EBAY", command=self._inventory_open_ebay).grid(row=0, column=6, padx=3, sticky="ew")
        ttk.Button(controls, text="DELETE", command=self._inventory_delete_selected, style="Danger.TButton").grid(row=0, column=7, padx=3, sticky="ew")
        ttk.Button(controls, text="REFRESH", command=self._inventory_refresh_all).grid(row=0, column=8, padx=3, sticky="ew")

        self._inventory_refresh_all()

    def _inventory_build_tree(self, frame, key):
        columns = ("qty", "stock", "item", "location", "comment", "condition", "item_number", "status")
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        vs = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        heads = {
            "qty":"QTY", "stock":"STOCK", "item":"ITEM", "location":"LOCATION",
            "comment":"COMMENT", "condition":"CONDITION", "item_number":"ITEM NUMBER", "status":"STATUS"
        }
        widths = {"qty":55,"stock":60,"item":430,"location":130,"comment":260,"condition":125,"item_number":125,"status":120}
        for c in columns:
            tree.heading(
                c,
                text=heads[c],
                command=lambda col=c, tr=tree: self._sort_treeview_column(tr, col),
            )
            tree.column(c, width=widths[c], minwidth=45, stretch=(c in ("item","comment")))
        tree.bind("<Double-1>", lambda _e: self._inventory_edit_selected())
        tree.bind("<Return>", lambda _e: self._inventory_edit_selected())
        self.inventory_trees[key] = tree

    def _inventory_active_key(self):
        try:
            idx = self.inventory_notebook.index(self.inventory_notebook.select())
            return ("MASTER", "PENDING_LOCATION", "PENDING_SHIPPING", "SOLD")[idx]
        except Exception:
            return "MASTER"

    def _inventory_selected_id(self):
        tree = self.inventory_trees.get(self._inventory_active_key())
        if tree is None:
            return None
        sel = tree.selection()
        if not sel:
            return None
        try:
            return int(sel[0])
        except Exception:
            return None

    def _inventory_refresh_all(self):
        if not getattr(self, "inventory_trees", None):
            return
        search = str(self.inventory_search_var.get() or "").strip().lower()
        con = self._inventory_connect()
        try:
            colors = {r["location"]: r["color"] for r in con.execute("SELECT location,color FROM location_colors")}
            views = {
                "MASTER": "status NOT IN ('SOLD','PENDING_LOCATION','PENDING_SHIPPING','DEPLETED')",
                "PENDING_LOCATION": "status='PENDING_LOCATION'",
                "PENDING_SHIPPING": "status='PENDING_SHIPPING'",
                "SOLD": "status='SOLD'",
            }
            total_counts = {}
            for key, where in views.items():
                tree = self.inventory_trees[key]
                tree.delete(*tree.get_children())
                sql = f"SELECT * FROM inventory_items WHERE {where}"
                args = []
                if search:
                    sql += " AND (lower(item) LIKE ? OR lower(location) LIKE ? OR lower(comment) LIKE ? OR lower(condition) LIKE ? OR lower(item_number) LIKE ?)"
                    like = f"%{search}%"
                    args = [like, like, like, like, like]
                sql += " ORDER BY location COLLATE NOCASE, item COLLATE NOCASE"
                rows = con.execute(sql, args).fetchall()
                total_counts[key] = len(rows)
                for row in rows:
                    loc = str(row["location"] or "")
                    tag = ""
                    if key == "PENDING_SHIPPING":
                        tag = "pending_shipping_row"
                        try:
                            tree.tag_configure(
                                "pending_shipping_row",
                                background="#dceeff",
                                foreground="#213547",
                            )
                        except Exception:
                            tag = ""
                    elif key == "SOLD":
                        tag = "sold_row"
                        try:
                            tree.tag_configure(
                                "sold_row",
                                background="#f3c7c7",
                                foreground="#442222",
                            )
                        except Exception:
                            tag = ""
                    else:
                        color = str(row["color"] or colors.get(loc, "") or "")
                        if color:
                            tag = "loc_" + re.sub(r"[^A-Za-z0-9]", "_", color)
                            try:
                                tree.tag_configure(tag, background=color)
                            except Exception:
                                tag = ""
                    vals = (
                        "" if row["qty"] is None else row["qty"],
                        "" if row["stock"] is None else row["stock"],
                        row["item"] or "",
                        loc,
                        row["comment"] or "",
                        row["condition"] or "",
                        row["item_number"] or "",
                        str(row["status"] or "").replace("_", " "),
                    )
                    tree.insert("", "end", iid=str(row["id"]), values=vals, tags=(tag,) if tag else ())
            self.inventory_status_var.set(
                f"Master: {total_counts.get('MASTER',0):,}  •  Pending location: {total_counts.get('PENDING_LOCATION',0):,}  •  "
                f"Pending shipping: {total_counts.get('PENDING_SHIPPING',0):,}  •  Sold: {total_counts.get('SOLD',0):,}"
            )
        finally:
            con.close()

    def _inventory_item_dialog(self, existing=None, title="Inventory Item"):
        existing = dict(existing or {})
        win = tk.Toplevel(self)
        win.title(title)
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)
        frm = ttk.Frame(win, padding=14)
        frm.pack(fill="both", expand=True)
        fields = [
            ("qty", "QTY"), ("stock", "STOCK"), ("item", "ITEM"),
            ("location", "LOCATION"), ("comment", "COMMENT"),
            ("condition", "CONDITION"), ("item_number", "ITEM NUMBER"),
        ]
        vars_ = {}
        for r,(key,label) in enumerate(fields):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="e", padx=(0,8), pady=4)
            value = existing.get(key, "")
            if value is None: value = ""
            v = tk.StringVar(value=str(value))
            vars_[key]=v
            if key == "location":
                con=self._inventory_connect()
                try:
                    locations=[x[0] for x in con.execute("SELECT location FROM location_colors ORDER BY location COLLATE NOCASE")]
                finally: con.close()
                w=ttk.Combobox(frm, textvariable=v, values=locations, width=52)
            else:
                w=ttk.Entry(frm, textvariable=v, width=55)
            w.grid(row=r, column=1, sticky="ew", pady=4)
        ttk.Label(frm, text="Leave LOCATION blank to place the item in PENDING LOCATION.", style="Subheader.TLabel").grid(row=len(fields), column=0, columnspan=2, sticky="w", pady=(6,8))
        result={}
        def save():
            if not vars_["item"].get().strip():
                messagebox.showerror(APP_NAME, "ITEM is required.", parent=win); return
            for k,v in vars_.items(): result[k]=v.get().strip()
            win.destroy()
        btn=ttk.Frame(frm); btn.grid(row=len(fields)+1,column=0,columnspan=2,sticky="e")
        ttk.Button(btn,text="CANCEL",command=win.destroy).pack(side="right",padx=(6,0))
        ttk.Button(btn,text="SAVE",command=save,style="Accent.TButton").pack(side="right")
        win.wait_window()
        return result or None

    @staticmethod
    def _inventory_num(value):
        s=str(value or "").strip()
        if not s: return None
        try: return float(s)
        except Exception: return None

    def _inventory_save_record(self, data, record_id=None, forced_status=None):
        location=str(data.get("location","") or "").strip()
        status=forced_status or ("MASTER" if location else "PENDING_LOCATION")
        item_number=str(data.get("item_number","") or "").strip()
        if status == "MASTER" and item_number:
            status="LISTED"
        con=self._inventory_connect()
        try:
            color=""
            if location:
                row=con.execute("SELECT color FROM location_colors WHERE location=?",(location,)).fetchone()
                color=str(row[0] or "") if row else ""
            vals=(self._inventory_num(data.get("qty")), self._inventory_num(data.get("stock")), str(data.get("item","")).strip(), location, str(data.get("comment","")).strip(), str(data.get("condition","")).strip(), item_number, status, color)
            if record_id:
                con.execute("""UPDATE inventory_items SET qty=?,stock=?,item=?,location=?,comment=?,condition=?,item_number=?,status=?,color=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""", vals+(int(record_id),))
            else:
                con.execute("""INSERT INTO inventory_items(qty,stock,item,location,comment,condition,item_number,status,color) VALUES(?,?,?,?,?,?,?,?,?)""", vals)
            con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_add_manual(self):
        data=self._inventory_item_dialog(title="Add Inventory Item")
        if data: self._inventory_save_record(data)

    def _inventory_edit_selected(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try: row=con.execute("SELECT * FROM inventory_items WHERE id=?",(rid,)).fetchone()
        finally: con.close()
        if not row: return
        data=self._inventory_item_dialog(row,title="Edit Inventory Item")
        if data:
            status=str(row["status"] or "MASTER")
            if status=="SOLD": forced="SOLD"
            elif not str(data.get("location","")).strip(): forced="PENDING_LOCATION"
            else: forced="LISTED" if str(data.get("item_number","")).strip() else "MASTER"
            self._inventory_save_record(data,rid,forced)

    def _inventory_assign_location(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try:
            locations=[x[0] for x in con.execute("SELECT location FROM location_colors ORDER BY location COLLATE NOCASE")]
        finally: con.close()
        loc=simpledialog.askstring("Assign Inventory Location","Enter the physical location (for example JIMI 2):",parent=self)
        if loc is None: return
        loc=loc.strip()
        if not loc: return
        con=self._inventory_connect()
        try:
            row=con.execute("SELECT item_number FROM inventory_items WHERE id=?",(rid,)).fetchone()
            status="LISTED" if row and str(row[0] or "").strip() else "MASTER"
            color_row=con.execute("SELECT color FROM location_colors WHERE location=?",(loc,)).fetchone()
            color=str(color_row[0] or "") if color_row else ""
            con.execute("UPDATE inventory_items SET location=?,status=?,color=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(loc,status,color,rid))
            con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_move_pending(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try:
            con.execute("UPDATE inventory_items SET location='',status='PENDING_LOCATION',updated_at=CURRENT_TIMESTAMP WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_mark_sold(self):
        rid=self._inventory_selected_id()
        if not rid: return
        if not messagebox.askyesno("Inventory","Move this item to SOLD?",parent=self): return
        con=self._inventory_connect()
        try:
            con.execute("UPDATE inventory_items SET status='SOLD',date_sold=date('now'),updated_at=CURRENT_TIMESTAMP WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_unmark_sold(self):
        """Restore sold records; sale child rows merge their quantity back into parent stock."""
        rid = self._inventory_selected_id()
        if not rid:
            return

        con = self._inventory_connect()
        try:
            row = con.execute("SELECT * FROM inventory_items WHERE id=?", (rid,)).fetchone()
            if not row:
                return

            if str(row["status"] or "").upper() != "SOLD":
                messagebox.showinfo(
                    "Inventory",
                    "The selected inventory record is not marked SOLD.",
                    parent=self,
                )
                return

            parent_id = row["parent_item_id"]
            if parent_id:
                try:
                    sale_qty = int(row["sale_quantity"] if row["sale_quantity"] is not None else row["qty"] or 0)
                except Exception:
                    sale_qty = 0

                if not messagebox.askyesno(
                    "Inventory",
                    f"Return {sale_qty} unit(s) from this sold transaction back into inventory?\n\n"
                    "The sold transaction line will be removed and the parent item's STOCK will increase.",
                    parent=self,
                ):
                    return

                parent = con.execute(
                    "SELECT stock,item_number,location FROM inventory_items WHERE id=?",
                    (parent_id,),
                ).fetchone()
                if parent:
                    try:
                        stock = int(parent["stock"] or 0) + sale_qty
                    except Exception:
                        stock = sale_qty
                    new_status = (
                        "LISTED" if str(parent["item_number"] or "").strip()
                        else ("MASTER" if str(parent["location"] or "").strip() else "PENDING_LOCATION")
                    )
                    con.execute(
                        "UPDATE inventory_items SET stock=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                        (stock, new_status, parent_id),
                    )
                con.execute("DELETE FROM inventory_items WHERE id=?", (rid,))
                con.commit()
            else:
                location = str(row["location"] or "").strip()
                item_number = str(row["item_number"] or "").strip()
                new_status = "PENDING_LOCATION" if not location else ("LISTED" if item_number else "MASTER")

                if not messagebox.askyesno(
                    "Inventory",
                    "Restore this item from SOLD back to active inventory?\n\n"
                    "Its physical location and item information will be kept. "
                    "The sold date and matched eBay order will be cleared.",
                    parent=self,
                ):
                    return

                con.execute(
                    """UPDATE inventory_items
                       SET status=?,date_sold='',ebay_order_id='',updated_at=CURRENT_TIMESTAMP
                       WHERE id=?""",
                    (new_status, rid),
                )
                con.commit()
        finally:
            con.close()

        self._inventory_refresh_all()


    def _inventory_delete_selected(self):
        rid=self._inventory_selected_id()
        if not rid: return
        if not messagebox.askyesno("Inventory","Permanently remove this inventory record from the local database?",parent=self): return
        con=self._inventory_connect()
        try: con.execute("DELETE FROM inventory_items WHERE id=?",(rid,)); con.commit()
        finally: con.close()
        self._inventory_refresh_all()

    def _inventory_open_ebay(self):
        rid=self._inventory_selected_id()
        if not rid: return
        con=self._inventory_connect()
        try: row=con.execute("SELECT item_number FROM inventory_items WHERE id=?",(rid,)).fetchone()
        finally: con.close()
        item_number=str(row[0] or "").strip() if row else ""
        if not item_number:
            messagebox.showinfo("Inventory","This record does not have an eBay Item Number yet.",parent=self); return
        webbrowser.open(f"https://www.ebay.com/itm/{item_number}")

    def _inventory_export_csv(self):
        path=filedialog.asksaveasfilename(title="Export Inventory CSV",defaultextension=".csv",filetypes=[("CSV files","*.csv")],initialfile="TradeComponents_Inventory.csv")
        if not path: return
        con=self._inventory_connect()
        try: rows=con.execute("SELECT * FROM inventory_items ORDER BY status,location,item").fetchall()
        finally: con.close()
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(["QTY","STOCK","ITEM","LOCATION","COMMENT","CONDITION","ITEM NUMBER","STATUS","DATE SOLD"])
            for r in rows: w.writerow([r["qty"],r["stock"],r["item"],r["location"],r["comment"],r["condition"],r["item_number"],r["status"],r["date_sold"]])
        messagebox.showinfo("Inventory",f"Inventory exported to:\n{path}",parent=self)

    def _inventory_ensure_published(self, listing_id, listing):
        """Automatically track every listing published by this app."""
        listing_id=str(listing_id or "").strip()
        if not listing_id: return
        con=self._inventory_connect()
        try:
            existing=con.execute("SELECT id FROM inventory_items WHERE item_number=? LIMIT 1",(listing_id,)).fetchone()
            if existing:
                con.execute("UPDATE inventory_items SET status=CASE WHEN status='SOLD' THEN status ELSE 'LISTED' END,updated_at=CURRENT_TIMESTAMP WHERE id=?",(existing[0],)); con.commit(); return
            qty=listing.get("quantity",1)
            title=str(listing.get("title","") or "").strip()
            condition=str(listing.get("condition","") or "").strip()
            con.execute("""INSERT INTO inventory_items(qty,stock,item,location,comment,condition,item_number,status,source_sheet)
                           VALUES(?,?,?,?,?,?,?,?,?)""",(qty,qty,title,"","",condition,listing_id,"PENDING_LOCATION","APP PUBLISH"))
            con.commit()
        finally: con.close()
        self.after(0,self._inventory_refresh_all)

    def _inventory_sync_active_apply(self, active_listings):
        """Reconcile local inventory against every current eBay active listing."""
        active_listings = [x for x in (active_listings or []) if isinstance(x, dict)]
        con = self._inventory_connect()
        marked_listed = 0
        added_missing = 0
        try:
            for listing in active_listings:
                item_number = str(listing.get("item_number", "") or "").strip()
                if not item_number:
                    continue

                row = con.execute(
                    """SELECT id,status,stock FROM inventory_items
                       WHERE item_number=? AND parent_item_id IS NULL
                       ORDER BY id LIMIT 1""",
                    (item_number,),
                ).fetchone()

                if row:
                    status = str(row["status"] or "MASTER").upper()
                    available = listing.get("quantity_available", None)
                    try:
                        available = max(0, int(available)) if available is not None else None
                    except Exception:
                        available = None

                    # eBay's current available quantity is authoritative for an
                    # active listing. This corrects local stock after partial sales
                    # without changing the original inventoried QTY.
                    if available is not None:
                        con.execute(
                            "UPDATE inventory_items SET stock=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                            (available, row["id"]),
                        )

                    if status not in ("PENDING_LOCATION", "PENDING_SHIPPING", "SOLD"):
                        if status != "LISTED":
                            marked_listed += 1
                        con.execute(
                            "UPDATE inventory_items SET status='LISTED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                            (row["id"],),
                        )
                else:
                    title = str(listing.get("title", "") or "").strip() or f"eBay Item {item_number}"
                    qty = listing.get("quantity_available", 1)
                    try:
                        qty = max(0, int(qty))
                    except Exception:
                        qty = 1
                    con.execute(
                        """INSERT INTO inventory_items(
                               qty,stock,item,location,comment,condition,item_number,status,source_sheet
                           ) VALUES(?,?,?,?,?,?,?,?,?)""",
                        (
                            qty, qty, title, "",
                            "Imported automatically from current eBay listings",
                            "", item_number, "PENDING_LOCATION", "EBAY ACTIVE SYNC"
                        ),
                    )
                    added_missing += 1
            con.commit()
        finally:
            con.close()

        self.after(0, self._inventory_refresh_all)
        return marked_listed, added_missing

    def _inventory_sync_orders_apply(self, orders):
        """
        Quantity-aware order synchronization.

        The main inventory row represents currently available physical stock.
        Each eBay order line gets its own child row so a partial sale does not
        mark an entire multi-quantity inventory record sold.
        """
        con = self._inventory_connect()
        pending_count = 0
        sold_count = 0
        new_sale_lines = 0

        try:
            for order in orders or []:
                if not isinstance(order, dict):
                    continue

                order_id = str(order.get("orderId", "") or "").strip()
                order_status = str(order.get("orderFulfillmentStatus", "") or "").upper()
                is_fulfilled = order_status == "FULFILLED"
                child_status = "SOLD" if is_fulfilled else "PENDING_SHIPPING"

                for idx, li in enumerate(order.get("lineItems", []) or []):
                    if not isinstance(li, dict):
                        continue

                    legacy = str(li.get("legacyItemId", "") or "").strip()
                    if not legacy:
                        lr = li.get("legacyReference", {}) or {}
                        if isinstance(lr, dict):
                            legacy = str(lr.get("legacyItemId", "") or "").strip()
                    if not legacy:
                        itemid = str(li.get("itemId", "") or "")
                        m = re.search(r"(?:v1\|)?(\d{9,})", itemid)
                        legacy = m.group(1) if m else ""
                    if not legacy:
                        continue

                    try:
                        sold_qty = int(li.get("quantity", 1) or 1)
                    except Exception:
                        sold_qty = 1
                    sold_qty = max(1, sold_qty)

                    line_id = str(li.get("lineItemId", "") or "").strip()
                    if not line_id:
                        # Stable fallback prevents repeated syncs from subtracting twice.
                        line_id = f"{order_id}:{legacy}:{idx}"

                    existing_child = con.execute(
                        "SELECT id,status FROM inventory_items WHERE ebay_order_line_id=? LIMIT 1",
                        (line_id,),
                    ).fetchone()

                    if existing_child:
                        old = str(existing_child["status"] or "").upper()
                        if is_fulfilled and old != "SOLD":
                            con.execute(
                                """UPDATE inventory_items
                                   SET status='SOLD',
                                       date_sold=COALESCE(NULLIF(date_sold,''),date('now')),
                                       ebay_order_id=?,
                                       updated_at=CURRENT_TIMESTAMP
                                   WHERE id=?""",
                                (order_id, existing_child["id"]),
                            )
                            sold_count += 1
                        elif not is_fulfilled and old != "PENDING_SHIPPING":
                            con.execute(
                                """UPDATE inventory_items
                                   SET status='PENDING_SHIPPING',
                                       ebay_order_id=?,
                                       updated_at=CURRENT_TIMESTAMP
                                   WHERE id=?""",
                                (order_id, existing_child["id"]),
                            )
                            pending_count += 1
                        continue

                    parent = con.execute(
                        """SELECT * FROM inventory_items
                           WHERE item_number=? AND parent_item_id IS NULL
                           ORDER BY CASE WHEN status='SOLD' THEN 1 ELSE 0 END, id
                           LIMIT 1""",
                        (legacy,),
                    ).fetchone()
                    if not parent:
                        continue

                    current_stock = parent["stock"]
                    try:
                        current_stock = int(current_stock if current_stock is not None else parent["qty"] or 0)
                    except Exception:
                        current_stock = 0
                    remaining = max(0, current_stock - sold_qty)

                    parent_status = str(parent["status"] or "MASTER").upper()
                    if remaining <= 0:
                        parent_status = "DEPLETED"
                    elif parent_status in ("SOLD", "DEPLETED", "PENDING_SHIPPING"):
                        parent_status = "LISTED" if legacy else "MASTER"

                    con.execute(
                        """UPDATE inventory_items
                           SET stock=?,status=?,updated_at=CURRENT_TIMESTAMP
                           WHERE id=?""",
                        (remaining, parent_status, parent["id"]),
                    )

                    con.execute(
                        """INSERT INTO inventory_items(
                               qty,stock,item,location,comment,condition,item_number,
                               status,date_sold,ebay_order_id,source_sheet,color,
                               parent_item_id,ebay_order_line_id,sale_quantity
                           ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            sold_qty,
                            0,
                            parent["item"],
                            parent["location"],
                            f"eBay order {order_id}",
                            parent["condition"],
                            legacy,
                            child_status,
                            time.strftime("%Y-%m-%d") if is_fulfilled else "",
                            order_id,
                            "EBAY ORDER SYNC",
                            parent["color"],
                            parent["id"],
                            line_id,
                            sold_qty,
                        ),
                    )
                    new_sale_lines += 1
                    if is_fulfilled:
                        sold_count += 1
                    else:
                        pending_count += 1

            con.commit()
        finally:
            con.close()

        self.after(0, self._inventory_refresh_all)
        return pending_count, sold_count, new_sale_lines


    def _inventory_sync_ebay(self, silent=False):
        if self.worker and self.worker.is_alive():
            if not silent:
                messagebox.showinfo("Inventory", "Another operation is already running.", parent=self)
            return

        self._save_settings_ui_silent()

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                # Record order lines first. Then use eBay's current active
                # quantity as the authoritative remaining STOCK for live listings.
                self._log("INVENTORY SYNC: loading recent eBay orders...")
                orders = client.get_recent_orders(90)
                pending, sold, new_sale_lines = self._inventory_sync_orders_apply(orders)

                self._log("INVENTORY SYNC: loading all current eBay listings...")
                active = client.get_all_active_listings()
                marked_listed, added_missing = self._inventory_sync_active_apply(active)

                if not silent:
                    self.after(
                        0,
                        lambda: messagebox.showinfo(
                            "Inventory Sync",
                            f"Full eBay reconciliation complete.\n\n"
                            f"Current active listings checked: {len(active):,}\n"
                            f"Recent orders checked: {len(orders):,}\n\n"
                            f"Existing inventory marked LISTED: {marked_listed:,}\n"
                            f"Active eBay listings added to Pending Location: {added_missing:,}\n"
                            f"New sale/order lines recorded: {new_sale_lines:,}\n"
                            f"Pending Shipping lines updated: {pending:,}\n"
                            f"Sold/shipped lines updated: {sold:,}\n\n"
                            "Partial-quantity sales are tracked separately. The main inventory row keeps "
                            "the remaining STOCK, while only the quantity actually purchased appears in "
                            "Pending Shipping/Sold. Current active eBay quantity is used to reconcile "
                            "remaining STOCK.",
                            parent=self,
                        ),
                    )
            except Exception as exc:
                msg = str(exc)
                if "403" in msg or "scope" in msg.lower() or "fulfillment" in msg.lower():
                    msg = (
                        "Inventory sync needs the eBay OAuth permissions configured for this app.\n\n"
                        "sell.fulfillment is required for order/shipping status, and the base api_scope "
                        "is used to read the full current eBay Active List.\n\n" + str(exc)
                    )
                self._log("INVENTORY EBAY SYNC ERROR: " + str(exc))
                if not silent:
                    self.after(
                        0,
                        lambda m=msg: messagebox.showerror("Inventory Sync", m, parent=self),
                    )

        threading.Thread(target=work, daemon=True).start()


    def _inventory_background_sync(self):
        try:
            self._inventory_sync_ebay(silent=True)
        finally:
            self.after(15*60*1000,self._inventory_background_sync)

    def _build_listing_tab(self):
        outer = self.listing_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        f = ttk.Frame(canvas, padding=(8, 6, 14, 20))
        window_id = canvas.create_window((0, 0), window=f, anchor="nw")

        def _sync_scrollregion(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_width(event):
            canvas.itemconfigure(window_id, width=event.width)

        f.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        def _on_mousewheel(event):
            if event.delta:
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"

        # Keep mouse-wheel handling local to this tab.  Do not use bind_all:
        # global bindings can make the notebook/tab area respond while another
        # tab is active.
        canvas.bind("<MouseWheel>", _on_mousewheel)
        f.bind("<MouseWheel>", _on_mousewheel)

        def _bind_descendant_wheel(widget):
            try:
                widget.bind("<MouseWheel>", _on_mousewheel, add="+")
            except Exception:
                pass
            try:
                for child in widget.winfo_children():
                    _bind_descendant_wheel(child)
            except Exception:
                pass

        # Widgets created later may not exist yet; schedule once UI construction
        # for this tab has completed.
        self.after_idle(lambda: _bind_descendant_wheel(f))

        f.columnconfigure(1, weight=1)
        f.columnconfigure(3, weight=1)

        ttk.Label(
            f,
            text="Scroll down for listing details, pricing, shipping, eBay actions, and status.",
            style="Subheader.TLabel",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        # Photos are intentionally the first workflow section.  V4.04 uses a
        # local thumbnail manager; local grouping/scoring makes no AI/network calls.
        if PhotoManagerFrame is not None:
            self.photo_manager = PhotoManagerFrame(
                f,
                on_change=self._photos_changed,
                on_analyze=self._analyze_photos,
                log=self._log,
            )
            self.photo_manager.grid(
                row=1, column=0, columnspan=4, sticky="nsew", pady=(0, 8)
            )
            # Compatibility alias used by the analysis worker.
            self.analyze_btn = self.photo_manager.analyze_btn
        else:
            self.photo_manager = None
            missing_frame = ttk.LabelFrame(f, text="1. Item Photos", padding=8)
            missing_frame.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(0, 8))
            ttk.Label(
                missing_frame,
                text=(
                    "Local photo manager is unavailable because Pillow is not installed. "
                    "Run INSTALL_IMAGE_SUPPORT.bat, then restart the tool. "
                    + PHOTO_MANAGER_IMPORT_ERROR
                ),
                wraplength=900, justify="left",
            ).pack(anchor="w")

        self.vars = {}
        fields = [
            ("Brand / Manufacturer", "brand"),
            ("MPN / Part Number", "mpn"),
            ("Model", "model"),
            ("Basic Item Description", "item_description"),
            ("SKU / Custom Label", "sku"),
            ("Price", "price"),
            ("Quantity", "quantity"),
            ("Country of Origin", "country"),
            ("Category ID", "category_id"),
        ]

        r = 2
        for i, (label, key) in enumerate(fields):
            col = 0 if i % 2 == 0 else 2
            if i % 2 == 0 and i > 0:
                r += 1
            ttk.Label(f, text=label + ":").grid(row=r, column=col, sticky="w", padx=(0, 6), pady=4)
            v = tk.StringVar()
            self.vars[key] = v
            e = ttk.Entry(f, textvariable=v)
            e.grid(row=r, column=col + 1, sticky="ew", padx=(0, 14), pady=4)
            if key == "category_id":
                self.category_entry = e
                e.bind("<FocusOut>", lambda _e: self._sync_category_requirements_async())
            if key in ("brand", "mpn", "item_description"):
                v.trace_add("write", lambda *_: self._auto_title())
        self.category_suggestion_label = ttk.Label(
            f, text="", foreground="gray"
        )
        self.category_suggestion_label.grid(
            row=r + 1, column=2, columnspan=2, sticky="w", pady=(0, 2)
        )
        self.category_requirements_var = tk.StringVar(
            value="Category requirements not synced yet."
        )
        ttk.Label(
            f,
            textvariable=self.category_requirements_var,
            foreground="gray",
            wraplength=850,
        ).grid(row=r + 2, column=0, columnspan=4, sticky="w", pady=(0, 3))
        r += 2

        ttk.Label(f, text="Condition:").grid(row=r, column=0, sticky="w", pady=4)
        self.condition_var = tk.StringVar()
        self.condition_combo = ttk.Combobox(
            f,
            textvariable=self.condition_var,
            values=list(CONDITION_MAP.keys()),
            state="readonly",
        )
        self.condition_combo.grid(row=r, column=1, sticky="ew", padx=(0, 14), pady=4)

        ttk.Label(f, text="Title:").grid(row=r, column=2, sticky="w", pady=4)
        self.title_var = tk.StringVar()
        ttk.Entry(f, textvariable=self.title_var).grid(row=r, column=3, sticky="ew", pady=4)

        r += 1
        price_frame = ttk.LabelFrame(f, text="2. Competitive Price Research", padding=8)
        price_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        price_frame.columnconfigure(0, weight=1)
        price_frame.columnconfigure(1, weight=1)
        price_frame.columnconfigure(2, weight=1)
        self.price_research_var = tk.StringVar(
            value="Not researched yet. Current eBay Buy It Now listings will be used."
        )
        ttk.Label(
            price_frame, textvariable=self.price_research_var, wraplength=760, justify="left"
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))
        self.research_price_btn = ttk.Button(
            price_frame, text="RESEARCH + SUGGEST PRICE",
            command=self._research_price_manual, style="Accent.TButton"
        )
        self.research_price_btn.grid(row=1, column=0, sticky="ew", padx=(0, 5))
        ttk.Button(
            price_frame, text="Open Sold / Completed Comps on eBay",
            command=self._open_sold_comps
        ).grid(row=1, column=1, sticky="ew", padx=5)
        ttk.Button(
            price_frame, text="Clear Price Research",
            command=self._clear_price_research
        ).grid(row=1, column=2, sticky="ew", padx=(5, 0))

        r += 1
        offer_frame = ttk.LabelFrame(f, text="3. Sale Format — Buy It Now / Best Offer", padding=6)
        offer_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=4)
        for c in range(6):
            offer_frame.columnconfigure(c, weight=1)
        ttk.Label(offer_frame, text="Listing format: Buy It Now (Fixed Price)").grid(
            row=0, column=0, columnspan=2, sticky="w"
        )
        self.best_offer_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            offer_frame, text="Accept Best Offers", variable=self.best_offer_var
        ).grid(row=0, column=2, sticky="w")
        ttk.Label(offer_frame, text="Auto-accept $:").grid(row=0, column=3, sticky="e")
        self.auto_accept_var = tk.StringVar()
        ttk.Entry(offer_frame, textvariable=self.auto_accept_var, width=12).grid(
            row=0, column=4, sticky="ew", padx=(4, 10)
        )
        ttk.Label(offer_frame, text="Auto-decline $:").grid(row=0, column=5, sticky="e")
        self.auto_decline_var = tk.StringVar()
        ttk.Entry(offer_frame, textvariable=self.auto_decline_var, width=12).grid(
            row=0, column=6, sticky="ew", padx=(4, 0)
        )

        r += 1
        policy_frame = ttk.LabelFrame(f, text="4. eBay Business Policies", padding=6)
        policy_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=4)
        for c in range(6):
            policy_frame.columnconfigure(c, weight=1)
        self.fulfillment_policy_var = tk.StringVar()
        self.payment_policy_var = tk.StringVar()
        self.return_policy_var = tk.StringVar()
        ttk.Label(policy_frame, text="Shipping:").grid(row=0, column=0, sticky="e", padx=(0, 4))
        self.fulfillment_combo = ttk.Combobox(
            policy_frame, textvariable=self.fulfillment_policy_var, state="readonly"
        )
        self.fulfillment_combo.grid(row=0, column=1, sticky="ew", padx=(0, 8))
        ttk.Label(policy_frame, text="Payment:").grid(row=0, column=2, sticky="e", padx=(0, 4))
        self.payment_combo = ttk.Combobox(
            policy_frame, textvariable=self.payment_policy_var, state="readonly"
        )
        self.payment_combo.grid(row=0, column=3, sticky="ew", padx=(0, 8))
        ttk.Label(policy_frame, text="Returns:").grid(row=0, column=4, sticky="e", padx=(0, 4))
        self.return_combo = ttk.Combobox(
            policy_frame, textvariable=self.return_policy_var, state="readonly"
        )
        self.return_combo.grid(row=0, column=5, sticky="ew", padx=(0, 8))
        ttk.Button(
            policy_frame, text="Refresh Policies from eBay", command=self._refresh_policies
        ).grid(row=1, column=0, columnspan=6, sticky="e", pady=(6, 0))

        r += 1
        shipping_frame = ttk.LabelFrame(f, text="5. Shipping Package", padding=8)
        shipping_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=5)
        for c in range(12):
            shipping_frame.columnconfigure(c, weight=1)

        self.package_length_var = tk.StringVar()
        self.package_width_var = tk.StringVar()
        self.package_height_var = tk.StringVar()
        self.package_lb_var = tk.StringVar()
        self.package_oz_var = tk.StringVar()
        self.package_type_var = tk.StringVar(value="Standard package / thick envelope")

        ttk.Label(shipping_frame, text="Length (in):").grid(row=0, column=0, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_length_var, width=8).grid(row=0, column=1, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Width (in):").grid(row=0, column=2, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_width_var, width=8).grid(row=0, column=3, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Height (in):").grid(row=0, column=4, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_height_var, width=8).grid(row=0, column=5, sticky="ew", padx=(4, 10))
        ttk.Label(shipping_frame, text="Weight:").grid(row=0, column=6, sticky="e")
        ttk.Entry(shipping_frame, textvariable=self.package_lb_var, width=7).grid(row=0, column=7, sticky="ew", padx=(4, 2))
        ttk.Label(shipping_frame, text="lb").grid(row=0, column=8, sticky="w")
        ttk.Entry(shipping_frame, textvariable=self.package_oz_var, width=7).grid(row=0, column=9, sticky="ew", padx=(4, 2))
        ttk.Label(shipping_frame, text="oz").grid(row=0, column=10, sticky="w")

        ttk.Label(shipping_frame, text="Package type:").grid(row=1, column=0, sticky="e", pady=(6, 0))
        self.package_type_combo = ttk.Combobox(
            shipping_frame,
            textvariable=self.package_type_var,
            values=list(PACKAGE_TYPE_MAP.keys()),
            state="readonly",
            width=32,
        )
        self.package_type_combo.grid(row=1, column=1, columnspan=4, sticky="ew", padx=(4, 10), pady=(6, 0))
        ttk.Label(
            shipping_frame,
            text="Used by eBay for calculated shipping; leave blank only when your policy does not need package data.",
            style="Subheader.TLabel",
        ).grid(row=1, column=5, columnspan=7, sticky="w", pady=(6, 0))

        r += 1
        ttk.Label(f, text="Condition Notes:").grid(row=r, column=0, sticky="nw", pady=4)
        self.condition_notes = tk.Text(f, height=4, wrap="word", bg="#fffdf8", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.condition_notes.grid(row=r, column=1, columnspan=3, sticky="ew", pady=4)

        r += 1
        ttk.Label(f, text="Extra Item Specifics:",).grid(row=r, column=0, sticky="nw", pady=4)
        specific_frame = ttk.Frame(f)
        specific_frame.grid(row=r, column=1, columnspan=3, sticky="ew", pady=4)
        specific_frame.columnconfigure(0, weight=1)
        self.specifics = tk.Text(specific_frame, height=6, wrap="none", bg="#fffdf8", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.specifics.grid(row=0, column=0, sticky="ew")
        ttk.Button(
            specific_frame,
            text="Sync Details",
            command=self._sync_category_requirements_async,
        ).grid(row=1, column=0, sticky="w", pady=(4, 2))
        ttk.Label(
            specific_frame,
            text=(
                "One per line: Connector Style=2 Row, 25-Pin. "
                "Required category details are checked against eBay before listing."
            ),
        ).grid(row=2, column=0, sticky="w", pady=(2, 0))

        r += 1
        button_frame = ttk.LabelFrame(f, text="6. Listing & eBay", padding=10)
        button_frame.grid(row=r, column=0, columnspan=4, sticky="ew", pady=10)
        for c in range(5):
            button_frame.columnconfigure(c, weight=1)

        ttk.Button(
            button_frame, text="PREVIEW", command=self._preview
        ).grid(row=0, column=0, padx=4, pady=4, sticky="ew")

        ttk.Button(
            button_frame, text="SUGGEST CATEGORY", command=self._suggest_category_manual
        ).grid(row=0, column=1, padx=4, pady=4, sticky="ew")

        ttk.Button(
            button_frame, text="SYNC DETAILS", command=self._sync_category_requirements_async
        ).grid(row=0, column=2, padx=4, pady=4, sticky="ew")

        listing_tools_btn = ttk.Menubutton(button_frame, text="LISTING TOOLS ▾")
        listing_tools_menu = tk.Menu(listing_tools_btn, tearoff=False)
        listing_tools_btn["menu"] = listing_tools_menu
        listing_tools_btn.grid(row=0, column=3, padx=4, pady=4, sticky="ew")
        listing_tools_menu.add_command(label="Save Listing File", command=self._save_listing_file)
        listing_tools_menu.add_command(label="Load Listing File", command=self._load_listing_file)
        listing_tools_menu.add_separator()
        listing_tools_menu.add_command(label="New / Clear Listing", command=self._new_listing)
        listing_tools_menu.add_separator()
        listing_tools_menu.add_command(
            label="Open Seller Hub",
            command=lambda: webbrowser.open("https://www.ebay.com/sh/lst/active"),
        )

        self.stop_btn = ttk.Button(
            button_frame,
            text="STOP / CANCEL",
            command=self._stop,
            state="disabled",
            style="Danger.TButton",
        )
        self.stop_btn.grid(row=0, column=4, padx=4, pady=4, sticky="ew")

        self.create_btn = ttk.Button(
            button_frame,
            text="SAVE DRAFT",
            command=self._create_draft,
        )
        self.create_btn.grid(row=1, column=0, padx=4, pady=(8, 4), sticky="ew")

        self.publish_btn = ttk.Button(
            button_frame,
            text="PUBLISH",
            command=self._publish_to_ebay,
            state="normal",
            style="Accent.TButton",
        )
        self.publish_btn.grid(row=1, column=1, padx=4, pady=(8, 4), sticky="ew")

        self.save_changes_btn = ttk.Button(
            button_frame,
            text="SAVE CHANGES",
            command=self._save_changes_to_ebay,
            state="normal",
        )
        self.save_changes_btn.grid(row=1, column=2, padx=4, pady=(8, 4), sticky="ew")

        self.create_publish_btn = ttk.Button(
            button_frame,
            text="CREATE + PUBLISH",
            command=self._create_draft_and_publish,
            style="Primary.TButton",
        )
        self.create_publish_btn.grid(
            row=1, column=3, columnspan=2, padx=4, pady=(8, 4), sticky="ew"
        )

        r += 1
        log_frame = ttk.LabelFrame(f, text="Status", padding=6)
        log_frame.grid(row=r, column=0, columnspan=4, sticky="nsew", pady=(4, 0))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_box = tk.Text(log_frame, height=8, wrap="word", state="disabled", bg="#f7f4ef", relief="flat", highlightthickness=1, highlightbackground="#d8d1c7")
        self.log_box.grid(row=0, column=0, sticky="nsew")

    def _build_existing_tab(self):
        f = self.existing_tab
        f.columnconfigure(1, weight=1)
        f.columnconfigure(3, weight=1)
        f.rowconfigure(3, weight=1)
        f.rowconfigure(5, weight=1)

        ttk.Label(
            f,
            text=(
                "Load an Inventory-API-created offer by Offer ID or SKU, then edit it "
                "in the Listing Editor tab. Published listing changes are live after Save Changes."
            ),
            wraplength=850,
            justify="left",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 12))

        self.lookup_offer_var = tk.StringVar()
        self.lookup_sku_var = tk.StringVar()

        ttk.Label(f, text="Offer ID:").grid(row=1, column=0, sticky="e", padx=(0, 5))
        ttk.Entry(f, textvariable=self.lookup_offer_var).grid(row=1, column=1, sticky="ew", padx=(0, 10))
        ttk.Button(f, text="Load Offer ID", command=self._load_existing_by_offer_id).grid(
            row=1, column=2, sticky="w"
        )

        ttk.Label(f, text="SKU / Custom Label:").grid(row=2, column=0, sticky="e", padx=(0, 5))
        ttk.Entry(f, textvariable=self.lookup_sku_var).grid(row=2, column=1, sticky="ew", padx=(0, 10))
        ttk.Button(f, text="Find by SKU", command=self._load_existing_by_sku).grid(
            row=2, column=2, sticky="w"
        )

        history_box = ttk.LabelFrame(f, text="Created by This App / Inventory API Offers", padding=8)
        history_box.grid(row=3, column=0, columnspan=4, sticky="nsew", pady=(10, 8))
        history_box.columnconfigure(0, weight=1)
        history_box.rowconfigure(1, weight=1)

        history_actions = ttk.Frame(history_box)
        history_actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(
            history_actions, text="Refresh Local History", command=self._refresh_offer_history_table
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            history_actions, text="Refresh from eBay", command=self._refresh_offers_from_ebay
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            history_actions, text="Load Selected Offer", command=self._load_selected_history_offer
        ).pack(side="left")

        cols = ("offer_id", "sku", "status", "listing_id", "title", "price", "category")
        self.offer_history_tree = ttk.Treeview(
            history_box, columns=cols, show="headings", height=8
        )
        headings = {
            "offer_id": "Offer ID",
            "sku": "SKU",
            "status": "Status",
            "listing_id": "Listing ID",
            "title": "Title",
            "price": "Price",
            "category": "Category",
        }
        widths = {
            "offer_id": 145, "sku": 120, "status": 95, "listing_id": 125,
            "title": 280, "price": 80, "category": 90,
        }
        for c in cols:
            self.offer_history_tree.heading(
                c,
                text=headings[c],
                command=lambda col=c, tr=self.offer_history_tree:
                    self._sort_treeview_column(tr, col),
            )
            self.offer_history_tree.column(c, width=widths[c], anchor="w")
        self.offer_history_tree.grid(row=1, column=0, sticky="nsew")
        hscroll = ttk.Scrollbar(
            history_box, orient="horizontal", command=self.offer_history_tree.xview
        )
        self.offer_history_tree.configure(xscrollcommand=hscroll.set)
        hscroll.grid(row=2, column=0, sticky="ew")
        self.offer_history_tree.bind(
            "<Double-1>", lambda e: self._load_selected_history_offer()
        )

        self.existing_status_var = tk.StringVar(value="No eBay offer loaded.")
        ttk.Label(
            f, textvariable=self.existing_status_var, wraplength=850, justify="left"
        ).grid(row=4, column=0, columnspan=4, sticky="w", pady=10)

        info = tk.Text(f, wrap="word", height=10, state="disabled")
        info.grid(row=5, column=0, columnspan=4, sticky="nsew")
        self.existing_info = info
        self.after_idle(self._refresh_offer_history_table)

    def _refresh_offer_history_table(self):
        tree = getattr(self, "offer_history_tree", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        rows = load_offer_history()
        for row in rows:
            tree.insert(
                "",
                "end",
                values=(
                    row.get("offer_id", ""),
                    row.get("sku", ""),
                    row.get("status", ""),
                    row.get("listing_id", ""),
                    row.get("title", ""),
                    row.get("price", ""),
                    row.get("category_id", ""),
                ),
            )

    def _load_selected_history_offer(self):
        tree = getattr(self, "offer_history_tree", None)
        if tree is None:
            return
        sel = tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select an offer in the table first.")
            return
        values = tree.item(sel[0], "values")
        offer_id = str(values[0] or "")
        if not offer_id:
            return
        self.lookup_offer_var.set(offer_id)
        self._load_existing_by_offer_id()

    def _refresh_offers_from_ebay(self):
        if self.worker and self.worker.is_alive():
            self._close_progress_popup()
            return
        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._show_progress_popup(
            "Refreshing eBay Offers",
            "Loading Inventory API items and their Offer IDs..."
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                items = client.get_inventory_items(limit=100)
                total = len(items)
                for idx, inventory in enumerate(items, start=1):
                    client._check_cancel()
                    sku = str(inventory.get("sku", "") or "")
                    if not sku:
                        continue
                    self.after(
                        0,
                        lambda i=idx, n=total, s=sku:
                            self._update_progress_popup(
                                f"Checking SKU {i} of {n}: {s}"
                            )
                    )
                    offers = client.get_offers_by_sku(sku)
                    product = inventory.get("product", {}) or {}
                    for offer in offers:
                        price = (
                            ((offer.get("pricingSummary", {}) or {}).get("price", {}) or {})
                            .get("value", "")
                        )
                        listing = offer.get("listing", {}) or {}
                        upsert_offer_history({
                            "offer_id": str(offer.get("offerId", "") or ""),
                            "sku": sku,
                            "status": str(offer.get("status", "") or ""),
                            "listing_id": str(listing.get("listingId", "") or ""),
                            "title": str(product.get("title", "") or ""),
                            "price": str(price or ""),
                            "category_id": str(offer.get("categoryId", "") or ""),
                        })
                self.after(0, self._refresh_offer_history_table)
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        f"Offer refresh complete. Checked {total} Inventory API item(s)."
                    )
                )
            except Exception as exc:
                self._log(f"OFFER HISTORY REFRESH ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _set_existing_info(self, text_value):
        self.existing_info.configure(state="normal")
        self.existing_info.delete("1.0", "end")
        self.existing_info.insert("1.0", text_value)
        self.existing_info.configure(state="disabled")

    def _build_settings_tab(self):
        outer = self.settings_tab
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        f = ttk.Frame(canvas, padding=(8, 6, 14, 24))
        window_id = canvas.create_window((0, 0), window=f, anchor="nw")

        def _sync_scrollregion(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_width(event):
            canvas.itemconfigure(window_id, width=event.width)

        f.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        def _on_mousewheel(event):
            if event.delta:
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"

        # Keep mouse-wheel handling local to this tab.  Do not use bind_all:
        # global bindings can make the notebook/tab area respond while another
        # tab is active.
        canvas.bind("<MouseWheel>", _on_mousewheel)
        f.bind("<MouseWheel>", _on_mousewheel)

        def _bind_descendant_wheel(widget):
            try:
                widget.bind("<MouseWheel>", _on_mousewheel, add="+")
            except Exception:
                pass
            try:
                for child in widget.winfo_children():
                    _bind_descendant_wheel(child)
            except Exception:
                pass

        # Widgets created later may not exist yet; schedule once UI construction
        # for this tab has completed.
        self.after_idle(lambda: _bind_descendant_wheel(f))

        f.columnconfigure(1, weight=1)

        self.setting_vars = {}
        settings_fields = [
            ("OAuth Access Token", "access_token"),
            ("Merchant Location Key", "merchant_location_key"),
            ("Payment Policy ID", "payment_policy_id"),
            ("Return Policy ID", "return_policy_id"),
            ("Fulfillment Policy ID", "fulfillment_policy_id"),
            ("Default Category ID", "default_category_id"),
            ("Marketplace", "marketplace_id"),
            ("Currency", "currency"),
            ("OpenAI API Key", "openai_api_key"),
            ("OpenAI Vision Model", "openai_model"),
            ("eBay App ID / Client ID", "ebay_client_id"),
            ("eBay Cert ID / Client Secret", "ebay_client_secret"),
            ("AI Photo Grouping Spend Cap ($)", "ai_grouping_spend_cap"),
            ("eBay Refresh Token (optional)", "ebay_refresh_token"),
            ("eBay OAuth RuName (optional)", "ebay_runame"),
        ]

        for r, (label, key) in enumerate(settings_fields):
            ttk.Label(f, text=label + ":").grid(row=r, column=0, sticky="w", padx=(0, 10), pady=6)
            v = tk.StringVar(value=self.settings.get(key, ""))
            self.setting_vars[key] = v
            show = "*" if key in ("access_token", "openai_api_key", "ebay_client_secret", "ebay_refresh_token") else ""
            ttk.Entry(f, textvariable=v, show=show).grid(row=r, column=1, sticky="ew", pady=6)

        r = len(settings_fields)
        ttk.Label(f, text="API Environment:").grid(row=r, column=0, sticky="w", pady=6)
        self.env_var = tk.StringVar(value=self.settings.get("api_environment", "production"))
        ttk.Combobox(
            f, textvariable=self.env_var, values=["production", "sandbox"], state="readonly"
        ).grid(row=r, column=1, sticky="w", pady=6)

        r += 1
        location_box = ttk.LabelFrame(f, text="Inventory Location / Merchant Location Key", padding=8)
        location_box.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(12, 6))
        location_box.columnconfigure(1, weight=1)

        self.location_choice_var = tk.StringVar()
        self.location_combo = ttk.Combobox(
            location_box, textvariable=self.location_choice_var, state="readonly"
        )
        ttk.Label(location_box, text="Existing locations:").grid(row=0, column=0, sticky="e", padx=(0, 6))
        self.location_combo.grid(row=0, column=1, sticky="ew")
        ttk.Button(
            location_box, text="Load Existing Locations", command=self._load_inventory_locations
        ).grid(row=0, column=2, padx=(6, 0))
        ttk.Button(
            location_box, text="Use Selected Location", command=self._use_selected_inventory_location
        ).grid(row=1, column=2, padx=(6, 0), pady=(6, 0))

        self.new_location_key_var = tk.StringVar(value="able-main-warehouse")
        self.new_location_name_var = tk.StringVar(value="Main Warehouse")
        self.new_location_postal_var = tk.StringVar()
        self.new_location_country_var = tk.StringVar(value="US")

        ttk.Label(location_box, text="New key:").grid(row=2, column=0, sticky="e", padx=(0, 6), pady=(12, 4))
        ttk.Entry(location_box, textvariable=self.new_location_key_var).grid(row=2, column=1, sticky="ew", pady=(12, 4))
        ttk.Label(location_box, text="Name:").grid(row=3, column=0, sticky="e", padx=(0, 6), pady=4)
        ttk.Entry(location_box, textvariable=self.new_location_name_var).grid(row=3, column=1, sticky="ew", pady=4)

        mini = ttk.Frame(location_box)
        mini.grid(row=4, column=1, sticky="ew", pady=4)
        mini.columnconfigure(1, weight=1)
        mini.columnconfigure(3, weight=1)
        ttk.Label(mini, text="Postal code:").grid(row=0, column=0, padx=(0, 4))
        ttk.Entry(mini, textvariable=self.new_location_postal_var, width=12).grid(row=0, column=1, sticky="ew", padx=(0, 8))
        ttk.Label(mini, text="Country:").grid(row=0, column=2, padx=(0, 4))
        ttk.Entry(mini, textvariable=self.new_location_country_var, width=8).grid(row=0, column=3, sticky="ew")

        ttk.Button(
            location_box, text="CREATE WAREHOUSE LOCATION",
            command=self._create_inventory_location, style="Accent.TButton"
        ).grid(row=5, column=1, sticky="e", pady=(8, 0))

        ttk.Label(
            location_box,
            text=(
                "The Merchant Location Key is a seller-defined permanent ID, not a secret key. "
                "For a normal warehouse, postal code + country are sufficient for eBay's Inventory API."
            ),
            wraplength=720, justify="left", style="Subheader.TLabel"
        ).grid(row=6, column=0, columnspan=3, sticky="w", pady=(8, 0))

        r += 1
        action_settings = ttk.Frame(f)
        action_settings.grid(row=r, column=1, sticky="e", pady=10)
        ttk.Button(action_settings, text="Save Settings", command=self._save_settings_ui).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(action_settings, text="Test eBay Connection", command=self._test_ebay_connection).grid(row=0, column=1)

        r += 1
        oauth_box = ttk.LabelFrame(f, text="Automatic eBay Login Refresh", padding=8)
        oauth_box.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(12, 6))
        oauth_box.columnconfigure(1, weight=1)

        ttk.Label(
            oauth_box,
            text=(
                "One-time setup: open eBay authorization, approve the same scopes, "
                "then paste the FINAL browser URL here. The app will extract the "
                "authorization code and securely exchange it for a refresh token."
            ),
            wraplength=760, justify="left"
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        oauth_actions = ttk.Frame(oauth_box)
        oauth_actions.grid(row=1, column=0, sticky="ew", padx=(0, 6))
        oauth_actions.columnconfigure(0, weight=1)
        oauth_actions.columnconfigure(1, weight=1)

        ttk.Button(
            oauth_actions,
            text="CHECK OAUTH SETUP",
            command=self._validate_oauth_setup,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))

        ttk.Button(
            oauth_actions,
            text="1. OPEN EBAY AUTHORIZATION",
            command=self._open_refresh_authorization,
            style="Accent.TButton",
        ).grid(row=0, column=1, sticky="ew", padx=(4, 0))

        self.oauth_return_url_var = tk.StringVar()
        ttk.Entry(
            oauth_box, textvariable=self.oauth_return_url_var
        ).grid(row=1, column=1, sticky="ew", padx=(0, 6))

        ttk.Button(
            oauth_box,
            text="2. SAVE REFRESH TOKEN",
            command=self._exchange_refresh_authorization,
            style="Accent.TButton",
        ).grid(row=1, column=2, sticky="ew")

        self.oauth_refresh_status_var = tk.StringVar(
            value="Automatic refresh is not configured yet."
        )
        ttk.Label(
            oauth_box,
            textvariable=self.oauth_refresh_status_var,
            wraplength=760,
            justify="left",
            style="Subheader.TLabel",
        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))

        if self.settings.get("ebay_refresh_token", "").strip():
            self.oauth_refresh_status_var.set(
                "Automatic refresh is configured. The app will refresh an expired "
                "eBay User Access Token automatically."
            )

        r += 1

        note = (
            "The eBay access/refresh tokens, eBay app secret, and OpenAI API key are stored locally on this computer in your user profile. "
            "The program never asks for or stores your eBay password.\n\n"
            "The OpenAI key is used when you click ANALYZE PHOTOS + FILL DETAILS or AI GROUP BATCH. "
            "Selected photos are then sent to the OpenAI API for analysis.\n\n"
            "This program deliberately has NO publishOffer function. Creating a draft here does not make a listing live.\n\n"
            "Once eBay authorization is connected, use Refresh Policies from eBay so the program loads your existing shipping, payment, and return policies by name. "
            "See SETUP_GUIDE.txt included with this program."
        )
        ttk.Label(f, text=note, wraplength=760, justify="left").grid(
            row=r, column=0, columnspan=2, sticky="w", pady=(16, 0)
        )

    def _log(self, msg):
        def write():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg.rstrip() + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.after(0, write)

    def _new_listing(self):
        for k, v in getattr(self, "vars", {}).items():
            v.set("")
        if hasattr(self, "vars"):
            self.vars["quantity"].set("1")
            self.vars["price"].set("")
            self.vars["category_id"].set(self.settings.get("default_category_id", ""))
        if hasattr(self, "condition_var"):
            self.condition_var.set("Used - Good")
        if hasattr(self, "condition_notes"):
            self.condition_notes.delete("1.0", "end")
        if hasattr(self, "specifics"):
            self.specifics.delete("1.0", "end")
        if hasattr(self, "title_var"):
            self.title_var.set("")
        if hasattr(self, "best_offer_var"):
            self.best_offer_var.set(True)
            self.auto_accept_var.set("")
            self.auto_decline_var.set("")
        if hasattr(self, "package_length_var"):
            self.package_length_var.set("")
            self.package_width_var.set("")
            self.package_height_var.set("")
            self.package_lb_var.set("")
            self.package_oz_var.set("")
            self.package_type_var.set("Standard package / thick envelope")
        self._clear_photos()
        self.existing_image_urls = []
        self.editing_offer_id = ""
        self.editing_offer_status = ""
        self.original_offer = None
        self.original_inventory_item = None
        if hasattr(self, "save_changes_btn"):
            self.save_changes_btn.config(state="normal")
        if hasattr(self, "publish_btn"):
            self.publish_btn.config(state="normal")
        if hasattr(self, "existing_status_var"):
            self.existing_status_var.set("No eBay offer loaded.")
        self.last_category_name = ""
        self.last_price_research = None
        if hasattr(self, "price_research_var"):
            self.price_research_var.set(
                "Not researched yet. Current eBay Buy It Now listings will be used."
            )
        if hasattr(self, "category_suggestion_label"):
            self.category_suggestion_label.config(text="")
        if hasattr(self, "log_box"):
            self.log_box.configure(state="normal")
            self.log_box.delete("1.0", "end")
            self.log_box.configure(state="disabled")

    def _auto_title(self):
        if not hasattr(self, "vars"):
            return
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        desc = self.vars["item_description"].get().strip()
        parts = []
        for p in (brand, mpn, desc):
            if p and p.lower() not in [x.lower() for x in parts]:
                parts.append(p)
        title = " ".join(parts).upper()
        self.title_var.set(title[:80])

    def _photos_changed(self, paths):
        # Exact photos currently checked "Use", in eBay upload order.
        self.photos = [str(p) for p in paths]
        if hasattr(self, "photo_label"):
            try:
                self.photo_label.config(text=f"{len(self.photos)} photo(s) selected")
            except Exception:
                pass

    def _select_photos(self):
        if getattr(self, "photo_manager", None) is not None:
            self.photo_manager.add_files()
            return
        paths = filedialog.askopenfilenames(
            title="Select item photos",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.bmp *.tif *.tiff *.webp *.heic *.heif *.avif"),
                ("All files", "*.*"),
            ],
        )
        if paths:
            self.photos = list(paths)

    def _clear_photos(self):
        self.photos = []
        manager = getattr(self, "photo_manager", None)
        if manager is not None and manager.records:
            manager.clear()

    def _policy_id_from_selection(self, kind):
        var = {
            "fulfillment": self.fulfillment_policy_var,
            "payment": self.payment_policy_var,
            "return": self.return_policy_var,
        }[kind]
        selected = var.get().strip()
        mapping = self.policy_maps.get(kind, {})
        if selected in mapping:
            return mapping[selected]
        # Fall back to the manually stored ID until policies are loaded.
        fallback_key = {
            "fulfillment": "fulfillment_policy_id",
            "payment": "payment_policy_id",
            "return": "return_policy_id",
        }[kind]
        return self.settings.get(fallback_key, "").strip()

    def _select_policy_by_id(self, kind, policy_id):
        policy_id = str(policy_id or "")
        mapping = self.policy_maps.get(kind, {})
        for display, pid in mapping.items():
            if str(pid) == policy_id:
                {
                    "fulfillment": self.fulfillment_policy_var,
                    "payment": self.payment_policy_var,
                    "return": self.return_policy_var,
                }[kind].set(display)
                return
        # If not loaded yet, leave combo blank; ID remains available through settings.

    def _apply_policies(self, policies):
        combos = {
            "fulfillment": self.fulfillment_combo,
            "payment": self.payment_combo,
            "return": self.return_combo,
        }
        vars_ = {
            "fulfillment": self.fulfillment_policy_var,
            "payment": self.payment_policy_var,
            "return": self.return_policy_var,
        }
        setting_keys = {
            "fulfillment": "fulfillment_policy_id",
            "payment": "payment_policy_id",
            "return": "return_policy_id",
        }
        for kind in ("fulfillment", "payment", "return"):
            mapping = {}
            for p in policies.get(kind, []):
                display = f'{p.get("name") or "(unnamed policy)"}  [{p.get("id")}]'
                mapping[display] = p.get("id", "")
            self.policy_maps[kind] = mapping
            combos[kind]["values"] = list(mapping.keys())
            current_id = self.settings.get(setting_keys[kind], "")
            chosen = ""
            for display, pid in mapping.items():
                if str(pid) == str(current_id):
                    chosen = display
                    break
            if not chosen and mapping:
                chosen = next(iter(mapping))
            vars_[kind].set(chosen)

            # Keep selected IDs as defaults in settings.
            if chosen:
                self.settings[setting_keys[kind]] = mapping[chosen]
        save_settings(self.settings)
        self._log(
            "Loaded eBay business policies: "
            f'{len(policies.get("fulfillment", []))} shipping, '
            f'{len(policies.get("payment", []))} payment, '
            f'{len(policies.get("return", []))} return.'
        )

    def _refresh_policies(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter an eBay OAuth access token first.")
            return
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._show_progress_popup(
            "Refreshing eBay Details",
            "Loading eBay shipping, payment, and return policies..."
        )

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                policies = client.get_business_policies()
                self.after(0, lambda: self._apply_policies(policies))
            except Exception as exc:
                self._log(f"POLICY LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _selected_photo_paths(self):
        """Return the exact photos checked 'Use' in the integrated photo manager."""
        pm = getattr(self, "photo_manager", None)

        if pm is not None and hasattr(pm, "selected_paths"):
            try:
                paths = list(pm.selected_paths)
                return [str(p) for p in paths if Path(str(p)).exists()]
            except Exception as exc:
                self._log(f"Photo selection sync error: {exc}")

        # Legacy fallback only.
        return [
            str(p)
            for p in getattr(self, "photos", [])
            if Path(str(p)).exists()
        ]

    def _sync_selected_photos(self):
        self.photos = list(self._selected_photo_paths())
        if hasattr(self, "photo_label"):
            self.photo_label.config(text=f"{len(self.photos)} photo(s) selected")
        return self.photos

    def _generate_description(self):
        item = self.vars["item_description"].get().strip()
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        subject = " ".join(x for x in (brand, mpn, item) if x).strip()
        quantity = self.vars["quantity"].get().strip()
        prefix = "These are" if quantity.isdigit() and int(quantity) > 1 else "This is a"
        first = f"{prefix} {subject}.".replace("  ", " ").strip()
        return first + "\n\n" + BOILERPLATE

    def _collect(self):
        self._sync_selected_photos()
        try:
            qty = int(self.vars["quantity"].get().strip())
            if qty < 0:
                raise ValueError
        except Exception:
            raise ValueError("Quantity must be a whole number 0 or greater.")
        try:
            price = float(self.vars["price"].get().strip())
            if price <= 0:
                raise ValueError
        except Exception:
            raise ValueError("Price must be a number greater than zero.")

        if self.best_offer_var.get():
            for label, raw in (
                ("Auto-accept price", self.auto_accept_var.get().strip()),
                ("Auto-decline price", self.auto_decline_var.get().strip()),
            ):
                if raw:
                    try:
                        if float(raw) <= 0:
                            raise ValueError
                    except Exception:
                        raise ValueError(f"{label} must be blank or a number greater than zero.")
            if self.auto_accept_var.get().strip() and self.auto_decline_var.get().strip():
                if float(self.auto_decline_var.get()) >= float(self.auto_accept_var.get()):
                    raise ValueError("Auto-decline price should be lower than auto-accept price.")

        # Shipping package validation.
        dim_raw = [
            self.package_length_var.get().strip(),
            self.package_width_var.get().strip(),
            self.package_height_var.get().strip(),
        ]
        any_dims = any(dim_raw)
        if any_dims and not all(dim_raw):
            raise ValueError("If you enter package dimensions, fill Length, Width, and Height.")
        dimensions = None
        if all(dim_raw):
            try:
                length, width, height = [float(x) for x in dim_raw]
                if min(length, width, height) <= 0:
                    raise ValueError
            except Exception:
                raise ValueError("Package dimensions must be numbers greater than zero.")
            dimensions = {"length": length, "width": width, "height": height}

        lb_raw = self.package_lb_var.get().strip()
        oz_raw = self.package_oz_var.get().strip()
        weight_oz = None
        if lb_raw or oz_raw:
            try:
                lbs = float(lb_raw or 0)
                oz = float(oz_raw or 0)
                if lbs < 0 or oz < 0:
                    raise ValueError
                weight_oz = lbs * 16.0 + oz
                if weight_oz <= 0:
                    raise ValueError
            except Exception:
                raise ValueError("Package weight must be a positive number of pounds/ounces.")

        title = self.title_var.get().strip()
        if not title:
            raise ValueError("A title is required.")
        if len(title) > 80:
            raise ValueError("The title is over 80 characters.")

        sku = self.vars["sku"].get().strip()
        if not sku:
            sku = sanitize_sku(
                "-".join(
                    x for x in (
                        self.vars["brand"].get(),
                        self.vars["mpn"].get(),
                        str(int(time.time())),
                    ) if x.strip()
                )
            )
            self.vars["sku"].set(sku)

        return {
            "brand": self.vars["brand"].get().strip(),
            "mpn": self.vars["mpn"].get().strip(),
            "model": self.vars["model"].get().strip(),
            "item_description": self.vars["item_description"].get().strip(),
            "sku": sku,
            "price": price,
            "quantity": qty,
            "country": self.vars["country"].get().strip(),
            "category_id": self.vars["category_id"].get().strip(),
            "condition": self.condition_var.get(),
            "condition_notes": self.condition_notes.get("1.0", "end").strip(),
            "specifics": self.specifics.get("1.0", "end").strip(),
            "title": title,
            "description": self._generate_description(),
            "photos": list(self.photos),
            "existing_image_urls": list(self.existing_image_urls),
            "best_offer_enabled": bool(self.best_offer_var.get()),
            "auto_accept_price": (
                float(self.auto_accept_var.get().strip())
                if self.best_offer_var.get() and self.auto_accept_var.get().strip()
                else None
            ),
            "auto_decline_price": (
                float(self.auto_decline_var.get().strip())
                if self.best_offer_var.get() and self.auto_decline_var.get().strip()
                else None
            ),
            "fulfillment_policy_id": self._policy_id_from_selection("fulfillment"),
            "payment_policy_id": self._policy_id_from_selection("payment"),
            "return_policy_id": self._policy_id_from_selection("return"),
            "package_dimensions": dimensions,
            "package_weight_oz": weight_oz,
            "package_type": PACKAGE_TYPE_MAP.get(
                self.package_type_var.get(), "PACKAGE_THICK_ENVELOPE"
            ),
        }

    def _does_not_apply_value(self, marketplace_id="EBAY_US"):
        # This build targets eBay US by default. The US product-identifier
        # substitute text documented by eBay is exactly "Does not apply".
        marketplace_id = str(marketplace_id or "EBAY_US")
        return "Does not apply"

    def _sync_category_specifics(self, client, listing, update_ui=False):
        """
        Normalize listing specifics against the chosen eBay leaf category.

        Required FREE_TEXT aspects that are missing are filled with eBay's
        marketplace-appropriate "Does not apply" placeholder. Selection-only
        required aspects are only auto-filled when eBay explicitly offers an
        equivalent value; otherwise the listing is stopped for review.
        """
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return {"required": 0, "recommended": 0, "filled": 0, "unresolved": []}

        aspects = client.get_item_aspects_for_category(category_id)
        if isinstance(aspects, dict):
            aspects = [aspects]
        aspects = [a for a in (aspects or []) if isinstance(a, dict)]

        existing = parse_specifics(listing.get("specifics", ""))
        existing_by_lower = {
            str(k).strip().lower(): (k, list(v) if isinstance(v, list) else [v])
            for k, v in existing.items()
        }

        dedicated = {
            "brand": str(listing.get("brand", "") or "").strip(),
            "mpn": str(listing.get("mpn", "") or "").strip(),
            "model": str(listing.get("model", "") or "").strip(),
            "country of origin": str(listing.get("country", "") or "").strip(),
        }

        normalized = {}
        required_count = 0
        recommended_count = 0
        filled_count = 0
        unresolved = []
        allowed_names = set()

        dna_generic = self._does_not_apply_value(
            self.settings.get("marketplace_id", "EBAY_US")
        )

        def find_dna(allowed):
            targets = {
                "does not apply",
                "doesn't apply",
                "not applicable",
                "n/a",
                "na",
            }
            for value in allowed:
                if str(value).strip().lower() in targets:
                    return str(value).strip()
            return ""

        for aspect in aspects:
            name = str(aspect.get("localizedAspectName", "") or "").strip()
            if not name:
                continue
            lower = name.lower()
            allowed_names.add(lower)

            constraint = aspect.get("aspectConstraint", {}) or {}
            if not isinstance(constraint, dict):
                constraint = {}

            required = bool(constraint.get("aspectRequired", False))
            usage = str(constraint.get("aspectUsage", "") or "").upper()
            mode = str(constraint.get("aspectMode", "") or "").upper()

            if required:
                required_count += 1
            elif usage == "RECOMMENDED":
                recommended_count += 1

            allowed = []
            for av in aspect.get("aspectValues", []) or []:
                if isinstance(av, dict):
                    value = str(av.get("localizedValue", "") or "").strip()
                    if value:
                        allowed.append(value)

            # Prefer the dedicated editor fields for common eBay aspects.
            value = dedicated.get(lower, "")
            if not value and lower in existing_by_lower:
                vals = existing_by_lower[lower][1]
                if vals:
                    value = str(vals[0]).strip()

            # Canonicalize selection-only values to eBay's exact spelling.
            if value and mode == "SELECTION_ONLY" and allowed:
                match = next((v for v in allowed if v.lower() == value.lower()), None)
                if match:
                    value = match
                elif required:
                    unresolved.append(
                        f"{name}: '{value}' is not an allowed value. "
                        f"Allowed examples: {', '.join(allowed[:12])}"
                    )
                    value = ""
                else:
                    # Drop an invalid optional value rather than sending data
                    # eBay says is not applicable to this category.
                    value = ""

            if required and not value:
                dna_allowed = find_dna(allowed)
                if dna_allowed:
                    value = dna_allowed
                    filled_count += 1
                elif mode != "SELECTION_ONLY":
                    value = dna_generic
                    filled_count += 1
                else:
                    unresolved.append(
                        f"{name}: required by eBay and must be chosen from "
                        f"{', '.join(allowed[:12]) or 'the category-specific allowed values'}"
                    )

            if value:
                normalized[name] = [value]

                if lower == "brand":
                    listing["brand"] = value
                elif lower == "mpn":
                    listing["mpn"] = value
                elif lower == "model":
                    listing["model"] = value
                elif lower == "country of origin":
                    listing["country"] = value

        # Preserve existing custom/recommended details only when eBay returned
        # that aspect name for this category. This prevents carrying item
        # specifics from one category into a completely different category.
        for lower, (original_name, values) in existing_by_lower.items():
            if lower in allowed_names and original_name not in normalized:
                normalized[original_name] = values

        listing["specifics"] = format_specifics(normalized)

        summary = {
            "required": required_count,
            "recommended": recommended_count,
            "filled": filled_count,
            "unresolved": unresolved,
            "aspect_count": len(aspects),
        }

        self._log(
            f"CATEGORY SYNC {category_id}: {len(aspects)} applicable aspect(s), "
            f"{required_count} required, {recommended_count} recommended, "
            f"{filled_count} missing required value(s) filled with Does not apply."
        )

        if update_ui:
            def apply_ui():
                self.vars["brand"].set(str(listing.get("brand", "") or ""))
                self.vars["mpn"].set(str(listing.get("mpn", "") or ""))
                self.vars["model"].set(str(listing.get("model", "") or ""))
                self.vars["country"].set(str(listing.get("country", "") or ""))
                self.specifics.delete("1.0", "end")
                self.specifics.insert("1.0", listing.get("specifics", ""))
                if hasattr(self, "category_requirements_var"):
                    self.category_requirements_var.set(
                        f"eBay category {category_id}: {len(aspects)} applicable specifics • "
                        f"{required_count} required • {recommended_count} recommended • "
                        f"{filled_count} missing required value(s) auto-filled."
                    )
            self.after(0, apply_ui)

        if unresolved:
            raise RuntimeError(
                "eBay requires category-specific details that cannot safely be "
                "filled with 'Does not apply':\n\n• "
                + "\n• ".join(unresolved)
            )

        return summary

    def _sync_category_requirements_async(self):
        category_id = str(self.vars.get("category_id").get() or "").strip()
        if not category_id:
            return
        if self.worker and self.worker.is_alive():
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        if hasattr(self, "category_requirements_var"):
            self.category_requirements_var.set(
                f"Checking eBay requirements for category {category_id}..."
            )

        # Build only the fields needed for metadata sync; no price/shipping
        # validation is needed for this UI operation.
        listing = {
            "category_id": category_id,
            "brand": self.vars["brand"].get().strip(),
            "mpn": self.vars["mpn"].get().strip(),
            "model": self.vars["model"].get().strip(),
            "country": self.vars["country"].get().strip(),
            "specifics": self.specifics.get("1.0", "end").strip(),
        }

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                summary = self._sync_category_specifics(client, listing, update_ui=True)
                policy = client.get_item_condition_policies(category_id)

                def finish():
                    self._apply_condition_policy(policy, category_id, show_message=False)
                    if hasattr(self, "category_requirements_var"):
                        self.category_requirements_var.set(
                            f"eBay category {category_id}: "
                            f"{summary.get('aspect_count', 0)} applicable specifics • "
                            f"{summary.get('required', 0)} required • "
                            f"{summary.get('recommended', 0)} recommended • "
                            f"{summary.get('filled', 0)} missing required value(s) auto-filled."
                        )
                self.after(0, finish)
            except Exception as exc:
                err = str(exc)
                self._log(f"CATEGORY REQUIREMENTS ERROR: {err}")
                self.after(
                    0,
                    lambda e=err: messagebox.showerror(
                        "eBay Category Requirements",
                        e,
                        parent=self,
                    )
                )

        threading.Thread(target=work, daemon=True).start()

    def _validate_category_product_identifiers(self, client, listing):
        """
        Validate Brand/MPN against eBay's leaf-category Taxonomy metadata before
        any Inventory API write. This converts error 25002/BrandMPN into a useful
        preflight message.
        """
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return True

        aspects = client.get_item_aspects_for_category(category_id)
        if isinstance(aspects, dict):
            aspects = [aspects]
        if not isinstance(aspects, list):
            aspects = []

        meta = {}
        for aspect in aspects:
            if not isinstance(aspect, dict):
                continue
            name = str(aspect.get("localizedAspectName", "") or "").strip()
            if not name:
                continue
            constraint = aspect.get("aspectConstraint", {}) or {}
            if not isinstance(constraint, dict):
                constraint = {}

            allowed = []
            for av in aspect.get("aspectValues", []) or []:
                if isinstance(av, dict) and av.get("localizedValue") is not None:
                    allowed.append(str(av.get("localizedValue")).strip())

            meta[name.lower()] = {
                "name": name,
                "required": bool(constraint.get("aspectRequired", False)),
                "usage": str(constraint.get("aspectUsage", "") or ""),
                "mode": str(constraint.get("aspectMode", "") or ""),
                "allowed": [x for x in allowed if x],
            }

        specifics = parse_specifics(listing.get("specifics", ""))

        # Reject a combined custom BrandMPN aspect early.
        for key in specifics:
            if str(key).strip().lower().replace(" ", "") == "brandmpn":
                raise RuntimeError(
                    "eBay does not accept 'BrandMPN' as one combined item specific.\\n\\n"
                    "Use the separate Brand / Manufacturer and MPN / Part Number fields."
                )

        def first_specific(name):
            for key, vals in specifics.items():
                if str(key).strip().lower() == name.lower():
                    if isinstance(vals, list) and vals:
                        return str(vals[0]).strip()
                    if vals:
                        return str(vals).strip()
            return ""

        brand = str(listing.get("brand", "") or "").strip() or first_specific("Brand")
        mpn = str(listing.get("mpn", "") or "").strip() or first_specific("MPN")

        brand_meta = meta.get("brand")
        mpn_meta = meta.get("mpn")

        brand_required = bool(brand_meta and brand_meta.get("required"))
        mpn_required = bool(mpn_meta and mpn_meta.get("required"))

        # If eBay requires either member of the Brand/MPN product identifier pair,
        # require both before attempting the listing.
        if brand_required or mpn_required:
            missing = []
            if not brand:
                missing.append("Brand / Manufacturer")
            if not mpn:
                missing.append("MPN / Part Number")
            if missing:
                raise RuntimeError(
                    f"eBay category {category_id} requires a valid Brand/MPN product "
                    "identifier pair.\\n\\nMissing: "
                    + ", ".join(missing)
                    + "\\n\\nFill those fields with the markings from the item, then try again."
                )

        # If the user supplies one side of a supported Brand/MPN pair, don't send
        # an incomplete pair that eBay can reject as BrandMPN.
        if brand_meta and mpn_meta and bool(brand) != bool(mpn):
            missing = "MPN / Part Number" if brand else "Brand / Manufacturer"
            raise RuntimeError(
                f"The selected category supports Brand + MPN as a product identifier pair.\\n\\n"
                f"You supplied only one side of the pair. Fill in {missing}, or clear "
                "both fields if they are genuinely not applicable and eBay permits that."
            )

        # For selection-only Brand fields, require an eBay-supported value.
        if brand and brand_meta and brand_meta.get("mode") == "SELECTION_ONLY":
            allowed = brand_meta.get("allowed", []) or []
            if allowed:
                match = next((v for v in allowed if v.lower() == brand.lower()), None)
                if match:
                    brand = match
                else:
                    preview = ", ".join(allowed[:15])
                    more = "..." if len(allowed) > 15 else ""
                    raise RuntimeError(
                        f"eBay does not accept Brand '{brand}' for category {category_id}.\\n\\n"
                        f"This category requires a predefined Brand value. Examples: "
                        f"{preview}{more}"
                    )

        listing["brand"] = brand
        listing["mpn"] = mpn

        self._log(
            "PRODUCT IDENTIFIER PREFLIGHT: "
            f"Brand={'present' if brand else 'blank'}, "
            f"MPN={'present' if mpn else 'blank'}, "
            f"Brand required={brand_required}, MPN required={mpn_required}."
        )
        return True

    def _condition_displays_for_ids(self, condition_ids):
        allowed = set(str(x) for x in condition_ids)
        displays = []
        for display, enum_value in CONDITION_MAP.items():
            if CONDITION_ID_BY_ENUM.get(enum_value) in allowed:
                displays.append(display)
        return displays

    def _apply_condition_policy(self, policy, category_id, show_message=False):
        if not isinstance(policy, dict):
            self._log(
                f"Condition policy type {type(policy).__name__} could not be applied."
            )
            return True

        conditions = policy.get("conditions", []) or []
        if isinstance(conditions, dict):
            conditions = [conditions]
        elif isinstance(conditions, (str, int, float)):
            conditions = [conditions]

        ids = []
        for entry in conditions:
            cid = entry.get("id") if isinstance(entry, dict) else entry
            if cid:
                ids.append(str(cid))
        displays = self._condition_displays_for_ids(ids)
        current = self.condition_var.get()

        if getattr(self, "condition_combo", None) is not None and displays:
            self.condition_combo["values"] = displays

        if displays and current not in displays:
            # Do not silently change the seller's meaning. Select the first valid
            # option only as a visible placeholder and tell the user to review.
            self.condition_var.set(displays[0])
            self._log(
                f"Condition '{current}' is not valid for category {category_id}. "
                f"Changed selector to '{displays[0]}' for review."
            )
            if show_message:
                messagebox.showwarning(
                    APP_NAME,
                    f"The previous condition '{current}' is not allowed in eBay category {category_id}.\\n\\n"
                    f"Valid choices shown by eBay:\\n"
                    + "\\n".join("• " + d for d in displays)
                    + f"\\n\\nThe selector is currently set to '{displays[0]}'. "
                      "Please choose the condition that accurately describes the item."
                )
            return False

        if show_message and displays:
            messagebox.showinfo(
                APP_NAME,
                f"Condition '{current}' is valid for category {category_id}."
            )
        return True

    def _validate_category_condition_sync(self, client, listing, show_message=False):
        category_id = str(listing.get("category_id", "") or "").strip()
        if not category_id:
            return True
        policy = client.get_item_condition_policies(category_id)
        raw_conditions = policy.get("conditions", []) if isinstance(policy, dict) else []
        raw_conditions = raw_conditions or []
        if isinstance(raw_conditions, dict):
            raw_conditions = [raw_conditions]
        elif isinstance(raw_conditions, (str, int, float)):
            raw_conditions = [raw_conditions]

        allowed_ids = set()
        for entry in raw_conditions:
            cid = entry.get("id") if isinstance(entry, dict) else entry
            if cid:
                allowed_ids.add(str(cid))
        enum_value = CONDITION_MAP.get(listing.get("condition", ""))
        condition_id = CONDITION_ID_BY_ENUM.get(enum_value)

        # Some categories do not use Condition. If eBay says it is required but
        # gives us no usable values, stop instead of guessing.
        if not allowed_ids:
            if isinstance(policy, dict) and policy.get("required"):
                raise RuntimeError(
                    f"eBay says a condition is required for category {category_id}, "
                    "but no usable condition values were returned."
                )
            return True

        if condition_id not in allowed_ids:
            # Some eBay categories collapse granular "Used - Good/Excellent/etc."
            # into one broad "Used / Pre-owned" condition. Normalize that case
            # automatically because it preserves the seller's underlying meaning.
            current_name = str(listing.get("condition", "") or "")
            valid_names = self._condition_displays_for_ids(allowed_ids)

            compatible = None
            if current_name.lower().startswith("used"):
                compatible = next(
                    (name for name in valid_names if "used / pre-owned" in name.lower()),
                    None,
                )
            elif "parts" in current_name.lower():
                compatible = next(
                    (name for name in valid_names if "parts" in name.lower()),
                    None,
                )
            elif current_name.lower().startswith("new"):
                if "open" in current_name.lower():
                    compatible = next(
                        (name for name in valid_names if "open box" in name.lower()),
                        None,
                    )
                if compatible is None:
                    compatible = next(
                        (name for name in valid_names if name.lower() == "new"),
                        None,
                    )

            if compatible:
                self._log(
                    f"Condition normalization: '{current_name}' -> '{compatible}' "
                    f"for category {category_id}."
                )
                listing["condition"] = compatible
                enum_value = CONDITION_MAP.get(compatible)
                condition_id = CONDITION_ID_BY_ENUM.get(enum_value)
                self.after(0, lambda v=compatible: self.condition_var.set(v))

            if condition_id in allowed_ids:
                return True

            self.after(
                0,
                lambda p=policy, cid=category_id:
                    self._apply_condition_policy(p, cid, show_message=True)
            )
            valid_names = self._condition_displays_for_ids(allowed_ids)
            raise RuntimeError(
                f"Selected condition '{listing.get('condition')}' is not valid for category "
                f"{category_id}. Choose one of: {', '.join(valid_names) or 'the eBay-provided conditions'}."
            )
        return True

    def _category_query(self):
        parts = [
            self.vars["brand"].get().strip(),
            self.vars["mpn"].get().strip(),
            self.vars["model"].get().strip(),
            self.vars["item_description"].get().strip(),
            self.title_var.get().strip(),
        ]
        # Preserve order but remove duplicates / blanks.
        out = []
        seen = set()
        for p in parts:
            key = p.lower()
            if p and key not in seen:
                out.append(p)
                seen.add(key)
        return " ".join(out)[:350]

    def _apply_category_suggestion(self, suggestion):
        cid = suggestion.get("category_id", "")
        breadcrumb = suggestion.get("breadcrumb", "") or suggestion.get("category_name", "")
        if cid:
            self.vars["category_id"].set(cid)
            self.last_category_name = breadcrumb
            self.category_suggestion_label.config(
                text=f"eBay suggestion: {breadcrumb}  (Category {cid})"
            )
            self._log(f"eBay selected category {cid}: {breadcrumb}")

            # Immediately synchronize the category's applicable item specifics
            # and allowed condition choices.
            self._sync_category_requirements_async()

    def _suggest_category_manual(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(
                APP_NAME,
                "An eBay OAuth access token is required to ask eBay for category suggestions."
            )
            return
        query = self._category_query()
        if not query:
            messagebox.showerror(
                APP_NAME,
                "Enter or analyze enough item information to identify the item first."
            )
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log(f"Category search query: {query}")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                suggestion = client.suggest_category(query)
                self.after(0, lambda: self._apply_category_suggestion(suggestion))
            except Exception as exc:
                self._log(f"CATEGORY SUGGESTION ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()


    def _price_research_query(self):
        brand = self.vars["brand"].get().strip()
        mpn = self.vars["mpn"].get().strip()
        model = self.vars["model"].get().strip()
        desc = self.vars["item_description"].get().strip()

        # Exact part number is the best signal for obscure surplus inventory.
        if mpn:
            return " ".join(x for x in (brand, mpn) if x).strip()
        if model:
            return " ".join(x for x in (brand, model, desc) if x).strip()
        return " ".join(x for x in (brand, desc) if x).strip() or self.title_var.get().strip()

    def _clear_price_research(self):
        self.last_price_research = None
        self.price_research_var.set(
            "Not researched yet. Current eBay Buy It Now listings will be used."
        )

    def _open_sold_comps(self):
        query = self._price_research_query()
        if not query:
            messagebox.showerror(APP_NAME, "Identify the item before opening sold comps.")
            return
        params = {
            "_nkw": query,
            "LH_Sold": "1",
            "LH_Complete": "1",
        }
        category_id = self.vars["category_id"].get().strip()
        if category_id:
            params["_sacat"] = category_id
        webbrowser.open("https://www.ebay.com/sch/i.html?" + parse.urlencode(params))

    def _apply_price_research(self, result):
        self.last_price_research = result
        suggested = float(result["suggested"])
        self.vars["price"].set(f"{suggested:.2f}")
        summary = (
            f"Suggested ${suggested:.2f} from {result['used_count']} usable active comps "
            f"({result['count']} returned). "
            f"Low ${result['low']:.2f} • Median ${result['median']:.2f} • "
            f"High ${result['high']:.2f}. "
            "Target is competitive lower-middle pricing, not automatic lowest-price undercutting."
        )
        self.price_research_var.set(summary)
        self._log("PRICE RESEARCH: " + summary)
        for comp in result.get("comparables", [])[:5]:
            self._log(f"  ${comp['price']:.2f} | {comp['title'][:100]}")

    def _research_price_manual(self):
        self._sync_selected_photos()
        if self.worker and self.worker.is_alive():
            return
        query = self._price_research_query()
        if not query:
            messagebox.showerror(
                APP_NAME, "Analyze the photos or enter enough item information first."
            )
            return
        self._save_settings_ui_silent()
        if not self.settings.get("ebay_client_id", "").strip() or not self.settings.get("ebay_client_secret", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Price research needs your eBay App ID and Cert ID in eBay Settings. "
                "Those become available after the developer application is approved."
            )
            return

        self.cancel_event.clear()
        self.research_price_btn.config(state="disabled")
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                result = client.research_price(
                    query, self.vars["category_id"].get().strip()
                )
                self.after(0, lambda: self._apply_price_research(result))
            except Exception as exc:
                self._log(f"PRICE RESEARCH ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.research_price_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _analyze_photos(self):
        self._log("ANALYZE SELECTED clicked.")
        self._show_progress_popup(
            "AI Photo Analysis",
            "Preparing selected photos for OpenAI analysis..."
        )
        self._sync_selected_photos()
        self._log(f"Photos currently checked Use: {len(self.photos)}")
        if not self.photos:
            messagebox.showerror(
                APP_NAME,
                "No photos are currently checked 'Use'.\n\n"
                "Check at least one thumbnail in the Photo Manager and try again."
            )
            self._close_progress_popup()
            return
        if self.worker and self.worker.is_alive():
            self._log("Analyze did not start because another background operation is still running.")
            messagebox.showinfo(
                APP_NAME,
                "Another operation is still running. Wait for it to finish or press STOP / CANCEL."
            )
            return
        if not self.photos:
            messagebox.showerror(APP_NAME, "Select/check at least one photo in the Photo Manager first.")
            return

        self._save_settings_ui_silent()
        if not self.settings.get("openai_api_key", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Open the eBay Settings tab and enter your OpenAI API key first."
            )
            return

        if not messagebox.askyesno(
            APP_NAME,
            "Analyze the selected photos and fill the listing fields?\n\n"
            "The photos will be sent to the OpenAI API. Existing listing text "
            "may be replaced. Nothing will be sent to eBay."
        ):
            return

        self.cancel_event.clear()
        if getattr(self, "analyze_btn", None) is not None:
            self.analyze_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log("Starting photo analysis. Nothing is being sent to eBay.")

        def work():
            try:
                analyzer = PhotoAnalyzer(
                    self.settings.copy(), self.cancel_event, self._log
                )
                result = analyzer.analyze(self.photos)
                if self.cancel_event.is_set():
                    raise RuntimeError("Cancelled by user.")

                def apply_result():
                    mapping = {
                        "brand": "brand",
                        "mpn": "mpn",
                        "model": "model",
                        "item_description": "item_description",
                        "country": "country",
                    }
                    for source, dest in mapping.items():
                        value = str(result.get(source, "") or "").strip()
                        if value:
                            self.vars[dest].set(value)

                    title = str(result.get("title", "") or "").strip()
                    if title:
                        self.title_var.set(title[:80])

                    condition = result.get("condition", "")
                    if condition in CONDITION_MAP:
                        self.condition_var.set(condition)

                    self.condition_notes.delete("1.0", "end")
                    self.condition_notes.insert(
                        "1.0", str(result.get("condition_notes", "") or "").strip()
                    )

                    self.specifics.delete("1.0", "end")
                    self.specifics.insert(
                        "1.0", str(result.get("specifics", "") or "").strip()
                    )

                    notes = str(result.get("review_notes", "") or "").strip()
                    usage = result.get("_usage", {}) or {}
                    cost = float(usage.get("estimated_cost", 0.0) or 0.0)
                    self.session_ai_cost += cost
                    self.session_ai_analyses += 1
                    avg = self.session_ai_cost / self.session_ai_analyses
                    per_five = int(5.0 / avg) if avg > 0 else 0

                    self._log(
                        "Photo analysis complete. REVIEW EVERY FILLED FIELD "
                        "before creating the eBay draft."
                    )
                    self._log(
                        f"AI COST: ${cost:.4f} this analysis | "
                        f"{usage.get('input_tokens', 0):,} input tokens | "
                        f"{usage.get('output_tokens', 0):,} output tokens"
                    )
                    self._log(
                        f"SESSION AI SPEND: ${self.session_ai_cost:.4f} across "
                        f"{self.session_ai_analyses} analysis(es) | "
                        f"At this average, $5 ≈ {per_five:,} analyses"
                    )
                    if notes:
                        self._log("AI REVIEW NOTES: " + notes)

                    # Once the AI has identified the item, let eBay's own Taxonomy
                    # service choose the best category when eBay authorization exists.
                    category_message = ""
                    if self.settings.get("access_token", "").strip():
                        try:
                            client = EbayClient(
                                self.settings.copy(), self.cancel_event, self._log
                            )
                            suggestion = client.suggest_category(self._category_query())
                            self._apply_category_suggestion(suggestion)
                            category_message = (
                                f"\n\neBay suggested category:\n"
                                f"{suggestion.get('breadcrumb', '')} "
                                f"({suggestion.get('category_id', '')})"
                            )
                        except Exception as cat_exc:
                            self._log(f"Automatic category suggestion failed: {cat_exc}")
                            category_message = (
                                "\n\nI could not automatically choose the eBay category. "
                                "You can use 'Suggest eBay Category' after checking your eBay token."
                            )
                    else:
                        category_message = (
                            "\n\nCategory selection will become automatic once your eBay "
                            "OAuth token is entered."
                        )

                    price_message = ""
                    if (
                        self.settings.get("ebay_client_id", "").strip()
                        and self.settings.get("ebay_client_secret", "").strip()
                    ):
                        try:
                            price_client = EbayClient(
                                self.settings.copy(), self.cancel_event, self._log
                            )
                            price_result = price_client.research_price(
                                self._price_research_query(),
                                self.vars["category_id"].get().strip(),
                            )
                            self._apply_price_research(price_result)
                            price_message = (
                                f"\n\nCompetitive price suggestion: "
                                f"${price_result['suggested']:.2f} "
                                f"(median ${price_result['median']:.2f}, "
                                f"{price_result['used_count']} usable active comps)"
                            )
                        except Exception as price_exc:
                            self._log(f"Automatic price research failed: {price_exc}")
                            price_message = (
                                "\n\nAutomatic price research could not complete. "
                                "Use RESEARCH + SUGGEST PRICE after checking your eBay app credentials."
                            )
                    else:
                        price_message = (
                            "\n\nPrice research will become automatic once your eBay "
                            "App ID and Cert ID are entered."
                        )

                    messagebox.showinfo(
                        APP_NAME,
                        "Photo analysis finished and the listing fields were filled.\n\n"
                        f"OpenAI model: {usage.get('model', self.settings.get('openai_model', ''))}\n"
                        f"ACTUAL AI COST: ${cost:.4f}\n"
                        f"Input tokens: {usage.get('input_tokens', 0):,} | "
                        f"Output tokens: {usage.get('output_tokens', 0):,}\n"
                        f"Session AI spend: ${self.session_ai_cost:.4f}\n"
                        f"At this session average, $5 ≈ {per_five:,} analyses.\n\n"
                        "Please review the title, part number, condition and item specifics "
                        "before creating an eBay draft."
                        + category_message
                        + price_message
                        + (f"\n\nReview notes:\n{notes}" if notes else "")
                    )

                self.after(0, apply_result)
            except Exception as exc:
                self._log(f"PHOTO ANALYSIS STOPPED / ERROR: {exc}")
                def show_analyze_error(e=str(exc)):
                    self._close_progress_popup()
                    messagebox.showerror(APP_NAME, e)
                self.after(0, show_analyze_error)
            finally:
                if getattr(self, "analyze_btn", None) is not None:
                    self.after(0, lambda: self.analyze_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)


        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _preview(self):
        try:
            d = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        # Gather visual sources in exact gallery order.
        visual_sources = []
        pm = getattr(self, "photo_manager", None)
        if pm is not None:
            try:
                visual_sources = pm.ordered_image_sources()
            except Exception:
                visual_sources = []
        if not visual_sources:
            visual_sources = [("local", p) for p in d.get("photos", [])]
            if not visual_sources:
                visual_sources = [("remote", u) for u in self.existing_image_urls]

        win = tk.Toplevel(self)
        win.title("eBay-style Listing Preview — approximate")
        win.geometry("1180x820")
        win.minsize(900, 650)

        canvas = tk.Canvas(win, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        root = ttk.Frame(canvas, padding=18)
        root_id = canvas.create_window((0, 0), window=root, anchor="nw")
        root.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(root_id, width=e.width))

        banner = ttk.Frame(root, padding=(0, 0, 0, 12))
        banner.grid(row=0, column=0, columnspan=2, sticky="ew")
        ttk.Label(
            banner,
            text="Approximate eBay buyer-view preview",
            style="Header.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            banner,
            text=(
                "This mimics the information hierarchy of an eBay listing so you can "
                "review it before publishing. Final eBay fonts/layout may differ."
            ),
            style="Subheader.TLabel",
        ).pack(anchor="w")

        root.columnconfigure(0, weight=3)
        root.columnconfigure(1, weight=2)

        # Image gallery
        gallery = ttk.Frame(root)
        gallery.grid(row=1, column=0, sticky="nsew", padx=(0, 18))
        gallery.columnconfigure(0, weight=1)

        main_photo = ttk.Label(
            gallery,
            text="No listing photo",
            anchor="center",
            relief="solid",
            padding=8,
        )
        main_photo.grid(row=0, column=0, sticky="nsew")
        main_photo._img_ref = None

        thumb_row = ttk.Frame(gallery)
        thumb_row.grid(row=1, column=0, sticky="w", pady=(8, 0))
        thumb_refs = []

        def load_preview_image(kind, value, max_size=(620, 520)):
            try:
                if kind == "local":
                    im = _open_oriented(value)
                else:
                    req = request.Request(value, headers={"User-Agent": "Mozilla/5.0"})
                    with request.urlopen(req, timeout=20) as resp:
                        import io
                        im = Image.open(io.BytesIO(resp.read()))
                        im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail(max_size, Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(im)
            except Exception:
                return None

        def select_source(kind, value):
            img = load_preview_image(kind, value)
            if img:
                main_photo._img_ref = img
                main_photo.configure(image=img, text="")
            else:
                main_photo.configure(image="", text="Photo preview unavailable")

        for idx, (kind, value) in enumerate(visual_sources[:12]):
            img = load_preview_image(kind, value, (90, 90))
            if img:
                thumb_refs.append(img)
                b = ttk.Button(
                    thumb_row,
                    image=img,
                    command=lambda k=kind, v=value: select_source(k, v),
                )
            else:
                b = ttk.Button(
                    thumb_row,
                    text=f"#{idx + 1}",
                    command=lambda k=kind, v=value: select_source(k, v),
                )
            b.grid(row=0, column=idx, padx=(0, 5))

        if visual_sources:
            select_source(*visual_sources[0])

        # Buyer-side detail panel
        details = ttk.Frame(root, padding=4)
        details.grid(row=1, column=1, sticky="nsew")
        ttk.Label(
            details,
            text=d["title"],
            wraplength=430,
            justify="left",
            font=("Segoe UI Semibold", 17),
        ).pack(anchor="w", pady=(0, 6))
        ttk.Label(
            details,
            text=f"Condition: {d['condition']}",
            font=("Segoe UI", 10),
        ).pack(anchor="w", pady=(0, 12))
        ttk.Label(
            details,
            text=f"${float(d['price']):,.2f}",
            font=("Segoe UI Semibold", 24),
        ).pack(anchor="w", pady=(0, 6))
        ttk.Label(
            details,
            text="Buy It Now",
            font=("Segoe UI Semibold", 12),
        ).pack(anchor="w")

        if d["best_offer_enabled"]:
            offer_text = "Best Offer accepted"
            if d["auto_accept_price"] is not None:
                offer_text += f" • auto-accept ≥ ${d['auto_accept_price']:.2f}"
            ttk.Label(details, text=offer_text).pack(anchor="w", pady=(4, 12))
        else:
            ttk.Label(details, text="Best Offer disabled").pack(anchor="w", pady=(4, 12))

        ttk.Separator(details).pack(fill="x", pady=8)
        ttk.Label(details, text=f"Quantity available: {d['quantity']}").pack(anchor="w", pady=3)
        package_text = "Package dimensions not entered"
        if d["package_dimensions"]:
            pd = d["package_dimensions"]
            package_text = (
                f"Package: {pd['length']} × {pd['width']} × {pd['height']} in"
            )
        if d["package_weight_oz"] is not None:
            package_text += f" • {d['package_weight_oz'] / 16:.2f} lb"
        ttk.Label(details, text=package_text, wraplength=430).pack(anchor="w", pady=3)
        ttk.Label(
            details,
            text=(
                f"Shipping policy: {d['fulfillment_policy_id'] or '[not selected]'}\\n"
                f"Returns: {d['return_policy_id'] or '[not selected]'}\\n"
                f"Payment: {d['payment_policy_id'] or '[not selected]'}"
            ),
            justify="left",
        ).pack(anchor="w", pady=8)

        # Lower listing information
        lower = ttk.Frame(root)
        lower.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(22, 0))
        lower.columnconfigure(0, weight=1)

        specifics_box = ttk.LabelFrame(lower, text="Item specifics", padding=12)
        specifics_box.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        specifics = parse_specifics(d["specifics"])
        common = [
            ("Brand", d["brand"]),
            ("MPN", d["mpn"]),
            ("Model", d["model"]),
            ("Country of Origin", d["country"]),
            ("SKU / Custom Label", d["sku"]),
            ("eBay Category ID", d["category_id"]),
        ]
        sr = 0
        for name, value in common:
            if value:
                ttk.Label(specifics_box, text=name + ":").grid(
                    row=sr, column=0, sticky="nw", padx=(0, 12), pady=2
                )
                ttk.Label(specifics_box, text=str(value), wraplength=850).grid(
                    row=sr, column=1, sticky="nw", pady=2
                )
                sr += 1
        for name, values in specifics.items():
            ttk.Label(specifics_box, text=name + ":").grid(
                row=sr, column=0, sticky="nw", padx=(0, 12), pady=2
            )
            ttk.Label(
                specifics_box,
                text=", ".join(str(v) for v in values),
                wraplength=850,
            ).grid(row=sr, column=1, sticky="nw", pady=2)
            sr += 1

        if d["condition_notes"]:
            cond_box = ttk.LabelFrame(lower, text="Seller's condition description", padding=12)
            cond_box.grid(row=1, column=0, sticky="ew", pady=(0, 12))
            ttk.Label(
                cond_box,
                text=d["condition_notes"],
                wraplength=1000,
                justify="left",
            ).pack(anchor="w")

        desc_box = ttk.LabelFrame(lower, text="Item description", padding=12)
        desc_box.grid(row=2, column=0, sticky="ew")
        ttk.Label(
            desc_box,
            text=d["description"],
            wraplength=1040,
            justify="left",
        ).pack(anchor="w")

        # Keep refs alive.
        win._thumb_refs = thumb_refs


    def _save_listing_file(self):
        try:
            d = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        path = filedialog.asksaveasfilename(
            title="Save listing",
            defaultextension=".json",
            filetypes=[("Listing JSON", "*.json")],
            initialfile=(d["sku"] or "listing") + ".json",
        )
        if path:
            Path(path).write_text(json.dumps(d, indent=2), encoding="utf-8")
            self._log(f"Saved listing file: {path}")

    def _load_listing_file(self):
        path = filedialog.askopenfilename(
            title="Load listing",
            filetypes=[("Listing JSON", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            d = json.loads(Path(path).read_text(encoding="utf-8"))
            for key in self.vars:
                if key in d:
                    self.vars[key].set(str(d[key]))
            self.condition_var.set(d.get("condition", "Used - Good"))
            self.title_var.set(d.get("title", ""))
            self.condition_notes.delete("1.0", "end")
            self.condition_notes.insert("1.0", d.get("condition_notes", ""))
            self.specifics.delete("1.0", "end")
            self.specifics.insert("1.0", d.get("specifics", ""))
            self.best_offer_var.set(bool(d.get("best_offer_enabled", True)))
            self.auto_accept_var.set(
                "" if d.get("auto_accept_price") is None else str(d.get("auto_accept_price"))
            )
            self.auto_decline_var.set(
                "" if d.get("auto_decline_price") is None else str(d.get("auto_decline_price"))
            )
            dims = d.get("package_dimensions") or {}
            self.package_length_var.set(str(dims.get("length", "") or ""))
            self.package_width_var.set(str(dims.get("width", "") or ""))
            self.package_height_var.set(str(dims.get("height", "") or ""))
            weight_oz = d.get("package_weight_oz")
            if weight_oz is not None:
                total = float(weight_oz)
                whole_lb = int(total // 16)
                remain_oz = total - whole_lb * 16
                self.package_lb_var.set(str(whole_lb))
                self.package_oz_var.set(f"{remain_oz:.2f}".rstrip("0").rstrip("."))
            else:
                self.package_lb_var.set("")
                self.package_oz_var.set("")
            api_type = d.get("package_type", "PACKAGE_THICK_ENVELOPE")
            display_type = "Standard package / thick envelope"
            for display, api_value in PACKAGE_TYPE_MAP.items():
                if api_value == api_type:
                    display_type = display
                    break
            self.package_type_var.set(display_type)
            self.existing_image_urls = list(d.get("existing_image_urls", []) or [])
            self.photos = [p for p in d.get("photos", []) if Path(p).exists()]
            if getattr(self, "photo_manager", None) is not None:
                self.photo_manager.set_paths(self.photos)
            self._log(f"Loaded listing file: {path}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Could not load listing:\n{exc}")

    def _condition_display_from_api(self, api_value):
        for display, api in CONDITION_MAP.items():
            if api == api_value:
                return display
        return "Used - Good"

    def _specifics_text_from_aspects(self, aspects):
        lines = []
        for key, values in (aspects or {}).items():
            if key in ("Brand", "MPN", "Model", "Country of Origin"):
                continue
            if isinstance(values, list):
                value = ", ".join(str(v) for v in values)
            else:
                value = str(values)
            lines.append(f"{key}={value}")
        return "\n".join(lines)

    def _load_offer_into_editor(self, offer, inventory):
        self.original_offer = offer
        self.original_inventory_item = inventory
        self.editing_offer_id = str(offer.get("offerId", "") or "")
        self.editing_offer_status = str(offer.get("status", "") or "")
        sku = str(offer.get("sku", "") or inventory.get("sku", "") or "")

        product = inventory.get("product", {}) or {}
        aspects = product.get("aspects", {}) or {}
        self.vars["sku"].set(sku)
        self.vars["brand"].set(str(product.get("brand", "") or (aspects.get("Brand", [""])[0] if aspects.get("Brand") else "")))
        self.vars["mpn"].set(str(product.get("mpn", "") or (aspects.get("MPN", [""])[0] if aspects.get("MPN") else "")))
        self.vars["model"].set(str((aspects.get("Model", [""])[0] if aspects.get("Model") else "")))
        self.vars["country"].set(str((aspects.get("Country of Origin", [""])[0] if aspects.get("Country of Origin") else "")))
        self.vars["item_description"].set("")  # title/description remain editable below
        self.title_var.set(str(product.get("title", "") or ""))

        price = ((offer.get("pricingSummary", {}) or {}).get("price", {}) or {}).get("value", "")
        self.vars["price"].set(str(price))
        quantity = offer.get("availableQuantity")
        if quantity is None:
            quantity = (
                ((inventory.get("availability", {}) or {}).get("shipToLocationAvailability", {}) or {})
                .get("quantity", 1)
            )
        self.vars["quantity"].set(str(quantity))
        self.vars["category_id"].set(str(offer.get("categoryId", "") or ""))
        self.category_suggestion_label.config(
            text=f"Loaded from eBay (Category {self.vars['category_id'].get()})"
        )

        self.condition_var.set(
            self._condition_display_from_api(str(inventory.get("condition", "") or ""))
        )
        self.condition_notes.delete("1.0", "end")
        self.condition_notes.insert("1.0", str(inventory.get("conditionDescription", "") or ""))
        self.specifics.delete("1.0", "end")
        self.specifics.insert("1.0", self._specifics_text_from_aspects(aspects))

        package = inventory.get("packageWeightAndSize", {}) or {}
        dims = package.get("dimensions", {}) or {}
        self.package_length_var.set(str(dims.get("length", "") or ""))
        self.package_width_var.set(str(dims.get("width", "") or ""))
        self.package_height_var.set(str(dims.get("height", "") or ""))

        weight = package.get("weight", {}) or {}
        weight_value = weight.get("value")
        weight_unit = str(weight.get("unit", "") or "").upper()
        lbs = ""
        oz = ""
        if weight_value not in (None, ""):
            try:
                w = float(weight_value)
                if weight_unit == "POUND":
                    total_oz = w * 16.0
                elif weight_unit == "KILOGRAM":
                    total_oz = w * 35.27396195
                elif weight_unit == "GRAM":
                    total_oz = w * 0.03527396195
                else:
                    total_oz = w
                whole_lb = int(total_oz // 16)
                remain_oz = total_oz - whole_lb * 16
                lbs = str(whole_lb)
                oz = f"{remain_oz:.2f}".rstrip("0").rstrip(".")
            except Exception:
                pass
        self.package_lb_var.set(lbs)
        self.package_oz_var.set(oz)

        api_package_type = str(package.get("packageType", "") or "")
        display_package_type = "Standard package / thick envelope"
        for display, api_value in PACKAGE_TYPE_MAP.items():
            if api_value == api_package_type:
                display_package_type = display
                break
        self.package_type_var.set(display_package_type)

        self.existing_image_urls = list(product.get("imageUrls", []) or [])
        self.photos = []
        if getattr(self, "photo_manager", None) is not None:
            if self.existing_image_urls:
                self.photo_manager.set_remote_urls(self.existing_image_urls)
            else:
                self.photo_manager.clear()

        listing_policies = offer.get("listingPolicies", {}) or {}
        self._select_policy_by_id("fulfillment", listing_policies.get("fulfillmentPolicyId"))
        self._select_policy_by_id("payment", listing_policies.get("paymentPolicyId"))
        self._select_policy_by_id("return", listing_policies.get("returnPolicyId"))

        terms = listing_policies.get("bestOfferTerms", {}) or {}
        self.best_offer_var.set(bool(terms.get("bestOfferEnabled", False)))
        auto_accept = (terms.get("autoAcceptPrice", {}) or {}).get("value", "")
        auto_decline = (terms.get("autoDeclinePrice", {}) or {}).get("value", "")
        self.auto_accept_var.set(str(auto_accept or ""))
        self.auto_decline_var.set(str(auto_decline or ""))

        # Preserve the actual offer description rather than replacing it simply by loading.
        # The standard generated description is shown/used if the user changes listing details.
        loaded_desc = str(offer.get("listingDescription", "") or product.get("description", "") or "")
        if loaded_desc:
            # Set a short descriptive phrase only when safely derivable from the title is not possible.
            self.vars["item_description"].set(str(product.get("subtitle", "") or ""))

        status_text = (
            f"Loaded Offer {self.editing_offer_id} | SKU {sku} | "
            f"Status {self.editing_offer_status}"
        )
        listing = offer.get("listing", {}) or {}
        if listing.get("listingId"):
            status_text += f" | Listing ID {listing.get('listingId')}"
        upsert_offer_history({
            "offer_id": self.editing_offer_id,
            "sku": sku,
            "status": self.editing_offer_status,
            "listing_id": str(listing.get("listingId", "") or ""),
            "title": self.title_var.get(),
            "price": str(price or ""),
            "category_id": self.vars["category_id"].get(),
        })
        self._refresh_offer_history_table()
        self.existing_status_var.set(status_text)

        # Refresh category-specific condition choices immediately for loaded offers.
        loaded_category = self.vars["category_id"].get().strip()
        if loaded_category:
            def refresh_loaded_condition_policy():
                try:
                    client = EbayClient(
                        self.settings.copy(), self.cancel_event, self._log
                    )
                    policy = client.get_item_condition_policies(loaded_category)
                    self.after(
                        0,
                        lambda p=policy, c=loaded_category:
                            self._apply_condition_policy(
                                p, c, show_message=True
                            )
                    )
                except Exception as exc:
                    self._log(
                        f"Could not refresh condition policy for loaded offer: {exc}"
                    )
            threading.Thread(
                target=refresh_loaded_condition_policy, daemon=True
            ).start()
        self._set_existing_info(
            status_text
            + "\n\nTitle: " + self.title_var.get()
            + "\nPrice: $" + str(price)
            + "\nCategory ID: " + self.vars["category_id"].get()
            + "\nBest Offer: " + ("Enabled" if self.best_offer_var.get() else "Disabled")
            + "\nShipping package: "
            + (
                f"{self.package_length_var.get()} x {self.package_width_var.get()} x {self.package_height_var.get()} in, "
                f"{self.package_lb_var.get() or '0'} lb {self.package_oz_var.get() or '0'} oz"
                if any((self.package_length_var.get(), self.package_width_var.get(), self.package_height_var.get(), self.package_lb_var.get(), self.package_oz_var.get()))
                else "[not set]"
            )
            + "\nExisting eBay photos: " + str(len(self.existing_image_urls))
            + "\n\nThe Listing Editor tab is now populated. "
              "Use SAVE CHANGES TO EBAY when you are ready."
        )
        self.save_changes_btn.config(state="normal")
        if hasattr(self, "publish_btn"):
            self.publish_btn.config(
                state="normal"
                if self.editing_offer_id and self.editing_offer_status.upper() != "PUBLISHED"
                else "disabled"
            )
        self.notebook.select(self.listing_tab)
        self._log(status_text)

    def _fetch_and_load_offer(self, offer_id):
        self._save_settings_ui_silent()
        client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
        offer = client.get_offer(offer_id)
        sku = offer.get("sku")
        if not sku:
            raise RuntimeError("eBay returned the offer but did not include its SKU.")
        inventory = client.get_inventory_item(sku)
        self.after(0, lambda: self._load_offer_into_editor(offer, inventory))

    def _load_existing_by_offer_id(self):
        offer_id = self.lookup_offer_var.get().strip()
        if not offer_id:
            messagebox.showerror(APP_NAME, "Enter an Offer ID.")
            return
        self._run_existing_lookup(lambda: self._fetch_and_load_offer(offer_id))

    def _load_existing_by_sku(self):
        sku = self.lookup_sku_var.get().strip()
        if not sku:
            messagebox.showerror(APP_NAME, "Enter a SKU / Custom Label.")
            return

        def lookup():
            self._save_settings_ui_silent()
            client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
            offers = client.get_offers_by_sku(sku)
            if not offers:
                raise RuntimeError(f"No Inventory API offers were found for SKU {sku}.")
            if len(offers) > 1:
                self._log(
                    f"Multiple offers found for SKU {sku}; loading the first offer "
                    f"for marketplace {self.settings.get('marketplace_id', 'EBAY_US')}."
                )
            offer = offers[0]
            inventory = client.get_inventory_item(sku)
            self.after(0, lambda: self._load_offer_into_editor(offer, inventory))

        self._run_existing_lookup(lookup)

    def _run_existing_lookup(self, fn):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter an eBay OAuth access token first.")
            return
        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                fn()
            except Exception as exc:
                self._log(f"EXISTING LISTING LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_changes_to_ebay(self):
        self._sync_selected_photos()
        if not self.editing_offer_id or not self.original_offer:
            messagebox.showinfo(
                APP_NAME,
                "There is no existing eBay offer loaded to revise.\n\n"
                "Load one from the Existing eBay Listing tab first."
            )
            return
        if self.worker and self.worker.is_alive():
            return
        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        is_live = self.editing_offer_status.upper() == "PUBLISHED"
        warning = (
            "This offer is PUBLISHED. A successful update will change the LIVE eBay listing immediately."
            if is_live
            else "This offer is currently unpublished. Changes will update the eBay offer but will not publish it."
        )
        if not messagebox.askyesno(
            APP_NAME,
            warning
            + "\n\nContinue saving these changes to eBay?\n\n"
              "The program still does not contain a Publish command."
        ):
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.save_changes_btn.config(state="normal")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log(f"Updating existing eBay offer {self.editing_offer_id}...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                # Preserve the exact gallery order, mixing existing eBay images
                # and newly added local images without unnecessary re-uploading.
                sources = (
                    self.photo_manager.ordered_image_sources()
                    if getattr(self, "photo_manager", None) is not None
                    else []
                )
                urls = []
                if sources:
                    for kind, value in sources:
                        client._check_cancel()
                        if kind == "remote":
                            urls.append(value)
                        else:
                            urls.append(client.upload_image(value))
                    listing["image_urls"] = urls
                elif listing["photos"]:
                    listing["image_urls"] = [
                        client.upload_image(p) for p in listing["photos"]
                    ]
                else:
                    listing["image_urls"] = list(self.existing_image_urls)

                if not listing["image_urls"]:
                    raise RuntimeError(
                        "The listing has no eBay photos. Select at least one photo before saving."
                    )

                client._check_cancel()
                self._sync_category_specifics(client, listing, update_ui=True)
                self._validate_category_product_identifiers(client, listing)
                self._validate_category_condition_sync(client, listing)
                client.create_inventory_item(listing["sku"], listing)

                client._check_cancel()
                client.update_offer(
                    self.editing_offer_id, listing, self.original_offer
                )

                client._check_cancel()
                self._log(
                    f"SUCCESS: Offer {self.editing_offer_id} updated."
                    + (" The live listing was revised." if is_live else " The offer remains unpublished.")
                )
                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        APP_NAME,
                        "Changes saved to eBay successfully.\n\n"
                        + (
                            "This was a published offer, so the live listing was revised."
                            if is_live
                            else "The offer remains unpublished."
                        )
                    )
                )
                # Reload from eBay so the editor has the authoritative current object.
                updated_offer = client.get_offer(self.editing_offer_id)
                updated_inventory = client.get_inventory_item(listing["sku"])
                self.after(
                    0,
                    lambda: self._load_offer_into_editor(
                        updated_offer, updated_inventory
                    )
                )
            except Exception as exc:
                self._log(f"UPDATE ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(
                    0,
                    lambda: self.save_changes_btn.config(
                        state="normal" if self.editing_offer_id else "disabled"
                    )
                )
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _format_inventory_location(self, loc):
        key = str(loc.get("merchantLocationKey", "") or "")
        name = str(loc.get("name", "") or "")
        status = str(loc.get("merchantLocationStatus", "") or "")
        address = ((loc.get("location", {}) or {}).get("address", {}) or {})
        postal = str(address.get("postalCode", "") or "")
        country = str(address.get("country", "") or "")
        return f"{name or key}  [{key}]  {postal} {country}  {status}".strip()

    def _load_inventory_locations(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter your eBay User Access Token first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                locations = client.get_inventory_locations()
                mapping = {}
                for loc in locations:
                    key = str(loc.get("merchantLocationKey", "") or "")
                    if key:
                        mapping[self._format_inventory_location(loc)] = key

                def done():
                    self.inventory_location_map = mapping
                    self.location_combo["values"] = list(mapping.keys())
                    if mapping:
                        # Prefer currently configured key.
                        current = self.settings.get("merchant_location_key", "")
                        choice = ""
                        for display, key in mapping.items():
                            if key == current:
                                choice = display
                                break
                        if not choice:
                            choice = next(iter(mapping))
                        self.location_choice_var.set(choice)
                        messagebox.showinfo(
                            APP_NAME,
                            f"Found {len(mapping)} eBay inventory location(s).\\n\\n"
                            "Choose one and click Use Selected Location."
                        )
                    else:
                        self.location_choice_var.set("")
                        messagebox.showinfo(
                            APP_NAME,
                            "No Inventory API locations were found.\\n\\n"
                            "Create a warehouse location in the section below."
                        )
                self.after(0, done)
            except Exception as exc:
                self._log(f"LOCATION LOAD ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _use_selected_inventory_location(self):
        display = self.location_choice_var.get().strip()
        mapping = getattr(self, "inventory_location_map", {})
        key = mapping.get(display)
        if not key:
            messagebox.showerror(APP_NAME, "Load and select an inventory location first.")
            return
        self.setting_vars["merchant_location_key"].set(key)
        self.settings["merchant_location_key"] = key
        save_settings(self.settings)
        messagebox.showinfo(
            APP_NAME,
            f"Merchant Location Key set to:\\n\\n{key}"
        )

    def _create_inventory_location(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()

        key = self.new_location_key_var.get().strip()
        name = self.new_location_name_var.get().strip()
        postal = self.new_location_postal_var.get().strip()
        country = self.new_location_country_var.get().strip() or "US"

        if not key or not name or not postal:
            messagebox.showerror(
                APP_NAME,
                "Enter a Merchant Location Key, location name, and postal code."
            )
            return

        if not messagebox.askyesno(
            APP_NAME,
            "Create this eBay Inventory API warehouse?\\n\\n"
            f"Merchant Location Key: {key}\\n"
            f"Name: {name}\\n"
            f"Postal Code: {postal}\\n"
            f"Country: {country}\\n\\n"
            "The Merchant Location Key cannot be renamed later."
        ):
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                created_key = client.create_warehouse_location(key, name, postal, country)

                def done():
                    self.setting_vars["merchant_location_key"].set(created_key)
                    self.settings["merchant_location_key"] = created_key
                    save_settings(self.settings)
                    messagebox.showinfo(
                        APP_NAME,
                        "Warehouse location created successfully.\\n\\n"
                        f"Merchant Location Key: {created_key}\\n\\n"
                        "The app saved this as your default location."
                    )
                    self._load_inventory_locations()
                self.after(0, done)
            except Exception as exc:
                self._log(f"LOCATION CREATE ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _ebay_oauth_scope_list(self):
        # Scopes selected for this app's current feature set.
        return [
            "https://api.ebay.com/oauth/api_scope",
            "https://api.ebay.com/oauth/api_scope/sell.inventory",
            "https://api.ebay.com/oauth/api_scope/sell.account",
            "https://api.ebay.com/oauth/api_scope/sell.fulfillment",
        ]

    def _validate_oauth_setup(self, show_success=True):
        """
        Validate the values we can verify locally before opening eBay.
        This does not expose or transmit the Client Secret.
        """
        self._save_settings_ui_silent()
        env = self.settings.get("api_environment", "production").strip()
        client_id = self.settings.get("ebay_client_id", "").strip()
        client_secret = self.settings.get("ebay_client_secret", "").strip()
        runame = self.settings.get("ebay_runame", "").strip()

        problems = []
        if env not in ("production", "sandbox"):
            problems.append("API Environment must be production or sandbox.")
        if not client_id:
            problems.append("App ID / Client ID is blank.")
        if not client_secret:
            problems.append("Cert ID / Client Secret is blank.")
        if not runame:
            problems.append("OAuth RuName is blank.")
        if "http://" in runame.lower() or "https://" in runame.lower():
            problems.append(
                "OAuth RuName should be the eBay-generated RuName value, not an https:// URL."
            )
        if any(ch.isspace() for ch in runame):
            problems.append("OAuth RuName contains spaces; copy the exact eBay-generated RuName.")

        if problems:
            messagebox.showerror(
                APP_NAME,
                "OAuth setup needs attention:\n\n- " + "\n- ".join(problems)
                + "\n\nUse the Production App ID, Production Cert ID, and the "
                  "OAuth-enabled Production RuName from the same eBay application."
            )
            return False

        if show_success:
            messagebox.showinfo(
                APP_NAME,
                "OAuth setup looks structurally correct.\n\n"
                f"Environment: {env}\n"
                f"App ID ending: ...{client_id[-8:]}\n"
                f"RuName: {runame}\n\n"
                "This check does not display your Client Secret."
            )
        return True

    def _open_refresh_authorization(self):
        if not self._validate_oauth_setup(show_success=False):
            return
        self._save_settings_ui_silent()
        client_id = self.settings.get("ebay_client_id", "").strip()
        runame = self.settings.get("ebay_runame", "").strip()

        if not client_id:
            messagebox.showerror(
                APP_NAME, "Enter your Production eBay App ID / Client ID first."
            )
            return
        if not runame:
            messagebox.showerror(
                APP_NAME,
                "Enter your Production OAuth RuName first. "
                "It is shown on eBay's User Tokens / OAuth configuration page."
            )
            return

        endpoint = (
            "https://auth.ebay.com/oauth2/authorize"
            if self.settings.get("api_environment", "production") == "production"
            else "https://auth.sandbox.ebay.com/oauth2/authorize"
        )

        params = {
            "client_id": client_id,
            "response_type": "code",
            "redirect_uri": runame,
            "scope": " ".join(self._ebay_oauth_scope_list()),
            "prompt": "login",
        }

        # eBay documents scope as a URL-encoded, space-separated list.
        # Use quote() rather than quote_plus() so spaces become %20, not '+'.
        url = endpoint + "?" + parse.urlencode(params, quote_via=parse.quote)

        self._log("Opening eBay OAuth consent request.")
        self._log(
            "OAuth setup: environment="
            + self.settings.get("api_environment", "production")
            + " | Client ID suffix="
            + (client_id[-8:] if len(client_id) >= 8 else "[short]")
            + " | RuName="
            + runame
        )
        webbrowser.open(url)

        messagebox.showinfo(
            APP_NAME,
            "eBay authorization opened in your browser.\n\n"
            "1. Sign into the seller account.\n"
            "2. Click Agree / Grant Access.\n"
            "3. When eBay redirects you to the final page, copy the ENTIRE URL "
            "from the browser address bar.\n"
            "4. Paste it into the box beside 'SAVE REFRESH TOKEN'.\n\n"
            "The URL should contain a parameter named code=...\n\n"
            "If eBay shows invalid_request before the consent page, verify that "
            "App ID and RuName are both from the same PRODUCTION keyset."
        )

    def _extract_authorization_code(self, pasted):
        raw = str(pasted or "").strip()
        if not raw:
            return ""

        # Accept either the entire final redirect URL or just the code itself.
        if "://" not in raw and "code=" not in raw:
            return parse.unquote(raw)

        try:
            parsed_url = parse.urlparse(raw)
            query = parse.parse_qs(parsed_url.query)
            code_values = query.get("code", [])
            if code_values:
                return parse.unquote(code_values[0])
        except Exception:
            pass

        # Last fallback if user pasted an incomplete URL fragment.
        match = re.search(r"(?:^|[?&])code=([^&]+)", raw)
        if match:
            return parse.unquote(match.group(1))
        return ""

    def _exchange_refresh_authorization(self):
        if self.worker and self.worker.is_alive():
            return

        self._save_settings_ui_silent()
        pasted = self.oauth_return_url_var.get().strip()
        code = self._extract_authorization_code(pasted)
        runame = self.settings.get("ebay_runame", "").strip()

        if not code:
            messagebox.showerror(
                APP_NAME,
                "I could not find an authorization code.\n\n"
                "Paste the full final eBay browser URL after you click Agree. "
                "It should contain code=..."
            )
            return

        if not runame:
            messagebox.showerror(APP_NAME, "Enter your OAuth RuName first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log("Exchanging one-time eBay authorization code for refresh token...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                tokens = client.exchange_authorization_code(code, runame)

                def done():
                    self.settings["access_token"] = tokens["access_token"]
                    self.settings["ebay_refresh_token"] = tokens["refresh_token"]

                    if "access_token" in self.setting_vars:
                        self.setting_vars["access_token"].set(tokens["access_token"])
                    if "ebay_refresh_token" in self.setting_vars:
                        self.setting_vars["ebay_refresh_token"].set(tokens["refresh_token"])

                    save_settings(self.settings)
                    self.oauth_return_url_var.set("")
                    self.oauth_refresh_status_var.set(
                        "Automatic refresh is configured. The app will renew expired "
                        "eBay User Access Tokens automatically."
                    )

                    refresh_days = (
                        tokens["refresh_token_expires_in"] / 86400
                        if tokens["refresh_token_expires_in"] else 0
                    )
                    messagebox.showinfo(
                        APP_NAME,
                        "Automatic eBay token refresh is configured.\n\n"
                        f"Current access token lifetime: about "
                        f"{tokens['expires_in'] / 3600:.1f} hours\n"
                        + (
                            f"Refresh-token lifetime reported by eBay: "
                            f"about {refresh_days:.0f} days\n\n"
                            if refresh_days else "\n"
                        )
                        + "You should no longer need to manually paste a new "
                        "access token every couple of hours."
                    )

                self.after(0, done)
            except Exception as exc:
                self._log(f"OAUTH REFRESH SETUP ERROR: {exc}")
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        APP_NAME,
                        "Automatic refresh setup failed:\n\n" + e
                    )
                )
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _test_ebay_connection(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings_ui_silent()
        if not self.settings.get("access_token", "").strip():
            messagebox.showerror(APP_NAME, "Enter a Production eBay OAuth User Access Token first.")
            return

        self.cancel_event.clear()
        self.stop_btn.config(state="normal")
        self._log("Testing eBay connection (read-only)...")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)
                tree_id = client.get_default_category_tree_id()
                policies = client.get_business_policies()

                def done():
                    self._apply_policies(policies)
                    messagebox.showinfo(
                        APP_NAME,
                        "eBay connection works.\n\n"
                        f"Marketplace: {self.settings.get('marketplace_id', 'EBAY_US')}\n"
                        f"Category tree: {tree_id}\n"
                        f"Shipping policies: {len(policies.get('fulfillment', []))}\n"
                        f"Payment policies: {len(policies.get('payment', []))}\n"
                        f"Return policies: {len(policies.get('return', []))}\n\n"
                        "No listing was created or changed."
                    )
                self.after(0, done)
            except Exception as exc:
                self._log(f"EBAY CONNECTION TEST ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, "eBay connection test failed:\n\n" + e))
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_settings_ui(self):
        for key, var in self.setting_vars.items():
            self.settings[key] = var.get().strip()
        self.settings["api_environment"] = self.env_var.get()
        save_settings(self.settings)
        if not self.vars["category_id"].get().strip():
            self.vars["category_id"].set(self.settings.get("default_category_id", ""))
        messagebox.showinfo(APP_NAME, "Settings saved locally.")

    def _stop(self):
        self._close_progress_popup()
        self.cancel_event.set()
        self._log("STOP requested. The current AI/eBay network request may finish, but no new steps will start.")

    def _draft_stage_error(self, stage, exc):
        msg = str(exc)
        is_404 = (
            "404" in msg
            and (
                "2002" in msg
                or "Resource not found" in msg
                or "Resource not resolved" in msg
                or "HTTP 404 Not Found" in msg
            )
        )
        if not is_404:
            return msg

        explanations = {
            "inventory preflight": "The Inventory API route itself could not be resolved.",
            "photo upload": "The failure happened while uploading a photo through eBay's Media API.",
            "category specifics metadata": "The failure happened while loading the complete set of category-specific item details.",
            "brand/mpn metadata": "The failure happened while validating Brand/MPN against the category.",
            "condition metadata": "The failure happened while loading valid conditions for the selected category.",
            "inventory item": "The failure happened while creating/updating the Inventory Item.",
            "offer": "The failure happened while creating the unpublished Offer.",
        }
        return (
            f"eBay returned HTTP 404 / error 2002 during: {stage.upper()}\n\n"
            + explanations.get(stage, "eBay could not resolve the API resource used in this stage.")
            + "\n\nThis is a resource/URI routing error, not the normal expired-token "
              "(401) or insufficient-permission (403) response."
        )

    def _create_draft_and_publish(self):
        if self.worker and self.worker.is_alive():
            return

        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        if not messagebox.askyesno(
            APP_NAME,
            "CREATE DRAFT AND PUBLISH LIVE?\n\n"
            f"Title: {listing.get('title', '')}\n"
            f"Price: ${float(listing.get('price', 0) or 0):.2f}\n"
            f"Quantity: {listing.get('quantity', '')}\n\n"
            "This will create the eBay inventory item and offer, then immediately "
            "publish it as a LIVE eBay listing.\n\n"
            "Are you sure you want to continue?",
        ):
            return

        self._create_draft(
            publish_after=True,
            confirmation_already_done=True,
        )

    def _create_draft(self, publish_after=False, confirmation_already_done=False):
        self._sync_selected_photos()
        self._show_progress_popup(
            "Creating eBay Draft",
            "Validating listing details and preparing photos..."
        )
        if self.worker and self.worker.is_alive():
            return
        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            self._close_progress_popup()
            return

        if not listing["photos"]:
            messagebox.showerror(APP_NAME, "Select/check at least one photo in the Photo Manager before creating an eBay draft.")
            self._close_progress_popup()
            return

        if not listing["category_id"]:
            messagebox.showerror(APP_NAME, "Enter an eBay leaf Category ID before creating the draft.")
            self._close_progress_popup()
            return

        if not confirmation_already_done:
            if not messagebox.askyesno(
                APP_NAME,
                "Create an UNPUBLISHED eBay offer?\n\n"
                "This will upload the selected photos and create/update eBay inventory data. "
                "It will NOT publish a live listing.",
            ):
                self._close_progress_popup()
                return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.create_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log("Starting draft creation. Nothing will be published.")

        def work():
            try:
                client = EbayClient(self.settings.copy(), self.cancel_event, self._log)

                current_stage = "inventory preflight"
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Checking eBay Inventory API access..."
                    )
                )
                client.check_inventory_api()

                current_stage = "photo upload"
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Uploading photos to eBay..."
                    )
                )
                urls = []
                total_photos = len(listing["photos"])
                for photo_index, p in enumerate(listing["photos"], start=1):
                    client._check_cancel()
                    self.after(
                        0,
                        lambda i=photo_index, n=total_photos, name=Path(p).name:
                            self._update_progress_popup(
                                f"Uploading photo {i} of {n}: {name}"
                            )
                    )
                    urls.append(client.upload_image(p))
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Photos uploaded. Creating/updating eBay inventory item..."
                    )
                )
                listing["image_urls"] = urls

                client._check_cancel()
                current_stage = "category specifics metadata"
                self._log("DRAFT STAGE: Syncing all category-specific item details...")
                self._sync_category_specifics(client, listing, update_ui=True)

                current_stage = "brand/mpn metadata"
                self._log("DRAFT STAGE: Validating category-specific Brand/MPN requirements...")
                self._validate_category_product_identifiers(client, listing)
                self._log("DRAFT STAGE COMPLETE: Product identifiers accepted for preflight.")
                current_stage = "condition metadata"
                self._log("DRAFT STAGE: Validating category-specific item condition...")
                self._validate_category_condition_sync(client, listing)
                self._log("DRAFT STAGE COMPLETE: Item condition accepted for category.")
                current_stage = "inventory item"
                self._log("DRAFT STAGE: Creating/updating Inventory Item...")
                client.create_inventory_item(listing["sku"], listing)
                self._log("DRAFT STAGE COMPLETE: Inventory Item accepted by eBay.")
                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Inventory item accepted. Creating unpublished eBay offer..."
                    )
                )

                client._check_cancel()
                current_stage = "offer"
                self._log("DRAFT STAGE: Creating unpublished Offer...")
                offer_id = client.create_offer(listing["sku"], listing)
                self._log("DRAFT STAGE COMPLETE: Unpublished Offer created.")

                client._check_cancel()
                self.editing_offer_id = str(offer_id)
                self.editing_offer_status = "UNPUBLISHED"
                upsert_offer_history({
                    "offer_id": str(offer_id),
                    "sku": listing["sku"],
                    "status": "UNPUBLISHED",
                    "listing_id": "",
                    "title": listing["title"],
                    "price": f"{float(listing['price']):.2f}",
                    "category_id": listing["category_id"],
                })
                self.after(0, self._refresh_offer_history_table)
                self._log(f"SUCCESS: Unpublished Buy It Now offer created. Offer ID: {offer_id}")
                self.after(0, lambda: self.publish_btn.config(state="normal"))

                if publish_after:
                    self.after(
                        0,
                        lambda: self._update_progress_popup(
                            "Draft created. Publishing the offer to eBay..."
                        )
                    )
                    listing_id = client.publish_offer(offer_id)
                    self.editing_offer_status = "PUBLISHED"
                    upsert_offer_history({
                        "offer_id": str(offer_id),
                        "sku": listing["sku"],
                        "status": "PUBLISHED",
                        "listing_id": listing_id,
                        "title": listing["title"],
                        "price": f"{float(listing['price']):.2f}",
                        "category_id": listing["category_id"],
                    })
                    self.after(0, self._refresh_offer_history_table)
                    self._log(
                        f"SUCCESS: Draft created and published. "
                        f"Listing ID: {listing_id}"
                    )
                    self.after(
                        0,
                        lambda lid=listing_id, data=listing: self._show_live_listing_success(
                            lid,
                            title="Draft created and listing published successfully",
                            listing_data=data,
                        ),
                    )
                else:
                    self._log(
                        "The program did NOT publish the offer. "
                        "Use PUBLISH TO EBAY only after review."
                    )
                    self.after(
                        0,
                        lambda: messagebox.showinfo(
                            APP_NAME,
                            f"eBay draft/unpublished offer created successfully.\n\n"
                            f"Offer ID: {offer_id}\n\nIt is NOT live.",
                        ),
                    )
            except Exception as exc:
                stage = locals().get("current_stage", "unknown draft stage")
                self._log(f"STOPPED / ERROR during {stage}: {exc}")
                err_text = self._draft_stage_error(stage, exc)

                def show_draft_error():
                    if "25002" in err_text and "BrandMPN" in err_text:
                        messagebox.showerror(
                            APP_NAME,
                            "eBay rejected the Brand/MPN product identifier.\n\n"
                            "Check that Brand / Manufacturer and MPN / Part Number are "
                            "both present and copied exactly from the item. Do not enter "
                            "'BrandMPN' as one combined Extra Item Specific.\n\n"
                            "The listing was not published."
                        )
                    else:
                        messagebox.showerror(APP_NAME, err_text)

                self.after(0, show_draft_error)
            finally:
                self.after(0, lambda: self.create_btn.config(state="normal"))
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _prepare_offer_for_publish(self, client, listing, offer_id):
        """
        Synchronize the editor state to eBay before publishOffer.

        This prevents an older unpublished offer/inventory item from being
        published with stale category, condition, photos, price, or policies.
        """
        self._log("PUBLISH PREFLIGHT: syncing category-specific item details...")
        self._sync_category_specifics(client, listing, update_ui=True)
        self._log("PUBLISH PREFLIGHT: validating category-specific Brand/MPN requirements...")
        self._validate_category_product_identifiers(client, listing)
        self._log("PUBLISH PREFLIGHT: validating category-specific condition...")
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Checking eBay category and allowed item conditions..."
            )
        )
        self._validate_category_condition_sync(client, listing, show_message=False)

        # Build the image URL set in current gallery order. Existing eBay-hosted
        # images are reused; only new local files are uploaded.
        sources = (
            self.photo_manager.ordered_image_sources()
            if getattr(self, "photo_manager", None) is not None
            else []
        )
        urls = []
        if sources:
            total = len(sources)
            for idx, (kind, value) in enumerate(sources, start=1):
                client._check_cancel()
                if kind == "remote":
                    urls.append(value)
                else:
                    self.after(
                        0,
                        lambda i=idx, n=total:
                            self._update_progress_popup(
                                f"Uploading new photo {i} of {n} before publishing..."
                            )
                    )
                    urls.append(client.upload_image(value))
        elif listing.get("photos"):
            urls = [client.upload_image(p) for p in listing["photos"]]
        else:
            urls = list(self.existing_image_urls)

        listing["image_urls"] = urls

        self._log("PUBLISH PREFLIGHT: updating Inventory Item...")
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Synchronizing inventory item with the current editor..."
            )
        )
        client.create_inventory_item(listing["sku"], listing)

        self._log(
            "PUBLISH PREFLIGHT: updating unpublished Offer "
            f"(listing={type(listing).__name__}, "
            f"original_offer={type(getattr(self, 'original_offer', None)).__name__})..."
        )
        self.after(
            0,
            lambda: self._update_progress_popup(
                "Synchronizing price, quantity, category and business policies..."
            )
        )
        original_offer = getattr(self, "original_offer", None)
        if not isinstance(original_offer, dict):
            self._log(
                "PUBLISH PREFLIGHT: reloading original eBay Offer before update..."
            )
            original_offer = client.get_offer(offer_id)
        client.update_offer(offer_id, listing, original_offer)
        self._log("PUBLISH PREFLIGHT COMPLETE.")

    def _show_live_listing_success(self, listing_id, title="Listing published successfully", listing_data=None):
        listing_id = str(listing_id or "").strip()
        url = f"https://www.ebay.com/itm/{listing_id}" if listing_id else ""
        if listing_data:
            try:
                self._inventory_ensure_published(listing_id, listing_data)
            except Exception as exc:
                self._log(f"Inventory auto-add warning: {exc}")

        win = tk.Toplevel(self)
        win.title(APP_NAME)
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)

        body = ttk.Frame(win, padding=18)
        body.pack(fill="both", expand=True)

        ttk.Label(
            body,
            text=title,
            font=("TkDefaultFont", 11, "bold"),
        ).pack(anchor="w", pady=(0, 10))

        ttk.Label(
            body,
            text=f"eBay Listing ID: {listing_id}",
        ).pack(anchor="w", pady=(0, 12))

        if url:
            ttk.Label(
                body,
                text=url,
                foreground="#1a5fb4",
                cursor="hand2",
            ).pack(anchor="w", pady=(0, 14))

        buttons = ttk.Frame(body)
        buttons.pack(fill="x")

        if url:
            ttk.Button(
                buttons,
                text="OPEN LIVE LISTING",
                command=lambda: webbrowser.open(url),
                style="Accent.TButton",
            ).pack(side="left", padx=(0, 8))
            ttk.Button(
                buttons,
                text="VIEW IN INVENTORY",
                command=lambda: (win.destroy(), self.notebook.select(self.inventory_tab), self.inventory_notebook.select(1), self._inventory_refresh_all()),
            ).pack(side="left", padx=(0, 8))

        ttk.Button(
            buttons,
            text="OK",
            command=win.destroy,
        ).pack(side="right")

        win.update_idletasks()
        x = self.winfo_rootx() + max(30, (self.winfo_width() - win.winfo_width()) // 2)
        y = self.winfo_rooty() + max(30, (self.winfo_height() - win.winfo_height()) // 2)
        win.geometry(f"+{x}+{y}")

    def _publish_to_ebay(self):
        if self.worker and self.worker.is_alive():
            return
        offer_id = str(self.editing_offer_id or "").strip()
        if not offer_id:
            messagebox.showinfo(
                APP_NAME,
                "Nothing is ready to publish yet.\n\n"
                "Create an eBay draft first, or load an existing unpublished offer."
            )
            return
        if self.editing_offer_status.upper() == "PUBLISHED":
            messagebox.showinfo(APP_NAME, "This offer is already published.")
            return

        try:
            listing = self._collect()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        # The old typed PUBLISH gate has been removed.
        # One explicit Yes/No confirmation remains before going live.
        if not messagebox.askyesno(
            APP_NAME,
            "Publish this listing to eBay now?\\n\\n"
            f"Title: {listing['title']}\\n"
            f"Price: ${float(listing['price']):.2f}\\n"
            f"Quantity: {listing['quantity']}\\n"
            f"Offer ID: {offer_id}\\n\\n"
            "This will create a live eBay listing."
        ):
            return

        self._save_settings_ui_silent()
        self.cancel_event.clear()
        self.publish_btn.config(state="normal")
        self.stop_btn.config(state="normal")
        self._log("=" * 60)
        self._log(f"Explicit publish requested for Offer ID {offer_id}.")
        self._show_progress_popup(
            "Publishing to eBay",
            "Running pre-publish validation and synchronizing the listing..."
        )

        def work():
            try:
                client = EbayClient(
                    self.settings.copy(), self.cancel_event, self._log
                )

                # Re-read the latest editor state in the UI thread before publish.
                self._prepare_offer_for_publish(client, listing, offer_id)

                self.after(
                    0,
                    lambda: self._update_progress_popup(
                        "Preflight passed. Publishing the offer to eBay..."
                    )
                )
                listing_id = client.publish_offer(offer_id)
                self.editing_offer_status = "PUBLISHED"
                upsert_offer_history({
                    "offer_id": offer_id,
                    "sku": listing["sku"],
                    "status": "PUBLISHED",
                    "listing_id": listing_id,
                    "title": listing["title"],
                    "price": f"{float(listing['price']):.2f}",
                    "category_id": listing["category_id"],
                })
                self.after(0, self._refresh_offer_history_table)
                self._log(
                    f"SUCCESS: Offer {offer_id} is LIVE. eBay Listing ID: {listing_id}"
                )
                self.after(
                    0,
                    lambda lid=listing_id, data=listing: self._show_live_listing_success(lid, listing_data=data),
                )
            except Exception as exc:
                self._log(f"PUBLISH ERROR: {exc}")
                err_text = str(exc)

                def show_publish_error():
                    if "25021" in err_text or "condition" in err_text.lower() and "category" in err_text.lower():
                        messagebox.showerror(
                            APP_NAME,
                            "eBay will not publish this offer because the selected item "
                            "condition is not allowed in this category.\n\n"
                            "The Condition dropdown has been refreshed from eBay's category "
                            "policy when possible. Choose the condition that accurately "
                            "describes the item, then press PUBLISH TO EBAY again.\n\n"
                            "The offer remains unpublished."
                        )
                    else:
                        messagebox.showerror(APP_NAME, err_text)

                self.after(0, show_publish_error)
                self.after(
                    0,
                    lambda: self.publish_btn.config(
                        state="normal"
                        if self.editing_offer_status.upper() != "PUBLISHED"
                        else "disabled"
                    ),
                )
            finally:
                self.after(0, lambda: self.stop_btn.config(state="disabled"))
                self.after(0, self._close_progress_popup)

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _save_settings_ui_silent(self):
        for key, var in self.setting_vars.items():
            self.settings[key] = var.get().strip()
        self.settings["api_environment"] = self.env_var.get()
        save_settings(self.settings)


if __name__ == "__main__":
    app = ListingTool()
    app.mainloop()
