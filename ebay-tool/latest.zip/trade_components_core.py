#!/usr/bin/env python3
"""
Trade Components eBay Listing Tool
Version 4.23.43

Uses only Python's standard library.
Analyzes item photos, researches current eBay prices, creates eBay Inventory API
offers, and can publish only through an explicit manual confirmation workflow.
"""

import base64
import hashlib
import hmac
import csv
import sqlite3
import html
import json
import xml.etree.ElementTree as ET
import mimetypes
import os
import re
import difflib
import shutil
import statistics
import subprocess
import sys
import math
import threading
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
import webbrowser
import zipfile
from pathlib import Path
from urllib import request, error, parse

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP_NAME = "Trade Components eBay Listing Tool V4.23.43"
APP_VERSION = "4.23.44"
UPDATE_MANIFEST_URL = "https://fuscaldo.org/ebay-tool/version.json"
UPDATE_BASE_URL = "https://fuscaldo.org/ebay-tool/"
APP_DIR = Path.home() / ".trade_components_ebay_tool"
CONFIG_FILE = APP_DIR / "settings.json"
OFFER_HISTORY_FILE = APP_DIR / "offer_history.json"
BUYER_OFFER_HISTORY_FILE = APP_DIR / "buyer_offer_history.json"
IMAGE_CACHE_DIR = APP_DIR / "ebay_image_cache"
INVENTORY_DB_FILE = APP_DIR / "inventory.db"
BACKUP_DIR = APP_DIR / "backups"
ACTIVITY_LOG_FILE = APP_DIR / "activity.log"
PULLED_ORDERS_FILE = APP_DIR / "pulled_orders.json"

# Standard OpenAI API pricing, USD per 1M tokens.
# Updated 2026-09-08. Unknown models fall back to the configured Luna rates
# only for display and are explicitly marked as estimates.
AI_MODEL_PRICING = {
    "gpt-5.6-luna": {"input": 0.20, "cached": 0.02, "output": 1.20},
    "gpt-5.6-terra": {"input": 2.00, "cached": 0.20, "output": 12.00},
    "gpt-5.6-sol": {"input": 4.00, "cached": 0.40, "output": 20.00},
    "gpt-5.6": {"input": 4.00, "cached": 0.40, "output": 20.00},
    "gpt-4.1-mini": {"input": 0.40, "cached": 0.10, "output": 1.60},
    "gpt-4.1": {"input": 2.00, "cached": 0.50, "output": 8.00},
}

def ai_cost_from_usage(model, usage):
    """Return (cost, input, cached, output, exact_known_rate)."""
    usage = usage or {}
    input_tokens = int(usage.get("input_tokens", 0) or 0)
    output_tokens = int(usage.get("output_tokens", 0) or 0)
    details = usage.get("input_tokens_details", {}) or {}
    cached = int(details.get("cached_tokens", 0) or 0)
    uncached = max(0, input_tokens - cached)

    model_key = str(model or "").strip().lower()
    rates = AI_MODEL_PRICING.get(model_key)
    known = rates is not None
    if rates is None:
        rates = AI_MODEL_PRICING["gpt-5.6-luna"]

    cost = (
        (uncached / 1_000_000) * rates["input"]
        + (cached / 1_000_000) * rates["cached"]
        + (output_tokens / 1_000_000) * rates["output"]
    )
    return cost, input_tokens, cached, output_tokens, known

DEFAULT_SETTINGS = {
    "marketplace_id": "EBAY_US",
    "currency": "USD",
    "merchant_location_key": "",
    "payment_policy_id": "",
    "return_policy_id": "",
    "fulfillment_policy_id": "",
    "default_category_id": "",
    "access_token": "",
    "api_environment": "production",
    "openai_api_key": "",
    "openai_model": "gpt-5.6-luna",
    "ebay_client_id": "",
    "ebay_client_secret": "",
    "ai_grouping_spend_cap": "1.00",
    "ebay_refresh_token": "",
    "ebay_runame": ""
}

CONDITION_MAP = {
    "New": "NEW",
    "New - Open Box": "NEW_OTHER",
    "Used / Pre-owned": "USED_EXCELLENT",
    "Very Good": "USED_VERY_GOOD",
    "Good": "USED_GOOD",
    "Acceptable": "USED_ACCEPTABLE",
    "For Parts / Not Working": "FOR_PARTS_OR_NOT_WORKING",
}

CONDITION_ID_BY_ENUM = {
    "NEW": "1000",
    "NEW_OTHER": "1500",
    "USED_EXCELLENT": "3000",
    "USED_VERY_GOOD": "4000",
    "USED_GOOD": "5000",
    "USED_ACCEPTABLE": "6000",
    "FOR_PARTS_OR_NOT_WORKING": "7000",
}

PACKAGE_TYPE_MAP = {
    "Standard package / thick envelope": "PACKAGE_THICK_ENVELOPE",
    "Mailing box": "MAILING_BOX",
    "Parcel or padded envelope": "PARCEL_OR_PADDED_ENVELOPE",
    "Padded bag": "PADDED_BAGS",
    "Large envelope": "LARGE_ENVELOPE",
    "Letter": "LETTER",
    "USPS Flat Rate Envelope": "USPS_FLAT_RATE_ENVELOPE",
    "USPS Large Package": "USPS_LARGE_PACK",
    "Very Large Package": "VERY_LARGE_PACK",
    "Extra Large Package": "EXTRA_LARGE_PACK",
    "Bulky goods": "BULKY_GOODS",
    "One-way pallet": "ONE_WAY_PALLET",
    "Euro pallet": "EUROPALLET",
}

BOILERPLATE = """Please review all photos carefully. If you know any more information about this item, please feel free to send us a message. Here at Trade Recycling we like to build good business relationships with our customers, so if you have any problems with your purchase please contact us first before leaving negative feedback. We will make sure we do our best to do right by our customer.

We are happy to work with any shipping provider that you wish, just send us a message and we will work out the details. We do not cover shipping costs.

Thank you.

Other Information:
Some stickers may be removed from the items before we ship them. All payments must be received within 7 Days of auctions end. WE ONLY ACCEPT PAYMENTS THROUGH EBAY (unless paying in cash for local pick-up). We only charge actual shipping costs and do not charge for handling. If you have any questions, feel free to send us a message and we'll get back to you as soon as we can!"""


def ensure_app_dir():
    APP_DIR.mkdir(parents=True, exist_ok=True)


def ensure_inventory_db():
    """Create the local inventory database, seeding it from the imported Master File on first run."""
    ensure_app_dir()
    if not INVENTORY_DB_FILE.exists():
        seed = Path(__file__).resolve().parent / "inventory_seed.db"
        if seed.exists():
            shutil.copy2(seed, INVENTORY_DB_FILE)
        else:
            con = sqlite3.connect(INVENTORY_DB_FILE)
            con.executescript("""
                CREATE TABLE IF NOT EXISTS inventory_items(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    qty REAL, stock REAL, item TEXT NOT NULL, location TEXT,
                    comment TEXT, condition TEXT, item_number TEXT,
                    status TEXT NOT NULL DEFAULT 'MASTER', date_sold TEXT,
                    ebay_order_id TEXT, source_sheet TEXT, source_row INTEGER,
                    color TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS location_colors(
                    location TEXT PRIMARY KEY, color TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_inventory_status ON inventory_items(status);
                CREATE INDEX IF NOT EXISTS idx_inventory_item_number ON inventory_items(item_number);
                CREATE INDEX IF NOT EXISTS idx_inventory_location ON inventory_items(location);
            """)
            con.commit()
            con.close()
    # Lightweight schema migrations for inventory features added after the
    # original seed database was created.
    con = sqlite3.connect(INVENTORY_DB_FILE)
    try:
        cols = {r[1] for r in con.execute("PRAGMA table_info(inventory_items)").fetchall()}
        migrations = {
            "parent_item_id": "ALTER TABLE inventory_items ADD COLUMN parent_item_id INTEGER",
            "ebay_order_line_id": "ALTER TABLE inventory_items ADD COLUMN ebay_order_line_id TEXT",
            "sale_quantity": "ALTER TABLE inventory_items ADD COLUMN sale_quantity REAL",
            "ship_by_date": "ALTER TABLE inventory_items ADD COLUMN ship_by_date TEXT",
        }
        for name, sql in migrations.items():
            if name not in cols:
                con.execute(sql)
        con.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_order_line "
            "ON inventory_items(ebay_order_line_id) WHERE ebay_order_line_id IS NOT NULL"
        )
        con.execute("""
            CREATE TABLE IF NOT EXISTS attention_issues(
                issue_key TEXT PRIMARY KEY,
                severity TEXT NOT NULL,
                category TEXT NOT NULL,
                issue TEXT NOT NULL,
                item TEXT,
                item_number TEXT,
                location TEXT,
                action TEXT,
                state TEXT NOT NULL DEFAULT 'OPEN',
                first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
                last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
                scan_token TEXT
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS listing_reviews(
                item_number TEXT PRIMARY KEY,
                reviewed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                note TEXT
            )
        """)
        con.execute(
            "CREATE INDEX IF NOT EXISTS idx_attention_state ON attention_issues(state)"
        )
        attention_cols = {r[1] for r in con.execute("PRAGMA table_info(attention_issues)").fetchall()}
        if "issue_type" not in attention_cols:
            con.execute("ALTER TABLE attention_issues ADD COLUMN issue_type TEXT")
        con.execute("""
            CREATE TABLE IF NOT EXISTS attention_rules(
                issue_type TEXT PRIMARY KEY,
                rule_action TEXT NOT NULL DEFAULT 'IGNORE',
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS sales_orders(
                order_id TEXT PRIMARY KEY,
                creation_date TEXT,
                sales_value REAL DEFAULT 0,
                order_total REAL DEFAULT 0,
                currency TEXT,
                units INTEGER DEFAULT 0,
                fulfillment_status TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("CREATE INDEX IF NOT EXISTS idx_sales_creation_date ON sales_orders(creation_date)")
        con.commit()
    finally:
        con.close()
    return INVENTORY_DB_FILE


def load_settings():
    ensure_app_dir()
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            merged = DEFAULT_SETTINGS.copy()
            merged.update(data)
            return merged
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()


def save_settings(data):
    ensure_app_dir()
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_offer_history():
    ensure_app_dir()
    if OFFER_HISTORY_FILE.exists():
        try:
            data = json.loads(OFFER_HISTORY_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []
    return []


def save_offer_history(rows):
    ensure_app_dir()
    OFFER_HISTORY_FILE.write_text(json.dumps(rows, indent=2), encoding="utf-8")


def upsert_offer_history(entry):
    rows = load_offer_history()
    offer_id = str(entry.get("offer_id", "") or "")
    sku = str(entry.get("sku", "") or "")
    replaced = False
    for i, row in enumerate(rows):
        if offer_id and str(row.get("offer_id", "")) == offer_id:
            merged = dict(row)
            merged.update(entry)
            rows[i] = merged
            replaced = True
            break
    if not replaced:
        rows.insert(0, dict(entry))
    # Keep a practical local history size.
    save_offer_history(rows[:500])


def load_buyer_offer_history():
    ensure_app_dir()
    if BUYER_OFFER_HISTORY_FILE.exists():
        try:
            data = json.loads(
                BUYER_OFFER_HISTORY_FILE.read_text(encoding="utf-8")
            )
            return data if isinstance(data, list) else []
        except Exception:
            return []
    return []


def save_buyer_offer_history(rows):
    ensure_app_dir()
    BUYER_OFFER_HISTORY_FILE.write_text(
        json.dumps(rows or [], indent=2),
        encoding="utf-8",
    )


def append_buyer_offer_history(rows):
    history = load_buyer_offer_history()
    for row in rows or []:
        if isinstance(row, dict):
            history.insert(0, dict(row))
    save_buyer_offer_history(history[:5000])


def sanitize_sku(text):
    text = re.sub(r"[^A-Za-z0-9._-]+", "-", text.strip())
    text = re.sub(r"-+", "-", text).strip("-")
    return text[:50] or f"ITEM-{int(time.time())}"


def parse_specifics(text):
    aspects = {}
    for raw in text.splitlines():
        raw = raw.strip()
        if not raw or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        key, value = key.strip(), value.strip()
        if key and value:
            aspects[key] = [value]
    return aspects


def format_specifics(aspects):
    """Convert eBay aspects dict back to the editor's Name=Value text format."""
    lines = []
    for key, values in (aspects or {}).items():
        if not key:
            continue
        if isinstance(values, list):
            value = ", ".join(str(v).strip() for v in values if str(v).strip())
        else:
            value = str(values).strip()
        if value:
            lines.append(f"{key}={value}")
    return "\n".join(lines)


def encode_multipart(field_name, filename, data, content_type):
    boundary = "----TradeComponents" + uuid.uuid4().hex
    crlf = b"\r\n"
    body = bytearray()
    body.extend(("--" + boundary).encode() + crlf)
    body.extend(
        f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"'.encode()
        + crlf
    )
    body.extend(f"Content-Type: {content_type}".encode() + crlf + crlf)
    body.extend(data)
    body.extend(crlf + ("--" + boundary + "--").encode() + crlf)
    return bytes(body), f"multipart/form-data; boundary={boundary}"


# ============================================================================
# Integrated local photo manager (V4.21.0)
# No AI/network calls are made by this section.
# ============================================================================

try:
    from PIL import Image, ImageTk, ImageOps, ImageStat, ImageFilter
    PHOTO_MANAGER_IMPORT_ERROR = ""
except ImportError as exc:
    Image = ImageTk = ImageOps = ImageStat = ImageFilter = None
    PHOTO_MANAGER_IMPORT_ERROR = (
        "Pillow is required for the local photo manager. "
        "Run INSTALL_IMAGE_SUPPORT.bat once."
    )

try:
    if Image is not None:
        import pillow_heif
        pillow_heif.register_heif_opener()
        HEIF_AVAILABLE = True
    else:
        HEIF_AVAILABLE = False
except Exception:
    HEIF_AVAILABLE = False

SUPPORTED_EXTS = {
    ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp",
    ".heic", ".heif", ".avif",
}

THUMB_SIZE = (118, 118)
PREVIEW_SIZE = (380, 380)


def _open_oriented(path: str | Path):
    im = Image.open(path)
    return ImageOps.exif_transpose(im).convert("RGB")


def _dhash(im: Image.Image, hash_size: int = 8) -> int:
    small = im.convert("L").resize((hash_size + 1, hash_size), Image.Resampling.BILINEAR)
    px = list(small.getdata())
    value = 0
    bit = 0
    stride = hash_size + 1
    for y in range(hash_size):
        row = y * stride
        for x in range(hash_size):
            if px[row + x] > px[row + x + 1]:
                value |= 1 << bit
            bit += 1
    return value


def _color_hist(im: Image.Image):
    small = im.resize((96, 96), Image.Resampling.BILINEAR)
    hist = small.histogram()
    # PIL RGB hist has 256 bins per channel. Collapse to 16 bins/channel.
    out = []
    for channel in range(3):
        base = channel * 256
        vals = hist[base:base + 256]
        for b in range(16):
            out.append(sum(vals[b * 16:(b + 1) * 16]))
    total = float(sum(out)) or 1.0
    return tuple(v / total for v in out)



_LOCAL_PHOTO_ANALYSIS_CACHE = {}


def _analysis_cache_key(path):
    p = Path(path)
    try:
        st = p.stat()
        return (str(p.resolve()), int(st.st_size), int(st.st_mtime_ns))
    except Exception:
        return (str(p), 0, 0)


def _feature(path: str | Path):
    key = ("feature",) + _analysis_cache_key(path)
    cached = _LOCAL_PHOTO_ANALYSIS_CACHE.get(key)
    if cached is not None:
        return cached

    im = _open_oriented(path)
    result = {
        "hash": _dhash(im),
        "hist": _color_hist(im),
        "aspect": im.width / max(1, im.height),
    }
    _LOCAL_PHOTO_ANALYSIS_CACHE[key] = result

    # Prevent an all-day warehouse session from growing forever.
    if len(_LOCAL_PHOTO_ANALYSIS_CACHE) > 2500:
        for stale_key in list(_LOCAL_PHOTO_ANALYSIS_CACHE.keys())[:400]:
            _LOCAL_PHOTO_ANALYSIS_CACHE.pop(stale_key, None)

    return result


def _hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def _similarity(a, b) -> float:
    hash_sim = 1.0 - (_hamming(a["hash"], b["hash"]) / 64.0)
    hist_sim = sum(min(x, y) for x, y in zip(a["hist"], b["hist"]))
    aspect_delta = abs(math.log(max(a["aspect"], 0.01) / max(b["aspect"], 0.01)))
    aspect_sim = max(0.0, 1.0 - aspect_delta / 1.25)
    return 0.50 * hash_sim + 0.42 * hist_sim + 0.08 * aspect_sim


def _quality_uncached(path: str | Path):
    """Return local, non-semantic image-quality scores in 0..100."""
    im = _open_oriented(path)
    im.thumbnail((420, 420), Image.Resampling.LANCZOS)
    gray = im.convert("L")
    stat = ImageStat.Stat(gray)
    mean = float(stat.mean[0])
    std = float(stat.stddev[0])

    # Exposure: broad plateau around useful midtones, with penalties at extremes.
    exposure = max(0.0, 1.0 - abs(mean - 145.0) / 145.0)
    contrast = min(1.0, std / 62.0)

    # Sharpness proxy from edge variance. This is inexpensive and works well for
    # choosing between repeated handheld shots, though it is not content-aware.
    edges = gray.filter(ImageFilter.FIND_EDGES)
    edge_var = float(ImageStat.Stat(edges).var[0])
    sharpness = min(1.0, math.log1p(edge_var) / math.log(1500.0))

    # Clipped pixels.
    hist = gray.histogram()
    total = float(sum(hist)) or 1.0
    clipped_dark = sum(hist[:10]) / total
    clipped_light = sum(hist[246:]) / total
    clipping = min(1.0, (clipped_dark + clipped_light) * 2.5)

    # Approximate compositional centering based on edge-energy center of mass.
    # Blank/background areas contribute little; product edges contribute more.
    edge_small = edges.resize((64, 64), Image.Resampling.BILINEAR)
    vals = list(edge_small.getdata())
    weights = [max(0, v - 18) for v in vals]
    wsum = float(sum(weights))
    if wsum > 0:
        cx = sum((i % 64) * w for i, w in enumerate(weights)) / wsum
        cy = sum((i // 64) * w for i, w in enumerate(weights)) / wsum
        dist = math.hypot(cx - 31.5, cy - 31.5) / math.hypot(31.5, 31.5)
        centering = max(0.0, 1.0 - dist)
    else:
        centering = 0.5

    score = (
        0.43 * sharpness
        + 0.25 * exposure
        + 0.14 * contrast
        + 0.18 * centering
        - 0.18 * clipping
    )
    score = max(0.0, min(1.0, score))
    return {
        "score": round(score * 100, 1),
        "sharpness": round(sharpness * 100, 1),
        "exposure": round(exposure * 100, 1),
        "contrast": round(contrast * 100, 1),
        "centering": round(centering * 100, 1),
        "clipping": round(clipping * 100, 1),
    }


def _quality(path: str | Path):
    key = ("quality",) + _analysis_cache_key(path)
    cached = _LOCAL_PHOTO_ANALYSIS_CACHE.get(key)
    if cached is not None:
        return dict(cached)

    result = _quality_uncached(path)
    _LOCAL_PHOTO_ANALYSIS_CACHE[key] = dict(result)

    if len(_LOCAL_PHOTO_ANALYSIS_CACHE) > 2500:
        for stale_key in list(_LOCAL_PHOTO_ANALYSIS_CACHE.keys())[:400]:
            _LOCAL_PHOTO_ANALYSIS_CACHE.pop(stale_key, None)

    return result


def group_photos(paths, progress=None):
    """Conservatively group visually similar photos without AI.

    It intentionally prefers *over-splitting* to incorrectly merging two products.
    The user can merge/move photos in Batch Review afterward.
    """
    paths = [str(Path(p)) for p in paths]
    features = {}
    valid = []
    for i, p in enumerate(paths):
        try:
            features[p] = _feature(p)
            valid.append(p)
        except Exception:
            continue
        if progress:
            progress(i + 1, len(paths), "Reading photo features")

    groups = []
    # Greedy conservative clustering. Compare against a few members of each group
    # so different angles can still connect through an intermediate view.
    for i, p in enumerate(valid):
        f = features[p]
        best_idx = None
        best_sim = -1.0
        for gi, group in enumerate(groups):
            candidates = group[-5:] + group[:2]
            sim = max((_similarity(f, features[q]) for q in candidates), default=0.0)
            if sim > best_sim:
                best_sim = sim
                best_idx = gi

        # Slightly relaxed threshold for adjacent shots: camera rolls usually keep
        # multiple angles of one item together, but we remain conservative.
        previous_same = False
        if i > 0 and groups:
            prev = valid[i - 1]
            prev_sim = _similarity(f, features[prev])
            previous_same = prev_sim >= 0.945

        if best_idx is not None and (best_sim >= 0.955 or (previous_same and best_sim >= 0.945)):
            groups[best_idx].append(p)
        else:
            groups.append([p])

        if progress:
            progress(i + 1, len(valid), "Building likely item groups")

    return groups, features


def rank_and_select(paths, target=12, progress=None):
    """Score photos and mark a diverse recommended subset; never delete anything."""
    paths = list(paths)
    q = {}
    f = {}
    for i, p in enumerate(paths):
        try:
            q[p] = _quality(p)
            f[p] = _feature(p)
        except Exception:
            q[p] = {"score": 0.0, "error": True}
            f[p] = None
        if progress:
            progress(i + 1, len(paths), "Scoring sharpness / exposure / framing")

    ranked = sorted(paths, key=lambda p: q[p].get("score", 0), reverse=True)
    selected = []
    redundant = set()
    for p in ranked:
        if len(selected) >= target:
            break
        if not selected:
            selected.append(p)
            continue
        if f[p] is None:
            continue
        maxsim = max((_similarity(f[p], f[s]) for s in selected if f[s] is not None), default=0)
        if maxsim >= 0.90:
            redundant.add(p)
            continue
        selected.append(p)

    # If diversity filtering left too few, fill with the highest-quality remaining shots.
    if len(selected) < min(target, len(ranked)):
        for p in ranked:
            if p not in selected:
                selected.append(p)
            if len(selected) >= min(target, len(ranked)):
                break

    selected_set = set(selected)
    for p in ranked:
        if p not in selected_set and f[p] is not None:
            if max((_similarity(f[p], f[s]) for s in selected if f[s] is not None), default=0) >= 0.90:
                redundant.add(p)

    return ranked, selected, q, redundant


class BatchReviewWindow(tk.Toplevel):
    """
    Review item groups produced by either OpenAI or the free/local grouper.

    Selection is intentionally explicit:
      - click the thumbnail
      - click its Select button
    Either action updates the selected-photo label and enables Move/Split.
    """

    def __init__(
        self,
        master,
        groups,
        on_use_group,
        log=None,
        group_meta=None,
        source_label="Grouping",
    ):
        super().__init__(master)
        self.title(f"Batch Photo Review — {source_label}")
        self.geometry("1180x780")
        self.minsize(920, 640)

        normalized_groups = []
        for raw_group in (groups or []):
            if isinstance(raw_group, dict):
                raw_group = raw_group.get("paths", []) or []
            if not isinstance(raw_group, (list, tuple, set)):
                continue
            clean_group = []
            for value in raw_group:
                path = str(value or "").strip()
                if path and Path(path).exists():
                    clean_group.append(path)
            if clean_group:
                normalized_groups.append(clean_group)

        self.groups = normalized_groups
        self.on_use_group = on_use_group
        self.log = log or (lambda x: None)
        self.group_meta = list(group_meta or [])
        self.source_label = source_label

        self.current_group = 0
        self.selected_path = None
        self.selected_paths = set()
        self._thumb_refs = []
        self._cards = {}

        persisted_used = set(
            getattr(master, "batch_used_group_signatures", set()) or set()
        )
        self.used_group_indexes = {
            i for i, group in enumerate(self.groups)
            if tuple(sorted(str(p) for p in group)) in persisted_used
        }

        # Closing/reopening Batch Review must not discard merges, splits, moves,
        # new groups, or manual group sorting.
        self.protocol("WM_DELETE_WINDOW", self._close_batch_review)

        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        if source_label.lower().startswith("openai"):
            intro = (
                "OpenAI item grouping — review these suggestions before creating listings. "
                "AI is deciding which photos appear to show the same item; nothing is deleted."
            )
        else:
            intro = (
                "Local visual grouping — conservative/free fallback. It may over-split different "
                "angles of the same item. Use OpenAI grouping when product identification matters."
            )

        ttk.Label(
            self,
            text=intro,
            wraplength=1060,
        ).grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 6))

        left = ttk.Frame(self, padding=(10, 0, 8, 10))
        left.grid(row=1, column=0, sticky="ns")
        ttk.Label(left, text="Likely item groups").pack(anchor="w")

        self.group_list = tk.Listbox(
            left, width=38, height=25, exportselection=False
        )
        self.group_list.pack(fill="y", expand=True, pady=(4, 8))
        self.group_list.bind("<<ListboxSelect>>", self._group_changed)

        ttk.Button(
            left, text="Sort This Group by Quality", command=self._sort_current_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left, text="New Empty Group", command=self._new_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left, text="Merge This Group Into…", command=self._merge_group
        ).pack(fill="x", pady=2)
        ttk.Button(
            left,
            text="Use This Group as Current Item",
            command=self._use_group,
            style="Accent.TButton",
        ).pack(fill="x", pady=(10, 2))
        ttk.Button(
            left,
            text="Use Group + AI Sort/Pick Best",
            command=self._use_group_and_sort,
        ).pack(fill="x", pady=2)

        right = ttk.Frame(self, padding=(0, 0, 10, 10))
        right.grid(row=1, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)

        self.group_info_var = tk.StringVar(value="")
        ttk.Label(
            right,
            textvariable=self.group_info_var,
            wraplength=760,
            justify="left",
            style="Subheader.TLabel",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))

        self.canvas = tk.Canvas(right, highlightthickness=0)
        scroll = ttk.Scrollbar(right, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scroll.set)
        self.canvas.grid(row=1, column=0, sticky="nsew")
        scroll.grid(row=1, column=1, sticky="ns")

        self.grid_frame = ttk.Frame(self.canvas, padding=6)
        self.grid_window = self.canvas.create_window(
            (0, 0), window=self.grid_frame, anchor="nw"
        )
        self.grid_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self.grid_window, width=e.width),
        )
        self.canvas.bind("<MouseWheel>", self._on_batch_mousewheel)
        self.grid_frame.bind("<MouseWheel>", self._on_batch_mousewheel)

        controls = ttk.LabelFrame(right, text="Selected Photo", padding=8)
        controls.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        controls.columnconfigure(1, weight=1)

        self.selected_var = tk.StringVar(value="None — click a thumbnail; Ctrl-click or Select adds more")
        ttk.Label(
            controls,
            textvariable=self.selected_var,
            wraplength=760,
            justify="left",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 7))

        ttk.Label(controls, text="Move selected photo(s) to:").grid(
            row=1, column=0, padx=(0, 5), sticky="e"
        )
        self.move_var = tk.StringVar()
        self.move_combo = ttk.Combobox(
            controls, textvariable=self.move_var, state="readonly", width=28
        )
        self.move_combo.grid(row=1, column=1, padx=(0, 5), sticky="w")

        self.move_btn = ttk.Button(
            controls, text="Move Selected to Group", command=self._move_selected, state="disabled"
        )
        self.move_btn.grid(row=1, column=2, sticky="w", padx=(0, 5))

        self.split_btn = ttk.Button(
            controls,
            text="Make New Group from Selected Photo(s)",
            command=self._split_selected,
            state="disabled",
        )
        self.split_btn.grid(row=1, column=3, sticky="w")

        # Populate the left list first and make this stage fail-safe. A partially
        # created Toplevel is extremely confusing because it looks like "AI returned
        # nothing" even when the actual problem was a review-window UI exception.
        try:
            self._refresh_group_list()
        except Exception as exc:
            self.log(f"BATCH REVIEW LIST ERROR: {exc}")
            self.group_list.delete(0, "end")
            for i, group in enumerate(self.groups):
                self.group_list.insert(
                    "end", f"Group {i + 1} — {len(group)} photo(s)"
                )
            self.move_combo["values"] = [
                f"Group {i + 1}" for i in range(len(self.groups))
            ]

        if self.groups:
            self.group_list.selection_clear(0, "end")
            self.group_list.selection_set(0)
            self.group_list.activate(0)
            self.group_list.see(0)
            self.group_info_var.set(
                f"{len(self.groups)} likely group(s) ready — loading Group 1 preview…"
            )
            self.after(50, lambda: self._safe_show_group(0))
        else:
            self.group_info_var.set(
                "No usable local photo paths were available for review."
            )

    def _sync_groups_to_master(self):
        """Persist all manual group edits back to the photo manager immediately."""
        try:
            self.master.batch_groups = [list(group) for group in self.groups]
            self.master.batch_group_meta = [
                dict(meta) if isinstance(meta, dict) else {}
                for meta in self.group_meta
            ]
            self.master.batch_used_group_signatures = {
                tuple(sorted(str(p) for p in self.groups[i]))
                for i in self.used_group_indexes
                if 0 <= i < len(self.groups)
            }
            self.master.review_groups_btn.config(
                state="normal" if self.master.batch_groups else "disabled"
            )
            self.log(
                f"BATCH GROUPS SAVED: {len(self.groups)} group(s), "
                f"{sum(len(g) for g in self.groups)} photo(s)."
            )
        except Exception as exc:
            self.log(f"BATCH GROUP SAVE WARNING: {exc}")

    def _close_batch_review(self):
        """Save edits before the review window is closed."""
        self._sync_groups_to_master()
        try:
            if getattr(self.master, "_batch_review_window", None) is self:
                self.master._batch_review_window = None
        except Exception:
            pass
        self.destroy()

    def _on_batch_mousewheel(self, event):
        """Scroll the Batch Review thumbnail canvas while the pointer is over it."""
        try:
            delta = int(-1 * (event.delta / 120))
            if delta == 0:
                delta = -1 if event.delta > 0 else 1
            self.canvas.yview_scroll(delta, "units")
        except Exception:
            pass
        return "break"

    def _meta_for_group(self, idx):
        if 0 <= idx < len(self.group_meta):
            meta = self.group_meta[idx]
            return meta if isinstance(meta, dict) else {}
        return {}

    def _refresh_group_list(self):
        current = min(self.current_group, max(0, len(self.groups) - 1))
        self.group_list.delete(0, "end")

        for i, group in enumerate(self.groups):
            try:
                meta = self._meta_for_group(i)
            except Exception:
                meta = {}
            label = str(meta.get("label", "") or "").strip() if isinstance(meta, dict) else ""
            confidence = meta.get("confidence") if isinstance(meta, dict) else None
            extra = ""
            if label:
                extra += f" — {label[:34]}"
            if isinstance(confidence, (int, float)) and confidence > 0:
                extra += f" ({confidence:.0%})"
            used = "✓ USED — " if i in getattr(self, "used_group_indexes", set()) else ""
            self.group_list.insert(
                "end",
                f"{used}Group {i + 1} — {len(group)} photo(s){extra}"
            )

        self.move_combo["values"] = [
            f"Group {i + 1}" for i in range(len(self.groups))
        ]
        if self.groups:
            self.current_group = current
            self.move_var.set(f"Group {self.current_group + 1}")


    def _group_changed(self, event=None):
        sel = self.group_list.curselection()
        if sel:
            self._safe_show_group(int(sel[0]))

    def _safe_show_group(self, idx):
        """Render a group without ever leaving the review window silently blank."""
        try:
            self._show_group(idx)
        except Exception as exc:
            self.log(f"BATCH REVIEW RENDER ERROR: {exc}")
            try:
                for child in self.grid_frame.winfo_children():
                    child.destroy()
                ttk.Label(
                    self.grid_frame,
                    text=(
                        "The group exists, but its thumbnail preview could not be rendered.\n\n"
                        f"Group {idx + 1} contains "
                        f"{len(self.groups[idx]) if 0 <= idx < len(self.groups) else 0} photo(s).\n"
                        "You can still use this group, or close the window and retry.\n\n"
                        f"Technical detail: {exc}"
                    ),
                    justify="left",
                    wraplength=700,
                ).grid(row=0, column=0, sticky="nw", padx=12, pady=12)
                self.group_info_var.set(
                    f"Group {idx + 1} loaded with a preview-render warning."
                )
                self.canvas.configure(scrollregion=self.canvas.bbox("all"))
            except Exception:
                pass

    def _show_group(self, idx):
        if idx < 0 or idx >= len(self.groups):
            return

        self.current_group = idx
        self._clear_photo_selection()

        # Invalidate any thumbnail-render callbacks still pending from a prior group.
        self._render_generation = getattr(self, "_render_generation", 0) + 1
        generation = self._render_generation

        for child in self.grid_frame.winfo_children():
            child.destroy()
        self._thumb_refs.clear()
        self._cards.clear()

        group = list(self.groups[idx])
        meta = self._meta_for_group(idx)
        label = str(meta.get("label", "") or "").strip()
        confidence = meta.get("confidence")

        info = f"Group {idx + 1}: {len(group)} photo(s)"
        if label:
            info += f"  •  AI label: {label}"
        if isinstance(confidence, (int, float)) and confidence > 0:
            info += f"  •  average confidence: {confidence:.0%}"
        self.group_info_var.set(info + "  •  loading previews…")

        # Compute width after the window has had an opportunity to lay itself out.
        try:
            self.update_idletasks()
        except Exception:
            pass
        width = max(650, self.canvas.winfo_width())
        cols = max(3, width // 185)

        def render_one(i):
            if generation != getattr(self, "_render_generation", generation):
                return
            if i >= len(group):
                self.group_info_var.set(info)
                self.canvas.yview_moveto(0)
                return

            p = group[i]
            card = tk.Frame(
                self.grid_frame,
                bd=2,
                relief="groove",
                highlightthickness=2,
                highlightbackground="#c9c9c9",
                highlightcolor="#c9c9c9",
            )
            card.grid(
                row=i // cols,
                column=i % cols,
                sticky="n",
                padx=5,
                pady=5,
            )
            self._cards[str(p)] = card

            try:
                im = _open_oriented(p)
                im.thumbnail((150, 150), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(im)
                self._thumb_refs.append(photo)
                lab = ttk.Label(card, image=photo, cursor="hand2")
            except Exception:
                lab = ttk.Label(
                    card, text="Preview unavailable", width=20, anchor="center"
                )

            lab.pack(padx=4, pady=(4, 2))
            name = Path(p).name
            ttk.Label(
                card, text=name[:26], width=27, anchor="center"
            ).pack(padx=3)

            select_btn = ttk.Button(
                card,
                text="Select",
                command=lambda path=p: self._select(path, additive=True),
            )
            select_btn.pack(fill="x", padx=4, pady=(3, 4))

            card.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")
            lab.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")
            select_btn.bind("<MouseWheel>", self._on_batch_mousewheel, add="+")
            lab.bind(
                "<Button-1>",
                lambda e, path=p: self._select_event(e, path),
            )
            card.bind(
                "<Button-1>",
                lambda e, path=p: self._select_event(e, path),
            )

            # Render only a few thumbnails per UI turn. This keeps the review
            # window responsive even if AI places many photos into one group.
            if (i + 1) % 6 == 0:
                self.group_info_var.set(
                    info + f"  •  loading previews {i + 1}/{len(group)}…"
                )
            self.after(1, lambda n=i + 1: render_one(n))

        if group:
            self.after(1, lambda: render_one(0))
        else:
            self.group_info_var.set(info + "  •  empty group")


    def _clear_photo_selection(self):
        self.selected_path = None
        self.selected_paths = set()
        self.selected_var.set(
            "None — click a thumbnail; Ctrl-click or Select adds more"
        )
        if hasattr(self, "move_btn"):
            self.move_btn.config(state="disabled")
        if hasattr(self, "split_btn"):
            self.split_btn.config(state="disabled")
        self._refresh_selection_borders()

    def _refresh_selection_borders(self):
        selected = set(getattr(self, "selected_paths", set()) or set())
        for p, card in self._cards.items():
            is_selected = p in selected
            try:
                card.configure(
                    highlightbackground=("#1f6aa5" if is_selected else "#c9c9c9"),
                    highlightcolor=("#1f6aa5" if is_selected else "#c9c9c9"),
                )
            except Exception:
                pass

    def _select(self, path, additive=False):
        path = str(path)
        if path not in self.groups[self.current_group]:
            return

        if additive:
            if path in self.selected_paths:
                self.selected_paths.remove(path)
            else:
                self.selected_paths.add(path)
        else:
            self.selected_paths = {path}

        self.selected_path = next(iter(self.selected_paths), None)
        count = len(self.selected_paths)
        if count == 1:
            only = next(iter(self.selected_paths))
            self.selected_var.set(
                f"{Path(only).name}  •  Group {self.current_group + 1}"
            )
            self.title(
                f"Batch Photo Review — selected: {Path(only).name}"
            )
        elif count > 1:
            self.selected_var.set(
                f"{count} photos selected  •  Group {self.current_group + 1}"
            )
            self.title(
                f"Batch Photo Review — {count} photos selected"
            )
        else:
            self.selected_var.set(
                "None — click a thumbnail; Ctrl-click or Select adds more"
            )

        state = "normal" if count else "disabled"
        self.move_btn.config(state=state)
        self.split_btn.config(state=state)
        self._refresh_selection_borders()

    def _select_event(self, event, path):
        # Windows Ctrl key state bit. Plain click selects one; Ctrl-click toggles.
        additive = bool(getattr(event, "state", 0) & 0x0004)
        self._select(path, additive=additive)
        return "break"


    def _new_group(self):
        self.groups.append([])
        self.group_meta.append({})
        self._refresh_group_list()
        self._sync_groups_to_master()

    def _split_selected(self):
        paths = [
            p for p in self.groups[self.current_group]
            if str(p) in self.selected_paths
        ]
        if not paths:
            messagebox.showinfo(
                "Batch Review",
                "Select one or more photos first.",
                parent=self,
            )
            return

        src = self.current_group
        for path in paths:
            self.groups[src].remove(path)
        self.groups.append(list(paths))
        self.group_meta.append({"label": "Manual split"})

        if not self.groups[src]:
            del self.groups[src]
            if src < len(self.group_meta):
                del self.group_meta[src]
            # Shift used indexes after deletion.
            self.used_group_indexes = {
                i - 1 if i > src else i
                for i in self.used_group_indexes
                if i != src
            }

        self.current_group = min(src, len(self.groups) - 1)
        self._refresh_group_list()
        self._sync_groups_to_master()
        self.group_list.selection_clear(0, "end")
        self.group_list.selection_set(self.current_group)
        self.group_list.activate(self.current_group)
        self._safe_show_group(self.current_group)

    def _move_selected(self):
        selected = set(self.selected_paths)
        paths = [
            p for p in self.groups[self.current_group]
            if str(p) in selected
        ]
        if not paths:
            messagebox.showinfo(
                "Batch Review",
                "Select one or more photos first.",
                parent=self,
            )
            return

        try:
            dst = int(self.move_var.get().replace("Group", "").strip()) - 1
        except Exception:
            messagebox.showerror(
                "Batch Review", "Choose a destination group first.", parent=self
            )
            return

        src = self.current_group
        if dst == src:
            messagebox.showinfo(
                "Batch Review",
                "The selected photos are already in that group.",
                parent=self,
            )
            return
        if not (0 <= dst < len(self.groups)):
            return

        for path in paths:
            self.groups[src].remove(path)
            self.groups[dst].append(path)

        source_removed = not self.groups[src]
        if source_removed:
            del self.groups[src]
            if src < len(self.group_meta):
                del self.group_meta[src]
            self.used_group_indexes = {
                i - 1 if i > src else i
                for i in self.used_group_indexes
                if i != src
            }
            if src < dst:
                dst -= 1

        # Stay on the group being worked on. Only move to another index if the
        # source group became empty and therefore no longer exists.
        if source_removed:
            self.current_group = min(src, len(self.groups) - 1)
        else:
            self.current_group = src

        self._refresh_group_list()
        self._sync_groups_to_master()
        self.group_list.selection_clear(0, "end")
        self.group_list.selection_set(self.current_group)
        self.group_list.activate(self.current_group)
        self.group_list.see(self.current_group)
        self._safe_show_group(self.current_group)

        self.log(
            f"Moved {len(paths)} photo(s) to Group {dst + 1}; "
            f"stayed on Group {self.current_group + 1}."
        )


    def _merge_group(self):
        if len(self.groups) < 2:
            return

        target = simpledialog.askinteger(
            "Merge Group",
            f"Merge Group {self.current_group + 1} into which group number?",
            parent=self,
            minvalue=1,
            maxvalue=len(self.groups),
        )
        if not target:
            return

        src = self.current_group
        dst = target - 1
        if dst == src:
            return

        self.groups[dst].extend(self.groups[src])

        # Prefer destination metadata but keep a useful label if it was blank.
        src_meta = self._meta_for_group(src)
        dst_meta = self._meta_for_group(dst)
        if not dst_meta.get("label") and src_meta.get("label"):
            dst_meta["label"] = src_meta.get("label")

        del self.groups[src]
        if src < len(self.group_meta):
            del self.group_meta[src]
        self.used_group_indexes = {
            i - 1 if i > src else i
            for i in self.used_group_indexes
            if i != src
        }
        if src < dst:
            dst -= 1

        self.current_group = max(0, min(dst, len(self.groups) - 1))
        self._refresh_group_list()
        self._sync_groups_to_master()
        self.group_list.selection_clear(0, "end")
        self.group_list.selection_set(self.current_group)
        self._show_group(self.current_group)

    def _sort_current_group(self):
        if not self.groups:
            return
        idx = self.current_group
        paths = list(self.groups[idx])
        if len(paths) < 2:
            return

        self.config(cursor="watch")
        self.update_idletasks()

        def work():
            try:
                ranked, selected, quality, redundant = rank_and_select(
                    paths, target=len(paths)
                )
                self.groups[idx] = list(ranked)
                self.log(
                    f"Sorted Group {idx + 1} by local photo quality."
                )
                self.after(0, self._sync_groups_to_master)
                self.after(0, lambda: self._show_group(idx))
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Batch Review", e, parent=self
                    ),
                )
            finally:
                self.after(0, lambda: self.config(cursor=""))

        threading.Thread(target=work, daemon=True).start()

    def _mark_current_group_used_and_advance(self):
        idx = getattr(self, "current_group", None)
        if idx is None:
            return
        try:
            idx = int(idx)
        except Exception:
            return
        self.used_group_indexes.add(idx)
        self._refresh_group_list()
        self._sync_groups_to_master()

        # Select the next unused group; wrap once if needed.
        candidates = list(range(idx + 1, len(self.groups))) + list(range(0, idx))
        next_idx = next(
            (i for i in candidates if i not in self.used_group_indexes),
            None,
        )
        if next_idx is not None:
            self.group_list.selection_clear(0, "end")
            self.group_list.selection_set(next_idx)
            self.group_list.activate(next_idx)
            self.group_list.see(next_idx)
            self.after(20, lambda i=next_idx: self._safe_show_group(i))
        else:
            self.group_info_var.set(
                f"All {len(self.groups)} group(s) have been used at least once."
            )

    def _use_group(self):
        if not self.groups:
            return
        group = list(self.groups[self.current_group])
        if not group:
            return
        self.on_use_group(group)
        self._mark_current_group_used_and_advance()

    def _use_group_and_sort(self):
        if not self.groups:
            return
        group = list(self.groups[self.current_group])
        if not group:
            return
        self.on_use_group(group)
        # Give the main photo manager a moment to rebuild its thumbnails.
        try:
            self.master.after(150, self.master.ai_sort_best)
        except Exception:
            pass
        self._mark_current_group_used_and_advance()

class _IntegratedPhotoManagerFrame(ttk.LabelFrame):
    """eBay-style local thumbnail manager for one listing's photos."""
    def __init__(self, master, on_change, on_analyze=None, log=None, **kwargs):
        super().__init__(master, text="1. Item Photos", padding=8, **kwargs)
        self.on_change = on_change
        self.on_analyze = on_analyze
        self.log = log or (lambda x: None)
        self.records = []  # {path, included, quality, redundant}
        self.selected_index = None
        self.drag_from = None
        self._thumb_refs = []
        self._check_vars = []
        self._preview_ref = None
        self.busy = False

        # Gallery performance caches. Thumbnails are tiny compared with originals,
        # and are reused across selection/reorder/check-state refreshes.
        self._gallery_thumb_cache = {}
        self._gallery_last_cols = None

        # Multi-item batch state lives separately from the current listing.
        # This lets the user build Listing #1, then reopen the same groups for
        # Listing #2 without re-importing hundreds of photos.
        self.batch_paths = []
        self.batch_groups = []
        self.batch_group_meta = []
        self.batch_source_label = ""
        self.batch_used_group_signatures = set()

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=0)
        self.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        for c in range(6):
            toolbar.columnconfigure(c, weight=1)

        ttk.Button(toolbar, text="ADD PHOTOS", command=self.add_files).grid(
            row=0, column=0, padx=3, sticky="ew"
        )
        ttk.Button(toolbar, text="BATCH", command=self.import_batch).grid(
            row=0, column=1, padx=3, sticky="ew"
        )

        self.ai_group_btn = ttk.Button(
            toolbar,
            text="AI GROUP",
            command=self._ai_group_current_batch,
            style="Accent.TButton",
        )
        self.ai_group_btn.grid(row=0, column=2, padx=3, sticky="ew")

        ttk.Button(
            toolbar,
            text="AI SORT",
            command=self.ai_sort_best,
            style="Accent.TButton",
        ).grid(row=0, column=3, padx=3, sticky="ew")

        self.analyze_btn = None
        if on_analyze:
            self.analyze_btn = ttk.Button(
                toolbar,
                text="ANALYZE",
                command=on_analyze,
                style="Accent.TButton",
            )
            self.analyze_btn.grid(row=0, column=4, padx=3, sticky="ew")

        tools_btn = ttk.Menubutton(toolbar, text="PHOTO TOOLS ▾")
        tools_menu = tk.Menu(tools_btn, tearoff=False)
        tools_btn["menu"] = tools_menu
        tools_btn.grid(row=0, column=5, padx=3, sticky="ew")

        tools_menu.add_command(label="One Item Folder", command=self.add_one_folder)
        tools_menu.add_separator()
        tools_menu.add_command(label="Local Group (Free)", command=self._local_group_current_batch)
        tools_menu.add_command(label="Review Groups", command=self._open_batch_review)
        tools_menu.add_command(label="Local Sort + Pick", command=self.sort_best)
        tools_menu.add_command(label="Move Redundant to Rejected", command=self._move_redundant_to_rejected)
        tools_menu.add_separator()
        tools_menu.add_command(label="Select All Photos", command=self.select_all_photos)
        tools_menu.add_command(label="Clear Selection", command=self.clear_photo_selection)
        tools_menu.add_command(label="View Large", command=self.view_selected_large)
        tools_menu.add_separator()
        tools_menu.add_command(label="Remove Selected Files", command=self.move_selected_to_rejected)
        tools_menu.add_command(label="Remove Unselected Files", command=self.move_unselected_to_rejected)
        tools_menu.add_separator()
        tools_menu.add_command(label="Clear Current Photo Set", command=self.clear)

        # Keep these compatibility button attributes because older state-update
        # paths still reference them; they no longer need to be visible.
        self.review_groups_btn = ttk.Button(
            toolbar, text="REVIEW GROUPS", command=self._open_batch_review, state="disabled"
        )
        self.reject_redundant_btn = ttk.Button(
            toolbar, text="MOVE REDUNDANT TO REJECTED",
            command=self._move_redundant_to_rejected, state="disabled"
        )

        self.count_var = tk.StringVar(value="No local photos selected")
        ttk.Label(toolbar, textvariable=self.count_var, style="Subheader.TLabel").grid(row=1, column=0, columnspan=6, padx=4, pady=(7, 0), sticky="ew")

        left = ttk.Frame(self)
        left.grid(row=1, column=0, sticky="nsew")
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(left, height=330, highlightthickness=0)
        vbar = ttk.Scrollbar(left, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        self.gallery = ttk.Frame(self.canvas, padding=4)
        self.gallery_win = self.canvas.create_window((0, 0), window=self.gallery, anchor="nw")
        self.gallery.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._canvas_resized)
        self.canvas.bind("<MouseWheel>", self._on_gallery_mousewheel)
        self.gallery.bind("<MouseWheel>", self._on_gallery_mousewheel)

        side = ttk.LabelFrame(self, text="Selected Photo", padding=6)
        side.grid(row=1, column=1, sticky="ns", padx=(8, 0))
        self.preview = ttk.Label(side, text="Click a thumbnail\nto preview", anchor="center", width=42)
        self.preview.pack(fill="both", expand=True)
        self.preview.bind("<Button-3>", self._photo_context_menu)
        self.canvas.bind("<Button-3>", self._photo_context_menu)
        self.gallery.bind("<Button-3>", self._photo_context_menu)
        self.detail_var = tk.StringVar(value="")
        ttk.Label(side, textvariable=self.detail_var, wraplength=330, justify="left").pack(fill="x", pady=6)
        ctl = ttk.Frame(side)
        ctl.pack(fill="x")
        ttk.Button(ctl, text="Set Main", command=self.set_main).grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(ctl, text="←", width=4, command=lambda: self.move_selected(-1)).grid(row=0, column=1, padx=2)
        ttk.Button(ctl, text="→", width=4, command=lambda: self.move_selected(1)).grid(row=0, column=2, padx=2)
        ttk.Button(ctl, text="Remove", command=self.remove_selected).grid(row=0, column=3, padx=2)
        for c in range(4):
            ctl.columnconfigure(c, weight=1)

        bottom = ttk.Frame(self)
        bottom.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        self.target_var = tk.IntVar(value=12)
        ttk.Label(bottom, text="Recommended listing photos:").pack(side="left")
        ttk.Spinbox(bottom, from_=1, to=24, textvariable=self.target_var, width=5).pack(side="left", padx=(5, 12))
        ttk.Label(
            bottom,
            text="Drag thumbnails to reorder. Photo #1 is the eBay main image. Double-click sets Main; more actions are under PHOTO TOOLS.",
        ).pack(side="left")

    @property
    def get_selected_listing_photos(self):
        """Return photos currently selected for listing use, in gallery order."""

        def normalize_path_collection(value):
            # Some internal names are methods in older builds.
            if callable(value):
                try:
                    value = value()
                except TypeError:
                    return []
            if value is None:
                return []
            if isinstance(value, (str, Path)):
                return [str(value)]
            try:
                return [str(p) for p in list(value)]
            except TypeError:
                return []

        # First prefer explicit selected/used path providers.
        for attr in ("selected_paths", "used_paths"):
            if hasattr(self, attr):
                out = normalize_path_collection(getattr(self, attr))
                if out:
                    return out

        # Then inspect photo record containers.
        for attr in ("photos", "items", "photo_items", "records"):
            value = getattr(self, attr, None)
            if callable(value):
                try:
                    value = value()
                except TypeError:
                    value = None
            if not value:
                continue

            out = []
            try:
                iterable = list(value)
            except TypeError:
                continue

            for item in iterable:
                if isinstance(item, (str, Path)):
                    out.append(str(item))
                    continue

                if isinstance(item, dict):
                    path = item.get("path") or item.get("filepath") or item.get("file")
                    enabled = item.get(
                        "use",
                        item.get("selected", item.get("checked", True))
                    )
                    if hasattr(enabled, "get"):
                        try:
                            enabled = enabled.get()
                        except Exception:
                            enabled = True
                    if path and bool(enabled):
                        out.append(str(path))
                    continue

                path = (
                    getattr(item, "path", None)
                    or getattr(item, "filepath", None)
                    or getattr(item, "file", None)
                )

                enabled = True
                for flag in ("use", "selected", "checked", "enabled"):
                    if hasattr(item, flag):
                        raw = getattr(item, flag)
                        if callable(raw):
                            try:
                                raw = raw()
                            except TypeError:
                                pass
                        try:
                            enabled = bool(raw.get()) if hasattr(raw, "get") else bool(raw)
                        except Exception:
                            enabled = bool(raw)
                        break

                if path and enabled:
                    out.append(str(path))

            if out:
                return out

        # Fallback to all currently imported paths.
        provider = getattr(self, "_current_all_photo_paths", None)
        if callable(provider):
            try:
                return [str(p) for p in provider()]
            except Exception:
                pass

        return []


    def _get_ai_settings(self):
        """Return current app settings through the callback supplied by the main window."""
        provider = getattr(self, "settings_provider", None)
        if callable(provider):
            return provider()
        # Fallback used by some integrated builds.
        master = self.master
        while master is not None:
            if hasattr(master, "settings"):
                return master.settings
            master = getattr(master, "master", None)
        return {}

    def _ai_grouping_cap(self):
        settings = self._get_ai_settings()
        try:
            value = float(settings.get("ai_grouping_spend_cap", "1.00") or 1.00)
        except Exception:
            value = 1.00
        return max(0.05, value)

    def _current_all_photo_paths(self):
        """Return the retained multi-item batch, or current listing photos as fallback."""
        if getattr(self, "batch_paths", None):
            return [
                str(p)
                for p in self.batch_paths
                if Path(str(p)).exists()
            ]

        # Fallback to the current item only when no separate batch is loaded.
        records = getattr(self, "records", []) or []
        return [
            str(r.get("path"))
            for r in records
            if isinstance(r, dict)
            and r.get("path")
            and not r.get("remote_url")
            and Path(str(r.get("path"))).exists()
        ]

    def _apply_ai_groups_to_review(self, result):
        """Store OpenAI groups and open the real Batch Review window."""
        rich_groups = result.get("groups", []) or []
        path_groups = [
            [str(p) for p in (g.get("paths", []) or []) if Path(str(p)).exists()]
            for g in rich_groups
            if isinstance(g, dict) and g.get("paths")
        ]
        path_groups = [g for g in path_groups if g]

        # Do not silently lose a photo if an AI response omitted its assignment.
        assigned = {p for group in path_groups for p in group}
        leftovers = [
            p for p in self._current_all_photo_paths()
            if p not in assigned
        ]
        for p in leftovers:
            path_groups.append([p])
            rich_groups.append({
                "label": "Unassigned / review manually",
                "paths": [p],
                "confidence": 0.0,
            })

        self.batch_groups = path_groups
        aligned_meta = []
        for i, group in enumerate(path_groups):
            meta = rich_groups[i] if i < len(rich_groups) and isinstance(rich_groups[i], dict) else {}
            meta = dict(meta)
            meta["paths"] = list(group)
            aligned_meta.append(meta)
        self.batch_group_meta = aligned_meta
        self.batch_source_label = "OpenAI grouping"
        self.review_groups_btn.config(
            state="normal" if self.batch_groups else "disabled"
        )
        self.log(
            f"AI GROUP REVIEW READY: {len(self.batch_groups)} group(s), "
            f"{sum(len(g) for g in self.batch_groups)} local photo path(s)."
        )

        if not self.batch_groups:
            raise RuntimeError(
                "OpenAI completed the grouping request but no usable photo groups "
                "were produced. The imported batch has been retained."
            )

        # Log suspiciously large groups. They are still reviewable, but the new
        # progressive renderer prevents the UI from appearing frozen/blank.
        largest = max((len(g) for g in self.batch_groups), default=0)
        if largest >= 40:
            self.log(
                f"AI GROUPING NOTE: largest suggested group contains {largest} photos; "
                "review carefully for accidental merges."
            )

        self._open_batch_review()

    def _ai_group_current_batch(self):
        paths = self._current_all_photo_paths()
        if not paths:
            messagebox.showerror(APP_NAME, "Click Batch / Multiple Items and import a folder first.")
            return

        if len(paths) > 500:
            messagebox.showerror(
                APP_NAME,
                f"AI grouping is limited to 500 photos per pass. "
                f"You currently have {len(paths)} imported photos."
            )
            return

        settings = self._get_ai_settings()
        if not settings.get("openai_api_key", "").strip():
            messagebox.showerror(
                APP_NAME,
                "Enter your OpenAI API key in the eBay Settings tab first."
            )
            return

        cancel_event = getattr(self, "cancel_event", None)
        if cancel_event is None:
            cancel_event = threading.Event()
            self.cancel_event = cancel_event

        log_fn = getattr(self, "log", None)
        if not callable(log_fn):
            log_fn = lambda msg: None

        grouper = AIPhotoGrouper(settings, cancel_event, log_fn)
        cap = self._ai_grouping_cap()
        estimate = grouper.estimate_cost(len(paths))

        if estimate > cap:
            messagebox.showerror(
                APP_NAME,
                f"Estimated grouping cost ${estimate:.2f} exceeds your "
                f"${cap:.2f} hard cap.\n\nIncrease the cap in eBay Settings "
                "or process fewer photos."
            )
            return

        if not messagebox.askyesno(
            APP_NAME,
            f"AI-group {len(paths)} photos by likely item?\n\n"
            f"Estimated cost: about ${estimate:.2f}\n"
            f"Hard spend cap: ${cap:.2f}\n\n"
            "Compact thumbnails will be sent to OpenAI. "
            "No original photo will be deleted."
        ):
            return

        cancel_event.clear()

        # Disable the button during work if present.
        btn = getattr(self, "ai_group_btn", None)
        if btn is not None:
            try:
                btn.config(state="disabled")
            except Exception:
                pass

        log_fn(
            f"Starting AI grouping for {len(paths)} photos | "
            f"estimate ${estimate:.2f} | cap ${cap:.2f}"
        )

        app = self._find_app_controller()
        if app is not None and hasattr(app, "_show_busy"):
            try:
                app._show_busy(
                    "AI Grouping",
                    f"Grouping {len(paths)} photos by likely physical item with OpenAI…",
                    cancellable=True,
                )
            except Exception:
                pass

        def work():
            try:
                result = grouper.group(paths, spend_cap=cap)

                def apply():
                    self._apply_ai_groups_to_review(result)
                    log_fn(
                        f"AI grouping complete: {len(result.get('groups', []))} groups | "
                        f"actual cost ${result.get('cost', 0.0):.4f}"
                    )
                    messagebox.showinfo(
                        APP_NAME,
                        f"AI grouping complete.\n\n"
                        f"Photos: {len(paths)}\n"
                        f"Likely groups: {len(result.get('groups', []))}\n"
                        f"OpenAI model: {result.get('model', settings.get('openai_model', ''))}\n"
                        f"ACTUAL AI COST: ${result.get('cost', 0.0):.4f}\n"
                        f"Input tokens: {result.get('input_tokens', 0):,}\n"
                        f"Output tokens: {result.get('output_tokens', 0):,}\n"
                        f"Spend cap: ${cap:.2f}\n\n"
                        "Review and correct the groups before making listings."
                    )

                self.after(0, apply)
            except Exception as exc:
                log_fn(f"AI GROUPING ERROR: {exc}")
                self.after(0, lambda e=str(exc): messagebox.showerror(APP_NAME, e))
            finally:
                if btn is not None:
                    self.after(0, lambda: btn.config(state="normal"))
                self.after(
                    0,
                    lambda: self.count_var.set(
                        f"{len(self.batch_paths)} batch photo(s) retained"
                        if self.batch_paths
                        else self.count_var.get()
                    ),
                )
                if app is not None and hasattr(app, "_finish_busy_from_worker"):
                    app._finish_busy_from_worker()

        threading.Thread(target=work, daemon=True).start()

    @property
    def selected_paths(self):
        """Local photos currently checked Use, in gallery/upload order."""
        return [
            str(r["path"])
            for r in self.records
            if r.get("included", True)
            and not r.get("remote_url")
            and Path(str(r["path"])).exists()
        ]

    @property
    def selected_existing_urls(self):
        """Existing eBay image URLs currently checked Use, in gallery order."""
        return [
            str(r.get("remote_url"))
            for r in self.records
            if r.get("included", True) and r.get("remote_url")
        ]

    def ordered_image_sources(self):
        """Return mixed local/remote sources in exact gallery order."""
        out = []
        for r in self.records:
            if not r.get("included", True):
                continue
            if r.get("remote_url"):
                out.append(("remote", str(r["remote_url"])))
            elif Path(str(r.get("path", ""))).exists():
                out.append(("local", str(r["path"])))
        return out

    def set_paths(self, paths, all_included=True):
        seen = set()
        records = []
        for p in paths:
            p = str(Path(p))
            if p not in seen and Path(p).exists():
                records.append({"path": p, "included": all_included, "quality": None, "redundant": False})
                seen.add(p)
        self.records = records
        if hasattr(self, "reject_redundant_btn"):
            self.reject_redundant_btn.config(state="disabled")
        self.selected_index = 0 if records else None
        self._refresh()
        self._emit_change()

    def set_remote_urls(self, urls):
        """Display existing eBay photos as normal thumbnails without re-uploading them."""
        ensure_app_dir()
        IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        records = []
        for idx, url in enumerate(urls or []):
            url = str(url or "").strip()
            if not url:
                continue
            suffix = ".jpg"
            cache_path = IMAGE_CACHE_DIR / f"{abs(hash(url))}_{idx}{suffix}"
            try:
                if not cache_path.exists():
                    req = request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                    with request.urlopen(req, timeout=30) as resp:
                        cache_path.write_bytes(resp.read())
                records.append({
                    "path": str(cache_path),
                    "remote_url": url,
                    "included": True,
                    "quality": None,
                    "redundant": False,
                })
            except Exception as exc:
                self.log(f"Could not cache existing eBay image {idx + 1}: {exc}")
        self.records = records
        self.selected_index = 0 if records else None
        self._refresh()
        self._emit_change()

    def add_paths(self, paths):
        existing = {r["path"] for r in self.records}
        for p in paths:
            p = str(Path(p))
            if p not in existing and Path(p).exists():
                self.records.append({"path": p, "included": True, "quality": None, "redundant": False})
                existing.add(p)
        if self.selected_index is None and self.records:
            self.selected_index = 0
        self._refresh()
        self._emit_change()

    def add_files(self):
        paths = filedialog.askopenfilenames(
            title="Add item photos",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp *.heic *.heif *.avif"), ("All files", "*.*")],
        )
        if paths:
            self.add_paths(paths)

    def add_one_folder(self):
        folder = filedialog.askdirectory(title="Choose folder containing photos for ONE item")
        if not folder:
            return
        paths = self._folder_images(folder)
        if not paths:
            messagebox.showinfo("Photos", "No supported image files were found.", parent=self)
            return
        self.set_paths(paths)

    def import_batch(self):
        folder = filedialog.askdirectory(
            title="Choose folder containing MULTIPLE items"
        )
        if not folder:
            return

        paths = self._folder_images(folder)
        if not paths:
            messagebox.showinfo(
                "Photos",
                "No supported image files were found.",
                parent=self,
            )
            return

        if len(paths) > 500:
            messagebox.showerror(
                "Batch Photos",
                f"This folder contains {len(paths)} photos.\\n\\n"
                "AI grouping is capped at 500 photos per pass. "
                "Split this folder into smaller batches first.",
                parent=self,
            )
            return

        self.batch_paths = list(paths)
        self.batch_groups = []
        self.batch_group_meta = []
        self.batch_source_label = ""
        self.review_groups_btn.config(state="disabled")

        self.count_var.set(
            f"{len(paths)} batch photo(s) ready — click AI GROUP BATCH"
        )
        self.log(
            f"Imported {len(paths)} photos as a multi-item batch. "
            "No grouping has been run yet."
        )

        messagebox.showinfo(
            "Batch Photos Ready",
            f"Imported {len(paths)} photos.\\n\\n"
            "Recommended next step: AI GROUP BATCH.\\n\\n"
            "LOCAL GROUP (FREE) is still available as a conservative fallback, "
            "but it may split different angles of the same item into separate groups.",
            parent=self,
        )

    def _folder_images(self, folder):
        files = []
        for p in Path(folder).iterdir():
            if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS:
                files.append(p)
        # Filename order is usually camera capture order; use mtime as a tie-breaker.
        files.sort(key=lambda p: (p.name.lower(), p.stat().st_mtime))
        return [str(p) for p in files]

    def _local_group_current_batch(self):
        paths = self._current_all_photo_paths()
        if not paths:
            messagebox.showinfo(
                "Batch Grouping",
                "Import a Batch / Multiple Items folder first.",
                parent=self,
            )
            return
        self._run_batch_grouping(paths)

    def _run_batch_grouping(self, paths):
        """Free/local conservative grouping fallback."""
        if self.busy:
            return

        self.busy = True
        self.log(
            f"Locally grouping {len(paths)} batch photos. No AI/network use."
        )
        self.count_var.set(f"Local grouping {len(paths)} photos…")

        def progress(done, total, label):
            self.after(
                0,
                lambda: self.count_var.set(
                    f"{label}: {done}/{total}"
                ),
            )

        def work():
            try:
                groups, _ = group_photos(paths, progress=progress)
                self.batch_groups = [list(g) for g in groups if g]
                self.batch_used_group_signatures = set()
                self.batch_group_meta = [
                    {
                        "label": "Local visual similarity",
                        "confidence": 0.0,
                        "paths": list(g),
                    }
                    for g in self.batch_groups
                ]
                self.batch_source_label = "Local visual grouping"
                self.log(
                    f"Local grouping produced {len(self.batch_groups)} "
                    "likely group(s)."
                )
                self.after(
                    0,
                    lambda: self.review_groups_btn.config(
                        state="normal" if self.batch_groups else "disabled"
                    ),
                )
                self.after(0, self._open_batch_review)
            except Exception as exc:
                self.after(
                    0,
                    lambda e=str(exc): messagebox.showerror(
                        "Batch Grouping", e, parent=self
                    ),
                )
            finally:
                self.busy = False
                self.after(
                    0,
                    lambda: self.count_var.set(
                        f"{len(self.batch_paths)} batch photo(s) retained"
                    ),
                )

        threading.Thread(target=work, daemon=True).start()

    def _open_batch_review(self):
        if not getattr(self, "batch_groups", None):
            messagebox.showinfo(
                "Batch Review",
                "No grouped batch is available yet.\\n\\n"
                "Import Batch / Multiple Items, then run AI GROUP BATCH "
                "or LOCAL GROUP (FREE).",
                parent=self,
            )
            return

        try:
            old_review = getattr(self, "_batch_review_window", None)
            if old_review is not None:
                try:
                    if old_review.winfo_exists():
                        old_review.lift()
                        old_review.focus_set()
                        return
                except Exception:
                    self._batch_review_window = None

            review = BatchReviewWindow(
                self,
                self.batch_groups,
                self._use_batch_group,
                self.log,
                group_meta=self.batch_group_meta,
                source_label=self.batch_source_label or "Batch grouping",
            )
            self._batch_review_window = review
            review.focus_set()
            review.lift()
        except Exception as exc:
            self.log(f"BATCH REVIEW WINDOW ERROR: {exc}")
            messagebox.showerror(
                "Batch Review",
                "The groups were created, but the review window could not be built.\n\n"
                f"Groups retained: {len(self.batch_groups)}\n"
                f"Technical detail: {exc}",
                parent=self,
            )

    def _use_batch_group(self, paths):
        self.set_paths(paths)
        self.log(
            f"Loaded {len(paths)} photos from selected batch group into current listing. "
            "The full batch is retained; click REVIEW GROUPS later for the next item."
        )

    def _find_app_controller(self):
        widget = self
        seen = set()
        while widget is not None and id(widget) not in seen:
            seen.add(id(widget))
            if (
                hasattr(widget, "settings")
                and hasattr(widget, "_show_progress_popup")
                and hasattr(widget, "_close_progress_popup")
            ):
                return widget
            widget = getattr(widget, "master", None)
        return None

    def ai_sort_best(self):
        self.log("AI SORT + PICK BEST clicked.")

        if self.busy:
            self.log("AI SORT: another photo operation is already running.")
            return

        app = self._find_app_controller()
        if app is None:
            messagebox.showerror(
                "AI Sort + Pick Best",
                "Could not reach the main application controller.",
                parent=self,
            )
            return

        paths = [
            str(r.get("path"))
            for r in self.records
            if isinstance(r, dict)
            and r.get("path")
            and not r.get("remote_url")
            and Path(str(r.get("path"))).exists()
        ]

        self.log(f"AI SORT: {len(paths)} local photo(s) available.")

        if not paths:
            messagebox.showinfo(
                "AI Sort + Pick Best",
                "Load photos for one item first.",
                parent=self,
            )
            return

        if not str(app.settings.get("openai_api_key", "") or "").strip():
            messagebox.showerror(
                "AI Sort + Pick Best",
                "Add your OpenAI API key in eBay Settings first.",
                parent=self,
            )
            return

        try:
            app.cancel_event.clear()
        except Exception:
            pass

        self.busy = True
        try:
            app._show_progress_popup(
                "AI Sort + Pick Best",
                f"Reviewing {len(paths)} photos and identifying distinct views..."
            )
        except Exception as exc:
            self.log(f"AI SORT loader warning: {exc}")

        def work():
            try:
                self.log("AI SORT: sending request to OpenAI...")
                analyzer = PhotoAnalyzer(
                    app.settings.copy(),
                    app.cancel_event,
                    self.log,
                )

                try:
                    target = max(1, min(int(self.recommended_var.get() or 12), 24))
                except Exception:
                    target = 12

                result = analyzer.select_best_views(paths, max_final=target)
                selected_paths = list(result.get("selected_paths", []) or [])

                if not selected_paths:
                    raise RuntimeError("AI completed but returned no selected photos.")

                selected_set = set(selected_paths)
                by_path = {
                    str(r.get("path")): r
                    for r in self.records
                    if isinstance(r, dict) and r.get("path")
                }

                new_records = []

                for p in selected_paths:
                    rec = by_path.get(str(p))
                    if rec is not None:
                        rec["included"] = True
                        rec["redundant"] = False
                        new_records.append(rec)

                for rec in self.records:
                    p = str(rec.get("path"))
                    if rec.get("remote_url"):
                        new_records.append(rec)
                    elif p not in selected_set:
                        rec["included"] = False
                        rec["redundant"] = True
                        new_records.append(rec)

                self.records = new_records
                self.selected_index = 0 if new_records else None

                def finish():
                    try:
                        self._refresh()
                        self._emit_change()

                        if hasattr(self, "reject_redundant_btn"):
                            self.reject_redundant_btn.config(
                                state="normal"
                                if any(r.get("redundant") for r in self.records)
                                else "disabled"
                            )

                        views = result.get("view_groups", []) or []
                        notes = str(result.get("notes", "") or "")
                        usage = result.get("_usage", {}) or {}
                        ai_cost = float(usage.get("estimated_cost", 0.0) or 0.0)

                        msg = f"Selected {len(selected_paths)} best photo(s)"
                        if views:
                            msg += f" across {len(views)} distinct view group(s)."
                        else:
                            msg += "."
                        msg += (
                            f"\n\nOpenAI model: "
                            f"{usage.get('model', app.settings.get('openai_model', ''))}"
                            f"\nACTUAL AI COST: ${ai_cost:.4f}"
                            f"\nInput tokens: {usage.get('input_tokens', 0):,}"
                            f" | Output tokens: {usage.get('output_tokens', 0):,}"
                        )
                        if notes:
                            msg += f"\n\n{notes}"

                        self.log(
                            f"AI COST: ${ai_cost:.4f} for AI Sort + Pick Best | "
                            f"{usage.get('input_tokens', 0):,} input | "
                            f"{usage.get('output_tokens', 0):,} output"
                        )
                        self.log(
                            f"AI SORT COMPLETE: selected {len(selected_paths)} "
                            f"of {len(paths)} photo(s)."
                        )
                        messagebox.showinfo(
                            "AI Sort + Pick Best",
                            msg,
                            parent=self,
                        )
                    finally:
                        try:
                            app._close_progress_popup()
                        except Exception:
                            pass

                self.after(0, finish)

            except Exception as exc:
                err = str(exc)
                self.log(f"AI SORT ERROR: {err}")

                def fail():
                    try:
                        messagebox.showerror(
                            "AI Sort + Pick Best",
                            err,
                            parent=self,
                        )
                    finally:
                        try:
                            app._close_progress_popup()
                        except Exception:
                            pass

                self.after(0, fail)

            finally:
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def sort_best(self):
        if self.busy:
            return
        if not self.records:
            messagebox.showinfo("Photos", "Add photos first.", parent=self)
            return
        self.busy = True
        paths = [r["path"] for r in self.records]
        target = max(1, min(24, int(self.target_var.get() or 12)))
        self.log(f"Locally scoring {len(paths)} photos and selecting up to {target} diverse shots.")

        def progress(done, total, label):
            self.after(0, lambda: self.count_var.set(f"{label}: {done}/{total}"))

        def work():
            try:
                ranked, selected, quality, redundant = rank_and_select(paths, target, progress)
                by_path = {r["path"]: r for r in self.records}
                new_records = []
                selected_set = set(selected)
                for p in ranked:
                    rec = by_path[p]
                    rec["quality"] = quality.get(p)
                    rec["included"] = p in selected_set
                    rec["redundant"] = p in redundant and p not in selected_set
                    new_records.append(rec)
                # Ensure the best recommended photo is first / main.
                new_records.sort(key=lambda r: (not r["included"], -(r["quality"] or {}).get("score", 0)))
                self.records = new_records
                self.selected_index = 0 if self.records else None
                self.after(0, self._refresh)
                self.after(0, self._emit_change)
                self.after(
                    0,
                    lambda: self.reject_redundant_btn.config(
                        state="normal"
                        if any(r.get("redundant") for r in self.records)
                        else "disabled"
                    ),
                )
                self.log(
                    f"Selected {len(selected)} recommended photo(s); kept all {len(paths)} originals available for manual changes."
                )
            except Exception as exc:
                self.after(0, lambda e=str(exc): messagebox.showerror("Photo Sort", e, parent=self))
            finally:
                self.busy = False
                self.after(0, self._update_count)
        threading.Thread(target=work, daemon=True).start()

    def _move_records_to_rejected(self, records, label):
        """
        Remove chosen local photos from the active gallery/batch immediately.

        The app also tries to move originals to a sibling Rejected Photos folder.
        If Windows/filesystem locking prevents the physical move, the photo still
        disappears from the active viewer so it no longer has to be rendered.
        """
        records = [
            r for r in (records or [])
            if not r.get("remote_url")
            and r.get("path")
        ]

        if not records:
            messagebox.showinfo(
                "Photo Cleanup",
                f"No local {label.lower()} photos are available to remove.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Photo Cleanup",
            f"Remove {len(records)} {label.lower()} photo(s) from the active viewer?\n\n"
            "The app will also try to move the originals into a 'Rejected Photos' "
            "folder beside the source files.\n\n"
            "Even if Windows prevents a file from being moved, it will still be "
            "removed from the active viewer/batch.",
            parent=self,
        ):
            return

        target_paths = {
            str(r.get("path"))
            for r in records
            if str(r.get("path", "")).strip()
        }

        moved_to_rejected = set()
        originals_left_in_place = []
        move_errors = []

        for raw_path in sorted(target_paths):
            src = Path(raw_path)
            if not src.exists():
                continue
            try:
                rejected = src.parent / "Rejected Photos"
                rejected.mkdir(parents=True, exist_ok=True)

                dst = rejected / src.name
                n = 2
                while dst.exists():
                    dst = rejected / f"{src.stem}_{n}{src.suffix}"
                    n += 1

                shutil.move(str(src), str(dst))
                moved_to_rejected.add(raw_path)
            except Exception as exc:
                # Viewer cleanup is independent of physical file movement.
                originals_left_in_place.append(raw_path)
                move_errors.append((raw_path, str(exc)))

        # Always remove the selected paths from the current UI/batch state.
        self.records = [
            r for r in self.records
            if str(r.get("path")) not in target_paths
        ]

        self.batch_paths = [
            p for p in self.batch_paths
            if str(p) not in target_paths
        ]

        self.batch_groups = [
            [p for p in group if str(p) not in target_paths]
            for group in self.batch_groups
        ]
        self.batch_groups = [g for g in self.batch_groups if g]

        # Release cached thumbnails immediately.
        for key in list(self._gallery_thumb_cache.keys()):
            try:
                if str(key[0]) in target_paths:
                    self._gallery_thumb_cache.pop(key, None)
            except Exception:
                pass

        self.selected_index = 0 if self.records else None
        self._refresh()
        self._emit_change()

        removed_count = len(target_paths)
        msg = f"Removed {removed_count} photo(s) from the active viewer/batch."

        if moved_to_rejected:
            msg += (
                f"\n\n{len(moved_to_rejected)} original file(s) were moved to "
                "'Rejected Photos'."
            )

        if originals_left_in_place:
            msg += (
                f"\n\n{len(originals_left_in_place)} original file(s) could not be "
                "moved, so those originals were left where they are. They are still "
                "removed from this working photo set."
            )
            self.log("PHOTO MOVE WARNINGS: " + repr(move_errors[:20]))

        messagebox.showinfo("Photo Cleanup", msg, parent=self)


    def move_selected_to_rejected(self):
        self._move_records_to_rejected(
            [r for r in self.records if r.get("included", True)],
            "SELECTED",
        )

    def move_unselected_to_rejected(self):
        self._move_records_to_rejected(
            [r for r in self.records if not r.get("included", True)],
            "UNSELECTED",
        )

    def _move_redundant_to_rejected(self):
        """
        Move photos marked redundant by SORT + PICK BEST into a sibling
        'Rejected Photos' folder. This is deliberately safer than permanent delete.
        """
        redundant_records = [
            r for r in self.records
            if r.get("redundant")
            and not r.get("remote_url")
            and Path(str(r.get("path", ""))).exists()
        ]

        if not redundant_records:
            messagebox.showinfo(
                "Redundant Photos",
                "No redundant local photos are currently flagged.\\n\\n"
                "Run AI SORT + PICK BEST or LOCAL SORT + PICK first.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Move Redundant Photos",
            f"Move {len(redundant_records)} redundant photo(s) to a "
            "'Rejected Photos' folder?\\n\\n"
            "They will be removed from this listing/batch but NOT permanently deleted.",
            parent=self,
        ):
            return

        moved_originals = set()
        failures = []

        for rec in redundant_records:
            src = Path(str(rec["path"]))
            try:
                rejected = src.parent / "Rejected Photos"
                rejected.mkdir(parents=True, exist_ok=True)

                dst = rejected / src.name
                n = 2
                while dst.exists():
                    dst = rejected / f"{src.stem}_{n}{src.suffix}"
                    n += 1

                shutil.move(str(src), str(dst))
                moved_originals.add(str(src))
            except Exception as exc:
                failures.append((str(src), str(exc)))

        if moved_originals:
            self.records = [
                r for r in self.records
                if str(r.get("path")) not in moved_originals
            ]

            self.batch_paths = [
                p for p in self.batch_paths
                if str(p) not in moved_originals
            ]

            new_groups = []
            for group in self.batch_groups:
                kept = [p for p in group if str(p) not in moved_originals]
                if kept:
                    new_groups.append(kept)
            self.batch_groups = new_groups

            self.selected_index = 0 if self.records else None
            self.reject_redundant_btn.config(state="disabled")
            self._refresh()
            self._emit_change()

        message = (
            f"Moved {len(moved_originals)} redundant photo(s) into "
            "'Rejected Photos'."
        )
        if failures:
            message += (
                f"\\n\\n{len(failures)} photo(s) could not be moved. "
                "Details were written to Status."
            )
            self.log("Redundant photo move failures: " + repr(failures[:15]))

        messagebox.showinfo("Redundant Photos", message, parent=self)

    def view_selected_large(self):
        """Open the currently highlighted photo in the lazy large viewer."""
        if not self.records:
            messagebox.showinfo(
                "Large Photo Viewer",
                "No photos are loaded.",
                parent=self,
            )
            return

        idx = self.selected_index
        if idx is None or not (0 <= idx < len(self.records)):
            idx = 0

        self.view_photo_large(idx)

    def view_photo_large(self, index=0):
        """
        Lazy large viewer for the photos currently checked Use.

        Ctrl+mouse-wheel zooms. Arrow keys, buttons, or clicking the left/right
        half of the image move through the selected photos. Scrollbars allow
        panning while zoomed.
        """
        if not self.records:
            return

        try:
            index = int(index)
        except Exception:
            index = 0
        if index < 0 or index >= len(self.records):
            index = 0

        included_indices = [
            i for i, r in enumerate(self.records)
            if r.get("included", True)
        ]
        if not included_indices:
            included_indices = list(range(len(self.records)))

        if index not in included_indices:
            nav_indices = [index] + [i for i in included_indices if i != index]
        else:
            nav_indices = included_indices

        try:
            nav_pos = nav_indices.index(index)
        except ValueError:
            nav_pos = 0

        win = tk.Toplevel(self)
        win.title("Large Photo Viewer")
        win.transient(self.winfo_toplevel())
        win.geometry("1150x850")
        win.minsize(700, 520)
        win.columnconfigure(0, weight=1)
        win.rowconfigure(0, weight=1)

        holder = ttk.Frame(win, padding=6)
        holder.grid(row=0, column=0, sticky="nsew")
        holder.columnconfigure(0, weight=1)
        holder.rowconfigure(0, weight=1)

        canvas = tk.Canvas(
            holder,
            highlightthickness=0,
            background="#202020",
            cursor="hand2",
        )
        hbar = ttk.Scrollbar(holder, orient="horizontal", command=canvas.xview)
        vbar = ttk.Scrollbar(holder, orient="vertical", command=canvas.yview)
        canvas.configure(xscrollcommand=hbar.set, yscrollcommand=vbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")

        info_var = tk.StringVar(value="")
        ttk.Label(
            win, textvariable=info_var, anchor="center"
        ).grid(row=1, column=0, sticky="ew", pady=(4, 2))

        controls = ttk.Frame(win, padding=(8, 2, 8, 8))
        controls.grid(row=2, column=0, sticky="ew")
        controls.columnconfigure(1, weight=1)

        state = {
            "nav_indices": nav_indices,
            "nav_pos": nav_pos,
            "photo_ref": None,
            "original": None,
            "original_size": (0, 0),
            "fit_scale": 1.0,
            "zoom": 1.0,
            "resize_after": None,
        }

        def load_current():
            idx = state["nav_indices"][state["nav_pos"]]
            rec = self.records[idx]
            path = str(rec.get("path", "") or "")
            if not path or not Path(path).exists():
                state["original"] = None
                canvas.delete("all")
                canvas.create_text(
                    20, 20, anchor="nw", fill="white",
                    text="Image file is unavailable."
                )
                return
            try:
                state["original"] = _open_oriented(path)
                state["original_size"] = (
                    state["original"].width,
                    state["original"].height,
                )
                state["zoom"] = 1.0
                self.selected_index = idx
                render_current()
            except Exception as exc:
                state["original"] = None
                canvas.delete("all")
                canvas.create_text(
                    20, 20, anchor="nw", fill="white",
                    text=f"Could not display image:\n{exc}"
                )

        def render_current():
            im = state.get("original")
            if im is None:
                return

            win.update_idletasks()
            view_w = max(300, canvas.winfo_width() - 12)
            view_h = max(250, canvas.winfo_height() - 12)
            ow, oh = state["original_size"]
            fit = min(view_w / max(1, ow), view_h / max(1, oh), 1.0)
            state["fit_scale"] = fit

            scale = min(4.0, max(0.15, fit * state["zoom"]))
            # Do not enlarge beyond 4x original pixels.
            target_w = max(1, int(ow * scale))
            target_h = max(1, int(oh * scale))

            resized = im.resize(
                (target_w, target_h),
                Image.Resampling.LANCZOS,
            )
            photo = ImageTk.PhotoImage(resized)
            state["photo_ref"] = photo

            canvas.delete("all")
            cx = max(view_w // 2, target_w // 2)
            cy = max(view_h // 2, target_h // 2)
            canvas.create_image(cx, cy, image=photo, anchor="center")
            scroll_w = max(view_w, target_w)
            scroll_h = max(view_h, target_h)
            canvas.configure(scrollregion=(0, 0, scroll_w, scroll_h))

            idx = state["nav_indices"][state["nav_pos"]]
            rec = self.records[idx]
            path = str(rec.get("path", "") or "")
            info_var.set(
                f"Selected photo {state['nav_pos'] + 1} of "
                f"{len(state['nav_indices'])}  •  {Path(path).name}  •  "
                f"{ow}×{oh}  •  Zoom {state['zoom']:.2f}×  •  "
                "Ctrl+wheel to zoom"
            )

        def prev_photo():
            if not state["nav_indices"]:
                return
            state["nav_pos"] = (
                state["nav_pos"] - 1
            ) % len(state["nav_indices"])
            load_current()

        def next_photo():
            if not state["nav_indices"]:
                return
            state["nav_pos"] = (
                state["nav_pos"] + 1
            ) % len(state["nav_indices"])
            load_current()

        def zoom_by(factor):
            state["zoom"] = min(
                8.0, max(0.25, state["zoom"] * factor)
            )
            render_current()

        def on_mousewheel(event):
            ctrl = bool(getattr(event, "state", 0) & 0x0004)
            if ctrl:
                zoom_by(1.18 if event.delta > 0 else 1 / 1.18)
                return "break"
            canvas.yview_scroll(
                -1 if event.delta > 0 else 1, "units"
            )
            return "break"

        def on_click(event):
            # Clicking the left/right half navigates while normal dragging/panning
            # remains available through the scrollbars.
            width = max(1, canvas.winfo_width())
            if event.x < width * 0.35:
                prev_photo()
            elif event.x > width * 0.65:
                next_photo()
            return "break"

        def on_resize(_event=None):
            if state["resize_after"] is not None:
                try:
                    win.after_cancel(state["resize_after"])
                except Exception:
                    pass
            state["resize_after"] = win.after(180, render_current)

        ttk.Button(
            controls, text="◀ PREVIOUS", command=prev_photo
        ).grid(row=0, column=0, padx=(0, 6))
        ttk.Label(
            controls,
            text=(
                "Click left/right side or use ←/→ to browse selected photos • "
                "Ctrl+wheel zooms"
            ),
            anchor="center",
        ).grid(row=0, column=1, sticky="ew")
        ttk.Button(
            controls, text="NEXT ▶", command=next_photo
        ).grid(row=0, column=2, padx=(6, 0))
        ttk.Button(
            controls, text="FIT", command=lambda: (
                state.update({"zoom": 1.0}), render_current()
            )
        ).grid(row=0, column=3, padx=(12, 0))
        ttk.Button(
            controls, text="CLOSE", command=win.destroy
        ).grid(row=0, column=4, padx=(6, 0))

        win.bind("<Left>", lambda _e: prev_photo())
        win.bind("<Right>", lambda _e: next_photo())
        win.bind("<Escape>", lambda _e: win.destroy())
        win.bind("<Control-plus>", lambda _e: zoom_by(1.18))
        win.bind("<Control-equal>", lambda _e: zoom_by(1.18))
        win.bind("<Control-minus>", lambda _e: zoom_by(1 / 1.18))
        canvas.bind("<MouseWheel>", on_mousewheel)
        canvas.bind("<Button-1>", on_click)
        canvas.bind("<Configure>", on_resize)

        load_current()
        try:
            win.focus_set()
        except Exception:
            pass


    def select_all_photos(self):
        """Check Use on every photo currently loaded in the viewer."""
        changed = False
        for rec in self.records:
            if not rec.get("included", True):
                rec["included"] = True
                changed = True

        if changed:
            self._refresh()
            self._emit_change()

        self.log(
            f"Selected all {len(self.records)} photo(s) in the current viewer."
        )

    def clear_photo_selection(self):
        """Uncheck Use on every photo without deleting/removing the files."""
        changed = False
        for rec in self.records:
            if rec.get("included", True):
                rec["included"] = False
                changed = True

        if changed:
            self._refresh()
            self._emit_change()

        self.log(
            f"Cleared Use selection for {len(self.records)} photo(s). "
            "No files were removed."
        )

    def clear(self):
        # Clear only the current listing photos. A retained multi-item batch is
        # intentionally kept so the next product group can be opened afterward.
        self.records = []
        self.selected_index = None
        self._refresh()
        self._emit_change()
        if self.batch_paths:
            self.count_var.set(
                f"Current item cleared • {len(self.batch_paths)} batch photo(s) retained"
            )

    def show_existing_count(self, count):
        if not self.records and count:
            self.count_var.set(
                f"{count} existing eBay photo(s) will be preserved unless you add replacements"
            )

    def _on_gallery_mousewheel(self, event):
        """Scroll the thumbnail gallery when the pointer is anywhere over it."""
        if getattr(event, "delta", 0):
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        return "break"

    def _canvas_resized(self, event):
        self.canvas.itemconfigure(self.gallery_win, width=event.width)

        # Window resize events can fire dozens of times per second. Rebuilding
        # hundreds of thumbnail widgets on every pixel was a major slowdown.
        new_cols = max(2, max(500, event.width) // 155)
        if new_cols != self._gallery_last_cols:
            self._gallery_last_cols = new_cols
            self._refresh()

    def _photo_context_menu(self, event, index=None):
        if index is not None and 0 <= int(index) < len(self.records):
            self.selected_index = int(index)
            self._show_preview()

        menu = tk.Menu(self, tearoff=False)
        menu.add_command(
            label="View Large",
            command=self.view_selected_large,
        )
        menu.add_command(
            label="Set as Main Photo",
            command=self.set_main,
            state="normal" if self.selected_index is not None else "disabled",
        )
        menu.add_separator()

        if self.selected_index is not None:
            rec = self.records[self.selected_index]
            included = bool(rec.get("included", True))

            def toggle_use():
                rec["included"] = not included
                self._refresh()
                self._emit_change()

            menu.add_command(
                label=("Uncheck Use" if included else "Check Use"),
                command=toggle_use,
            )
            menu.add_command(
                label="Move Left",
                command=lambda: self.move_selected(-1),
            )
            menu.add_command(
                label="Move Right",
                command=lambda: self.move_selected(1),
            )
            menu.add_command(
                label="Remove Photo",
                command=self.remove_selected,
            )

        menu.add_separator()
        menu.add_command(
            label="Select All Photos",
            command=self.select_all_photos,
        )
        menu.add_command(
            label="Clear Use Selection",
            command=self.clear_photo_selection,
        )
        menu.add_separator()
        menu.add_command(
            label="AI Sort + Pick Best",
            command=self.ai_sort_best,
        )
        menu.add_command(
            label="Review Groups",
            command=self._open_batch_review,
            state=(
                "normal"
                if getattr(self, "batch_groups", None)
                else "disabled"
            ),
        )

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass
        return "break"

    def _refresh(self):
        for child in self.gallery.winfo_children():
            child.destroy()
        self._thumb_refs.clear()
        self._check_vars.clear()
        width = max(500, self.canvas.winfo_width())
        cols = max(2, width // 155)
        self._gallery_last_cols = cols
        for idx, rec in enumerate(self.records):
            card = ttk.Frame(self.gallery, padding=4, relief="ridge")
            card.grid(row=idx // cols, column=idx % cols, padx=4, pady=4, sticky="n")
            try:
                path = str(rec["path"])
                try:
                    stat = Path(path).stat()
                    cache_key = (
                        path,
                        int(stat.st_size),
                        int(stat.st_mtime_ns),
                        tuple(THUMB_SIZE),
                    )
                except Exception:
                    cache_key = (path, 0, 0, tuple(THUMB_SIZE))

                cached_im = self._gallery_thumb_cache.get(cache_key)
                if cached_im is None:
                    cached_im = _open_oriented(path)
                    cached_im.thumbnail(THUMB_SIZE, Image.Resampling.LANCZOS)
                    cached_im = cached_im.copy()
                    self._gallery_thumb_cache[cache_key] = cached_im

                    # 700 cached listing thumbnails is still modest memory use.
                    if len(self._gallery_thumb_cache) > 700:
                        for stale in list(self._gallery_thumb_cache.keys())[:120]:
                            self._gallery_thumb_cache.pop(stale, None)

                photo = ImageTk.PhotoImage(cached_im)
                self._thumb_refs.append(photo)
                lab = ttk.Label(card, image=photo, cursor="hand2")
            except Exception as exc:
                lab = ttk.Label(card, text="Preview\nunavailable", width=16, anchor="center")
            lab.pack()
            title = "MAIN" if idx == 0 else f"#{idx + 1}"
            if rec.get("remote_url"):
                title += "  • eBay"
            q = rec.get("quality") or {}
            if q:
                title += f"  Q {q.get('score', 0):.0f}"
            ttk.Label(card, text=title).pack()
            use_var = tk.BooleanVar(value=rec.get("included", True))
            self._check_vars.append(use_var)
            check = ttk.Checkbutton(card, text="Use", variable=use_var, command=lambda i=idx, v=use_var: self._toggle(i, v))
            check.pack()

            # Keep scrolling working even when the pointer is directly over a card,
            # thumbnail, or its Use checkbox.
            card.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            lab.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            check.bind("<MouseWheel>", self._on_gallery_mousewheel, add="+")
            if rec.get("redundant"):
                ttk.Label(card, text="similar/redundant").pack()
            # Store the record index on each visual element so pointer-based
            # drag/drop can determine which thumbnail is under the mouse.
            card._photo_index = idx
            lab._photo_index = idx

            lab.bind("<Button-1>", lambda e, i=idx: self._select(i))
            lab.bind(
                "<Button-3>",
                lambda e, i=idx: self._photo_context_menu(e, i),
            )
            card.bind(
                "<Button-3>",
                lambda e, i=idx: self._photo_context_menu(e, i),
            )
            check.bind(
                "<Button-3>",
                lambda e, i=idx: self._photo_context_menu(e, i),
            )
            lab.bind(
                "<Double-1>",
                lambda e, i=idx: self.view_photo_large(i),
                add="+",
            )
            lab.bind("<Double-Button-1>", lambda e, i=idx: self._set_main_index(i))

            # True drag/drop: press on a thumbnail, move over another card,
            # then release. Tk keeps an implicit mouse grab on the source
            # widget, so release coordinates are resolved using root coordinates.
            lab.bind("<ButtonPress-1>", lambda e, i=idx: self._drag_start_event(e, i), add="+")
            lab.bind("<B1-Motion>", self._drag_motion, add="+")
            lab.bind("<ButtonRelease-1>", self._drag_release, add="+")
        self._update_count()
        self._show_preview()

    def _toggle(self, idx, var):
        if 0 <= idx < len(self.records):
            self.records[idx]["included"] = bool(var.get())
            # Main should never be silently excluded; if user clears it, the first included becomes main.
            if idx == 0 and not self.records[idx]["included"]:
                for j in range(1, len(self.records)):
                    if self.records[j].get("included", True):
                        self.records.insert(0, self.records.pop(j))
                        break
            self._emit_change()
            self._refresh()

    def _select(self, idx):
        self.selected_index = idx
        self._show_preview()

    def _show_preview(self):
        if self.selected_index is None or not (0 <= self.selected_index < len(self.records)):
            self.preview.configure(image="", text="Click a thumbnail\nto preview")
            self.detail_var.set("")
            return
        rec = self.records[self.selected_index]
        try:
            im = _open_oriented(rec["path"])
            original_size = im.size
            im.thumbnail(PREVIEW_SIZE, Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(im)
            self._preview_ref = photo
            self.preview.configure(image=photo, text="")
            q = rec.get("quality") or {}
            detail = f"{Path(rec['path']).name}\n{original_size[0]} × {original_size[1]} px"
            if q:
                detail += (
                    f"\nOverall {q.get('score', 0):.1f}/100"
                    f" • Sharp {q.get('sharpness', 0):.0f}"
                    f" • Exposure {q.get('exposure', 0):.0f}"
                    f" • Center {q.get('centering', 0):.0f}"
                )
            self.detail_var.set(detail)
        except Exception as exc:
            self.preview.configure(image="", text="Preview unavailable")
            note = str(exc)
            if Path(rec["path"]).suffix.lower() in {".heic", ".heif"} and not HEIF_AVAILABLE:
                note += "\nInstall pillow-heif for HEIC support."
            self.detail_var.set(f"{Path(rec['path']).name}\n{note}")

    def set_main(self):
        if self.selected_index is not None:
            self._set_main_index(self.selected_index)

    def _set_main_index(self, idx):
        if 0 <= idx < len(self.records):
            rec = self.records.pop(idx)
            rec["included"] = True
            self.records.insert(0, rec)
            self.selected_index = 0
            self._refresh()
            self._emit_change()

    def move_selected(self, delta):
        if self.selected_index is None:
            return
        src = self.selected_index
        dst = max(0, min(len(self.records) - 1, src + delta))
        if dst == src:
            return
        self.records[src], self.records[dst] = self.records[dst], self.records[src]
        self.selected_index = dst
        self._refresh()
        self._emit_change()

    def remove_selected(self):
        if self.selected_index is None:
            return
        del self.records[self.selected_index]
        if self.records:
            self.selected_index = min(self.selected_index, len(self.records) - 1)
        else:
            self.selected_index = None
        self._refresh()
        self._emit_change()

    def _drag_start_event(self, event, idx):
        self.drag_from = idx
        self.selected_index = idx
        try:
            event.widget.configure(cursor="fleur")
        except Exception:
            pass

    def _drag_motion(self, event):
        """Give lightweight feedback while a thumbnail is being dragged."""
        if self.drag_from is None:
            return
        try:
            event.widget.configure(cursor="fleur")
        except Exception:
            pass

    def _photo_index_under_pointer(self, root_x, root_y):
        """Find the thumbnail card underneath screen coordinates."""
        try:
            widget = self.winfo_containing(root_x, root_y)
        except Exception:
            return None

        # Walk upward until we find a card/label carrying a photo index.
        while widget is not None:
            if hasattr(widget, "_photo_index"):
                try:
                    return int(widget._photo_index)
                except Exception:
                    return None
            if widget == self:
                break
            widget = getattr(widget, "master", None)
        return None

    def _drag_release(self, event):
        src = self.drag_from
        self.drag_from = None
        try:
            event.widget.configure(cursor="hand2")
        except Exception:
            pass

        if src is None:
            return

        dst = self._photo_index_under_pointer(event.x_root, event.y_root)
        if dst is None or dst == src:
            self.selected_index = src
            self._show_preview()
            return

        if not (0 <= src < len(self.records) and 0 <= dst < len(self.records)):
            return

        rec = self.records.pop(src)

        # Insert at the visible destination position. Adjust for the list
        # shrinking when dragging toward the right/down.
        if src < dst:
            dst -= 1
        dst = max(0, min(dst, len(self.records)))
        self.records.insert(dst, rec)
        self.selected_index = dst

        self._refresh()
        self._emit_change()
        self.log(
            f"Photo reordered: {Path(rec['path']).name} is now position {dst + 1}"
        )


    def _emit_change(self):
        paths = list(self.selected_paths)
        try:
            self.on_change(paths)
        except Exception as exc:
            self.log(f"Photo selection callback error: {exc}")

    def _update_count(self):
        total = len(self.records)
        local_used = len(self.selected_paths)
        ebay_used = len(self.selected_existing_urls)
        if total:
            if ebay_used:
                self.count_var.set(
                    f"{local_used} local + {ebay_used} existing eBay photo(s) selected / {total} total"
                )
            else:
                self.count_var.set(f"{local_used} selected / {total} total")
        else:
            self.count_var.set("No photos selected")


# Expose the integrated manager only when Pillow loaded successfully.
PhotoManagerFrame = _IntegratedPhotoManagerFrame if Image is not None else None



class AIPhotoGrouper:
    """
    Cloud-assisted photo grouping for large mixed-item batches.

    Strategy:
      1. Locally create compact JPEG thumbnails.
      2. Send them to OpenAI in bounded batches.
      3. Ask only for item-group assignments and view labels.
      4. Merge batch groups conservatively using textual fingerprints.
      5. Track actual token cost and enforce a hard per-job spend cap.
    """

    def __init__(self, settings, cancel_event, log):
        self.s = settings
        self.cancel_event = cancel_event
        self.log = log

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    @staticmethod
    def _responses_output_text(response):
        pieces = []
        for item in response.get("output", []) or []:
            for content in item.get("content", []) or []:
                if content.get("type") == "output_text":
                    pieces.append(content.get("text", ""))
        return "\n".join(pieces).strip()

    @staticmethod
    def _cost_from_usage(model, usage):
        cost, input_tokens, cached_tokens, output_tokens, known = ai_cost_from_usage(
            model, usage
        )
        return cost, input_tokens, output_tokens, cached_tokens, known

    def _thumbnail_data_url(self, path, max_side=512, jpeg_quality=68):
        if Image is None:
            raise RuntimeError("Pillow is required for AI batch grouping.")
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((max_side, max_side))
            import io
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=jpeg_quality, optimize=True)
            raw = base64.b64encode(buf.getvalue()).decode("ascii")
        return "data:image/jpeg;base64," + raw

    def estimate_cost(self, photo_count):
        """
        Conservative planning estimate, not the final bill.
        Uses thumbnail/batch design rather than original full-resolution images.
        """
        # Tuned intentionally conservatively: roughly $0.0012/image plus response overhead.
        # 500 images ~= $0.60 planned estimate, leaving headroom under the $1 cap.
        return 0.015 + max(0, int(photo_count)) * 0.0012

    def _call_group_batch(self, indexed_paths):
        self._check_cancel()
        key = self.s.get("openai_api_key", "").strip()
        if not key:
            raise RuntimeError("No OpenAI API key is configured.")

        model = self.s.get("openai_model", "gpt-4.1-mini").strip() or "gpt-5.6-luna"

        content = [{
            "type": "input_text",
            "text": (
                "Group these product-listing photos by the physical/product item they appear "
                "to represent. Photos can show different angles of the same item. Be conservative: "
                "if uncertain whether two photos are the same item/model, keep them in separate "
                "groups rather than merging them. Use visible manufacturer, model/part-number "
                "labels, housing shape, connectors, markings and damage patterns when available. "
                "For each photo return: photo_index, group_key, view_label, confidence. "
                "group_key should be a short stable textual fingerprint such as "
                "'Fluke-87V-meter' or 'unknown-black-backplane-A'. view_label can be front, rear, "
                "side, top, bottom, label, connector, detail, packaging, or unknown. "
                "Do not describe unrelated scene content. Return only the requested JSON."
            )
        }]

        for idx, path in indexed_paths:
            self._check_cancel()
            content.append({"type": "input_text", "text": f"PHOTO_INDEX={idx}"})
            content.append({
                "type": "input_image",
                "image_url": self._thumbnail_data_url(path),
                "detail": "low",
            })

        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "assignments": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "photo_index": {"type": "integer"},
                            "group_key": {"type": "string"},
                            "view_label": {"type": "string"},
                            "confidence": {"type": "number"},
                        },
                        "required": ["photo_index", "group_key", "view_label", "confidence"],
                    },
                }
            },
            "required": ["assignments"],
        }

        payload = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "photo_item_grouping",
                    "strict": True,
                    "schema": schema,
                }
            },
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=180) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI grouping error {exc.code}:\n{body}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"OpenAI grouping network error: {exc}") from exc

        out = self._responses_output_text(raw)
        if not out:
            raise RuntimeError("AI grouping returned no structured result.")
        try:
            parsed = json.loads(out)
        except Exception as exc:
            raise RuntimeError("Could not parse AI grouping result.") from exc

        cost, input_tokens, output_tokens, cached_tokens, known_rate = (
            self._cost_from_usage(model, raw.get("usage", {}))
        )
        return (
            parsed.get("assignments", []) or [],
            cost,
            input_tokens,
            output_tokens,
            cached_tokens,
            known_rate,
        )

    def group(self, photo_paths, spend_cap=1.00, batch_size=24):
        self._check_cancel()
        paths = list(photo_paths)
        if not paths:
            return {"groups": [], "cost": 0.0, "input_tokens": 0, "output_tokens": 0}

        estimate = self.estimate_cost(len(paths))
        if estimate > spend_cap:
            raise RuntimeError(
                f"Estimated AI grouping cost ${estimate:.2f} exceeds the configured "
                f"${spend_cap:.2f} hard cap. Increase the cap or process fewer photos."
            )

        total_cost = 0.0
        total_in = 0
        total_out = 0
        assignments = []

        for start in range(0, len(paths), batch_size):
            self._check_cancel()
            if total_cost >= spend_cap:
                raise RuntimeError(
                    f"AI grouping stopped at the ${spend_cap:.2f} spend cap before "
                    "starting another batch."
                )
            batch = [(i, paths[i]) for i in range(start, min(start + batch_size, len(paths)))]
            self.log(
                f"AI grouping photos {start + 1}-{start + len(batch)} of {len(paths)}..."
            )
            (
                batch_assignments,
                cost,
                inp,
                outp,
                cached_inp,
                known_rate,
            ) = self._call_group_batch(batch)
            total_cost += cost
            total_in += inp
            total_out += outp

            if total_cost > spend_cap:
                raise RuntimeError(
                    f"AI grouping reached ${total_cost:.4f}, above the configured "
                    f"${spend_cap:.2f} cap. No additional batches will be sent."
                )
            assignments.extend(batch_assignments)
            self.log(
                f"Grouping batch cost ${cost:.4f} | running total ${total_cost:.4f}"
            )

        # Merge by normalized group_key. Because the model is conservative, this
        # intentionally permits duplicate/adjacent groups for the user to merge manually.
        grouped = {}
        meta = {}
        for a in assignments:
            idx = int(a.get("photo_index", -1))
            if not (0 <= idx < len(paths)):
                continue
            raw_key = str(a.get("group_key", "") or "").strip() or f"uncertain-{idx}"
            norm = re.sub(r"[^a-z0-9]+", "-", raw_key.lower()).strip("-") or f"uncertain-{idx}"
            grouped.setdefault(norm, []).append(paths[idx])
            meta.setdefault(norm, {
                "label": raw_key,
                "views": {},
                "confidence": [],
            })
            meta[norm]["views"][str(paths[idx])] = str(a.get("view_label", "unknown") or "unknown")
            try:
                meta[norm]["confidence"].append(float(a.get("confidence", 0.0) or 0.0))
            except Exception:
                pass

        groups = []
        for key, group_paths in grouped.items():
            confs = meta[key]["confidence"]
            groups.append({
                "key": key,
                "label": meta[key]["label"],
                "paths": group_paths,
                "views": meta[key]["views"],
                "confidence": (sum(confs) / len(confs)) if confs else 0.0,
            })

        groups.sort(key=lambda g: (-len(g["paths"]), g["label"].lower()))
        return {
            "groups": groups,
            "cost": total_cost,
            "input_tokens": total_in,
            "output_tokens": total_out,
            "estimate": estimate,
            "model": self.s.get("openai_model", "gpt-5.6-luna"),
        }



class PhotoAnalyzer:
    """Analyze listing photos with the OpenAI Responses API using only urllib."""

    def __init__(self, settings, cancel_event, log):
        self.s = settings
        self.cancel_event = cancel_event
        self.log = log

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    @staticmethod
    def _data_url(path):
        path = Path(path)
        mime = mimetypes.guess_type(path.name)[0] or "image/jpeg"
        raw = base64.b64encode(path.read_bytes()).decode("ascii")
        return f"data:{mime};base64,{raw}"

    @staticmethod
    def _extract_output_text(response):
        pieces = []
        for item in response.get("output", []):
            for content in item.get("content", []) or []:
                if content.get("type") == "output_text":
                    pieces.append(content.get("text", ""))
        return "\n".join(pieces).strip()

    def analyze(self, photo_paths):
        self._check_cancel()
        key = self.s.get("openai_api_key", "").strip()
        if not key:
            raise RuntimeError(
                "No OpenAI API key is configured. Open the eBay Settings tab "
                "and paste an API key."
            )

        model = self.s.get("openai_model", "gpt-4.1-mini").strip() or "gpt-5.6-luna"
        self.log(f"Analyzing {len(photo_paths)} photo(s) with {model}...")

        content = [{
            "type": "input_text",
            "text": (
                "You are helping create a conservative eBay listing for surplus "
                "industrial/electronic inventory. Analyze ALL supplied photos as one item. "
                "Read labels, manufacturer markings, model/part numbers, connector counts, "
                "ratings, dimensions if visibly printed, country of origin, date codes, "
                "and other useful markings. Do NOT invent specifications that are not "
                "visible or strongly supported. If uncertain, leave the field empty or "
                "mention uncertainty in review_notes. Condition must be based only on "
                "visible cosmetic evidence; do not claim the item was tested or working. "
                "Create an eBay-style title no longer than 80 characters. "
                "item_description must be a short generic noun phrase. "
                "specifics must contain useful eBay item-specific Name=Value pairs, one "
                "per line, excluding Brand, MPN, Model, and Country of Origin. "
                "condition_notes must be factual and cautious. "
                "Return only the requested structured data."
            ),
        }]

        for p in photo_paths[:12]:
            self._check_cancel()
            content.append({
                "type": "input_image",
                "image_url": self._data_url(p),
                "detail": "high",
            })

        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "brand": {"type": "string"},
                "mpn": {"type": "string"},
                "model": {"type": "string"},
                "item_description": {"type": "string"},
                "country": {"type": "string"},
                "title": {"type": "string"},
                "condition": {
                    "type": "string",
                    "enum": [
                        "New", "New - Open Box", "Used - Excellent",
                        "Used - Very Good", "Used - Good",
                        "Used - Acceptable", "For Parts / Not Working"
                    ]
                },
                "condition_notes": {"type": "string"},
                "specifics": {"type": "string"},
                "review_notes": {"type": "string"},
            },
            "required": [
                "brand", "mpn", "model", "item_description", "country", "title",
                "condition", "condition_notes", "specifics", "review_notes"
            ],
        }

        payload = {
            "model": model,
            "input": [{"role": "user", "content": content}],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "ebay_listing_photo_analysis",
                    "strict": True,
                    "schema": schema,
                }
            },
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=120) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI API error {exc.code}:\n{body}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"OpenAI network error: {exc}") from exc

        self._check_cancel()
        out = self._extract_output_text(raw)
        if not out:
            raise RuntimeError("Photo analysis completed, but no structured result was returned.")

        try:
            result = json.loads(out)
        except Exception as exc:
            raise RuntimeError("Could not parse the AI photo-analysis result.") from exc

        result["title"] = (result.get("title") or "")[:80]

        estimated_cost, input_tokens, cached_tokens, output_tokens, known_rate = (
            ai_cost_from_usage(model, raw.get("usage", {}) or {})
        )
        result["_usage"] = {
            "model": model,
            "input_tokens": input_tokens,
            "cached_input_tokens": cached_tokens,
            "output_tokens": output_tokens,
            "estimated_cost": estimated_cost,
            "known_rate": known_rate,
        }
        return result

    def select_best_views(self, paths, max_final=12):
        """
        AI-assisted curation for ONE physical item.

        The AI groups photos by meaningful product view/angle and chooses the
        single best representative from each similar set, then chooses the
        strongest hero image for eBay position #1.
        """
        paths = [str(p) for p in paths if Path(str(p)).exists()]
        if not paths:
            raise RuntimeError("No photos were supplied for AI sorting.")
        # Cheap local prefilter when there are a lot of nearly-duplicate shots.
        # It deliberately keeps 75% so AI still has enough visual variety to
        # recognize angles instead of local math deciding the final set.
        candidates = list(paths)
        if len(paths) > 20:
            scored = []
            for p in paths:
                try:
                    q = _quality(p)
                    scored.append((float(q.get("score", 0.0)), p))
                except Exception:
                    scored.append((0.0, p))
            scored.sort(reverse=True)
            keep_n = max(14, int(len(scored) * 0.75))
            candidates = [p for _, p in scored[:keep_n]]

        content = [{
            "type": "input_text",
            "text": (
                "You are curating eBay listing photos for ONE physical product. "
                "Group the supplied photos by meaningful VIEW/ANGLE, not merely "
                "by superficial visual similarity. Examples: front, rear, left "
                "side, right side, top, underside, connector end, label close-up, "
                "part-number close-up, damage/flaw detail, packaging. "
                "Within each view group choose exactly ONE best representative "
                "based on sharpness, framing, glare, lighting, centering, useful "
                "detail, obstruction, and how clearly the item is shown. "
                "Do NOT keep multiple near-identical photos of the same angle. "
                "Choose the strongest overall hero image for eBay photo #1. "
                "Keep unique label, connector, marking, and damage-detail photos "
                "even if they are less attractive because they convey unique information. "
                f"Return no more than {int(max_final)} final photos. "
                "Return ONLY JSON using exactly this shape: "
                '{"hero_index":0,"selected_indices":[0,3,5],'
                '"view_groups":[{"view":"front three-quarter","indices":[0,1,2],'
                '"best_index":0,"reason":"sharpest and least glare"}],'
                '"notes":"brief summary"}'
            ),
        }]

        for idx, p in enumerate(candidates):
            # Use a resized analysis copy to reduce upload size/cost while keeping
            # enough detail for angle, glare, framing, and sharpness judgment.
            im = _open_oriented(p)
            im.thumbnail((1200, 1200), Image.Resampling.LANCZOS)
            import io
            buf = io.BytesIO()
            im.convert("RGB").save(buf, format="JPEG", quality=82)
            b64 = base64.b64encode(buf.getvalue()).decode("ascii")

            content.append({
                "type": "input_text",
                "text": f"IMAGE_INDEX={idx} FILE={Path(p).name}",
            })
            content.append({
                "type": "input_image",
                "image_url": f"data:image/jpeg;base64,{b64}",
                "detail": "low",
            })

        body = {
            "model": self.s.get("openai_model", "gpt-4.1-mini"),
            "input": [{"role": "user", "content": content}],
            "max_output_tokens": 2200,
        }

        req = request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Authorization": "Bearer " + self.s.get("openai_api_key", "").strip(),
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=180) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"OpenAI API error {exc.code}:\n{raw}") from exc

        output_text = ""
        for item in result.get("output", []) or []:
            if not isinstance(item, dict):
                continue
            for part in item.get("content", []) or []:
                if isinstance(part, dict) and part.get("type") in ("output_text", "text"):
                    output_text += str(part.get("text", "") or "")

        cleaned = output_text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        try:
            parsed = json.loads(cleaned)
        except Exception as exc:
            raise RuntimeError(
                "OpenAI returned an unreadable AI photo-sort response.\n\n"
                + cleaned[:900]
            ) from exc

        chosen = []
        for raw_idx in parsed.get("selected_indices", []) or []:
            try:
                idx = int(raw_idx)
            except Exception:
                continue
            if 0 <= idx < len(candidates) and idx not in chosen:
                chosen.append(idx)

        try:
            hero = int(parsed.get("hero_index"))
        except Exception:
            hero = None

        if hero is not None and 0 <= hero < len(candidates):
            if hero in chosen:
                chosen.remove(hero)
            chosen.insert(0, hero)

        if not chosen:
            raise RuntimeError("AI did not select any photos.")

        chosen = chosen[:max_final]
        selected_paths = [candidates[i] for i in chosen]

        model = str(body.get("model", "") or "")
        ai_cost, input_tokens, cached_tokens, output_tokens, known_rate = (
            ai_cost_from_usage(model, result.get("usage", {}) or {})
        )

        return {
            "selected_paths": selected_paths,
            "rejected_paths": [p for p in paths if p not in selected_paths],
            "view_groups": parsed.get("view_groups", []) or [],
            "notes": str(parsed.get("notes", "") or ""),
            "_usage": {
                "model": model,
                "input_tokens": input_tokens,
                "cached_input_tokens": cached_tokens,
                "output_tokens": output_tokens,
                "estimated_cost": ai_cost,
                "known_rate": known_rate,
            },
        }



class EbayClient:
    def __init__(self, settings, cancel_event, log):
        self.s = dict(settings or {})
        self.cancel_event = cancel_event
        self.log = log

        # Authentication can refresh in a different worker/client instance.
        # Always prefer the newest persisted auth values over a stale GUI copy.
        try:
            persisted = load_settings()
            for key in (
                "access_token",
                "ebay_refresh_token",
                "access_token_expires_at",
                "refresh_token_expires_at",
            ):
                if persisted.get(key):
                    self.s[key] = persisted.get(key)
        except Exception:
            pass

        # This flag is request-scoped and reset before each outbound call.
        self._refresh_attempted = False
        if settings.get("api_environment") == "sandbox":
            self.api_base = "https://api.sandbox.ebay.com"
            self.media_api_base = "https://apim.sandbox.ebay.com"
        else:
            self.api_base = "https://api.ebay.com"
            self.media_api_base = "https://apim.ebay.com"

    def _check_cancel(self):
        if self.cancel_event.is_set():
            raise RuntimeError("Cancelled by user.")

    def exchange_authorization_code(self, authorization_code, runame):
        """
        Exchange a one-time OAuth authorization code for:
          - User Access Token
          - Refresh Token
        """
        self._check_cancel()
        code = str(authorization_code or "").strip()
        runame = str(runame or "").strip()
        client_id = self.s.get("ebay_client_id", "").strip()
        client_secret = self.s.get("ebay_client_secret", "").strip()

        if not client_id or not client_secret:
            raise RuntimeError("Production App ID and Cert ID are required.")
        if not runame:
            raise RuntimeError("OAuth RuName is required.")
        if not code:
            raise RuntimeError("Authorization code is required.")

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        body = parse.urlencode({
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": runame,
        }).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(
                f"eBay authorization-code exchange error {exc.code}:\n{raw}"
            ) from exc
        except error.URLError as exc:
            raise RuntimeError(
                f"eBay authorization-code exchange network error: {exc}"
            ) from exc

        access_token = str(data.get("access_token", "") or "").strip()
        refresh_token = str(data.get("refresh_token", "") or "").strip()
        expires_in = int(data.get("expires_in", 0) or 0)
        refresh_expires_in = int(data.get("refresh_token_expires_in", 0) or 0)

        if not access_token or not refresh_token:
            raise RuntimeError(
                "eBay did not return both an access token and a refresh token."
            )

        now_ts = int(time.time())
        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_in": expires_in,
            "refresh_token_expires_in": refresh_expires_in,
            "access_token_expires_at": (
                now_ts + expires_in if expires_in else 0
            ),
            "refresh_token_expires_at": (
                now_ts + refresh_expires_in if refresh_expires_in else 0
            ),
        }

    def _refresh_user_access_token(self):
        """
        Use the long-lived refresh token to mint a new access token.

        Returns True only when a new token was obtained. Failure details are
        logged, including eBay's OAuth response body when available.
        """
        # Re-read persisted credentials first in case another client refreshed
        # or the GUI authorized more recently.
        try:
            persisted = load_settings()
            for key in (
                "ebay_refresh_token",
                "ebay_client_id",
                "ebay_client_secret",
                "access_token",
                "access_token_expires_at",
                "refresh_token_expires_at",
            ):
                if persisted.get(key):
                    self.s[key] = persisted.get(key)
        except Exception:
            pass

        refresh_token = str(
            self.s.get("ebay_refresh_token", "") or ""
        ).strip()
        client_id = str(
            self.s.get("ebay_client_id", "") or ""
        ).strip()
        client_secret = str(
            self.s.get("ebay_client_secret", "") or ""
        ).strip()

        if not refresh_token or not client_id or not client_secret:
            self.log(
                "Automatic eBay token refresh unavailable: refresh token, "
                "Client ID, or Client Secret is missing."
            )
            return False

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "scope": " ".join([
                "https://api.ebay.com/oauth/api_scope",
                "https://api.ebay.com/oauth/api_scope/sell.inventory",
                "https://api.ebay.com/oauth/api_scope/sell.account",
                "https://api.ebay.com/oauth/api_scope/sell.fulfillment",
                "https://api.ebay.com/oauth/api_scope/sell.finances",
            ]),
        }
        body = parse.urlencode(payload).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            self.log(
                f"Automatic eBay token refresh failed ({exc.code}): {detail[:2000]}"
            )
            return False
        except Exception as exc:
            self.log(f"Automatic eBay token refresh failed: {exc}")
            return False

        new_token = str(data.get("access_token", "") or "").strip()
        expires_in = int(data.get("expires_in", 0) or 0)
        if not new_token:
            self.log(
                "Automatic eBay token refresh failed: eBay returned no access_token."
            )
            return False

        self.s["access_token"] = new_token
        self.s["access_token_expires_at"] = (
            int(time.time()) + expires_in if expires_in else 0
        )

        # eBay normally does not rotate the refresh token here, but preserve a
        # replacement if it ever does.
        rotated_refresh = str(data.get("refresh_token", "") or "").strip()
        if rotated_refresh:
            self.s["ebay_refresh_token"] = rotated_refresh

        try:
            current = load_settings()
            current.update({
                "access_token": self.s["access_token"],
                "access_token_expires_at": self.s["access_token_expires_at"],
                "ebay_refresh_token": self.s.get("ebay_refresh_token", ""),
            })
            save_settings(current)
        except Exception as exc:
            self.log(
                f"WARNING: new eBay access token worked but could not be "
                f"persisted locally: {exc}"
            )

        self.log(
            "eBay access token refreshed automatically"
            + (
                f" (valid for about {expires_in / 3600:.1f} hours)."
                if expires_in else "."
            )
        )
        return True

    def _ensure_fresh_access_token(self):
        """
        Refresh proactively before expiry instead of waiting for an API 401/403.
        A five-minute cushion avoids expiration during a multi-call workflow.
        """
        # Pull in a refresh performed by another client instance.
        try:
            persisted = load_settings()
            persisted_token = str(
                persisted.get("access_token", "") or ""
            ).strip()
            persisted_expiry = int(
                persisted.get("access_token_expires_at", 0) or 0
            )
            if persisted_token:
                local_expiry = int(
                    self.s.get("access_token_expires_at", 0) or 0
                )
                if (
                    persisted_token != str(
                        self.s.get("access_token", "") or ""
                    ).strip()
                    or persisted_expiry > local_expiry
                ):
                    self.s["access_token"] = persisted_token
                    self.s["access_token_expires_at"] = persisted_expiry
            if persisted.get("ebay_refresh_token"):
                self.s["ebay_refresh_token"] = persisted.get(
                    "ebay_refresh_token"
                )
        except Exception:
            pass

        token = str(self.s.get("access_token", "") or "").strip()
        expiry = int(self.s.get("access_token_expires_at", 0) or 0)
        refresh = str(
            self.s.get("ebay_refresh_token", "") or ""
        ).strip()

        now = int(time.time())
        needs_refresh = (
            not token
            or (expiry > 0 and now >= expiry - 300)
        )

        if needs_refresh and refresh:
            self.log(
                "eBay access token is missing/near expiry; refreshing automatically…"
            )
            if self._refresh_user_access_token():
                return True

        return bool(str(self.s.get("access_token", "") or "").strip())


    def _call_once(self, method, url, body=None, content_type="application/json", extra_headers=None):
        self._check_cancel()
        self._refresh_attempted = False
        self._ensure_fresh_access_token()
        token = str(self.s.get("access_token", "") or "").strip()
        if not token:
            raise RuntimeError(
                "No usable eBay access token is available. "
                "If automatic refresh is configured, check the log for the "
                "specific refresh-token error before reauthorizing."
            )

        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Language": "en-US",
        }
        if content_type:
            headers["Content-Type"] = content_type
        if extra_headers:
            headers.update(extra_headers)

        req = request.Request(url, data=body, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=45) as resp:
                raw = resp.read()
                text = raw.decode("utf-8", "replace") if raw else ""
                data = json.loads(text) if text.strip() else {}
                return resp.status, dict(resp.headers), data
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")

            # If a seller access token expired, transparently refresh it once
            # when a refresh token has been configured.
            if exc.code in (401, 403) and not self._refresh_attempted:
                self._refresh_attempted = True
                if self._refresh_user_access_token():
                    token = self.s.get("access_token", "").strip()
                    retry_headers = dict(headers)
                    retry_headers["Authorization"] = f"Bearer {token}"
                    retry_req = request.Request(
                        url, data=body, headers=retry_headers, method=method
                    )
                    try:
                        with request.urlopen(retry_req, timeout=45) as resp:
                            retry_raw = resp.read()
                            retry_text = retry_raw.decode("utf-8", "replace") if retry_raw else ""
                            retry_data = json.loads(retry_text) if retry_text.strip() else {}
                            return resp.status, dict(resp.headers), retry_data
                    except error.HTTPError as retry_exc:
                        raw = retry_exc.read().decode("utf-8", "replace")
                        exc = retry_exc

            try:
                details = json.loads(raw)
                pretty = json.dumps(details, indent=2)
            except Exception:
                if "<html" in raw.lower() or "<!doctype html" in raw.lower():
                    pretty = (
                        "eBay returned a temporary HTML server error page. "
                        "This is usually an eBay-side failure, not a bad listing field."
                    )
                else:
                    pretty = raw
            raise RuntimeError(f"eBay API error {exc.code}:\\n{pretty}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Network error: {exc}") from exc

    def _call(self, method, url, body=None, content_type="application/json", extra_headers=None):
        """Retry temporary eBay 502/503/504 failures before surfacing an error."""
        attempts = ((1, 0), (2, 2), (3, 5), (4, 10))
        self.log(f"eBay request: {method} {url}")
        last_error = None

        for attempt, delay in attempts:
            self._check_cancel()
            if delay:
                self.log(
                    f"eBay temporary API/server error. Retrying in {delay} seconds "
                    f"(attempt {attempt} of 4)..."
                )
                time.sleep(delay)

            try:
                return self._call_once(method, url, body, content_type, extra_headers)
            except RuntimeError as exc:
                last_error = exc
                msg = str(exc)
                transient = any(
                    token in msg
                    for token in (
                        "eBay API error 500:",
                        "eBay API error 502:",
                        "eBay API error 503:",
                        "eBay API error 504:",
                        '"errorId": 25001',
                        "Core Inventory Service internal error",
                        "A system error has occurred.",
                        '"errorId": 20500',
                        '"domain": "API_ACCOUNT"',
                        '"message": "System error."',
                    )
                )
                if not transient or attempt == 4:
                    if (
                        '"errorId": 20500' in msg
                        or '"domain": "API_ACCOUNT"' in msg
                    ):
                        raise RuntimeError(
                            "eBay's Account API returned system error 20500 after "
                            "multiple retries.\n\n"
                            "This is normally an eBay-side temporary failure while "
                            "loading business policies, not a problem with your listing "
                            "or saved policy IDs. Your existing settings were left unchanged.\n\n"
                            "Try Refresh eBay Details again in a few minutes."
                        ) from exc
                    raise

        raise last_error


    def _get_application_token(self):
        """Mint an eBay Application access token for public Buy/Browse APIs."""
        self._check_cancel()
        client_id = self.s.get("ebay_client_id", "").strip()
        client_secret = self.s.get("ebay_client_secret", "").strip()
        if not client_id or not client_secret:
            raise RuntimeError(
                "Price research needs your eBay App ID (Client ID) and Cert ID "
                "(Client Secret) in eBay Settings."
            )

        credentials = base64.b64encode(
            f"{client_id}:{client_secret}".encode("utf-8")
        ).decode("ascii")

        endpoint = self.api_base + "/identity/v1/oauth2/token"
        body = parse.urlencode({
            "grant_type": "client_credentials",
            "scope": "https://api.ebay.com/oauth/api_scope",
        }).encode("utf-8")

        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": "Basic " + credentials,
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(
                f"eBay application-token error {exc.code}:\n{raw}"
            ) from exc
        except error.URLError as exc:
            raise RuntimeError(f"eBay application-token network error: {exc}") from exc

        token = data.get("access_token")
        if not token:
            raise RuntimeError("eBay did not return an Application access token.")
        return token

    def _buy_call(self, url):
        """GET an eBay Buy API endpoint using an Application access token."""
        self._check_cancel()
        token = self._get_application_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "X-EBAY-C-MARKETPLACE-ID": self.s.get("marketplace_id", "EBAY_US"),
        }
        req = request.Request(url, headers=headers, method="GET")
        try:
            with request.urlopen(req, timeout=45) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError(f"eBay Browse API error {exc.code}:\n{raw}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"eBay Browse API network error: {exc}") from exc

    @staticmethod
    def _percentile(values, p):
        values = sorted(values)
        if not values:
            return None
        if len(values) == 1:
            return values[0]
        pos = (len(values) - 1) * p
        lo = int(math.floor(pos))
        hi = int(math.ceil(pos))
        if lo == hi:
            return values[lo]
        frac = pos - lo
        return values[lo] * (1 - frac) + values[hi] * frac

    def research_price(self, query, category_id=""):
        """
        Research current active Buy It Now listings on eBay.

        Recommendation goal: competitive, but not necessarily lowest.
        Uses a lower-middle market position after basic outlier rejection.
        """
        self._check_cancel()
        query = (query or "").strip()
        if not query:
            raise RuntimeError("There is not enough item information for price research.")

        params = {
            "q": query,
            "limit": "50",
            "filter": "buyingOptions:{FIXED_PRICE}",
        }
        if str(category_id or "").strip():
            params["category_ids"] = str(category_id).strip()

        url = (
            self.api_base
            + "/buy/browse/v1/item_summary/search?"
            + parse.urlencode(params)
        )
        self.log(f"Researching active eBay prices for: {query}")
        response = self._buy_call(url)
        items = response.get("itemSummaries", []) or []

        comps = []
        for item in items:
            price = (item.get("price", {}) or {})
            try:
                value = float(price.get("value"))
            except (TypeError, ValueError):
                continue
            currency = str(price.get("currency", "") or "")
            if value <= 0:
                continue
            if self.s.get("currency", "USD") and currency and currency != self.s.get("currency", "USD"):
                continue
            comps.append({
                "title": str(item.get("title", "") or ""),
                "price": value,
                "currency": currency or self.s.get("currency", "USD"),
                "url": str(item.get("itemWebUrl", "") or ""),
                "condition": str(item.get("condition", "") or ""),
            })

        if not comps:
            raise RuntimeError("eBay returned no usable active Buy It Now price matches.")

        values = sorted(c["price"] for c in comps)
        median_all = statistics.median(values)

        # Conservative outlier filter. Rare surplus parts can legitimately have
        # wide spreads, so don't make this too aggressive.
        filtered = [
            v for v in values
            if v >= median_all * 0.35 and v <= median_all * 3.0
        ]
        if len(filtered) < 3:
            filtered = values[:]

        low = min(filtered)
        median = statistics.median(filtered)
        high = max(filtered)

        if len(filtered) >= 5:
            raw_target = self._percentile(filtered, 0.40)
        elif len(filtered) >= 3:
            raw_target = statistics.median(filtered)
        else:
            raw_target = sum(filtered) / len(filtered)

        # Retail-style rounding without intentionally becoming the lowest offer.
        if raw_target >= 10:
            suggested = max(0.99, round(raw_target) - 0.01)
        else:
            suggested = max(0.99, round(raw_target, 2))

        # Never deliberately recommend below the observed low.
        if suggested < low:
            suggested = low

        comps_sorted = sorted(comps, key=lambda x: x["price"])
        return {
            "query": query,
            "count": len(comps),
            "used_count": len(filtered),
            "low": low,
            "median": median,
            "high": high,
            "suggested": suggested,
            "comparables": comps_sorted[:10],
        }

    def publish_offer(self, offer_id):
        """Explicitly publish one previously-created unpublished offer."""
        self._check_cancel()
        offer_id = str(offer_id or "").strip()
        if not offer_id:
            raise RuntimeError("No unpublished Offer ID is available to publish.")
        self.log(f"Publishing eBay offer {offer_id}...")
        try:
            _, _, response = self._call(
                "POST",
                self.api_base
                + "/sell/inventory/v1/offer/"
                + parse.quote(offer_id, safe="")
                + "/publish",
                b"",
                "application/json",
            )
            listing_id = str(response.get("listingId", "") or "")
            if not listing_id:
                raise RuntimeError(
                    "eBay accepted the publish request but did not return a listingId."
                )
            return listing_id
        except Exception as exc:
            # eBay can answer a repeated publish request with 25002 / "Offer
            # entity already exists" even though the offer is already live.  Make
            # publish idempotent: verify the offer and return its live listing ID
            # instead of treating an already-published listing as a failure.
            text = str(exc)
            if "25002" in text or "Offer entity already exists" in text:
                try:
                    existing = self.get_offer(offer_id)
                    listing = existing.get("listing", {}) or {}
                    listing_id = str(listing.get("listingId", "") or "")
                    status = str(existing.get("status", "") or "").upper()
                    if listing_id and status == "PUBLISHED":
                        self.log(
                            f"Offer {offer_id} was already published as eBay listing {listing_id}; treating publish as successful."
                        )
                        return listing_id
                except Exception:
                    pass
            raise

    def get_inventory_locations(self):
        """Retrieve all Inventory API locations for the seller."""
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/location?limit=100&offset=0"
        self.log("Loading eBay inventory locations...")
        _, _, response = self._call("GET", url, None, None)
        return response.get("locations", []) or []

    def create_warehouse_location(self, merchant_key, name, postal_code, country="US"):
        """Create a normal WAREHOUSE inventory location."""
        self._check_cancel()
        merchant_key = str(merchant_key or "").strip()
        name = str(name or "").strip()
        postal_code = str(postal_code or "").strip()
        country = str(country or "US").strip().upper()

        if not merchant_key:
            raise RuntimeError("Merchant Location Key is required.")
        if len(merchant_key) > 50:
            raise RuntimeError("Merchant Location Key cannot exceed 50 characters.")
        if not name:
            raise RuntimeError("Location name is required.")
        if not postal_code or not country:
            raise RuntimeError("Postal code and country are required.")

        payload = {
            "location": {
                "address": {
                    "postalCode": postal_code,
                    "country": country,
                }
            },
            "name": name,
            "merchantLocationStatus": "ENABLED",
            "locationTypes": ["WAREHOUSE"],
        }

        url = (
            self.api_base
            + "/sell/inventory/v1/location/"
            + parse.quote(merchant_key, safe="")
        )
        self.log(f"Creating eBay warehouse location '{merchant_key}'...")
        self._call(
            "POST",
            url,
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )
        return merchant_key

    def get_business_policies(self):
        """Return the seller's fulfillment, payment, and return policies."""
        self._check_cancel()
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        endpoints = {
            "fulfillment": ("fulfillment_policy", "fulfillmentPolicies", "fulfillmentPolicyId"),
            "payment": ("payment_policy", "paymentPolicies", "paymentPolicyId"),
            "return": ("return_policy", "returnPolicies", "returnPolicyId"),
        }
        result = {}
        for kind, (endpoint, list_key, id_key) in endpoints.items():
            url = (
                self.api_base
                + f"/sell/account/v1/{endpoint}?marketplace_id="
                + parse.quote(marketplace, safe="")
            )
            self.log(f"Loading eBay {kind} policies...")
            _, _, response = self._call("GET", url, None, None)
            policies = response.get(list_key, []) or []
            # Be tolerant of response-wrapper changes.
            if not policies:
                for value in response.values():
                    if isinstance(value, list) and value and isinstance(value[0], dict):
                        if id_key in value[0]:
                            policies = value
                            break
            result[kind] = [
                {
                    "id": str(p.get(id_key, "") or ""),
                    "name": str(p.get("name", "") or ""),
                    "raw": p,
                }
                for p in policies
                if p.get(id_key)
            ]
        return result

    def check_inventory_api(self):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/getVersion"
        self.log("DRAFT PREFLIGHT: Checking eBay Inventory API access...")
        try:
            _, _, response = self._call("GET", url, None, None)
        except Exception as exc:
            msg = str(exc)
            if "404" in msg and ("2002" in msg or "Resource not found" in msg or "Resource not resolved" in msg):
                raise RuntimeError(
                    "eBay Inventory API preflight returned HTTP 404 / error 2002.\n\n"
                    "eBay could not resolve the Inventory API resource. Check Production/Sandbox "
                    "and confirm OAuth was authorized with sell.inventory."
                ) from exc
            if "401" in msg or "1001" in msg:
                raise RuntimeError(
                    "eBay rejected the access token during Inventory API preflight. "
                    "Refresh or re-authorize OAuth."
                ) from exc
            if "403" in msg or "1100" in msg:
                raise RuntimeError(
                    "eBay denied Inventory API access. Re-authorize OAuth with sell.inventory."
                ) from exc
            raise
        self.log("DRAFT PREFLIGHT COMPLETE: Inventory API responded successfully.")
        return response

    def find_eligible_offer_items(self, limit=200):
        """Return listing IDs currently eligible for seller-initiated offers."""
        self._check_cancel()
        marketplace = str(
            self.s.get("marketplace_id", "EBAY_US") or "EBAY_US"
        ).strip()
        limit = max(1, min(200, int(limit or 200)))
        offset = 0
        ids = []

        while True:
            url = (
                self.api_base
                + "/sell/negotiation/v1/find_eligible_items"
                + f"?limit={limit}&offset={offset}"
            )
            _, _, data = self._call(
                "GET",
                url,
                None,
                None,
                extra_headers={
                    "X-EBAY-C-MARKETPLACE-ID": marketplace,
                },
            )
            items = data.get("eligibleItems", []) or []
            for row in items:
                listing_id = str(
                    (row or {}).get("listingId", "") or ""
                ).strip()
                if listing_id and listing_id not in ids:
                    ids.append(listing_id)

            try:
                total = int(data.get("total", len(ids)) or len(ids))
            except Exception:
                total = len(ids)
            got = len(items)
            offset += got
            if not got or offset >= total:
                break

        return ids

    def send_offer_to_interested_buyers(
        self,
        listing_id,
        *,
        discount_percentage=None,
        price=None,
        quantity=1,
        message="",
        allow_counter_offer=False,
    ):
        """Send an offer to all buyers eBay currently considers eligible."""
        self._check_cancel()
        listing_id = str(listing_id or "").strip()
        if not listing_id:
            raise ValueError("A listing ID is required.")

        offered = {
            "listingId": listing_id,
            "quantity": max(1, int(quantity or 1)),
        }
        if price is not None:
            offered["price"] = {
                "value": f"{float(price):.2f}",
                "currency": str(
                    self.s.get("currency", "USD") or "USD"
                ).strip(),
            }
        elif discount_percentage is not None:
            offered["discountPercentage"] = (
                f"{float(discount_percentage):g}"
            )
        else:
            raise ValueError(
                "Provide either an offer price or discount percentage."
            )

        # Seller-initiated offers through this Negotiation endpoint do not
        # permit allowCounterOffer=true. eBay returns API_NEGOTIATION 150009.
        body_obj = {
            "allowCounterOffer": False,
            "message": str(message or "").strip(),
            "offerDuration": {"unit": "DAY", "value": 4},
            "offeredItems": [offered],
        }
        body = json.dumps(body_obj).encode("utf-8")
        marketplace = str(
            self.s.get("marketplace_id", "EBAY_US") or "EBAY_US"
        ).strip()
        url = (
            self.api_base
            + "/sell/negotiation/v1/send_offer_to_interested_buyers"
        )
        _, _, response = self._call(
            "POST",
            url,
            body,
            "application/json",
            extra_headers={
                "X-EBAY-C-MARKETPLACE-ID": marketplace,
            },
        )
        return response

    def get_all_active_listings(self):
        """
        Retrieve the seller's complete current Active List with Trading API
        GetMyeBaySelling. This includes listings created in Seller Hub/eBay UI,
        not only listings created through Inventory API.
        """
        self._check_cancel()
        self._refresh_attempted = False
        self._ensure_fresh_access_token()
        token = str(self.s.get("access_token", "") or "").strip()
        if not token:
            raise RuntimeError("No usable eBay access token is available.")

        endpoint = (
            "https://api.sandbox.ebay.com/ws/api.dll"
            if self.s.get("api_environment") == "sandbox"
            else "https://api.ebay.com/ws/api.dll"
        )

        page = 1
        per_page = 200
        results = []

        while True:
            self._check_cancel()
            xml_text = (
                '<?xml version="1.0" encoding="utf-8"?>'
                '<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">'
                '<DetailLevel>ReturnAll</DetailLevel>'
                '<ActiveList><Include>true</Include><Pagination>'
                f'<EntriesPerPage>{per_page}</EntriesPerPage>'
                f'<PageNumber>{page}</PageNumber>'
                '</Pagination></ActiveList>'
                '</GetMyeBaySellingRequest>'
            )
            body = xml_text.encode("utf-8")

            def make_request(access_token):
                return request.Request(
                    endpoint,
                    data=body,
                    headers={
                        "X-EBAY-API-CALL-NAME": "GetMyeBaySelling",
                        "X-EBAY-API-COMPATIBILITY-LEVEL": "1477",
                        "X-EBAY-API-SITEID": "0",
                        "X-EBAY-API-IAF-TOKEN": access_token,
                        "Content-Type": "text/xml",
                        "Accept": "text/xml",
                    },
                    method="POST",
                )

            try:
                with request.urlopen(make_request(token), timeout=60) as resp:
                    raw = resp.read().decode("utf-8", "replace")
            except error.HTTPError as exc:
                if exc.code in (401, 403) and not self._refresh_attempted:
                    self._refresh_attempted = True
                    if self._refresh_user_access_token():
                        token = self.s.get("access_token", "").strip()
                        with request.urlopen(make_request(token), timeout=60) as resp:
                            raw = resp.read().decode("utf-8", "replace")
                    else:
                        raise
                else:
                    detail = exc.read().decode("utf-8", "replace")
                    raise RuntimeError(
                        f"eBay Trading API error {exc.code} while loading current listings:\n"
                        + detail[:2000]
                    ) from exc

            root = ET.fromstring(raw)
            ns = {"e": "urn:ebay:apis:eBLBaseComponents"}
            ack = (root.findtext("e:Ack", default="", namespaces=ns) or "").upper()
            if ack not in ("SUCCESS", "WARNING"):
                errors = []
                for er in root.findall("e:Errors", ns):
                    code = er.findtext("e:ErrorCode", default="", namespaces=ns)
                    msg = (
                        er.findtext("e:LongMessage", default="", namespaces=ns)
                        or er.findtext("e:ShortMessage", default="", namespaces=ns)
                    )
                    errors.append(f"{code}: {msg}".strip(": "))
                raise RuntimeError(
                    "eBay could not load current active listings.\n\n" + "\n".join(errors)
                )

            items = root.findall(".//e:ActiveList/e:ItemArray/e:Item", ns)
            for item in items:
                item_id = (item.findtext("e:ItemID", default="", namespaces=ns) or "").strip()
                if not item_id:
                    continue
                title = (item.findtext("e:Title", default="", namespaces=ns) or "").strip()
                sku = (item.findtext("e:SKU", default="", namespaces=ns) or "").strip()
                qty_text = (
                    item.findtext("e:QuantityAvailable", default="", namespaces=ns)
                    or item.findtext("e:Quantity", default="1", namespaces=ns)
                    or "1"
                )
                try:
                    qty = int(float(qty_text))
                except Exception:
                    qty = 1
                start_time = (
                    item.findtext("e:ListingDetails/e:StartTime", default="", namespaces=ns)
                    or ""
                ).strip()
                price_text = (
                    item.findtext("e:SellingStatus/e:CurrentPrice", default="", namespaces=ns)
                    or ""
                ).strip()
                category_id = (
                    item.findtext("e:PrimaryCategory/e:CategoryID", default="", namespaces=ns)
                    or ""
                ).strip()
                picture_urls = item.findall(
                    "e:PictureDetails/e:PictureURL", ns
                )
                gallery_url = (
                    item.findtext(
                        "e:PictureDetails/e:GalleryURL",
                        default="",
                        namespaces=ns,
                    )
                    or ""
                ).strip()
                primary_picture_url = ""
                if picture_urls:
                    primary_picture_url = str(
                        picture_urls[0].text or ""
                    ).strip()
                if not primary_picture_url:
                    primary_picture_url = gallery_url
                picture_count = (
                    len(picture_urls)
                    if picture_urls
                    else ("1+" if gallery_url else "")
                )
                view_url = (
                    item.findtext("e:ListingDetails/e:ViewItemURL", default="", namespaces=ns)
                    or ""
                ).strip()
                try:
                    current_price = float(price_text) if price_text else 0.0
                except Exception:
                    current_price = 0.0
                results.append({
                    "item_number": item_id,
                    "title": title,
                    "sku": sku,
                    "quantity_available": qty,
                    "start_time": start_time,
                    "price": current_price,
                    "category_id": category_id,
                    "picture_count": picture_count,
                    "primary_picture_url": primary_picture_url,
                    "view_url": view_url,
                })

            total_pages_text = root.findtext(
                ".//e:ActiveList/e:PaginationResult/e:TotalNumberOfPages",
                default="1",
                namespaces=ns,
            )
            try:
                total_pages = max(1, int(total_pages_text or 1))
            except Exception:
                total_pages = 1

            if page >= total_pages:
                break
            page += 1

        return results



    def _trading_xml_call(self, call_name, xml_text, compatibility="1477"):
        self._check_cancel()
        self._refresh_attempted = False
        self._ensure_fresh_access_token()
        token = str(self.s.get("access_token", "") or "").strip()
        if not token:
            raise RuntimeError(
                "No usable eBay access token is available. "
                "Automatic refresh did not produce a token."
            )
        endpoint = (
            "https://api.sandbox.ebay.com/ws/api.dll"
            if self.s.get("api_environment") == "sandbox"
            else "https://api.ebay.com/ws/api.dll"
        )
        body = xml_text.encode("utf-8")
        def make_request(access_token):
            return request.Request(
                endpoint,
                data=body,
                headers={
                    "X-EBAY-API-CALL-NAME": call_name,
                    "X-EBAY-API-COMPATIBILITY-LEVEL": compatibility,
                    "X-EBAY-API-SITEID": "0",
                    "X-EBAY-API-IAF-TOKEN": access_token,
                    "Content-Type": "text/xml",
                    "Accept": "text/xml",
                },
                method="POST",
            )
        try:
            with request.urlopen(make_request(token), timeout=60) as resp:
                raw = resp.read().decode("utf-8", "replace")
        except error.HTTPError as exc:
            if exc.code in (401, 403) and not self._refresh_attempted:
                self._refresh_attempted = True
                if self._refresh_user_access_token():
                    token = str(self.s.get("access_token", "") or "").strip()
                    with request.urlopen(make_request(token), timeout=60) as resp:
                        raw = resp.read().decode("utf-8", "replace")
                else:
                    raise
            else:
                detail = exc.read().decode("utf-8", "replace")
                raise RuntimeError(
                    f"eBay Trading API error {exc.code} for {call_name}:\n{detail[:2500]}"
                ) from exc
        root = ET.fromstring(raw)
        ns = {"e": "urn:ebay:apis:eBLBaseComponents"}
        ack = (root.findtext("e:Ack", default="", namespaces=ns) or "").upper()

        if ack not in ("SUCCESS", "WARNING"):
            token_error_codes = {
                "931", "932", "16110", "17470",
            }
            returned_codes = {
                str(er.findtext("e:ErrorCode", default="", namespaces=ns) or "").strip()
                for er in root.findall("e:Errors", ns)
            }
            if (
                returned_codes & token_error_codes
                and not self._refresh_attempted
            ):
                self._refresh_attempted = True
                if self._refresh_user_access_token():
                    token = str(
                        self.s.get("access_token", "") or ""
                    ).strip()
                    with request.urlopen(
                        make_request(token), timeout=60
                    ) as resp:
                        raw = resp.read().decode("utf-8", "replace")
                    root = ET.fromstring(raw)
                    ack = (
                        root.findtext(
                            "e:Ack", default="", namespaces=ns
                        )
                        or ""
                    ).upper()

        if ack not in ("SUCCESS", "WARNING"):
            errors = []
            for er in root.findall("e:Errors", ns):
                code = er.findtext("e:ErrorCode", default="", namespaces=ns)
                msg = (
                    er.findtext("e:LongMessage", default="", namespaces=ns)
                    or er.findtext("e:ShortMessage", default="", namespaces=ns)
                )
                errors.append(f"{code}: {msg}".strip(": "))
            raise RuntimeError(f"eBay {call_name} failed.\n\n" + "\n".join(errors))
        return root, ns

    def get_member_messages(self, days=30, max_messages=200):
        """
        Retrieve buyer/seller item conversations with GetMemberMessages.

        GetMyMessages is still used for the inbox, eBay alerts, MessageIDs,
        read/unread state and deletion. GetMemberMessages supplies the complete
        buyer question body (up to eBay's current 4,000-character field limit)
        and seller response text when available.
        """
        days = max(1, min(int(days or 30), 365))
        max_messages = max(1, min(int(max_messages or 200), 1000))
        end_dt = datetime.now(timezone.utc)
        start_dt = end_dt - timedelta(days=days)

        page = 1
        results = []
        while len(results) < max_messages:
            entries = min(200, max_messages - len(results))
            # eBay documents accepted EntriesPerPage values as 25/50/100/200.
            if entries < 25:
                entries = 25
            elif entries < 50:
                entries = 25
            elif entries < 100:
                entries = 50
            elif entries < 200:
                entries = 100
            else:
                entries = 200

            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<GetMemberMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <MailMessageType>All</MailMessageType>
  <StartCreationTime>{start_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")}</StartCreationTime>
  <EndCreationTime>{end_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")}</EndCreationTime>
  <Pagination>
    <EntriesPerPage>{entries}</EntriesPerPage>
    <PageNumber>{page}</PageNumber>
  </Pagination>
</GetMemberMessagesRequest>"""
            root, ns = self._trading_xml_call(
                "GetMemberMessages", xml_text, compatibility="1477"
            )

            exchanges = root.findall(
                "e:MemberMessage/e:MemberMessageExchange", ns
            )
            if not exchanges:
                break

            for exch in exchanges:
                def tx(path):
                    return (
                        exch.findtext(path, default="", namespaces=ns) or ""
                    ).strip()

                responses = [
                    (node.text or "").strip()
                    for node in exch.findall("e:Response", ns)
                    if (node.text or "").strip()
                ]
                results.append({
                    "member_message_id": tx("e:Question/e:MessageID"),
                    "created": tx("e:CreationDate"),
                    "last_modified": tx("e:LastModifiedDate"),
                    "status": tx("e:MessageStatus"),
                    "item_number": tx("e:Item/e:ItemID"),
                    "item_title": tx("e:Item/e:Title"),
                    "sender": tx("e:Question/e:SenderID"),
                    "subject": tx("e:Question/e:Subject"),
                    "question_type": tx("e:Question/e:QuestionType") or "General",
                    "body": tx("e:Question/e:Body"),
                    "responses": responses,
                })
                if len(results) >= max_messages:
                    break

            pages_text = root.findtext(
                "e:PaginationResult/e:TotalNumberOfPages",
                default="1",
                namespaces=ns,
            ) or "1"
            try:
                pages = int(pages_text)
            except Exception:
                pages = 1
            if page >= pages or len(results) >= max_messages:
                break
            page += 1

        results.sort(key=lambda x: str(x.get("created", "") or ""))
        return results

    def enrich_my_messages_with_member_messages(self, my_messages, member_messages):
        """
        Add complete GetMemberMessages bodies/responses to matching My Messages.

        Matching uses item + sender first, then nearest timestamp. GetMyMessages
        remains authoritative for inbox MessageID/read/delete state.
        """
        my_messages = [dict(m) for m in (my_messages or []) if isinstance(m, dict)]
        members = [dict(m) for m in (member_messages or []) if isinstance(m, dict)]
        if not my_messages or not members:
            return my_messages

        def parse_dt(value):
            try:
                return datetime.fromisoformat(
                    str(value or "").replace("Z", "+00:00")
                )
            except Exception:
                return None

        # Pre-index by exact item/sender, with item-only fallback for privacy-ID
        # differences that eBay can return between message APIs.
        exact = {}
        by_item = {}
        for member in members:
            item = str(member.get("item_number", "") or "").strip()
            sender = str(member.get("sender", "") or "").strip().casefold()
            if item:
                by_item.setdefault(item, []).append(member)
                exact.setdefault((item, sender), []).append(member)

        used_member_ids = set()
        for msg in my_messages:
            if str(msg.get("sender", "") or "").strip().casefold() == "ebay":
                continue

            item = str(msg.get("item_number", "") or "").strip()
            sender = str(msg.get("sender", "") or "").strip().casefold()
            if not item:
                continue

            candidates = list(exact.get((item, sender), []))
            if not candidates:
                candidates = list(by_item.get(item, []))
            if not candidates:
                continue

            msg_dt = parse_dt(msg.get("received"))

            def score(member):
                member_id = str(member.get("member_message_id", "") or "")
                member_dt = parse_dt(member.get("created"))
                seconds = 10**12
                if msg_dt is not None and member_dt is not None:
                    seconds = abs((msg_dt - member_dt).total_seconds())

                sender_penalty = 0
                member_sender = str(member.get("sender", "") or "").strip().casefold()
                if sender and member_sender and sender != member_sender:
                    sender_penalty = 10**8

                used_penalty = 10**9 if member_id and member_id in used_member_ids else 0
                return sender_penalty + used_penalty + seconds

            best = min(candidates, key=score)
            best_id = str(best.get("member_message_id", "") or "")
            if best_id:
                used_member_ids.add(best_id)

            # Do not force a clearly unrelated timestamp match. Date differences of
            # a few minutes are normal; multiple days normally means it is another
            # exchange on the same listing.
            if msg_dt is not None:
                best_dt = parse_dt(best.get("created"))
                if best_dt is not None:
                    if abs((msg_dt - best_dt).total_seconds()) > (36 * 3600):
                        continue

            msg["member_message_id"] = best_id
            msg["member_body"] = str(best.get("body", "") or "")
            msg["member_responses"] = list(best.get("responses", []) or [])
            msg["member_created"] = str(best.get("created", "") or "")
            msg["member_status"] = str(best.get("status", "") or "")
            if not msg.get("question_type"):
                msg["question_type"] = best.get("question_type") or "General"
            if not msg.get("item_title") and best.get("item_title"):
                msg["item_title"] = best.get("item_title")

        return my_messages

    def get_my_messages(self, days=30, max_messages=150):
        """
        Retrieve recent My Messages in two stages.

        eBay allows date filtering when listing message headers, but ReturnMessages
        with body content requires explicit MessageIDs. Fetch headers first, then
        request full bodies in batches of at most 10 IDs.
        """
        days = max(1, min(int(days or 30), 365))
        max_messages = max(1, min(int(max_messages or 150), 500))
        end_dt = datetime.now(timezone.utc)
        start_dt = end_dt - timedelta(days=days)

        # Stage 1: collect message headers/IDs for the date range.
        header_ids = []
        header_cache = {}
        page = 1
        while len(header_ids) < max_messages:
            per_page = min(50, max_messages - len(header_ids))
            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<GetMyMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <DetailLevel>ReturnHeaders</DetailLevel>
  <StartTime>{start_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")}</StartTime>
  <EndTime>{end_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")}</EndTime>
  <Pagination><EntriesPerPage>{per_page}</EntriesPerPage><PageNumber>{page}</PageNumber></Pagination>
</GetMyMessagesRequest>"""
            root, ns = self._trading_xml_call("GetMyMessages", xml_text)
            msgs = root.findall("e:Messages/e:Message", ns)
            if not msgs:
                break

            for msg in msgs:
                def tx(path):
                    return (msg.findtext(path, default="", namespaces=ns) or "").strip()
                mid = tx("e:MessageID")
                if not mid or mid in header_cache:
                    continue
                header_cache[mid] = {
                    "message_id": mid,
                    "received": tx("e:ReceiveDate"),
                    "sender": tx("e:Sender"),
                    "subject": tx("e:Subject"),
                    "text": "",
                    "content": tx("e:Content"),
                    "html_text": tx("e:Text"),
                    "item_number": tx("e:ItemID"),
                    "item_title": tx("e:ItemTitle"),
                    "read": tx("e:Read").lower() == "true",
                    "replied": tx("e:Replied").lower() == "true",
                    "question_type": tx("e:QuestionType") or "General",
                }
                header_ids.append(mid)
                if len(header_ids) >= max_messages:
                    break

            pages = root.findtext(
                "e:PaginationResult/e:TotalNumberOfPages",
                default="1",
                namespaces=ns,
            ) or "1"
            try:
                pages = int(pages)
            except Exception:
                pages = 1
            if page >= pages:
                break
            page += 1

        # Stage 2: fetch full body/details in eBay's max-10 MessageID batches.
        results = []
        for i in range(0, len(header_ids), 10):
            batch = header_ids[i:i + 10]
            ids_xml = "".join(
                f"<MessageID>{html.escape(str(mid))}</MessageID>" for mid in batch
            )
            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<GetMyMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <DetailLevel>ReturnMessages</DetailLevel>
  <MessageIDs>{ids_xml}</MessageIDs>
</GetMyMessagesRequest>"""
            root, ns = self._trading_xml_call("GetMyMessages", xml_text)
            body_msgs = root.findall("e:Messages/e:Message", ns)

            seen = set()
            for msg in body_msgs:
                def tx(path):
                    return (msg.findtext(path, default="", namespaces=ns) or "").strip()
                mid = tx("e:MessageID")
                if not mid:
                    continue
                seen.add(mid)
                base = dict(header_cache.get(mid, {}))
                base.update({
                    "message_id": mid,
                    "received": tx("e:ReceiveDate") or base.get("received", ""),
                    "sender": tx("e:Sender") or base.get("sender", ""),
                    "subject": tx("e:Subject") or base.get("subject", ""),
                    "text": tx("e:Text") or tx("e:Content") or base.get("text", ""),
                    "content": tx("e:Content") or base.get("content", ""),
                    "html_text": tx("e:Text") or base.get("html_text", ""),
                    "item_number": tx("e:ItemID") or base.get("item_number", ""),
                    "item_title": tx("e:ItemTitle") or base.get("item_title", ""),
                    "read": (
                        tx("e:Read").lower() == "true"
                        if tx("e:Read")
                        else base.get("read", False)
                    ),
                    "replied": (
                        tx("e:Replied").lower() == "true"
                        if tx("e:Replied")
                        else base.get("replied", False)
                    ),
                    "question_type": tx("e:QuestionType") or base.get("question_type", "General"),
                })
                results.append(base)

            # Keep a header-only fallback if eBay omitted any requested full message.
            for mid in batch:
                if mid not in seen and mid in header_cache:
                    results.append(dict(header_cache[mid]))

        results.sort(key=lambda m: m.get("received", ""), reverse=True)
        return results


    def delete_my_messages(self, message_ids):
        """Delete My Messages from eBay in batches of at most 10 IDs."""
        ids = []
        for value in message_ids or []:
            mid = str(value or "").strip()
            if mid and mid not in ids:
                ids.append(mid)
        for i in range(0, len(ids), 10):
            batch = ids[i:i + 10]
            ids_xml = "".join(
                f"<MessageID>{html.escape(mid)}</MessageID>" for mid in batch
            )
            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<DeleteMyMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <MessageIDs>{ids_xml}</MessageIDs>
</DeleteMyMessagesRequest>"""
            self._trading_xml_call("DeleteMyMessages", xml_text)
        return True

    def mark_my_message_read(self, message_id, read=True):
        xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<ReviseMyMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <MessageIDs><MessageID>{html.escape(str(message_id or ""))}</MessageID></MessageIDs>
  <Read>{str(bool(read)).lower()}</Read>
</ReviseMyMessagesRequest>"""
        self._trading_xml_call("ReviseMyMessages", xml_text)
        return True

    def reply_to_partner_message(self, item_number, recipient_id, subject, body, question_type="General", parent_message_id=""):
        """Reply using the eBay messaging route that matches the relationship.

        Ask-Seller-a-Question / pre-sale threads must use AddMemberMessageRTQ
        with the original question MessageID.  AddMemberMessageAAQToPartner is
        only valid once the recipient is an actual order partner.
        """
        item_number = str(item_number or "").strip()
        recipient_id = str(recipient_id or "").strip()
        subject = str(subject or "").strip()
        body = str(body or "").strip()
        parent_message_id = str(parent_message_id or "").strip()
        if not item_number or not recipient_id or not body:
            raise RuntimeError("Item number, recipient, and message body are required.")
        if len(body) > 2000:
            raise RuntimeError(f"eBay limits this reply to 2,000 characters. Current length: {len(body):,}.")

        # If GetMemberMessages gave us the original question ID, this is the
        # correct reply route even when the sender has not yet purchased.
        if parent_message_id:
            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<AddMemberMessageRTQRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <ItemID>{html.escape(item_number)}</ItemID>
  <MemberMessage>
    <Subject>{html.escape(subject or "Re: eBay message")}</Subject>
    <Body>{html.escape(body)}</Body>
    <ParentMessageID>{html.escape(parent_message_id)}</ParentMessageID>
    <RecipientID>{html.escape(recipient_id)}</RecipientID>
  </MemberMessage>
</AddMemberMessageRTQRequest>"""
            self._trading_xml_call("AddMemberMessageRTQ", xml_text)
            return True

        # Post-sale/order-partner fallback.
        xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<AddMemberMessageAAQToPartnerRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <ItemID>{html.escape(item_number)}</ItemID>
  <MemberMessage>
    <Subject>{html.escape(subject or "Re: eBay message")}</Subject>
    <Body>{html.escape(body)}</Body>
    <QuestionType>{html.escape(question_type or "General")}</QuestionType>
    <RecipientID>{html.escape(recipient_id)}</RecipientID>
  </MemberMessage>
</AddMemberMessageAAQToPartnerRequest>"""
        self._trading_xml_call("AddMemberMessageAAQToPartner", xml_text)
        return True

    def end_active_listing(self, item_number, reason="NotAvailable"):
        """End an active fixed-price listing by ItemID."""
        item_number = str(item_number or "").strip()
        if not item_number:
            raise RuntimeError("No eBay Item Number was supplied.")

        reason = str(reason or "NotAvailable").strip() or "NotAvailable"
        xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<EndFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <ItemID>{html.escape(item_number)}</ItemID>
  <EndingReason>{html.escape(reason)}</EndingReason>
</EndFixedPriceItemRequest>"""
        self._trading_xml_call("EndFixedPriceItem", xml_text)
        return True

    def get_order_earnings_summary(self, start_iso, end_iso):
        """
        Retrieve eBay's order-earnings summary for orders in a date range.

        This resource is designed for composite gross sales, expenses, buyer
        refunds, and net order earnings. eBay added it to Finances API in 2026.
        """
        self._check_cancel()
        finance_base = (
            "https://apiz.sandbox.ebay.com"
            if self.s.get("api_environment") == "sandbox"
            else "https://apiz.ebay.com"
        )

        # The current API uses an order-creation date filter. Keep a small set of
        # compatibility attempts because eBay's early documentation/examples for
        # this newly-added resource have used slightly different naming.
        filter_names = ("orderCreationDate", "creationDate")
        last_error = None
        for filter_name in filter_names:
            filter_value = f"{filter_name}:[{start_iso}..{end_iso}]"
            query = parse.urlencode({"filter": filter_value})
            url = finance_base + "/sell/finances/v1/order_earnings_summary?" + query
            try:
                _, _, response = self._call("GET", url, None, None)
                if isinstance(response, dict):
                    return response
            except Exception as exc:
                last_error = exc
                # Try the compatibility spelling only for request-shape errors.
                msg = str(exc)
                if "400" not in msg and "INVALID" not in msg.upper():
                    raise

        if last_error:
            raise last_error
        raise RuntimeError("eBay did not return an order earnings summary.")

    def get_finance_transactions(self, start_iso, end_iso):
        """Retrieve seller monetary transactions for a report date range."""
        self._check_cancel()
        transactions = []
        offset = 0
        limit = 1000
        filter_value = f"transactionDate:[{start_iso}..{end_iso}]"
        while True:
            query = parse.urlencode({
                "filter": filter_value,
                "limit": str(limit),
                "offset": str(offset),
            })
            finance_base = (
                "https://apiz.sandbox.ebay.com"
                if self.s.get("api_environment") == "sandbox"
                else "https://apiz.ebay.com"
            )
            url = finance_base + "/sell/finances/v1/transaction?" + query
            _, _, response = self._call("GET", url, None, None)
            if not isinstance(response, dict):
                break
            batch = response.get("transactions", []) or []
            transactions.extend([x for x in batch if isinstance(x, dict)])
            total = int(response.get("total", len(transactions)) or len(transactions))
            offset += len(batch)
            if not batch or offset >= total:
                break
        return transactions

    def get_orders_between(self, start_iso, end_iso, field_groups=None):
        """Return seller orders created inside one eBay creation-date range."""
        self._check_cancel()
        filter_value = f"creationdate:[{start_iso}..{end_iso}]"
        offset = 0
        orders = []
        while True:
            params = {
                "filter": filter_value,
                "limit": "50",
                "offset": str(offset),
            }
            if field_groups:
                params["fieldGroups"] = str(field_groups)
            query = parse.urlencode(params)
            url = self.api_base + "/sell/fulfillment/v1/order?" + query
            _, _, response = self._call("GET", url, None, None)
            if not isinstance(response, dict):
                break
            batch = response.get("orders", []) or []
            orders.extend([o for o in batch if isinstance(o, dict)])
            total = int(response.get("total", len(orders)) or len(orders))
            offset += len(batch)
            if not batch or offset >= total:
                break
        return orders

    def get_order_by_id(self, order_id):
        """Retrieve one Fulfillment order directly by order ID."""
        self._check_cancel()
        order_id = str(order_id or "").strip()
        if not order_id:
            raise RuntimeError("No eBay order ID was supplied.")
        url = self.api_base + "/sell/fulfillment/v1/order/" + parse.quote(order_id, safe="")
        _, _, response = self._call("GET", url, None, None)
        return response if isinstance(response, dict) else {}

    def get_trading_orders_between(self, start_iso, end_iso):
        """
        Retrieve seller orders through Trading API GetOrders.

        With compatibility level 1477, Order.Total includes sales tax, which makes
        this a useful compatibility source when newer Finances order-earnings
        resources are not available to a seller/keyset.
        """
        page = 1
        results = []
        while True:
            xml_text = f"""<?xml version="1.0" encoding="utf-8"?>
<GetOrdersRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <DetailLevel>ReturnAll</DetailLevel>
  <CreateTimeFrom>{html.escape(str(start_iso))}</CreateTimeFrom>
  <CreateTimeTo>{html.escape(str(end_iso))}</CreateTimeTo>
  <OrderRole>Seller</OrderRole>
  <OrderStatus>All</OrderStatus>
  <Pagination><EntriesPerPage>100</EntriesPerPage><PageNumber>{page}</PageNumber></Pagination>
</GetOrdersRequest>"""
            root, ns = self._trading_xml_call("GetOrders", xml_text, compatibility="1477")
            orders = root.findall("e:OrderArray/e:Order", ns)
            for order in orders:
                def tx(path):
                    return (order.findtext(path, default="", namespaces=ns) or "").strip()

                total = 0.0
                subtotal = 0.0
                shipping = 0.0
                tax = 0.0
                units = 0
                try:
                    total = float(tx("e:Total") or tx("e:AmountPaid") or 0)
                except Exception:
                    pass
                try:
                    subtotal = float(tx("e:Subtotal") or 0)
                except Exception:
                    pass
                try:
                    shipping = float(tx("e:ShippingServiceSelected/e:ShippingServiceCost") or 0)
                except Exception:
                    pass

                for tr in order.findall("e:TransactionArray/e:Transaction", ns):
                    try:
                        units += int(
                            tr.findtext("e:QuantityPurchased", default="1", namespaces=ns) or 1
                        )
                    except Exception:
                        units += 1
                    tax_text = (
                        tr.findtext(
                            "e:eBayCollectAndRemitTaxes/e:TotalTaxAmount",
                            default="",
                            namespaces=ns,
                        )
                        or tr.findtext(
                            "e:Taxes/e:TotalTaxAmount",
                            default="",
                            namespaces=ns,
                        )
                    )
                    try:
                        tax += float(tax_text or 0)
                    except Exception:
                        pass

                results.append({
                    "order_id": tx("e:OrderID"),
                    "created": tx("e:CreatedTime"),
                    "status": tx("e:OrderStatus"),
                    "total": total,
                    "subtotal": subtotal,
                    "shipping": shipping,
                    "tax": tax,
                    "units": units,
                })

            pages_text = root.findtext(
                "e:PaginationResult/e:TotalNumberOfPages",
                default="1",
                namespaces=ns,
            ) or "1"
            try:
                pages = int(pages_text)
            except Exception:
                pages = 1
            if page >= pages:
                break
            page += 1
        return results

    def get_recent_orders(self, days=90):
        """Return recent seller orders for local inventory status synchronization."""
        self._check_cancel()
        days = max(1, min(int(days or 90), 90))
        end_dt = datetime.now(timezone.utc)
        start_dt = end_dt - timedelta(days=days)
        start_iso = start_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        end_iso = end_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        return self.get_orders_between(start_iso, end_iso)

    def get_offer(self, offer_id):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/offer/" + parse.quote(str(offer_id), safe="")
        _, _, response = self._call("GET", url, None, None)
        return response

    def get_offers_by_sku(self, sku):
        self._check_cancel()
        url = (
            self.api_base
            + "/sell/inventory/v1/offer?sku="
            + parse.quote(str(sku), safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        return response.get("offers", []) or []

    def get_inventory_item(self, sku):
        self._check_cancel()
        url = (
            self.api_base
            + "/sell/inventory/v1/inventory_item/"
            + parse.quote(str(sku), safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        return response

    def get_item_condition_policies(self, category_id):
        """Retrieve and normalize eBay category-specific item conditions."""
        self._check_cancel()
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        category_id = str(category_id or "").strip()
        if not category_id:
            raise RuntimeError("Category ID is required to retrieve condition policies.")

        filter_value = f"categoryIds:{{{category_id}}}"
        url = (
            self.api_base
            + "/sell/metadata/v1/marketplace/"
            + parse.quote(marketplace, safe="")
            + "/get_item_condition_policies?filter="
            + parse.quote(filter_value, safe="")
        )

        self.log(f"Loading valid eBay conditions for category {category_id}...")
        _, _, response = self._call("GET", url, None, None)

        if not isinstance(response, dict):
            self.log(
                f"Condition metadata returned {type(response).__name__}, not an object."
            )
            return {"required": False, "conditions": []}

        raw_policies = response.get("itemConditionPolicies", []) or []
        if isinstance(raw_policies, dict):
            raw_policies = [raw_policies]
        elif isinstance(raw_policies, str):
            raw_policies = []
        elif not isinstance(raw_policies, list):
            try:
                raw_policies = list(raw_policies)
            except Exception:
                raw_policies = []

        policies = [p for p in raw_policies if isinstance(p, dict)]

        policy = next(
            (
                p for p in policies
                if str(p.get("categoryId", "") or "") == category_id
            ),
            policies[0] if policies else None,
        )
        if not isinstance(policy, dict):
            return {"required": False, "conditions": []}

        raw_conditions = policy.get("itemConditions", []) or []
        if isinstance(raw_conditions, dict):
            raw_conditions = [raw_conditions]
        elif isinstance(raw_conditions, (str, int, float)):
            raw_conditions = [raw_conditions]
        elif not isinstance(raw_conditions, list):
            try:
                raw_conditions = list(raw_conditions)
            except Exception:
                raw_conditions = []

        enum_to_id = {
            "NEW": "1000",
            "NEW_OTHER": "1500",
            "NEW_WITH_DEFECTS": "1750",
            "CERTIFIED_REFURBISHED": "2000",
            "EXCELLENT_REFURBISHED": "2010",
            "VERY_GOOD_REFURBISHED": "2020",
            "GOOD_REFURBISHED": "2030",
            "SELLER_REFURBISHED": "2500",
            "USED_EXCELLENT": "3000",
            "USED_VERY_GOOD": "4000",
            "USED_GOOD": "5000",
            "USED_ACCEPTABLE": "6000",
            "FOR_PARTS_OR_NOT_WORKING": "7000",
        }

        normalized = []
        for entry in raw_conditions:
            cid = ""
            desc = ""
            help_text = ""

            if isinstance(entry, dict):
                cid = str(
                    entry.get("conditionId")
                    or entry.get("id")
                    or entry.get("condition")
                    or ""
                ).strip()
                desc = str(
                    entry.get("conditionDescription")
                    or entry.get("description")
                    or entry.get("displayName")
                    or ""
                ).strip()
                help_text = str(
                    entry.get("conditionHelpText")
                    or entry.get("help")
                    or ""
                ).strip()

            elif isinstance(entry, (str, int, float)):
                raw = str(entry).strip()
                if raw.isdigit():
                    cid = raw
                else:
                    cid = enum_to_id.get(raw.upper(), "")
                    desc = raw

            if cid:
                normalized.append({
                    "id": cid,
                    "description": desc,
                    "help": help_text,
                })
            else:
                self.log(
                    "Skipped unrecognized eBay condition metadata entry: "
                    f"{type(entry).__name__} {str(entry)[:100]}"
                )

        self.log(
            f"Condition metadata normalized: {len(normalized)} value(s) "
            f"for category {category_id}."
        )

        return {
            "required": bool(policy.get("itemConditionRequired", False)),
            "conditions": normalized,
        }

    def get_inventory_items(self, limit=100):
        """Retrieve up to limit Inventory API records for this seller."""
        self._check_cancel()
        limit = max(1, min(100, int(limit or 100)))
        url = self.api_base + f"/sell/inventory/v1/inventory_item?limit={limit}&offset=0"
        _, _, response = self._call("GET", url, None, None)
        return response.get("inventoryItems", []) or []

    def get_item_aspects_for_category(self, category_id):
        """Return Taxonomy aspect metadata for one eBay leaf category."""
        self._check_cancel()
        category_id = str(category_id or "").strip()
        if not category_id:
            raise RuntimeError("Category ID is required to retrieve item specifics.")

        tree_id = self.get_default_category_tree_id()
        self.log(
            f"Loading eBay category aspects for category {category_id} "
            f"(tree {tree_id})..."
        )

        # eBay documentation/examples have used both v1_beta and v1 for this
        # Taxonomy method. Try the current beta route first, then the stable route
        # before concluding the category/resource is bad.
        urls = [
            (
                self.api_base
                + "/commerce/taxonomy/v1_beta/category_tree/"
                + parse.quote(tree_id, safe="")
                + "/get_item_aspects_for_category?category_id="
                + parse.quote(category_id, safe="")
            ),
            (
                self.api_base
                + "/commerce/taxonomy/v1/category_tree/"
                + parse.quote(tree_id, safe="")
                + "/get_item_aspects_for_category?category_id="
                + parse.quote(category_id, safe="")
            ),
        ]

        errors = []
        for url in urls:
            try:
                _, _, response = self._call("GET", url, None, None)
                if not isinstance(response, dict):
                    raise RuntimeError(
                        "eBay Taxonomy returned an unexpected response while "
                        "checking item specifics."
                    )
                aspects = response.get("aspects", []) or []
                self.log(
                    f"Category {category_id}: eBay returned {len(aspects)} aspect(s)."
                )
                return aspects
            except Exception as exc:
                msg = str(exc)
                errors.append(msg)
                if not (
                    "404" in msg
                    or "2002" in msg
                    or "Resource not found" in msg
                    or "Resource not resolved" in msg
                ):
                    raise

        raise RuntimeError(
            f"eBay could not load item-specific metadata for category {category_id}.\n\n"
            "The category may be stale, non-leaf, or not part of the current "
            "marketplace category tree. Re-run Suggest eBay Category and choose "
            "the most specific leaf category before listing."
        )


    def get_default_category_tree_id(self):
        marketplace = self.s.get("marketplace_id", "EBAY_US")
        url = (
            self.api_base
            + "/commerce/taxonomy/v1/get_default_category_tree_id?marketplace_id="
            + parse.quote(marketplace, safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        tree_id = response.get("categoryTreeId")
        if not tree_id:
            raise RuntimeError("eBay did not return a default category tree ID.")
        return str(tree_id)

    def suggest_category(self, query):
        self._check_cancel()
        query = (query or "").strip()
        if not query:
            raise RuntimeError("There is not enough item information to request an eBay category.")

        self.log("Asking eBay for category suggestions...")
        tree_id = self.get_default_category_tree_id()
        url = (
            self.api_base
            + "/commerce/taxonomy/v1/category_tree/"
            + parse.quote(tree_id, safe="")
            + "/get_category_suggestions?q="
            + parse.quote(query, safe="")
        )
        _, _, response = self._call("GET", url, None, None)
        suggestions = response.get("categorySuggestions", []) or []
        if not suggestions:
            raise RuntimeError("eBay returned no category suggestions for this item.")

        best = suggestions[0]
        category = best.get("category", {}) or {}
        category_id = str(category.get("categoryId", "") or "")
        category_name = str(category.get("categoryName", "") or "")
        ancestors = best.get("categoryTreeNodeAncestors", []) or []
        breadcrumb = " > ".join(
            [str(a.get("categoryName", "")) for a in ancestors if a.get("categoryName")]
            + ([category_name] if category_name else [])
        )
        if not category_id:
            raise RuntimeError("eBay's top category suggestion did not include a category ID.")
        return {
            "category_id": category_id,
            "category_name": category_name,
            "breadcrumb": breadcrumb or category_name,
            "suggestions": suggestions[:5],
        }

    def upload_image(self, path):
        self._check_cancel()
        path = Path(path)
        data = path.read_bytes()
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        body, multipart_type = encode_multipart("image", path.name, data, ctype)
        url = self.media_api_base + "/commerce/media/v1_beta/image/create_image_from_file"
        self.log(f"Uploading photo to eBay Picture Services: {path.name}")
        self.log(
            "Media API host: "
            + ("Sandbox apim.sandbox.ebay.com" if self.s.get("api_environment") == "sandbox"
               else "Production apim.ebay.com")
        )
        try:
            status, headers, response = self._call("POST", url, body, multipart_type)
        except RuntimeError as exc:
            if "eBay API error 404:" in str(exc):
                raise RuntimeError(
                    "eBay Media API returned 404 while uploading a photo.\n\n"
                    "V4.21.0 uses eBay's dedicated Media API host (apim.ebay.com). "
                    "If this still occurs, verify the OAuth token includes sell.inventory "
                    "and that Production/Sandbox credentials are not mixed."
                ) from exc
            raise
        image_url = response.get("imageUrl")
        if not image_url:
            # Some responses may require retrieving the created image resource.
            location = headers.get("Location") or headers.get("location")
            if location:
                image_id = location.rstrip("/").split("/")[-1]
                _, _, details = self._call(
                    "GET",
                    self.media_api_base + f"/commerce/media/v1_beta/image/{parse.quote(image_id)}",
                    None,
                    None,
                )
                image_url = details.get("imageUrl")
        if not image_url:
            raise RuntimeError(f"eBay accepted {path.name}, but no image URL was returned.")
        return image_url

    def create_inventory_item(self, sku, listing):
        self._check_cancel()
        url = self.api_base + "/sell/inventory/v1/inventory_item/" + parse.quote(sku, safe="")
        aspects = parse_specifics(listing["specifics"])

        # Never send a combined "BrandMPN" item specific. eBay models Brand and
        # MPN as two separate values/fields.
        for key in list(aspects.keys()):
            if str(key).strip().lower().replace(" ", "") == "brandmpn":
                raise RuntimeError(
                    "Remove the combined Extra Item Specific 'BrandMPN'.\n\n"
                    "Enter the manufacturer in Brand / Manufacturer and the part "
                    "number in MPN / Part Number as separate fields."
                )

        # If Brand/MPN were entered only in Extra Item Specifics, copy them into
        # the product identifier fields too. This keeps both representations in sync.
        def _first_aspect_value(name):
            for k, values in aspects.items():
                if str(k).strip().lower() == name.lower():
                    if isinstance(values, list) and values:
                        return str(values[0]).strip()
                    if values:
                        return str(values).strip()
            return ""

        if not listing.get("brand"):
            listing["brand"] = _first_aspect_value("Brand")
        if not listing.get("mpn"):
            listing["mpn"] = _first_aspect_value("MPN")

        # Common specifics get included automatically unless already supplied.
        if listing["brand"] and "Brand" not in aspects:
            aspects["Brand"] = [listing["brand"]]
        if listing["mpn"] and "MPN" not in aspects:
            aspects["MPN"] = [listing["mpn"]]
        if listing["model"] and "Model" not in aspects:
            aspects["Model"] = [listing["model"]]
        if listing["country"] and "Country of Origin" not in aspects:
            aspects["Country of Origin"] = [listing["country"]]

        product = {
            "title": listing["title"][:80],
            "description": listing["description"],
            "aspects": aspects,
            "imageUrls": listing["image_urls"],
        }
        if listing["brand"]:
            product["brand"] = listing["brand"]
        if listing["mpn"]:
            product["mpn"] = listing["mpn"]

        payload = {
            "availability": {
                "shipToLocationAvailability": {
                    "quantity": int(listing["quantity"])
                }
            },
            "condition": CONDITION_MAP[listing["condition"]],
            "product": product,
        }

        package = {}
        if listing.get("package_dimensions"):
            dims = listing["package_dimensions"]
            package["dimensions"] = {
                "length": float(dims["length"]),
                "width": float(dims["width"]),
                "height": float(dims["height"]),
                "unit": "INCH",
            }
        if listing.get("package_weight_oz") is not None:
            package["weight"] = {
                "value": float(listing["package_weight_oz"]),
                "unit": "OUNCE",
            }
        if package:
            package["packageType"] = listing.get("package_type") or "PACKAGE_THICK_ENVELOPE"
            payload["packageWeightAndSize"] = package

        # eBay ignores conditionDescription for some "new" conditions.
        if listing["condition_notes"].strip():
            payload["conditionDescription"] = listing["condition_notes"].strip()

        self.log("Creating/updating eBay inventory item...")
        self._call(
            "PUT",
            url,
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )

    def _listing_policies_payload(self, listing):
        policies = {
            "paymentPolicyId": listing["payment_policy_id"].strip(),
            "returnPolicyId": listing["return_policy_id"].strip(),
            "fulfillmentPolicyId": listing["fulfillment_policy_id"].strip(),
        }
        if listing.get("best_offer_enabled"):
            terms = {"bestOfferEnabled": True}
            currency = self.s.get("currency", "USD")
            if listing.get("auto_accept_price") is not None:
                terms["autoAcceptPrice"] = {
                    "value": f'{float(listing["auto_accept_price"]):.2f}',
                    "currency": currency,
                }
            if listing.get("auto_decline_price") is not None:
                terms["autoDeclinePrice"] = {
                    "value": f'{float(listing["auto_decline_price"]):.2f}',
                    "currency": currency,
                }
            policies["bestOfferTerms"] = terms
        else:
            policies["bestOfferTerms"] = {"bestOfferEnabled": False}
        return policies

    def _validate_offer_requirements(self, listing):
        s = self.s
        required = {
            "Category ID": listing.get("category_id"),
            "Merchant Location Key": s.get("merchant_location_key"),
            "Payment Policy": listing.get("payment_policy_id"),
            "Return Policy": listing.get("return_policy_id"),
            "Fulfillment / Shipping Policy": listing.get("fulfillment_policy_id"),
        }
        missing = [k for k, v in required.items() if not str(v or "").strip()]
        if missing:
            raise RuntimeError(
                "Missing required eBay setup value(s):\n- " + "\n- ".join(missing)
            )

    def create_offer(self, sku, listing):
        self._check_cancel()
        self._validate_offer_requirements(listing)
        s = self.s
        payload = {
            "sku": sku,
            "marketplaceId": s.get("marketplace_id", "EBAY_US"),
            "format": "FIXED_PRICE",
            "categoryId": listing["category_id"].strip(),
            "merchantLocationKey": s["merchant_location_key"].strip(),
            "availableQuantity": int(listing["quantity"]),
            "listingDescription": listing["description"],
            "listingDuration": "GTC",
            "pricingSummary": {
                "price": {
                    "value": f'{float(listing["price"]):.2f}',
                    "currency": s.get("currency", "USD"),
                }
            },
            "listingPolicies": self._listing_policies_payload(listing),
        }
        self.log("Creating UNPUBLISHED Buy It Now eBay offer...")
        _, _, response = self._call(
            "POST",
            self.api_base + "/sell/inventory/v1/offer",
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )
        offer_id = response.get("offerId")
        if not offer_id:
            raise RuntimeError(
                "The Inventory item was created, but eBay did not return an offerId."
            )
        return offer_id

    def update_offer(self, offer_id, listing, original_offer):
        """Completely replace an existing offer while preserving fetched settings."""
        self._check_cancel()

        if not isinstance(listing, dict):
            raise RuntimeError(
                "Internal offer-update error: listing data must be a dictionary, "
                f"but received {type(listing).__name__}. "
                "The offer was not changed."
            )
        if original_offer is not None and not isinstance(original_offer, dict):
            raise RuntimeError(
                "Internal offer-update error: original eBay offer must be a dictionary, "
                f"but received {type(original_offer).__name__}. "
                "The offer was not changed."
            )

        self._validate_offer_requirements(listing)
        s = self.s

        # eBay recommends starting with the object returned by getOffer because
        # updateOffer is a complete replacement. Remove response-only identifiers.
        payload = dict(original_offer or {})
        for key in ("offerId", "status", "listing", "sku"):
            payload.pop(key, None)

        payload["marketplaceId"] = payload.get(
            "marketplaceId", s.get("marketplace_id", "EBAY_US")
        )
        payload["format"] = "FIXED_PRICE"
        payload["categoryId"] = listing["category_id"].strip()
        payload["merchantLocationKey"] = s["merchant_location_key"].strip()
        payload["availableQuantity"] = int(listing["quantity"])
        payload["listingDescription"] = listing["description"]
        payload["listingDuration"] = payload.get("listingDuration") or "GTC"
        payload["pricingSummary"] = {
            "price": {
                "value": f'{float(listing["price"]):.2f}',
                "currency": s.get("currency", "USD"),
            }
        }
        payload["listingPolicies"] = self._listing_policies_payload(listing)

        self.log(f"Updating eBay offer {offer_id}...")
        self._call(
            "PUT",
            self.api_base + "/sell/inventory/v1/offer/" + parse.quote(str(offer_id), safe=""),
            json.dumps(payload).encode("utf-8"),
            "application/json",
        )

# Explicitly export underscore-prefixed helpers too; the GUI controller relies on
# several of them. Keeping this list dynamic avoids maintaining a second symbol list.
__all__ = [name for name in globals() if not name.startswith("__")]
