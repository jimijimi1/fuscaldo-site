Trade Components eBay Listing Tool V4.23.9

Fixes the multi-item batch workflow:
- Batch import now retains photos without prematurely running local grouping.
- AI GROUP BATCH actually groups the retained batch and opens the AI results.
- REVIEW GROUPS reopens the same batch for subsequent listings.
- Reliable thumbnail selection in Batch Review.
- Visible selected-photo highlighting.
- Quality sort per group.
- Use Group + Sort/Pick Best shortcut.


OVER-THE-AIR UPDATES
--------------------
Use CHECK FOR UPDATES in the app header. The app reads:
https://fuscaldo.org/ebay-tool/version.json
and downloads the ZIP named by the 'file' value.
Settings and inventory are stored separately and preserved.


V4.23.9 OPERATIONS INTEGRATION
------------------------------
- New Dashboard for daily work counts and one-click Sync + Scan.
- New Listings area with sortable/searchable current eBay Active Listings.
- Existing Inventory API offer editor moved under Listings > Edit Existing / Offers.
- New Revamp Queue with configurable listing-age threshold and specific reasons.
- MARK REVIEWED resets age-based revamp reminders without changing the eBay listing.
- New Needs Attention center with OPEN / IGNORED / RESOLVED issue lifecycle.
- Attention scan checks listings, inventory, quantities, locations, shipping age,
  duplicate item numbers, old listings, photo counts, and SKU gaps.
- Normal 15-minute eBay sync now refreshes Listings, Revamp Queue, Attention, and Dashboard.


V4.23.9 SALES + ATTENTION AUTOMATION
------------------------------------
- Sales tab with monthly sales, order count, unit count, month-over-month and year-over-year comparisons.
- 6/12/24 month charts and historical eBay order refresh.
- Right-click issue menus: Open/Fix, Open eBay, Ignore, Always Ignore Type, Resolve, Restore.
- Persistent issue suppression rules with a Rules manager.
- Auto Fix Safe button runs deterministic/reversible synchronization only.
- Sales orders are cached locally and refreshed during normal eBay synchronization.

V4.23.9 REMEMBERED INVENTORY MATCHING
------------------------------------
Active listings with a missing/no-location inventory match are compared against
remembered inventory rows using title similarity, token overlap, quantity, and
SKU/custom-label hints. High-confidence unique matches are shown as a reviewable
"Possible remembered inventory match" rather than a generic no-location error.
OPEN / FIX lets the user confirm the match, preserving the location/stock and
updating the eBay item number. Old item numbers are retained in COMMENT.

V4.23.9 ISSUE NAVIGATION + END LISTINGS
---------------------------------------
- Needs Attention OPEN / FIX now jumps to the exact local inventory row and automatically
  switches to MASTER LIST, PENDING LOCATION, PENDING SHIPPING, or SOLD as appropriate.
- Previous Inventory search text is cleared so the target row cannot remain hidden.
- Listings and Revamp Queue now support END LISTING with confirmation.
- Active Listings and Revamp Queue have right-click menus with Open on eBay, Jump to
  Inventory Item, and End eBay Listing.
- Needs Attention right-click also gains Jump to Inventory Item and End eBay Listing
  when the issue points to a currently active listing.
- Ending a listing keeps local inventory intact; a local LISTED row becomes MASTER
  (or PENDING LOCATION if it has no location). It is never marked SOLD automatically.

V4.23.9 WORKFLOW / SALES REPORT UPDATE
-------------------------------------
- Fixed 24-month sales refresh failure by respecting eBay Fulfillment API's strict
  two-year creation-date limit.
- Added sell.finances OAuth scope for detailed gross/net/fees monthly reporting.
- Sales can generate a polished printable monthly HTML report with gross sales,
  net eBay proceeds, selling fees, shipping-label costs, refunds, credits, orders,
  units, and a fee breakdown.
- Top tabs are now Dashboard / Listing Editor / Listings / Inventory / Sales /
  Needs Attention / Settings. Revamp Queue lives under Listings.
- Revamp observations and Pending Location items no longer clutter Needs Attention.
- Attention table keeps the user's sort after resolving/ignoring items.
- "Always Ignore This Issue Type" reports how many current issues it ignored.
- False "0 photos" warnings are suppressed when eBay did not actually return photo data.
- Listing button says CREATE DRAFT before an offer exists and SAVE DRAFT afterward.
- Added right-click quick-action menus to Inventory, Sales, and Existing Offers;
  Listings, Revamp and Needs Attention already have context menus.

V4.23.9 LOADING FEEDBACK + REPORT DATE FIX
------------------------------------------
- Fixed Monthly Sales Report YYYY-MM validation; valid inputs such as 2026-08 now work.
- Added a reusable modal loading/progress box for long-running operations.
- Sales refresh, monthly report generation, active-listing refresh, Needs Attention
  Sync + Scan, ending a listing, and safe auto-fix work now show visible progress
  instead of appearing stalled.
- Long cancellable operations expose STOP / CANCEL in the loading box.

V4.23.9 STARTUP SYNC + LOADING WINDOW RELIABILITY
-------------------------------------------------
- Fixed long-running loading boxes that could remain on screen after completion.
- Every patched worker now closes its loading window from a finally block, so success,
  errors, and cancellations all clean up the modal reliably.
- STOP / CANCEL immediately releases the loading window while signalling the worker
  to stop; a cancelled operation no longer leaves the UI trapped.
- Starting a new long operation clears stale cancellation state from an earlier cancel.
- Added automatic eBay reconciliation shortly after startup whenever an OAuth access
  token or refresh token is configured.
- Startup sync updates active listings, recent orders, inventory, sales, Needs Attention,
  and dashboard data; normal background reconciliation continues every 15 minutes.
- Startup sync is skipped quietly when eBay OAuth has not been configured.
- Sales history refresh now also uses the standard visible loading box.

V4.23.9 FINANCES API FIX
------------------------
- Fixed Monthly Sales Report 404 errors caused by sending Finances API calls to
  api.ebay.com. eBay's Finances API uses the dedicated apiz.ebay.com gateway
  (apiz.sandbox.ebay.com in Sandbox).
- Detailed monthly gross/net/fee reports now call the correct transaction endpoint.
- Added a clearer diagnostic if eBay still returns a 404.

V4.23.9 SELLER HUB-STYLE MONTHLY REPORTING
------------------------------------------
- Reworked the monthly printable report to follow Seller Hub Performance reporting
  instead of using raw Finances transaction-date cash movement as the headline basis.
- Uses the 2026 Finances order_earnings_summary resource for gross seller amount,
  selling expenses, buyer refunds, and net order earnings.
- Requests Fulfillment TAX_BREAKDOWN data to calculate taxes/fees collected by eBay.
- Headline report now mirrors Seller Hub terminology:
  Total Sales (includes taxes) / Taxes & Fees Collected by eBay /
  Selling Costs (includes shipping) / Net Sales / Quantity Sold / Average Sales Price.
- Raw Finances transaction fee categories remain only as supplemental detail because
  individual charges/credits can post in a different month than Seller Hub Performance.

V4.23.9 AI BATCH REVIEW FIX
---------------------------
- Fixed Batch Photo Review windows that could appear blank after AI Group.
- The review window now paints the group list immediately, then renders thumbnails
  progressively instead of decoding an entire large group on the Tk UI thread.
- Large AI-created groups remain responsive and display loading progress while previews render.
- AI Group now uses the standard visible/cancellable loading box and always closes it.
- Added validation so a completed AI request cannot silently open an empty review window.
- Group metadata is aligned defensively with the actual path groups.
- Suspiciously large AI groups are logged for manual review rather than freezing the UI.

V4.23.9 AI SORT + BATCH WORKFLOW
---------------------------------
- Removed the hard AI Sort photo-count limit. AI Sort can now process all selected
  photos rather than stopping at 125.
- Large sorts may cost more and take longer, so the existing AI cost/progress feedback
  remains important.
- Batch Review now remembers which groups have already been used.
- Used groups are labeled with a check mark in the group list.
- After using a group, Batch Review stays open and automatically advances to the next
  unused group instead of making the remaining groups feel like they disappeared.

V4.23.9 ANALYZE WORKFLOW
-------------------------
- Removed the extra approval/confirmation step from Analyze Selected.
- Analyze now begins immediately when invoked and applies the returned item analysis
  directly to the listing fields, while retaining normal progress/cancel feedback.
- Publish confirmation remains unchanged.

V4.23.9 AI SORT LIMIT + POST-PUBLISH RESET
-------------------------------------------
- Removed the actual remaining 125-photo guard inside AI Sort + Pick Best.
- AI Sort can now process all photos supplied to it; large runs may take longer/cost more.
- Listing Editor automatically resets after a listing is successfully published live.
- Creating or saving an unpublished draft does NOT clear the Listing Editor.
- Both PUBLISH and CREATE + PUBLISH success paths trigger the post-publish reset.

V4.23.9 PENDING SHIPPING WORKFLOW
----------------------------------
- Dashboard Pending Shipping now opens Inventory directly on PENDING SHIPPING.
- Dashboard Pending Location and Sold cards also jump directly to their matching tabs.
- Added SHIP BY column to Pending Shipping.
- Order reconciliation stores and refreshes eBay's available ship/handle-by deadline
  whenever that deadline is present in the Fulfillment order payload.

V4.23.9 MESSAGES + QUEUE CLEANUP
--------------------------------
- Added top-level eBay Messages inbox: refresh, search, unread/read/replied state,
  preview, reply, open eBay item, jump to inventory, mark read/unread, right-click actions.
- Uses GetMyMessages and AddMemberMessageAAQToPartner through Trading API.
- Inventory double-click now validates row/cell region so rapid header sorting won't open a selected item.
- Pending Shipping now defaults to earliest SHIP BY first, then item name.
- Any user-selected sort is reapplied after inventory refresh.
- Inventory/order startup reconciliation looks back 180 days to better clear stale pending-shipping records.
- Messages quietly refresh after startup when OAuth is available.

V4.23.9 STARTUP FIX
-------------------
- Fixed the V4.23.0 startup crash caused by the new Messages notebook page being
  referenced before its ttk.Frame had been created.
- No feature changes; this is a launch-repair release for V4.23.0.

V4.23.9 MESSAGES + END-LISTING ISSUE CLEANUP
--------------------------------------------
- Fixed GetMyMessages error 20106. The app now retrieves recent message headers by
  date first, then requests full message bodies by explicit MessageIDs in batches of 10.
- Ending an eBay listing now automatically resolves Needs Attention issues tied to
  that eBay Item Number.
- Needs Attention refreshes immediately after a listing is successfully ended.

V4.23.9 CODEBASE CLEANUP
------------------------
- Split the 13k-line monolithic Python file into a GUI/controller module and a
  reusable core module.
- Core module now owns shared utilities, photo manager, batch review, AI grouping/
  analysis, and EbayClient.
- Main ebay_listing_tool.py now focuses on ListingTool application workflows/UI.
- End-listing API code now reuses the common Trading API request/auth/error handler
  instead of maintaining a second duplicate implementation.
- Added CODE_STRUCTURE.txt for future maintenance.
- This is a conservative refactor: settings, inventory DB, updater, and user-facing
  workflows are intentionally unchanged.

V4.23.9 UPDATER COMPATIBILITY FIX
---------------------------------
- Fixed Vunknown verification caused by the V4.23.3 module split.
- ebay_listing_tool.py now keeps a literal APP_VERSION for compatibility with
  older installed updaters.
- The updated verifier can read APP_VERSION from either ebay_listing_tool.py or
  trade_components_core.py.
- No inventory/settings/user-data changes.

V4.23.9 MESSAGE DISPLAY + REPORT AUTHORIZATION
----------------------------------------------
- eBay message bodies are now displayed as readable plain text instead of raw
  HTML/CSS email templates.
- Message retrieval prefers eBay's plain-text Content field and sanitizes Text
  when eBay returns an HTML-formatted body.
- The OAuth request now includes sell.finances in addition to
  sell.finances and sell.fulfillment for the newer Order Earnings report resource.
- Report permission errors now explain the exact one-time reauthorization steps.

V4.23.9 OAUTH SCOPE CORRECTION
------------------------------
- Removed the sell.finances.readonly scope from the OAuth request.
- eBay rejected that scope with invalid_scope.
- The app now requests the five scopes actually needed:
  base api_scope, sell.inventory, sell.account, sell.fulfillment, sell.finances.
- No user data or inventory changes.

V4.23.9 MESSAGE BODY PARSER
---------------------------
- Fixed eBay message templates that still displayed CSS after the previous cleanup.
- HTML entities are decoded before parsing, which handles eBay payloads containing
  escaped <style>/<head> markup.
- Message rendering now uses a stdlib HTML parser that ignores style/script/head/template
  content and keeps only visible text.
- Added malformed-template CSS cleanup and a right-click "Copy Raw Message (Diagnostics)"
  action for future edge cases.

V4.23.9 REPORT FALLBACK + PENDING SHIPPING RECONCILIATION
----------------------------------------------------------
- Monthly report no longer fails outright when eBay returns 403/1100 for the newer
  Finances order_earnings_summary resource.
- Added compatibility reporting using Trading GetOrders (tax-inclusive totals at
  compatibility 1477) plus regular Finances transactions for selling costs.
- Report states which data path was used.
- Added direct Fulfillment order lookup for stale Pending Shipping rows.
- Fulfilled stale rows move to Sold; canceled orders leave Pending Shipping and
  restore sold quantity; orders no longer resolvable by eBay are archived out of
  the shipping queue while preserving the audit row.
- Canceled orders are no longer created as new Pending Shipping rows.

V4.23.9 CONVERSATION MESSAGES + SCROLLING
------------------------------------------
- Messages now groups entries by buyer + item into conversations instead of showing
  each eBay message as an isolated row.
- Selecting a conversation opens a chat-style back-and-forth panel with readable bubbles.
- The parser extracts the newest buyer message and quoted "Your previous message" reply
  from eBay's repeated email-style templates, with duplicate text suppressed.
- Needs Attention columns no longer stretch/shrink to hide overflow. Its bottom
  horizontal scrollbar now moves through the full ISSUE/ITEM/ACTION text.
- Shift+mouse-wheel scrolls horizontally in Needs Attention, Messages, and Inventory.
- Inventory's bottom horizontal scrollbar now remains useful for wide rows as well.
