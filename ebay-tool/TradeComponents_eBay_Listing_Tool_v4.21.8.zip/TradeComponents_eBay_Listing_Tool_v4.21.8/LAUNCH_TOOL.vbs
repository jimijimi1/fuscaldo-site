Option Explicit
Dim fso, shell, folder, bat
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
bat = Chr(34) & folder & "\START_TOOL.bat" & Chr(34)
shell.Run bat, 0, False
