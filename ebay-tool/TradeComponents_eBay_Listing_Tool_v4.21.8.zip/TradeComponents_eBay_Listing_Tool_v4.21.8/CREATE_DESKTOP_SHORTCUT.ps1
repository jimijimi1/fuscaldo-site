$ErrorActionPreference = "Stop"
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Trade Components eBay Listing Tool.lnk"
$launcher = Join-Path $appDir "LAUNCH_TOOL.vbs"
$icon = Join-Path $appDir "TradeComponents_icon.ico"

$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($shortcutPath)
$s.TargetPath = "$env:WINDIR\System32\wscript.exe"
$s.Arguments = "`"$launcher`""
$s.WorkingDirectory = $appDir
$s.IconLocation = "$icon,0"
$s.Description = "Trade Components eBay Listing Tool"
$s.WindowStyle = 1
$s.Save()

Write-Host ""
Write-Host "Desktop shortcut created:"
Write-Host $shortcutPath
